﻿using DigitalAudit.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Services
{
    public interface IConfigService
    {
        T GetAppConfig<T>(string key);
    }

    public class ConfigService : IConfigService
    {
        private readonly IUnitOfWork _unitOfWork;

        public ConfigService(IUnitOfWork unitOfWork)
        {
            this._unitOfWork = unitOfWork;
        }

        public T GetAppConfig<T>(string key)
        {
            string result;

            try
            {
                result = _unitOfWork.MConfigRepository.GetConfigValue(key)
                        .Trim();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            if (typeof(T) != typeof(string))
            {
                if (typeof(T) == typeof(bool))
                {
                    string[] arr = { "true", "false" };

                    if (!arr.Contains(result.ToString().ToLower()))
                    {
                        return (T)Convert.ChangeType(false, typeof(T));
                    }
                }
                else if (Helpers.IsNumeric(typeof(T)))
                {
                    try//coba convert
                    {
                        return (T)Convert.ChangeType(result, typeof(T));
                    }
                    catch (Exception ex)//kalo error, default 0
                    {
                        return (T)Convert.ChangeType(0, typeof(T));
                    }
                }
            }

            return (T)Convert.ChangeType(result, typeof(T));
        }

        
    }
}
