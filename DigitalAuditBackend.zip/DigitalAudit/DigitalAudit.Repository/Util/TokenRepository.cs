﻿using DigitalAudit.Helper;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.Util;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;

namespace DigitalAudit.Repository.Util
{
    public interface ITokenRepository : IGenericRepository<MTokenUser>
    {
        bool IsAuthenticated(MTokenUser token);
        string GetTokenUserID(MTokenUser token);
        TokenModel GetToken(MTokenUser token, string tokenUserID);
    }

    public class TokenRepository : GenericRepository<MTokenUser>, ITokenRepository
    {
        public TokenRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public MTokenUser Get(string id)
        {
            return _context.MTokenUsers.Where(x => x.IsDeleted == false && x.TokenUserID == id).FirstOrDefault();
        }

        public IEnumerable<MTokenUser> GetAll()
        {
            return _context.MTokenUsers.Where(x => x.IsDeleted == false);
        }

        public bool IsAuthenticated(MTokenUser token)
        {
            MTokenUser item = GetAll().Where(x => x.TokenUser == token.TokenUser && x.TokenPassword == token.TokenPassword).FirstOrDefault();
            if (item != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public TokenModel GetToken(MTokenUser token, string tokenUserID)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(Configs.SecretKey);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                    //new Claim(ClaimTypes.Name, tokenUserID)
                    //new Claim("UserId", tokenUserID)
                    new Claim("UserId", "0000a4bc-bb1e-4a80-81e9-219e1eda90e0")
                }),
                Expires = DateTime.Now.AddMinutes(100),
                //Expires = DateTime.Now.AddMinutes(Constants.TokenTimeoutMinutes),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };
            var tokenData = tokenHandler.CreateToken(tokenDescriptor);

            return new TokenModel(tokenHandler.WriteToken(tokenData), Convert.ToDateTime(Convert.ToDateTime(tokenDescriptor.Expires).ToString("yyyy-MM-dd HH:mm:ss")));

        }

        public string GetTokenUserID(MTokenUser token)
        {
            return _context.MTokenUsers.Where(x => x.TokenUser == token.TokenUser && x.TokenPassword == token.TokenPassword).FirstOrDefault().TokenUserID;
        }
    }
}
