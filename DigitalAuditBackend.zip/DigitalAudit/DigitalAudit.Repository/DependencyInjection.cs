﻿using DigitalAudit.Helper;
using DigitalAudit.Repository.Master;
using DigitalAudit.Repository.Services;
using DigitalAudit.Repository.Transaction;
using DigitalAudit.Repository.Util;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalAudit.Repository
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddRepository(this IServiceCollection services)
        {
            services.AddTransient<IMFAQRepository, MFAQRepository>();
            services.AddTransient<IMConfigRepository, MConfigRepository>();
            services.AddTransient<IMRoleRepository, MRoleRepository>();
            services.AddTransient<IMAuditTypeRepository, MAuditTypeRepository>();
            services.AddTransient<IMUserTypeRepository, MUserTypeRepository>();
            services.AddTransient<IMRegionRepository, MRegionRepository>();
            services.AddTransient<IMUserGroupRepository, MUserGroupRepository>();
            services.AddTransient<IMUserMemberRepository, MUserMemberRepository>();
            services.AddTransient<IMAuditLocationRepository, MAuditLocationRepository>();
            services.AddTransient<IMAuditResultCategoryRepository, MAuditResultCategoryRepository>();
            services.AddTransient<IMuserRoleRepository, MUserRoleRepository>();
            services.AddTransient<IMPriorityRepository, MPriorityRepository>();
            services.AddTransient<IMIssueStatusRepository, MIssueStatusRepository>();
            services.AddTransient<IMIssueCategoryRepository, MIssueCategoryRepository>();
            services.AddTransient<IMLogTypeRepository, MLogTypeRepository>();
            services.AddTransient<IMUserSyncUploadRepository, MUserSyncUploadRepository>();
            services.AddTransient<IMUserSyncRepository, MUserSyncRepository>();
            services.AddTransient<IMActionStatusRepository, MActionStatusRepository>();
            services.AddTransient<IMScheduleStatusRepository, MScheduleStatusRepository>();
            services.AddTransient<IMKboAuditLocationRepository, MKboAuditLocationRepository>();
            services.AddTransient<IMActionRepairCategoryRepository, MActionRepairCategoryRepository>();
            services.AddTransient<IMRootCauseCategoryRepository, MRootCauseCategoryRepository>();
            services.AddTransient<IMTemplateRepository, MTemplateRepository>();
            services.AddTransient<IMTemplateCategoryRepository, MTemplateCategoryRepository>();
            services.AddTransient<IMTemplatePermissionTypeRepository, MTemplatePermissionTypeRepository>();
            services.AddTransient<IMUserSyncWhitelistRepository, MUserSyncWhitelistRepository>();
            services.AddTransient<IMUserWhitelistRepository, MUserWhitelistRepository>();
            services.AddTransient<IMUserSyncAllRepository, MUserSyncAllRepository>();
            services.AddTransient<IMInspectionStatusRepository, MInspectionStatusRepository>();
            services.AddTransient<IMTemplatePageRepository, MTemplatePageRepository>();
            services.AddTransient<IMTemplateSectionRepository, MTemplateSectionRepository>();
            services.AddTransient<IMTemplateQuestionRepository, MTemplateQuestionRepository>();
            services.AddTransient<IMResponseRepository, MResponseRepository>();
            services.AddTransient<IMResponseListRepository, MResponseListRepository>();
            services.AddTransient<IMResponseTypeRepository, MResponseTypeRepository>();
            services.AddTransient<IMFileTypeRepository, MFileTypeRepository>();

            services.AddTransient<ITrIssueRepository, TrIssueRepository>();
            services.AddTransient<ITrIssueImportRepository, TrIssueImportRepository>();
            services.AddTransient<ITrIssueImportSessionRepository, TrIssueImportSessionRepository>();
            services.AddTransient<ITrIssueLogRepository, TrIssueLogRepository>();
            services.AddTransient<ITrActionRepository, TrActionRepository>();
            services.AddTransient<ITrActionLogRepository, TrActionLogRepository>();
            services.AddTransient<ITrActionImportRepository, TrActionImportRepository>();
            services.AddTransient<ITrActionImportSessionRepository, TrActionImportSessionRepository>();

            services.AddTransient<ITrAuditScheduleRepository, TrAuditScheduleRepository>();
            services.AddTransient<ITrAuditSchedulePICRepository, TrAuditSchedulePICRepository>();
            services.AddTransient<ITrActionRepairRepository, TrActionRepairRepository>();
            services.AddTransient<ITrAuditRescheduleRepository, TrAuditRescheduleRepository>();
            services.AddTransient<ITrAuditScheduleImportRepository, TrAuditScheduleImportRepository>();
            services.AddTransient<ITrAuditScheduleImportSessionRepository, TrAuditScheduleImportSessionRepository>();

            services.AddTransient<ITrInspectionRepository, TrInspectionRepository>();
            services.AddTransient<ITrInspectionResultRepository, TrInspectionResultRepository>();
            services.AddTransient<ITrInspectionFileRepository, TrInspectionFileRepository>();
            services.AddTransient<ITrInspectionNoteRepository, TrInspectionNoteRepository>();
            services.AddTransient<ITrInspectionPICRepository, TrInspectionPICRepository>();
            services.AddTransient<ITrInspectionInfoRepository, TrInspectionInfoRepository>();
            services.AddTransient<ITrInspectionSignatureRepository, TrInspectionSignatureRepository>();


            services.AddTransient<ITokenRepository, TokenRepository>();

            services.AddTransient<IUnitOfWork, UnitOfWork>();


            services.AddDbContext<DigitalAuditDbContext>(opt => opt
                .UseSqlServer(Configs.ConnectionString));

            return services;
        }
    }
}
