﻿using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalAudit.Repository
{
    public class DigitalAuditDbContext : DbContext
    {
        public DigitalAuditDbContext(DbContextOptions<DigitalAuditDbContext> options) : base(options) { }
        public DbSet<MTokenUser> MTokenUsers { get; set; }
        public DbSet<MAuditLocation> MAuditLocations { get; set; }
        public DbSet<MAuditType> MAuditTypes { get; set; }
        public DbSet<MUserType> MUserTypes { get; set; }
        public DbSet<MRegion> MRegions { get; set; }
        public DbSet<MAuditResultCategory> MAuditResultCategories { get; set; }
        public DbSet<MFAQ> MFAQs { get; set; }
        public DbSet<MRole> MRoles { get; set; }
        public DbSet<MConfig> MConfigs { get; set; }
        public DbSet<MUserRole> MUserRoles { get; set; }
        public DbSet<MUserGroup> MUserGroups { get; set; }
        public DbSet<MUserMember> MUserMembers { get; set; }
        public DbSet<MPriority> MPriorities { get; set; }
        public DbSet<MIssueStatus> MIssueStatuses { get; set; }
        public DbSet<MIssueCategory> MIssueCategories { get; set; }
        public DbSet<MLogType> MLogTypes { get; set; }
        public DbSet<MUserSyncUpload> MUserSyncUploads { get; set; }
        public DbSet<MUserSync> MUserSyncs { get; set; }
        public DbSet<MActionStatus> MActionStatuses { get; set; }
        public DbSet<MScheduleStatus> MScheduleStatuses { get; set; }
        public DbSet<MActionRepairCategory> MActionRepairCategories { get; set; }
        public DbSet<MRootCauseCategory> MRootCauseCategories { get; set; }
        public DbSet<MAnswerType> MAnswerTypes { get; set; }
        public DbSet<MResponse> MResponses { get; set; }
        public DbSet<MResponseList> MResponseLists { get; set; }
        public DbSet<MResponseType> MResponseTypes { get; set; }
        public DbSet<MTemplate> MTemplates { get; set; }
        public DbSet<MTemplateCategory> MTemplateCategories { get; set; }
        public DbSet<MTemplatePermissionType> MTemplatePermissionTypes { get; set; }
        public DbSet<MTemplatePage> MTemplatePages { get; set; }
        public DbSet<MTemplateQuestion> MTemplateQuestions { get; set; }
        public DbSet<MTemplateSection> MTemplateSections { get; set; }
        public DbSet<MUserSyncWhitelist> MUserSyncWhitelists { get; set; }
        public DbSet<MUserSyncAll> MUserSyncAlls { get; set; }
        public DbSet<MUserWhitelist> MUserWhitelists { get; set; }
        public DbSet<MInspectionStatus> MInspectionStatuses { get; set; }
        public DbSet<MFileType> MFileTypes { get; set; }
        


        public DbSet<TrIssue> TrIssues { get; set; }
        public DbSet<TrIssueImport> TrIssueImports { get; set; }
        public DbSet<TrIssueImportSession> TrIssueImportSessions { get; set; }
        public DbSet<TrIssueLog> TrIssueLogs { get; set; }
        public DbSet<TrAction> TrActions { get; set; }
        public DbSet<TrActionLog> TrActionLogs { get; set; }
        public DbSet<MKboAuditLocation> MKboAuditLocations { get; set; }
        public DbSet<TrActionImport> TrActionImports { get; set; }
        public DbSet<TrActionImportSession> TrActionImportSessions { get; set; }


        public DbSet<TrAuditSchedule> TrAuditSchedules { get; set; }
        public DbSet<TrAuditSchedulePIC> TrAuditSchedulePICs { get; set; }
        public DbSet<TrAuditReschedule> TrAuditReschedules { get; set; }
        public DbSet<TrAuditRescheduleApproval> TrAuditRescheduleApprovals { get; set; }
        public DbSet<TrActionRepair> TrActionRepairs { get; set; }
        public DbSet<TrInspectionResult> TrInspectionResults { get; set; }
        public DbSet<TrInspectionPIC> TrInspectionPICs { get; set; }
        public DbSet<TrInspectionNote> TrInspectionNotes { get; set; }
        public DbSet<TrInspectionInfo> TrInspectionInfos { get; set; }
        public DbSet<TrInspectionSignature> TrInspectionSignatures { get; set; }
        public DbSet<TrInspectionFile> TrInspectionFiles { get; set; }
        public DbSet<TrInspection> TrInspections { get; set; }
        public DbSet<TrAuditScheduleImport> TrAuditScheduleImports { get; set; }
        public DbSet<TrAuditScheduleImportSession> TrAuditScheduleImportSessions { get; set; }


        public DbSet<fn_Get_MAuditLocation> fn_Get_MAuditLocation { get; set; }
        public DbSet<fn_Get_MUserRole> fn_Get_MUserRole { get; set; }
        public DbSet<fn_Get_MUserMember> fn_Get_MUserMember { get; set; }
        public DbSet<fn_Get_MUserGroup> fn_Get_MUserGroup { get; set; }
        public DbSet<fn_Get_Issue> fn_Get_Issue { get; set; }
        public DbSet<fn_Get_IssueImport> fn_Get_IssueImport { get; set; }
        public DbSet<fn_Get_MKboAuditLocation> fn_Get_MKboAuditLocation { get; set; }
        public DbSet<fn_Get_ActionImport> fn_Get_ActionImport { get; set; }
        public DbSet<fn_Get_TrAuditSchedule> fn_Get_TrAuditSchedule { get; set; }
        public DbSet<fn_Get_Action> fn_Get_Action { get; set; }
        public DbSet<fn_Get_TrAuditSchedulePICID> fn_Get_TrAuditSchedulePICIDs { get; set; }
        public DbSet<fn_ValidatePICDouble_TrAuditSchedulePIC> fn_ValidatePICDouble_TrAuditSchedulePICs { get; set; }
        public DbSet<fn_Get_TrAuditReschedule> fn_Get_TrAuditReschedules { get; set; }
        public DbSet<fn_Get_MTemplate> fn_Get_MTemplates { get; set; }
        public DbSet<fn_Get_MTemplatePermission> fn_Get_MTemplatePermissions { get; set; }
        public DbSet<fn_Get_MUserWhitelist> fn_Get_MUserWhitelists { get; set; }
        public DbSet<fn_Get_Inspection> fn_Get_Inspections { get; set; }
        public DbSet<fn_Get_ScheduleImport> fn_Get_ScheduleImports { get; set; }
        public DbSet<fn_Get_MUserRole_AllUser> fn_Get_MUserRole_AllUsers { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            #region fn
            modelBuilder.Entity<fn_Get_MAuditLocation>().ToFunction("fn_Get_MAuditLocation").HasKey(m => m.AuditLocationId);
            modelBuilder.Entity<fn_Get_MUserRole>().ToFunction("fn_Get_MUserRole").HasKey(m => m.UserRoleId);
            modelBuilder.Entity<fn_Get_MUserMember>().ToFunction("fn_Get_MUserMember").HasKey(m => m.UserMemberId);
            modelBuilder.Entity<fn_Get_MUserGroup>().ToFunction("fn_Get_MUserGroup").HasKey(m => m.UserGroupId);
            modelBuilder.Entity<fn_Get_Issue>().ToFunction("fn_Get_Issue").HasKey(m => m.IssueId);
            modelBuilder.Entity<fn_Get_IssueImport>().ToFunction("fn_Get_IssueImport").HasKey(m => m.IssueImportId);
            modelBuilder.Entity<fn_Get_ActionImport>().ToFunction("fn_Get_ActionImport").HasKey(m => m.ActionImportId);
            modelBuilder.Entity<fn_Get_MKboAuditLocation>().ToFunction("fn_Get_MKboAuditLocation").HasKey(m => m.KboAuditLocationId);
            modelBuilder.Entity<fn_Get_TrAuditSchedule>().ToFunction("fn_Get_TrAuditSchedule").HasKey(m => m.ScheduleId);
            modelBuilder.Entity<fn_Get_IssueImportStatus>().ToFunction("fn_Get_IssueImportStatus").HasKey(m => m.SessionId);
            modelBuilder.Entity<fn_Get_Action>().ToFunction("fn_Get_Action").HasKey(m => m.ActionId);
            modelBuilder.Entity<fn_Get_TrAuditSchedulePICID>().ToFunction("fn_Get_TrAuditSchedulePICID").HasKey(m => m.PicId);
            modelBuilder.Entity<fn_ValidatePICDouble_TrAuditSchedulePIC>().ToFunction("fn_ValidatePICDouble_TrAuditSchedulePIC").HasKey(m => m.UserId);
            modelBuilder.Entity<fn_Get_TrAuditReschedule>().ToFunction("fn_Get_TrAuditReschedule").HasKey(m => m.RescheduleId);
            modelBuilder.Entity<fn_Get_MTemplate>().ToFunction("fn_Get_MTemplate").HasKey(m => m.TemplateId);
            modelBuilder.Entity<fn_Get_MTemplatePermission>().ToFunction("fn_Get_MTemplatePermission").HasKey(m => m.RowNum);
            modelBuilder.Entity<fn_Get_MUserWhitelist>().ToFunction("fn_Get_MUserWhitelist").HasKey(m => m.UserWhitelistId);
            modelBuilder.Entity<fn_Get_Inspection>().ToFunction("fn_Get_Inspection").HasKey(m => m.InspectionId);
            modelBuilder.Entity<fn_Get_ScheduleImport>().ToFunction("fn_Get_ScheduleImport").HasKey(m => m.ScheduleImportId);
            modelBuilder.Entity<fn_Get_MUserRole_AllUser>().ToFunction("fn_Get_MUserRole_AllUser").HasKey(m => m.UserId);
            #endregion

            modelBuilder.Entity<StatusViewModel>().HasNoKey().ToView(null);
            modelBuilder.Entity<ReportInspectionViewModel.ReportOverview>().HasNoKey().ToView(null);
            modelBuilder.Entity<ReportInspectionViewModel.Issue>().HasNoKey().ToView(null);
            modelBuilder.Entity<ReportInspectionViewModel.Action>().HasNoKey().ToView(null);
            modelBuilder.Entity<ReportInspectionViewModel.Score>().HasNoKey().ToView(null);


            #region Table
            modelBuilder.Entity<MAuditLocation>().Property(p => p.ID).UseIdentityColumn().Metadata.SetAfterSaveBehavior(PropertySaveBehavior.Ignore);
            modelBuilder.Entity<MAuditType>().Property(p => p.ID).UseIdentityColumn().Metadata.SetAfterSaveBehavior(PropertySaveBehavior.Ignore);
            modelBuilder.Entity<MUserGroup>().Property(p => p.ID).UseIdentityColumn().Metadata.SetAfterSaveBehavior(PropertySaveBehavior.Ignore);
            modelBuilder.Entity<MAuditLocation>().Property(p => p.ID).UseIdentityColumn().Metadata.SetAfterSaveBehavior(PropertySaveBehavior.Ignore);
            #endregion
        }
    }
}
