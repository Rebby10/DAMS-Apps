﻿using DigitalAudit.Repository.Master;
using DigitalAudit.Repository.Transaction;
using DigitalAudit.Repository.Util;
using Microsoft.EntityFrameworkCore.Storage;
using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalAudit.Repository
{
    public interface IUnitOfWork : IDisposable
    {
        #region Master
        IMConfigRepository MConfigRepository { get; }
        IMFAQRepository MFAQRepository { get; }
        IMRoleRepository MRoleRepository { get; }
        IMAuditTypeRepository MAuditTypeRepository { get; }
        IMUserTypeRepository MUserTypeRepository { get; }
        IMRegionRepository MRegionRepository { get; }
        IMUserGroupRepository MUserGroupRepository { get; }
        IMUserMemberRepository MUserMemberRepository { get; }
        IMAuditLocationRepository MAuditLocationRepository { get; }
        IMAuditResultCategoryRepository MAuditResultCategoryRepository { get; }
        IMuserRoleRepository MUserRoleRepository { get; }
        IMPriorityRepository MPriorityRepository { get; }
        IMIssueStatusRepository MIssueStatusRepository { get; }
        IMIssueCategoryRepository MIssueCategoryRepository { get; }
        IMLogTypeRepository MLogTypeRepository { get; }
        IMUserSyncUploadRepository MUserSyncUploadRepository { get; }
        IMUserSyncRepository MUserSyncRepository { get; }
        IMActionStatusRepository MActionStatusRepository { get; }
        IMKboAuditLocationRepository MKboAuditLocationRepository { get; }
        IMScheduleStatusRepository MScheduleStatusRepository { get; }
        IMRootCauseCategoryRepository MRootCauseCategoryRepository { get; }
        IMActionRepairCategoryRepository MActionRepairCategoryRepository { get; }
        IMTemplateCategoryRepository MTemplateCategoryRepository { get; }
        IMTemplateRepository MTemplateRepository { get; }
        IMTemplatePermissionTypeRepository MTemplatePermissionTypeRepository { get; }
        IMUserSyncWhitelistRepository MUserSyncWhitelistRepository { get; }
        IMUserWhitelistRepository MUserWhitelistRepository { get; }
        IMUserSyncAllRepository MUserSyncAllRepository { get; }
        IMInspectionStatusRepository MInspectionStatusRepository { get; }
        IMTemplatePageRepository MTemplatePageRepository { get; }
        IMTemplateSectionRepository MTemplateSectionRepository { get; }
        IMTemplateQuestionRepository MTemplateQuestionRepository { get; }
        IMResponseRepository MResponseRepository { get; }
        IMResponseListRepository MResponseListRepository { get; }
        IMResponseTypeRepository MResponseTypeRepository { get; }
        IMFileTypeRepository MFileTypeRepository { get; }
        #endregion

        #region Transaction
        ITrIssueRepository TrIssueRepository { get; }
        ITrIssueImportRepository TrIssueImportRepository { get; }
        ITrIssueImportSessionRepository TrIssueImportSessionRepository { get; }
        ITrIssueLogRepository TrIssueLogRepository { get; }
        ITrActionRepository TrActionRepository { get; }
        ITrActionLogRepository TrActionLogRepository { get; }
        ITrActionImportRepository TrActionImportRepository { get; }
        ITrActionImportSessionRepository TrActionImportSessionRepository { get; }
        ITrAuditScheduleRepository TrAuditScheduleRepository { get; }
        ITrAuditSchedulePICRepository TrAuditSchedulePICRepository { get; }
        ITrActionRepairRepository TrActionRepairRepository { get; }
        ITrAuditRescheduleRepository TrAuditRescheduleRepository { get; }
        ITrInspectionRepository TrInspectionRepository { get; }
        ITrInspectionResultRepository TrInspectionResultRepository { get; }
        ITrInspectionNoteRepository TrInspectionNoteRepository { get; }
        ITrInspectionFileRepository TrInspectionFileRepository { get; }
        ITrInspectionPICRepository TrInspectionPICRepository { get; }
        ITrInspectionInfoRepository TrInspectionInfoRepository { get; }
        ITrInspectionSignatureRepository TrInspectionSignatureRepository { get; }
        ITrAuditScheduleImportRepository TrAuditScheduleImportRepository { get; }
        ITrAuditScheduleImportSessionRepository TrAuditScheduleImportSessionRepository { get; }
        #endregion

        #region Util
        ITokenRepository TokenRepository { get; }
        #endregion

        void Begin();
        int Complete();
        void Commit();
        void RollBack();
    }

    public class UnitOfWork : IUnitOfWork
    {
        private readonly DigitalAuditDbContext _context;
        private IDbContextTransaction _transaction;



        public ITokenRepository TokenRepository { get; }
        public IMConfigRepository MConfigRepository { get; }
        public IMFAQRepository MFAQRepository { get; }
        public IMRoleRepository MRoleRepository { get; }
        public IMAuditTypeRepository MAuditTypeRepository { get; }
        public IMUserTypeRepository MUserTypeRepository { get; }
        public IMRegionRepository MRegionRepository { get; }
        public IMUserGroupRepository MUserGroupRepository { get; }
        public IMUserMemberRepository MUserMemberRepository { get; }
        public IMAuditLocationRepository MAuditLocationRepository { get; }
        public IMAuditResultCategoryRepository MAuditResultCategoryRepository { get; }
        public IMuserRoleRepository MUserRoleRepository { get; }
        public IMPriorityRepository MPriorityRepository { get; }
        public IMIssueStatusRepository MIssueStatusRepository { get; }
        public IMIssueCategoryRepository MIssueCategoryRepository { get; }
        public IMLogTypeRepository MLogTypeRepository { get; }
        public IMUserSyncUploadRepository MUserSyncUploadRepository { get; }
        public IMUserSyncRepository MUserSyncRepository { get; }
        public IMActionStatusRepository MActionStatusRepository { get; }
        public IMKboAuditLocationRepository MKboAuditLocationRepository { get; }
        public IMScheduleStatusRepository MScheduleStatusRepository { get; }
        public IMRootCauseCategoryRepository MRootCauseCategoryRepository { get; }
        public IMActionRepairCategoryRepository MActionRepairCategoryRepository { get; }
        public IMTemplateCategoryRepository MTemplateCategoryRepository { get; }
        public IMTemplateRepository MTemplateRepository { get; }
        public IMTemplatePermissionTypeRepository MTemplatePermissionTypeRepository { get; }
        public IMUserSyncWhitelistRepository MUserSyncWhitelistRepository { get; }
        public IMUserSyncAllRepository MUserSyncAllRepository { get; }
        public IMUserWhitelistRepository MUserWhitelistRepository { get; }
        public IMInspectionStatusRepository MInspectionStatusRepository { get; }
        public IMTemplatePageRepository MTemplatePageRepository { get; }
        public IMTemplateSectionRepository MTemplateSectionRepository { get; }
        public IMTemplateQuestionRepository MTemplateQuestionRepository { get; }
        public IMResponseRepository MResponseRepository { get; }
        public IMResponseListRepository MResponseListRepository { get; }
        public IMResponseTypeRepository MResponseTypeRepository{ get; }
        public IMFileTypeRepository MFileTypeRepository{ get; }


        public ITrIssueRepository TrIssueRepository { get; }
        public ITrIssueImportRepository TrIssueImportRepository { get; }
        public ITrIssueImportSessionRepository TrIssueImportSessionRepository { get; }
        public ITrIssueLogRepository TrIssueLogRepository { get; }
        public ITrActionRepository TrActionRepository { get; }
        public ITrActionLogRepository TrActionLogRepository { get; }
        public ITrActionImportRepository TrActionImportRepository { get; }
        public ITrActionImportSessionRepository TrActionImportSessionRepository { get; }
        public ITrAuditScheduleRepository TrAuditScheduleRepository { get; }
        public ITrAuditSchedulePICRepository TrAuditSchedulePICRepository { get; }
        public ITrActionRepairRepository TrActionRepairRepository { get; }
        public ITrAuditRescheduleRepository TrAuditRescheduleRepository { get; }
        public ITrInspectionRepository TrInspectionRepository { get; }
        public ITrInspectionResultRepository TrInspectionResultRepository { get; }
        public ITrInspectionNoteRepository TrInspectionNoteRepository { get; }
        public ITrInspectionFileRepository TrInspectionFileRepository { get; }
        public ITrInspectionPICRepository TrInspectionPICRepository { get; }
        public ITrInspectionInfoRepository TrInspectionInfoRepository { get; }
        public ITrInspectionSignatureRepository TrInspectionSignatureRepository { get; }

        public ITrAuditScheduleImportRepository TrAuditScheduleImportRepository { get; }
        public ITrAuditScheduleImportSessionRepository TrAuditScheduleImportSessionRepository { get; }

        public UnitOfWork(DigitalAuditDbContext DigitalAuditDbContext,
            ITokenRepository tokenRep
            , IMFAQRepository faqRep
            , IMConfigRepository configRep
            , IMRoleRepository roleRep
            , IMAuditTypeRepository auditTypeRep
            , IMUserTypeRepository userTypeRep
            , IMRegionRepository regionRep
            , IMUserGroupRepository userGroupRep
            , IMUserMemberRepository userMEmberRep
            , IMAuditLocationRepository auditLocationRep
            , IMAuditResultCategoryRepository auditResultCategoryRep
            , IMuserRoleRepository userRoleRep
            , IMPriorityRepository priorityRep
            , IMIssueStatusRepository issueStatusRep
            , IMIssueCategoryRepository issueCategoryRep
            , IMLogTypeRepository logTypeRep
            , IMUserSyncUploadRepository userSyncUploadRep
            , IMUserSyncRepository userSyncRep
            , IMActionStatusRepository actionStatusRep
            , IMKboAuditLocationRepository kboAuditLocationRep
            , IMScheduleStatusRepository scheduleStatusRep
            , IMActionRepairCategoryRepository actionRepairCategoryRep
            , IMRootCauseCategoryRepository rootCauseCategoryRep
            , IMTemplateCategoryRepository templateCategoryRep
            , IMTemplateRepository templateRep
            , IMTemplatePermissionTypeRepository templatePermissionTypeRep
            , IMUserSyncWhitelistRepository userSyncWhitelistRep
            , IMUserSyncAllRepository userSyncAllRep
            , IMUserWhitelistRepository userWhitelistRep
            , IMInspectionStatusRepository inspectionStatusRep
            , IMTemplatePageRepository templatePageRep
            , IMTemplateSectionRepository templateSectionRep
            , IMTemplateQuestionRepository templateQuestionRep
            , IMResponseRepository responseRep
            , IMResponseListRepository responseListRep
            , IMResponseTypeRepository responseTypeRep
            , IMFileTypeRepository fileTypeRep

            , ITrIssueRepository issueRep
            , ITrIssueImportRepository issueImportRep
            , ITrIssueImportSessionRepository issueImportSessionRep
            , ITrIssueLogRepository issueLogRep
            , ITrActionRepository actionRep
            , ITrActionLogRepository actionLogRep
            , ITrActionImportRepository actionImportLogRep
            , ITrActionImportSessionRepository actionImportSessionLogRep
            , ITrActionRepairRepository actionRepairRep

            , ITrAuditScheduleRepository auditScheduleRep
            , ITrAuditSchedulePICRepository auditSchedulePICRep
            , ITrAuditRescheduleRepository auditRescheduleRep
            , ITrAuditScheduleImportRepository auditRescheduleImportRep
            , ITrAuditScheduleImportSessionRepository auditRescheduleImportSessionRep

            , ITrInspectionRepository inspectionRep
            , ITrInspectionResultRepository inspectionResultRep
            , ITrInspectionNoteRepository inspectionNoteRep
            , ITrInspectionFileRepository inspectionFileRep
            , ITrInspectionPICRepository inspectionPICRep
            , ITrInspectionInfoRepository inspectionInfoRep
            , ITrInspectionSignatureRepository inspectionSignatureRep

            )
        {
            this._context = DigitalAuditDbContext;
            this.TokenRepository = tokenRep;
            this.MConfigRepository = configRep;
            this.MFAQRepository = faqRep;
            this.MRoleRepository = roleRep;
            this.MAuditTypeRepository = auditTypeRep;
            this.MUserTypeRepository = userTypeRep;
            this.MRegionRepository = regionRep;
            this.MUserGroupRepository = userGroupRep;
            this.MUserMemberRepository = userMEmberRep;
            this.MAuditLocationRepository = auditLocationRep;
            this.MAuditResultCategoryRepository = auditResultCategoryRep;
            this.MUserRoleRepository = userRoleRep;
            this.MPriorityRepository = priorityRep;
            this.MIssueStatusRepository = issueStatusRep;
            this.MIssueCategoryRepository = issueCategoryRep;
            this.MLogTypeRepository = logTypeRep;
            this.MUserSyncUploadRepository = userSyncUploadRep;
            this.MUserSyncRepository = userSyncRep;
            this.MActionStatusRepository = actionStatusRep;
            this.MKboAuditLocationRepository = kboAuditLocationRep;
            this.MScheduleStatusRepository = scheduleStatusRep;
            this.MActionRepairCategoryRepository = actionRepairCategoryRep;
            this.MRootCauseCategoryRepository = rootCauseCategoryRep;
            this.MTemplateCategoryRepository = templateCategoryRep;
            this.MTemplateRepository = templateRep;
            this.MTemplatePermissionTypeRepository = templatePermissionTypeRep;
            this.MUserSyncWhitelistRepository = userSyncWhitelistRep;
            this.MUserSyncAllRepository = userSyncAllRep;
            this.MUserWhitelistRepository = userWhitelistRep;
            this.MInspectionStatusRepository = inspectionStatusRep;
            this.MTemplatePageRepository = templatePageRep;
            this.MTemplateSectionRepository = templateSectionRep;
            this.MTemplateQuestionRepository = templateQuestionRep;
            this.MResponseListRepository = responseListRep;
            this.MResponseRepository = responseRep;
            this.MResponseTypeRepository = responseTypeRep;
            this.MFileTypeRepository = fileTypeRep;

            this.TrIssueRepository = issueRep;
            this.TrIssueImportRepository = issueImportRep;
            this.TrIssueImportSessionRepository = issueImportSessionRep;
            this.TrIssueLogRepository = issueLogRep;
            this.TrActionRepository = actionRep;
            this.TrActionLogRepository = actionLogRep;
            this.TrActionImportRepository = actionImportLogRep;
            this.TrActionImportSessionRepository = actionImportSessionLogRep;
            this.TrActionRepairRepository = actionRepairRep;

            this.TrAuditScheduleRepository = auditScheduleRep;
            this.TrAuditSchedulePICRepository = auditSchedulePICRep;
            this.TrAuditRescheduleRepository = auditRescheduleRep;
            this.TrAuditScheduleImportRepository = auditRescheduleImportRep;
            this.TrAuditScheduleImportSessionRepository = auditRescheduleImportSessionRep;

            this.TrInspectionRepository = inspectionRep;
            this.TrInspectionResultRepository = inspectionResultRep;
            this.TrInspectionNoteRepository = inspectionNoteRep;
            this.TrInspectionFileRepository = inspectionFileRep;
            this.TrInspectionPICRepository = inspectionPICRep;
            this.TrInspectionInfoRepository = inspectionInfoRep;
            this.TrInspectionSignatureRepository = inspectionSignatureRep;
            
        }

        public void Begin()
        {
            _transaction = _context.Database.BeginTransaction();
        }

        public int Complete()
        {
            return _context.SaveChanges();
        }

        public void Commit()
        {
            _transaction.Commit();
        }

        public void RollBack()
        {
            _transaction.Rollback();
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                _context.Dispose();
            }
        }
    }
}
