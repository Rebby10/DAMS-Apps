﻿using DigitalAudit.Helper;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Master
{
    public interface IMResponseTypeRepository : IGenericRepository<MResponseType>
    {
        //MResponseTypeViewModel.ReadMResponseType SelectOne(int id);
        List<MResponseTypeViewModel.ReadMResponseDetail> SelectAll();

        //void Add(MResponseType entity, string user, DateTime actiondate);
        //void Update(MResponseType entity, string user, DateTime actiondate);
        //void Delete(MResponseType entity, string user, DateTime actiondate);
        //bool anyInsert(MResponseType entity);
        //bool anyUpdate(MResponseType entity);
        //bool anyDelete(MResponseType entity);
    }

    public class MResponseTypeRepository : GenericRepository<MResponseType>, IMResponseTypeRepository
    {
        public MResponseTypeRepository(DigitalAuditDbContext context) : base(context)
        {
            
        }

        public List<MResponseTypeViewModel.ReadMResponseDetail> SelectAll()
        {
            List<MResponseTypeViewModel.ReadMResponseDetail> result = new List<MResponseTypeViewModel.ReadMResponseDetail>();

            result = Get_MResponseType().Where(x => x.IsDeleted == false).Select(o =>
               new MResponseTypeViewModel.ReadMResponseDetail
               {
                   TypeId = o.TypeId,
                   Name = o.Name,
                   Responses = GetResponses(o.TypeId)
               }).ToList();

            return result;
        }

        public List<MResponseViewModel.ReadResponseHeader> GetResponses(int typeId)
        {
            List<MResponseViewModel.ReadResponseHeader> result = new List<MResponseViewModel.ReadResponseHeader>();

            result = Get_MResponse().Where(x => x.IsDeleted == false && x.TypeId == typeId).Select(o =>
                new MResponseViewModel.ReadResponseHeader
                {
                    ResponseId = o.ResponseId,
                    Name = o.Name,
                    ResponseList = GetResponseList(o.ResponseId)
                }).ToList();

            return result;
        }

        public List<MResponseType> Get_MResponseType()
        {
            var result = _context.Set<MResponseType>().FromSqlRaw("select * from dbo.MResponseType");
            return result.ToList();
        }
        public List<MResponseList> Get_MResponseList()
        {
            var result = _context.Set<MResponseList>().FromSqlRaw("select * from dbo.MResponseList");
            return result.ToList();
        }

        public List<MResponse> Get_MResponse()
        {
            var result = _context.Set<MResponse>().FromSqlRaw("select * from dbo.MResponse");
            return result.ToList();
        }

        public List<MResponseListViewModel.ReadResponseList> GetResponseList(int reponse_id)
        {
            List<MResponseListViewModel.ReadResponseList> result = new List<MResponseListViewModel.ReadResponseList>();

            result = Get_MResponseList().Where(x => x.IsDeleted == false && x.ResponseId == reponse_id).Select(o =>
                new MResponseListViewModel.ReadResponseList
                {
                    //Response = this.SelectOne(o.ResponseId),
                    ResponseId = o.ResponseId,
                    IsFailedResponse = o.IsFailedResponse,
                    ListId = o.ListId,
                    Score = o.Score,
                    SeqNo = o.SeqNo,
                    Name = o.Name
                }).ToList();

            return result;
        }
    }
}
