﻿using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Master
{
    public interface IMInspectionStatusRepository : IGenericRepository<MInspectionStatus>
    {
        MInspectionStatusViewModel.ReadInspectiontatus SelectOne(int id);
        List<MInspectionStatusViewModel.ReadInspectiontatus> SelectAll();

        void Update(MInspectionStatus entity, string user, DateTime actiondate);
        void Delete(MInspectionStatus entity, string user, DateTime actiondate);
    }

    public class MInspectionStatusRepository : GenericRepository<MInspectionStatus>, IMInspectionStatusRepository
    {
        public MInspectionStatusRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public MInspectionStatus Get(int id)
        {
            return _context.MInspectionStatuses.Where(x => x.IsDeleted == false && x.StatusId == id).FirstOrDefault();
        }

        public List<MInspectionStatus> GetAll()
        {
            return _context.MInspectionStatuses.Where(x => x.IsDeleted == false).ToList();
        }

        public void Add(MInspectionStatus entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<MInspectionStatus>().Update(entity);
        }

        public void Delete(MInspectionStatus entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MInspectionStatus>().Update(entity);
        }

        public void Update(MInspectionStatus entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MInspectionStatus>().Update(entity);
        }

        public MInspectionStatusViewModel.ReadInspectiontatus SelectOne(int id)
        {
            return _context.MInspectionStatuses.Where(x => x.IsDeleted == false && x.StatusId == id).Select(o =>
                new MInspectionStatusViewModel.ReadInspectiontatus
                {
                    StatusId = o.StatusId,
                    Name = o.Name
                }).FirstOrDefault();
        }

        public List<MInspectionStatusViewModel.ReadInspectiontatus> SelectAll()
        {
            return _context.MInspectionStatuses.Where(x => x.IsDeleted == false).Select(o =>
                new MInspectionStatusViewModel.ReadInspectiontatus
                {
                    StatusId = o.StatusId,
                    Name = o.Name
                }).ToList();
        }
    }
}
