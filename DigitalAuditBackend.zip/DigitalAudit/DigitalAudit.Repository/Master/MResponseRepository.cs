﻿using DigitalAudit.Helper;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Master
{
    public interface IMResponseRepository : IGenericRepository<MResponse>
    {
        MResponseViewModel.ReadResponse SelectOne(int id);
        List<MResponseViewModel.ReadResponse> SelectAll();

        void Add(MResponse entity, string user, DateTime actiondate);
        void Update(MResponse entity, string user, DateTime actiondate);
        void Delete(MResponse entity, string user, DateTime actiondate);
        bool anyInsert(MResponse entity);
        bool anyUpdate(MResponse entity);
        bool anyDelete(MResponse entity);
    }

    public class MResponseRepository : GenericRepository<MResponse>, IMResponseRepository
    {
        public MResponseRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public MResponseViewModel.ReadResponse SelectOne(int id)
        {
            return Get_MResponse().Where(x => x.IsDeleted == false && x.ResponseId == id).Select(o =>
                new MResponseViewModel.ReadResponse
                {
                    ResponseId = o.ResponseId,
                    Name = o.Name,
                    ResponseType = this.GetResponseType(o.TypeId),
                    ResponseList = GetResponseList(o.ResponseId)
                }).FirstOrDefault();
        }

        public MResponseTypeViewModel.ReadMResponseType GetResponseType(int id)
        {
            return Get_MResponseType().Where(x => x.IsDeleted == false && x.TypeId == id).Select(o =>
                new MResponseTypeViewModel.ReadMResponseType
                {
                    TypeId = o.TypeId,
                    Name = o.Name
                }).FirstOrDefault();
        }

        public List<MResponseListViewModel.ReadResponseList> GetResponseList(int reponse_id)
        {
            return Get_MResponseList().Where(x => x.IsDeleted == false && x.ResponseId == reponse_id).Select(o =>
                new MResponseListViewModel.ReadResponseList
                {
                    //Response = this.SelectOne(o.ResponseId),
                    ResponseId = o.ResponseId,
                    IsFailedResponse = o.IsFailedResponse,
                    ListId = o.ListId,
                    Score = o.Score, 
                    SeqNo = o.SeqNo,
                    Name = o.Name
                }).ToList();
        }


        public List<MResponseViewModel.ReadResponse> SelectAll()
        {
            return Get_MResponse().Where(x => x.IsDeleted == false).Select(o =>
                new MResponseViewModel.ReadResponse
                {
                    ResponseId = o.ResponseId,
                    Name = o.Name,
                    ResponseType = this.GetResponseType(o.TypeId),
                    ResponseList = GetResponseList(o.ResponseId)
                }).ToList();
        }


        public MResponse Get(int id)
        {
            return _context.MResponses.Where(x => x.IsDeleted == false && x.ResponseId == id).FirstOrDefault();
        }

        public List<MResponse> GetAll()
        {
            return _context.MResponses.Where(x => x.IsDeleted == false).ToList();
        }

        public List<MResponse> Get_MResponse()
        {
            var result = _context.Set<MResponse>().FromSqlRaw("select * from dbo.MResponse");
            return result.ToList();
        }

        public List<MResponseType> Get_MResponseType()
        {
            var result = _context.Set<MResponseType>().FromSqlRaw("select * from dbo.MResponseType");
            return result.ToList();
        }
        public List<MResponseList> Get_MResponseList()
        {
            var result = _context.Set<MResponseList>().FromSqlRaw("select * from dbo.MResponseList");
            return result.ToList();
        }

        public void Add(MResponse entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<MResponse>().Update(entity);
        }

        public void Update(MResponse entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MResponse>().Update(entity);
        }

        public void Delete(MResponse entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MResponse>().Update(entity);
        }

        public bool anyInsert(MResponse entity)
        {
            return GetAll().Any(i => i.Name == entity.Name);
        }

        public bool anyUpdate(MResponse entity)
        {
            return GetAll().Any(i => i.Name == entity.Name && i.ResponseId != entity.ResponseId);
        }

        public bool anyDelete(MResponse entity)
        {
            return _context.MResponses.Any(i => i.IsDeleted == false && i.ResponseId == entity.ResponseId);
        }
    }
}
