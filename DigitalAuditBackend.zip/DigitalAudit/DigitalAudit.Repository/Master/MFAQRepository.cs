﻿using DigitalAudit.Helper;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Master
{
    public interface IMFAQRepository : IGenericRepository<MFAQ>
    {
        //void Add(MFAQ entity, string user, DateTime actiondate);
        MFAQViewModel.ReadFAQ SelectOne(string id);
        List<MFAQViewModel.ReadFAQ> SelectAll();
        void Update(MFAQ entity, string user, DateTime actiondate);
        void Delete(MFAQ entity, string user, DateTime actiondate);
        bool anyInsert(MFAQ entity);
        bool anyUpdate(MFAQ entity);
    }

    public class MFAQRepository : GenericRepository<MFAQ>, IMFAQRepository
    {
        public MFAQRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public MFAQViewModel.ReadFAQ SelectOne(string id)
        {
            return _context.MFAQs.Where(x => x.IsDeleted == false && x.FaqId == id).Select(o =>
                new MFAQViewModel.ReadFAQ
                {
                    FaqId = o.FaqId,
                    Answer = o.Answer,
                    Question = o.Question
                }).FirstOrDefault();
        }

        public List<MFAQViewModel.ReadFAQ> SelectAll()
        {
            return _context.MFAQs.Where(x => x.IsDeleted == false).Select(o =>
                new MFAQViewModel.ReadFAQ
                {
                    FaqId = o.FaqId,
                    Answer = o.Answer,
                    Question = o.Question
                }).ToList();
        }

        public MFAQ Get(string id)
        {
            return _context.MFAQs.Where(x => x.IsDeleted == false && x.FaqId == id).FirstOrDefault();
        }

        public List<MFAQ> GetAll()
        {
            return _context.MFAQs.Where(x => x.IsDeleted == false).ToList();
        }

        public void Add(MFAQ entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<MFAQ>().Update(entity);
        }

        public void Update(MFAQ entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MFAQ>().Update(entity);
        }

        public void Delete(MFAQ entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MFAQ>().Update(entity);
        }

        public bool anyInsert(MFAQ entity)
        {
            return GetAll().Any(i => i.Question == entity.Question);
        }

        public bool anyUpdate(MFAQ entity)
        {
            return GetAll().Any(i => i.Question == entity.Question && i.FaqId != entity.FaqId);
        }
    }
}
