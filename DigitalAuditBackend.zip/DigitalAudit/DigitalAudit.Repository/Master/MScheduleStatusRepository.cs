﻿using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;


namespace DigitalAudit.Repository.Master
{
    public interface IMScheduleStatusRepository : IGenericRepository<MScheduleStatus>
    {
        MScheduleStatusViewModel.ReadScheduleStatus SelectOne(int id);
        List<MScheduleStatusViewModel.ReadScheduleStatus> SelectAll();

        void Update(MScheduleStatus entity, string user, DateTime actiondate);
        void Delete(MScheduleStatus entity, string user, DateTime actiondate);
    }
    public class MScheduleStatusRepository : GenericRepository<MScheduleStatus>, IMScheduleStatusRepository
    {
        public MScheduleStatusRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public MScheduleStatus Get(int id)
        {
            return _context.MScheduleStatuses.Where(x => x.IsDeleted == false && x.StatusId == id).FirstOrDefault();
        }

        public List<MScheduleStatus> GetAll()
        {
            return _context.MScheduleStatuses.Where(x => x.IsDeleted == false).ToList();
        }

        public void Add(MScheduleStatus entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<MScheduleStatus>().Update(entity);
        }

        public void Delete(MScheduleStatus entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MScheduleStatus>().Update(entity);
        }

        public void Update(MScheduleStatus entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MScheduleStatus>().Update(entity);
        }

        public MScheduleStatusViewModel.ReadScheduleStatus SelectOne(int id)
        {
            return _context.MScheduleStatuses.Where(x => x.IsDeleted == false && x.StatusId == id).Select(o =>
                new MScheduleStatusViewModel.ReadScheduleStatus
                {
                    StatusId = o.StatusId,
                    Name = o.Name
                }).FirstOrDefault();
        }

        public List<MScheduleStatusViewModel.ReadScheduleStatus> SelectAll()
        {
            return _context.MIssueStatuses.Where(x => x.IsDeleted == false).Select(o =>
                new MScheduleStatusViewModel.ReadScheduleStatus
                {
                    StatusId = o.StatusId,
                    Name = o.Name
                }).ToList();
        }
    }
}
