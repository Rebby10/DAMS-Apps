﻿using DigitalAudit.Helper;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Master
{
    public interface IMTemplatePageRepository : IGenericRepository<MTemplatePage>
    {
        MTemplatePageViewModel.ReadTemplatePage SelectOne(string id);
        List<MTemplatePageViewModel.ReadTemplatePage> SelectAll();

        void Add(MTemplatePage entity, string user, DateTime actiondate);
        void Update(MTemplatePage entity, string user, DateTime actiondate);
        void Delete(MTemplatePage entity, string user, DateTime actiondate);
        //bool anyInsert(MTemplatePage entity);
        //bool anyUpdate(MTemplatePage entity);
        //bool anyDelete(MTemplatePage entity);
    }

    public class MTemplatePageRepository : GenericRepository<MTemplatePage>, IMTemplatePageRepository
    {
        public MTemplatePageRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public MTemplatePageViewModel.ReadTemplatePage SelectOne(string id)
        {
            return _context.MTemplatePages.Where(x => x.IsDeleted == false && x.PageId == id).Select(o =>
                new MTemplatePageViewModel.ReadTemplatePage
                {
                    PageId = o.PageId,
                    TemplateId = o.TemplateId,
                    Title = o.Title,
                    Descriptions = o.Descriptions,
                    SeqNo = o.SeqNo
                }).FirstOrDefault();
        }

        public List<MTemplatePageViewModel.ReadTemplatePage> SelectAll()
        {
            return _context.MTemplatePages.Where(x => x.IsDeleted == false).Select(o =>
                new MTemplatePageViewModel.ReadTemplatePage
                {
                    PageId = o.PageId,
                    TemplateId = o.TemplateId,
                    Title = o.Title,
                    Descriptions = o.Descriptions,
                    SeqNo = o.SeqNo
                }).ToList();
        }

        public List<MTemplatePageViewModel.ReadTemplatePageDetail> SelectTemplatePageDetail(string templateId)
        {
            return _context.MTemplatePages.Where(x => x.IsDeleted == false && x.TemplateId == templateId).Select(o =>
                new MTemplatePageViewModel.ReadTemplatePageDetail
                {
                    PageId = o.PageId,
                    TemplateId = o.TemplateId,
                    Title = o.Title,
                    Descriptions = o.Descriptions,
                    SeqNo = o.SeqNo,
                    Question = GetTemplateQuestion(o.PageId)
                }).ToList();
        }

        public MTemplatePage Get(string id)
        {
            return _context.MTemplatePages.Where(x => x.IsDeleted == false && x.PageId == id).FirstOrDefault();
        }

        public List<MTemplatePage> GetAll()
        {
            return _context.MTemplatePages.Where(x => x.IsDeleted == false).ToList();
        }

        public void Add(MTemplatePage entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<MTemplatePage>().Update(entity);
        }

        public void Update(MTemplatePage entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MTemplatePage>().Update(entity);
        }

        public void Delete(MTemplatePage entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MTemplatePage>().Update(entity);
        }

        public List<MTemplateQuestionViewModel.ReadTemplateQuestion> GetTemplateQuestion(string page_id)
        {
            return _context.MTemplateQuestions.Where(x => x.IsDeleted == false && x.PageId == page_id).Select(o =>
                new MTemplateQuestionViewModel.ReadTemplateQuestion
                {
                    QuestionId = o.QuestionId,
                    PageId = o.PageId,
                    Code = o.Code,
                    Question = o.Question,
                    IsMandatory = o.IsMandatory,
                    SectionId = o.SectionId,
                    Response = GetResponse(o.ResponseId)
                }).ToList();
        }

        public MResponseViewModel.ReadResponse GetResponse(int response_id)
        {
            return _context.MResponses.Where(x => x.IsDeleted == false && x.ResponseId == response_id).Select(o =>
                new MResponseViewModel.ReadResponse
                {
                    ResponseId = o.ResponseId,
                    Name = o.Name,
                    ResponseType = this.GetResponseType(o.TypeId),
                    ResponseList = GetResponseList(o.ResponseId)
                }).FirstOrDefault();
        }

        public MResponseTypeViewModel.ReadMResponseType GetResponseType(int id)
        {
            return _context.MResponseTypes.Where(x => x.IsDeleted == false && x.TypeId == id).Select(o =>
                new MResponseTypeViewModel.ReadMResponseType
                {
                    TypeId = o.TypeId,
                    Name = o.Name
                }).FirstOrDefault();
        }

        public List<MResponseListViewModel.ReadResponseList> GetResponseList(int reponse_id)
        {
            return _context.MResponseLists.Where(x => x.IsDeleted == false && x.ResponseId == reponse_id).Select(o =>
                new MResponseListViewModel.ReadResponseList
                {
                    //Response = this.GetMResponse(o.ResponseId),
                    ResponseId = o.ResponseId,
                    IsFailedResponse = o.IsFailedResponse,
                    ListId = o.ListId,
                    Score = o.Score,
                    SeqNo = o.SeqNo,
                    Name = o.Name
                }).ToList();
        }

        public MResponseViewModel.ReadResponse GetMResponse(int id)
        {
            return _context.MResponses.Where(x => x.IsDeleted == false && x.ResponseId == id).Select(o =>
                new MResponseViewModel.ReadResponse
                {
                    ResponseId = o.ResponseId,
                    Name = o.Name,
                    ResponseType = this.GetResponseType(o.TypeId),
                    ResponseList = GetResponseList(o.ResponseId)
                }).FirstOrDefault();
        }

        //public bool anyInsert(MTemplatePage entity)
        //{
        //    return GetAll().Any(i => i.Name == entity.Name);
        //}

        //public bool anyUpdate(MTemplatePage entity)
        //{
        //    return GetAll().Any(i => i.Name == entity.Name && i.TemplatePageId != entity.TemplatePageId);
        //}

        //public bool anyDelete(MTemplatePage entity)
        //{
        //    return _context.MAuditLocations.Any(i => i.IsDeleted == false && i.TemplatePageId == entity.TemplatePageId);
        //}
    }
}
