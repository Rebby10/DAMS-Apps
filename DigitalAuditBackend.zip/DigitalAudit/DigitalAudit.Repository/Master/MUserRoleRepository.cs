﻿using DigitalAudit.Helper;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Master
{
    public interface IMuserRoleRepository : IGenericRepository<MUserRole>
    {
        void Update(MUserRole entity, string user, DateTime actiondate);
        void Delete(MUserRole entity, string user, DateTime actiondate);
        fn_Get_MUserRole SelectOne(string id);
        IEnumerable<fn_Get_MUserRole> SelectAll(string userRoleId, string username, string email, string Userid);
        IQueryable<fn_Get_MUserRole_AllUser> SelectAllUser(string userRoleId, string username, string email, string Userid);
        bool anyInsert(MUserRole entity);
        bool anyUpdate(MUserRole entity);
        IEnumerable<fn_Get_MUserRole> Get_MUserRole(string userRoleId, string username, string email, string Userid);
    }
    public class MUserRoleRepository : GenericRepository<MUserRole>, IMuserRoleRepository
    {
        public MUserRoleRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public MUserRole Get(string id)
        {
            return _context.MUserRoles.Where(x => x.IsDeleted == false && x.UserRoleId == id).FirstOrDefault();
        }

        public IEnumerable<MUserRole> GetAll()
        {
            return _context.MUserRoles.Where(x => x.IsDeleted == false);
        }

        public void Add(MUserRole entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<MUserRole>().Update(entity);
        }

        public void Update(MUserRole entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MUserRole>().Update(entity);
        }

        public void Delete(MUserRole entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MUserRole>().Update(entity);
        }


        public fn_Get_MUserRole SelectOne(string id)
        {
            return Get_MUserRole(id, null, null, null).FirstOrDefault();
        }

        public IEnumerable<fn_Get_MUserRole> SelectAll(string userRoleId, string username, string email, string userId)
        {
           return Get_MUserRole(userRoleId, username, email, userId);
        }

        public IQueryable<fn_Get_MUserRole_AllUser> SelectAllUser(string userRoleId, string username, string email, string userId)
        {
            return Get_MUserRole_AllUser(userRoleId, username, email, userId);
        }

        public bool anyInsert(MUserRole entity)
        {
            return GetAll().Any(i => i.UserId == entity.UserId);
        }

        public bool anyUpdate(MUserRole entity)
        {
            return GetAll().Any(i => i.UserId == entity.UserId && i.UserRoleId != entity.UserRoleId);
        }

        public IEnumerable<fn_Get_MUserRole> Get_MUserRole(string userRoleId, string username, string email, string userId)
        {
            return _context.Set<fn_Get_MUserRole>().FromSqlRaw("select * from dbo.fn_Get_MUserRole({0},{1},{2}, {3})", userRoleId, username, email, userId);
        }

        public IQueryable<fn_Get_MUserRole_AllUser> Get_MUserRole_AllUser(string userRoleId, string username, string email, string userId)
        {
            return _context.Set<fn_Get_MUserRole_AllUser>().FromSqlRaw("select * from dbo.fn_Get_MUserRole_AllUser({0},{1},{2}, {3})", userRoleId, username, email, userId);
        }
    }
}
