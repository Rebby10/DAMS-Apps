﻿using DigitalAudit.Helper;
using DigitalAudit.Model.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Master
{
    public interface IMRoleRepository : IGenericRepository<MRole>
    {
        void Update(MRole entity, string user, DateTime actiondate);
        void Delete(MRole entity, string user, DateTime actiondate);
    }

    public class MRoleRepository : GenericRepository<MRole>, IMRoleRepository
    {
        public MRoleRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public MRole Get(string id)
        {
            return _context.MRoles.Where(x => x.IsDeleted == false && x.RoleId == id).FirstOrDefault();
        }

        public List<MRole> GetAll()
        {
            return _context.MRoles.Where(x => x.IsDeleted == false).ToList();
        }

        public void Add(MRole entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<MRole>().Update(entity);
        }

        public void Update(MRole entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MRole>().Update(entity);
        }

        public void Delete(MRole entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MRole>().Update(entity);
        }
    }
}
