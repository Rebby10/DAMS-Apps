﻿using DigitalAudit.Helper;
using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Master
{
    public interface IMKboAuditLocationRepository : IGenericRepository<MKboAuditLocation>
    {
        void Update(MKboAuditLocation entity, string user, DateTime actiondate);
        void Delete(MKboAuditLocation entity, string user, DateTime actiondate);
        MKboAuditLocationViewModel.ReadKboAuditLocation SelectOne(string id);
        List<MKboAuditLocationViewModel.ReadKboAuditLocation> SelectAll();
        bool anyInsert(MKboAuditLocation entity);
        bool anyUpdate(MKboAuditLocation entity);
        //bool anyDelete(MKboAuditLocation entity);
        List<fn_Get_MKboAuditLocation> Get_MKboAuditLocation(string KboAuditLocationId, string auditLocationId, string name, string regionId);

        StatusViewModel SyncronizeKboSync_Syncronize();
    }

    public class MKboAuditLocationRepository : GenericRepository<MKboAuditLocation>, IMKboAuditLocationRepository
    {
        public MKboAuditLocationRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public MKboAuditLocation Get(string id)
        {
            return _context.MKboAuditLocations.Where(x => x.IsDeleted == false && x.KboAuditLocationId == id).FirstOrDefault();
        }

        public List<MKboAuditLocation> GetAll()
        {
            return _context.MKboAuditLocations.Where(x => x.IsDeleted == false).ToList();
        }

        public void Add(MKboAuditLocation entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<MKboAuditLocation>().Update(entity);
        }

        public void Update(MKboAuditLocation entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MKboAuditLocation>().Update(entity);
        }

        public void Delete(MKboAuditLocation entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MKboAuditLocation>().Update(entity);
        }

        public MKboAuditLocationViewModel.ReadKboAuditLocation SelectOne(string id)
        {
            return Get_MKboAuditLocation(id, null, null, null).Select(o =>
                new MKboAuditLocationViewModel.ReadKboAuditLocation
                {
                    KboAuditLocationId = o.KboAuditLocationId,
                    Kbo = o.Kbo,
                    AuditLocation = new MAuditLocationViewModel.ReadAuditLocation(o.AuditLocationId, o.LocationName, o.Address, o.ZipCode, o.LatLong, o.RegionId, o.RegionName)
                }).FirstOrDefault();
        }

        public List<MKboAuditLocationViewModel.ReadKboAuditLocation> SelectAll()
        {
            return Get_MKboAuditLocation(null, null, null, null).Select(o =>
                new MKboAuditLocationViewModel.ReadKboAuditLocation
                {
                    KboAuditLocationId = o.KboAuditLocationId,
                    Kbo = o.Kbo,
                    AuditLocation = new MAuditLocationViewModel.ReadAuditLocation(o.AuditLocationId, o.LocationName, o.Address, o.ZipCode, o.LatLong, o.RegionId, o.RegionName)
                }).ToList();
        }

        public bool anyInsert(MKboAuditLocation entity)
        {
            return GetAll().Any(i => i.Kbo == entity.Kbo.Trim());
        }

        public bool anyUpdate(MKboAuditLocation entity)
        {
            return GetAll().Any(i => i.Kbo == entity.Kbo.Trim() && i.KboAuditLocationId != entity.KboAuditLocationId);
        }

        public List<fn_Get_MKboAuditLocation> Get_MKboAuditLocation(string KboAuditLocationId, string auditLocationId, string name, string regionId)
        {
            return _context.Set<fn_Get_MKboAuditLocation>().FromSqlRaw("select * from dbo.fn_Get_MKboAuditLocation({0},{1},{2},{3})", KboAuditLocationId, auditLocationId, name, regionId).ToList();
        }

        public StatusViewModel SyncronizeKboSync_Syncronize()
        {
            IEnumerable<StatusViewModel> result = _context.Set<StatusViewModel>().FromSqlRaw("exec spKboSync_Syncronize");
            return result.FirstOrDefault();
        }
    }
}
