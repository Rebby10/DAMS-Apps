﻿using DigitalAudit.Helper;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Master
{
    public interface IMTemplateQuestionRepository : IGenericRepository<MTemplateQuestion>
    {
        MTemplateQuestionViewModel.ReadTemplateQuestion SelectOne(int id);
        List<MTemplateQuestionViewModel.ReadTemplateQuestion> SelectAll();

        void Add(MTemplateQuestion entity, string user, DateTime actiondate);
        void Update(MTemplateQuestion entity, string user, DateTime actiondate);
        void Delete(MTemplateQuestion entity, string user, DateTime actiondate);
        //bool anyInsert(MTemplateQuestion entity);
        //bool anyUpdate(MTemplateQuestion entity);
        //bool anyDelete(MTemplateQuestion entity);
    }

    public class MTemplateQuestionRepository : GenericRepository<MTemplateQuestion>, IMTemplateQuestionRepository
    {
        public MTemplateQuestionRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public List<MTemplateQuestion> Get_MTemplateQuestion()
        {
            var result = _context.Set<MTemplateQuestion>().FromSqlRaw("select * from dbo.MTemplateQuestion");
            return result.ToList();
        }


        public List<MResponse> Get_MResponse()
        {
            var result = _context.Set<MResponse>().FromSqlRaw("select * from dbo.MResponse");
            return result.ToList();
        }


        public List<MResponseType> Get_MResponseType()
        {
            var result = _context.Set<MResponseType>().FromSqlRaw("select * from dbo.MResponseType");
            return result.ToList();
        }

        public List<MResponseList> Get_MResponseList()
        {
            var result = _context.Set<MResponseList>().FromSqlRaw("select * from dbo.MResponseList");
            return result.ToList();
        }




        public MTemplateQuestionViewModel.ReadTemplateQuestion SelectOne(int id)
        {
            return Get_MTemplateQuestion().Where(x => x.IsDeleted == false && x.QuestionId == id).Select(o =>
                new MTemplateQuestionViewModel.ReadTemplateQuestion
                {
                    QuestionId = o.QuestionId,
                    PageId = o.PageId,
                    SeqNo = o.SeqNo,
                    Code = o.Code,
                    Question = o.Question,
                    IsMandatory = o.IsMandatory,
                    SectionId = o.SectionId,
                    Response = GetResponse(o.ResponseId)
                }).FirstOrDefault();
        }


        public MResponseViewModel.ReadResponse GetResponse(int response_id)
        {
            return Get_MResponse().Where(x => x.IsDeleted == false && x.ResponseId == response_id).Select(o =>
                new MResponseViewModel.ReadResponse
                {
                    ResponseId = o.ResponseId,
                    Name = o.Name,
                    ResponseType = this.GetResponseType(o.TypeId),
                    ResponseList = GetResponseList(o.ResponseId)
                }).FirstOrDefault();
        }



        public MResponseTypeViewModel.ReadMResponseType GetResponseType(int id)
        {
            return Get_MResponseType().Where(x => x.IsDeleted == false && x.TypeId == id).Select(o =>
                new MResponseTypeViewModel.ReadMResponseType
                {
                    TypeId = o.TypeId,
                    Name = o.Name
                }).FirstOrDefault();
        }

        public List<MResponseListViewModel.ReadResponseList> GetResponseList(int reponse_id)
        {
            return Get_MResponseList().Where(x => x.IsDeleted == false && x.ResponseId == reponse_id).Select(o =>
                new MResponseListViewModel.ReadResponseList
                {
                    //Response = this.GetMResponse(o.ResponseId),
                    ResponseId = o.ResponseId,
                    IsFailedResponse = o.IsFailedResponse,
                    ListId = o.ListId,
                    Score = o.Score,
                    SeqNo = o.SeqNo,
                    Name = o.Name
                }).ToList();
        }

        public MResponseViewModel.ReadResponse GetMResponse(int id)
        {
            return Get_MResponse().Where(x => x.IsDeleted == false && x.ResponseId == id).Select(o =>
                new MResponseViewModel.ReadResponse
                {
                    ResponseId = o.ResponseId,
                    Name = o.Name,
                    ResponseType = this.GetResponseType(o.TypeId),
                    ResponseList = GetResponseList(o.ResponseId)
                }).FirstOrDefault();
        }

        public List<MTemplateQuestionViewModel.ReadTemplateQuestion> SelectAll()
        {
            return Get_MTemplateQuestion().Where(x => x.IsDeleted == false).Select(o =>
                new MTemplateQuestionViewModel.ReadTemplateQuestion
                {
                    QuestionId = o.QuestionId,
                    PageId = o.PageId,
                    SeqNo = o.SeqNo,
                    Code = o.Code,
                    Question = o.Question,
                    IsMandatory = o.IsMandatory,
                    SectionId = o.SectionId,
                    Response = GetResponse(o.ResponseId)
                }).ToList();
        }

        public MTemplateQuestion Get(int id)
        {
            return _context.MTemplateQuestions.Where(x => x.IsDeleted == false && x.QuestionId == id).FirstOrDefault();
        }

        public List<MTemplateQuestion> GetAll()
        {
            return _context.MTemplateQuestions.Where(x => x.IsDeleted == false).ToList();
        }

        public void Add(MTemplateQuestion entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<MTemplateQuestion>().Update(entity);
        }

        public void Update(MTemplateQuestion entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MTemplateQuestion>().Update(entity);
        }

        public void Delete(MTemplateQuestion entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MTemplateQuestion>().Update(entity);
        }

        //public bool anyInsert(MTemplateQuestion entity)
        //{
        //    return GetAll().Any(i => i.Name == entity.Name);
        //}

        //public bool anyUpdate(MTemplateQuestion entity)
        //{
        //    return GetAll().Any(i => i.Name == entity.Name && i.TemplateQuestionId != entity.TemplateQuestionId);
        //}

        //public bool anyDelete(MTemplateQuestion entity)
        //{
        //    return _context.MAuditLocations.Any(i => i.IsDeleted == false && i.TemplateQuestionId == entity.TemplateQuestionId);
        //}
    }
}
