﻿using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
namespace DigitalAudit.Repository.Master
{
    public interface IMRootCauseCategoryRepository : IGenericRepository<MRootCauseCategory>
    {
        MRootCauseCategoryViewModel.ReadRootCauseCategory SelectOne(string id);
        List<MRootCauseCategoryViewModel.ReadRootCauseCategory> SelectAll();
        void Update(MRootCauseCategory entity, string user, DateTime actiondate);
        void Delete(MRootCauseCategory entity, string user, DateTime actiondate);
    }

    public class MRootCauseCategoryRepository : GenericRepository<MRootCauseCategory>, IMRootCauseCategoryRepository
    {
        public MRootCauseCategoryRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public void Delete(MRootCauseCategory entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MRootCauseCategory>().Update(entity);
        }

        public List<MRootCauseCategoryViewModel.ReadRootCauseCategory> SelectAll()
        {
            return _context.MRootCauseCategories.Where(x => x.IsDeleted == false)
                .OrderBy(o => o.Name)
                .Select(o =>
                new MRootCauseCategoryViewModel.ReadRootCauseCategory
                {
                    Id = o.RootCauseCategoryId,
                    Name = o.Name
                }).ToList();
        }

        public MRootCauseCategoryViewModel.ReadRootCauseCategory SelectOne(string id)
        {
            return _context.MRootCauseCategories.Where(x => x.IsDeleted == false && x.RootCauseCategoryId == id).Select(o =>
               new MRootCauseCategoryViewModel.ReadRootCauseCategory
               {
                   Id = o.RootCauseCategoryId,
                   Name = o.Name
               }).FirstOrDefault();
        }

        public void Update(MRootCauseCategory entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MRootCauseCategory>().Update(entity);
        }
    }
}
