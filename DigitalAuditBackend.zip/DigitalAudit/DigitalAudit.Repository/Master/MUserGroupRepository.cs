﻿using DigitalAudit.Helper;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Master
{
    public interface IMUserGroupRepository : IGenericRepository<MUserGroup>
    {
        void Update(MUserGroup entity, string user, DateTime actiondate);
        void Delete(MUserGroup entity, string user, DateTime actiondate);
        MUserGroupViewModel.ReadUserGroup SelectOne(string id);
        List<MUserGroupViewModel.ReadUserGroup> SelectAll();
        List<MUserGroupViewModel.ReadUserGroupMember> SelectUserGroupMember(string userGroupId, string userTypeId);
        bool anyInsert(MUserGroup entity);
        bool anyUpdate(MUserGroup entity);
        List<fn_Get_MUserMember> Get_MUserMember(string userMemberId, string userGroupId, string userTypeId);
        List<fn_Get_MUserGroup> Get_MUserGroup(string userGroupId, string userTypeId);
    }

    public class MUserGroupRepository : GenericRepository<MUserGroup>, IMUserGroupRepository
    {
        public MUserGroupRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public MUserGroup Get(string id)
        {
            return _context.MUserGroups.Where(x => x.IsDeleted == false && x.UserGroupId == id).FirstOrDefault();
        }

        public List<MUserGroup> GetAll()
        {
            return _context.MUserGroups.Where(x => x.IsDeleted == false).ToList();
        }

        public void Add(MUserGroup entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<MUserGroup>().Update(entity);
        }

        public void Update(MUserGroup entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MUserGroup>().Update(entity);
        }

        public void Delete(MUserGroup entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MUserGroup>().Update(entity);
        }

        public MUserGroupViewModel.ReadUserGroup SelectOne(string id)
        {
            return Get_MUserGroup(id, null).Select(o =>
                new MUserGroupViewModel.ReadUserGroup
                {
                    UserGroupId = o.UserGroupId,
                    UserType = new MUserTypeViewModel.ReadUserType(o.UserTypeId, o.UserType),
                    Name = o.Name,
                    UserId = o.UserId,
                    Username = o.Username,
                    OfficialName = o.OfficialName
                }).FirstOrDefault();
        }

        public List<MUserGroupViewModel.ReadUserGroup> SelectAll()
        {
            return Get_MUserGroup(null, null).Select(o =>
                new MUserGroupViewModel.ReadUserGroup
                {
                    UserGroupId = o.UserGroupId,
                    UserType = new MUserTypeViewModel.ReadUserType(o.UserTypeId, o.UserType),
                    Name = o.Name,
                    UserId = o.UserId,
                    Username = o.Username,
                    OfficialName = o.OfficialName
                }).ToList();
        }

        public bool anyInsert(MUserGroup entity)
        {
            return GetAll().Any(i => i.Name == entity.Name.Trim());
        }

        public bool anyUpdate(MUserGroup entity)
        {
            return GetAll().Any(i => i.Name == entity.Name.Trim() && i.UserGroupId != entity.UserGroupId);
        }

        public List<fn_Get_MUserGroup> Get_MUserGroup(string userGroupId, string userTypeId)
        {
            var result = _context.Set<fn_Get_MUserGroup>().FromSqlRaw("select * from dbo.fn_Get_MUserGroup({0},{1})", userGroupId, userTypeId);
            return result.ToList();
        }

        public List<fn_Get_MUserMember> Get_MUserMember(string userMemberId, string userGroupId, string userTypeId)
        {
            var result = _context.Set<fn_Get_MUserMember>().FromSqlRaw("select * from dbo.fn_Get_MUserMember({0},{1},{2})", userMemberId, userGroupId, userTypeId);
            return result.ToList();
        }

        public List<MUserGroupViewModel.ReadUserGroupMember> SelectUserGroupMember(string userGroupId, string userTypeId)
        {
            return Get_MUserGroup(null, null).ToList().Select(o =>
                new MUserGroupViewModel.ReadUserGroupMember
                {
                    UserGroupId = o.UserGroupId,
                    UserType = new MUserTypeViewModel.ReadUserType(o.UserTypeId, o.UserType),
                    Name = o.Name,
                    UserId = o.UserId,
                    Username = o.Username,
                    OfficialName = o.OfficialName,
                    UserMember = Get_MUserMember(null, o.UserGroupId, o.UserTypeId).ToList().Select(o=> new MUserMemberViewModel.ReadUserMember { 
                        UserMemberId = o.UserMemberId,
                        UserId = o.UserIdMember,
                        Username = o.UsernameMember,
                        OfficialName = o.OfficialNameMember
                    }).ToList()
                }).ToList();
        }
    }
}
