﻿using DigitalAudit.Helper;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Master
{
    public interface IMTemplatePermissionTypeRepository : IGenericRepository<MTemplatePermissionType>
    {
        MTemplatePermissionTypeViewModel.ReadMTemplatePermissionType SelectOne(int id);
        List<MTemplatePermissionTypeViewModel.ReadMTemplatePermissionType> SelectAll();

        void Add(MTemplatePermissionType entity, string user, DateTime actiondate);
        void Update(MTemplatePermissionType entity, string user, DateTime actiondate);
        void Delete(MTemplatePermissionType entity, string user, DateTime actiondate);
        bool anyInsert(MTemplatePermissionType entity);
        bool anyUpdate(MTemplatePermissionType entity);
        bool anyDelete(MTemplatePermissionType entity);
    }

    public class MTemplatePermissionTypeRepository : GenericRepository<MTemplatePermissionType>, IMTemplatePermissionTypeRepository
    {
        public MTemplatePermissionTypeRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public MTemplatePermissionTypeViewModel.ReadMTemplatePermissionType SelectOne(int id)
        {
            return _context.MTemplatePermissionTypes.Where(x => x.IsDeleted == false && x.TemplatePermissionTypeId == id).Select(o =>
                new MTemplatePermissionTypeViewModel.ReadMTemplatePermissionType
                {
                    TemplatePermissionTypeId = o.TemplatePermissionTypeId,
                    Name = o.PermissionType
                }).FirstOrDefault();
        }

        public List<MTemplatePermissionTypeViewModel.ReadMTemplatePermissionType> SelectAll()
        {
            return _context.MTemplatePermissionTypes.Where(x => x.IsDeleted == false).Select(o =>
                new MTemplatePermissionTypeViewModel.ReadMTemplatePermissionType
                {
                    TemplatePermissionTypeId = o.TemplatePermissionTypeId,
                    Name = o.PermissionType
                }).ToList();
        }

        public MTemplatePermissionType Get(int id)
        {
            return _context.MTemplatePermissionTypes.Where(x => x.IsDeleted == false && x.TemplatePermissionTypeId == id).FirstOrDefault();
        }

        public List<MTemplatePermissionType> GetAll()
        {
            return _context.MTemplatePermissionTypes.Where(x => x.IsDeleted == false).ToList();
        }

        public void Add(MTemplatePermissionType entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<MTemplatePermissionType>().Update(entity);
        }

        public void Update(MTemplatePermissionType entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MTemplatePermissionType>().Update(entity);
        }

        public void Delete(MTemplatePermissionType entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MTemplatePermissionType>().Update(entity);
        }

        public bool anyInsert(MTemplatePermissionType entity)
        {
            return GetAll().Any(i => i.PermissionType == entity.PermissionType);
        }

        public bool anyUpdate(MTemplatePermissionType entity)
        {
            return GetAll().Any(i => i.PermissionType == entity.PermissionType && i.TemplatePermissionTypeId != entity.TemplatePermissionTypeId);
        }

        public bool anyDelete(MTemplatePermissionType entity)
        {
            return _context.MTemplatePermissionTypes.Any(i => i.IsDeleted == false && i.TemplatePermissionTypeId == entity.TemplatePermissionTypeId);
        }
    }
}
