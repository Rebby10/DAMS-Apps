﻿using DigitalAudit.Helper;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Master
{
    public interface IMTemplateCategoryRepository : IGenericRepository<MTemplateCategory>
    {
        MTemplateCategoryViewModel.ReadTemplateCategory SelectOne(int id);
        List<MTemplateCategoryViewModel.ReadTemplateCategory> SelectAll();

        void Add(MTemplateCategory entity, string user, DateTime actiondate);
        void Update(MTemplateCategory entity, string user, DateTime actiondate);
        void Delete(MTemplateCategory entity, string user, DateTime actiondate);
        bool anyInsert(MTemplateCategory entity);
        bool anyUpdate(MTemplateCategory entity);
        bool anyDelete(MTemplateCategory entity);
    }

    public class MTemplateCategoryRepository : GenericRepository<MTemplateCategory>, IMTemplateCategoryRepository
    {
        public MTemplateCategoryRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public MTemplateCategoryViewModel.ReadTemplateCategory SelectOne(int id)
        {
            return _context.MTemplateCategories.Where(x => x.IsDeleted == false && x.CategoryId == id).Select(o =>
                new MTemplateCategoryViewModel.ReadTemplateCategory
                {
                    CategoryId = o.CategoryId,
                    Name = o.Name
                }).FirstOrDefault();
        }

        public List<MTemplateCategoryViewModel.ReadTemplateCategory> SelectAll()
        {
            return _context.MTemplateCategories.Where(x => x.IsDeleted == false).Select(o =>
                new MTemplateCategoryViewModel.ReadTemplateCategory
                {
                    CategoryId = o.CategoryId,
                    Name = o.Name
                }).ToList();
        }

        public MTemplateCategory Get(int id)
        {
            return _context.MTemplateCategories.Where(x => x.IsDeleted == false && x.CategoryId == id).FirstOrDefault();
        }

        public List<MTemplateCategory> GetAll()
        {
            return _context.MTemplateCategories.Where(x => x.IsDeleted == false).ToList();
        }

        public void Add(MTemplateCategory entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<MTemplateCategory>().Update(entity);
        }

        public void Update(MTemplateCategory entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MTemplateCategory>().Update(entity);
        }

        public void Delete(MTemplateCategory entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MTemplateCategory>().Update(entity);
        }

        public bool anyInsert(MTemplateCategory entity)
        {
            return GetAll().Any(i => i.Name == entity.Name);
        }

        public bool anyUpdate(MTemplateCategory entity)
        {
            return GetAll().Any(i => i.Name == entity.Name && i.CategoryId != entity.CategoryId);
        }

        public bool anyDelete(MTemplateCategory entity)
        {
            return _context.MTemplateCategories.Any(i => i.IsDeleted == false && i.CategoryId == entity.CategoryId);
        }
    }
}
