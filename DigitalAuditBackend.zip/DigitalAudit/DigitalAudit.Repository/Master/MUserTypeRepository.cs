﻿using DigitalAudit.Helper;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Master
{
    public interface IMUserTypeRepository : IGenericRepository<MUserType>
    {
        MUserTypeViewModel.ReadUserType SelectOne(string id);
        List<MUserTypeViewModel.ReadUserType> SelectAll();
        void Update(MUserType entity, string user, DateTime actiondate);
        void Delete(MUserType entity, string user, DateTime actiondate);
        bool anyInsert(MUserType entity);
        bool anyUpdate(MUserType entity);
    }

    public class MUserTypeRepository : GenericRepository<MUserType>, IMUserTypeRepository
    {
        public MUserTypeRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public MUserTypeViewModel.ReadUserType SelectOne(string id)
        {
            return _context.MUserTypes.Where(x => x.IsDeleted == false && x.UserTypeId == id).Select(o =>
                new MUserTypeViewModel.ReadUserType
                {
                    UserTypeId = o.UserTypeId,
                    Name = o.Name
                }).FirstOrDefault();
        }

        public List<MUserTypeViewModel.ReadUserType> SelectAll()
        {
            return _context.MUserTypes.Where(x => x.IsDeleted == false).Select(o =>
                new MUserTypeViewModel.ReadUserType
                {
                    UserTypeId = o.UserTypeId,
                    Name = o.Name
                }).ToList();
        }

        public MUserType Get(string id)
        {
            return _context.MUserTypes.Where(x => x.IsDeleted == false && x.UserTypeId == id).FirstOrDefault();
        }

        public List<MUserType> GetAll()
        {
            return _context.MUserTypes.Where(x => x.IsDeleted == false).ToList();
        }

        public void Add(MUserType entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<MUserType>().Update(entity);
        }

        public void Update(MUserType entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MUserType>().Update(entity);
        }

        public void Delete(MUserType entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MUserType>().Update(entity);
        }

        public bool anyInsert(MUserType entity)
        {
            return GetAll().Any(i => i.Name == entity.Name);
        }

        public bool anyUpdate(MUserType entity)
        {
            return GetAll().Any(i => i.Name == entity.Name && i.UserTypeId != entity.UserTypeId);
        }
    }
}
