﻿using DigitalAudit.Helper;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Master
{
    public interface IMRegionRepository : IGenericRepository<MRegion>
    {
        MRegionViewModel.ReadRegion SelectOne(string id);
        List<MRegionViewModel.ReadRegion> SelectAll();

        void Add(MRegion entity, string user, DateTime actiondate);
        void Update(MRegion entity, string user, DateTime actiondate);
        void Delete(MRegion entity, string user, DateTime actiondate);
        bool anyInsert(MRegion entity);
        bool anyUpdate(MRegion entity);
        bool anyDelete(MRegion entity);
    }

    public class MRegionRepository : GenericRepository<MRegion>, IMRegionRepository
    {
        public MRegionRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public MRegionViewModel.ReadRegion SelectOne(string id)
        {
            return _context.MRegions.Where(x => x.IsDeleted == false && x.RegionId == id).Select(o =>
                new MRegionViewModel.ReadRegion
                {
                    RegionId = o.RegionId,
                    Name = o.Name
                }).FirstOrDefault();
        }

        public List<MRegionViewModel.ReadRegion> SelectAll()
        {
            return _context.MRegions.Where(x => x.IsDeleted == false).Select(o =>
                new MRegionViewModel.ReadRegion
                {
                    RegionId = o.RegionId,
                    Name = o.Name
                }).ToList();
        }

        public MRegion Get(string id)
        {
            return _context.MRegions.Where(x => x.IsDeleted == false && x.RegionId == id).FirstOrDefault();
        }

        public List<MRegion> GetAll()
        {
            return _context.MRegions.Where(x => x.IsDeleted == false).ToList();
        }

        public void Add(MRegion entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<MRegion>().Update(entity);
        }

        public void Update(MRegion entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MRegion>().Update(entity);
        }

        public void Delete(MRegion entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MRegion>().Update(entity);
        }

        public bool anyInsert(MRegion entity)
        {
            return GetAll().Any(i => i.Name == entity.Name);
        }

        public bool anyUpdate(MRegion entity)
        {
            return GetAll().Any(i => i.Name == entity.Name && i.RegionId != entity.RegionId);
        }

        public bool anyDelete(MRegion entity)
        {
            return _context.MAuditLocations.Any(i => i.IsDeleted == false && i.RegionId == entity.RegionId);
        }
    }
}
