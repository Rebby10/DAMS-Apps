﻿using DigitalAudit.Helper;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Master
{
    public interface IMAuditResultCategoryRepository : IGenericRepository<MAuditResultCategory>
    {
        MAuditResultCategoryViewModel.ReadAuditResultCategory SelectOne(string id);
        List<MAuditResultCategoryViewModel.ReadAuditResultCategory> SelectAll();
        void Update(MAuditResultCategory entity, string user, DateTime actiondate);
        void Delete(MAuditResultCategory entity, string user, DateTime actiondate);
        bool anyInsert(MAuditResultCategory entity);
        bool anyUpdate(MAuditResultCategory entity);
    }

    public class MAuditResultCategoryRepository : GenericRepository<MAuditResultCategory>, IMAuditResultCategoryRepository
    {
        public MAuditResultCategoryRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public MAuditResultCategory Get(string id)
        {
            return _context.MAuditResultCategories.Where(x => x.IsDeleted == false && x.AuditResultCategoryId == id).FirstOrDefault();
        }

        public List<MAuditResultCategory> GetAll()
        {
            return _context.MAuditResultCategories.Where(x => x.IsDeleted == false).ToList();
        }

        public void Add(MAuditResultCategory entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<MAuditResultCategory>().Update(entity);
        }

        public void Update(MAuditResultCategory entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MAuditResultCategory>().Update(entity);
        }

        public void Delete(MAuditResultCategory entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MAuditResultCategory>().Update(entity);
        }

        public bool anyInsert(MAuditResultCategory entity)
        {
            return GetAll().Any(i => i.Name == entity.Name);
        }

        public bool anyUpdate(MAuditResultCategory entity)
        {
            return GetAll().Any(i => i.Name == entity.Name && i.AuditResultCategoryId != entity.AuditResultCategoryId);
        }

        public MAuditResultCategoryViewModel.ReadAuditResultCategory SelectOne(string id)
        {
            return _context.MAuditResultCategories.Where(x => x.IsDeleted == false && x.AuditResultCategoryId == id).Select(o =>
                new MAuditResultCategoryViewModel.ReadAuditResultCategory
                {
                    AuditResultCategoryId = o.AuditResultCategoryId,
                    Name = o.Name
                }).FirstOrDefault();
        }

        public List<MAuditResultCategoryViewModel.ReadAuditResultCategory> SelectAll()
        {
            return _context.MAuditResultCategories.Where(x => x.IsDeleted == false).Select(o =>
                new MAuditResultCategoryViewModel.ReadAuditResultCategory
                {
                    AuditResultCategoryId = o.AuditResultCategoryId,
                    Name = o.Name
                }).ToList();
        }
    }
}
