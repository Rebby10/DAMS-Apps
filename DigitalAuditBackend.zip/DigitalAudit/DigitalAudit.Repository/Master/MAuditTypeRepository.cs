﻿using DigitalAudit.Helper;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Master
{
    public interface IMAuditTypeRepository : IGenericRepository<MAuditType>
    {
        MAuditTypeViewModel.ReadAuditType SelectOne(string id);
        List<MAuditTypeViewModel.ReadAuditType> SelectAll();
        void Update(MAuditType entity, string user, DateTime actiondate);
        void Delete(MAuditType entity, string user, DateTime actiondate);
        bool anyInsert(MAuditType entity);
        bool anyUpdate(MAuditType entity);
        bool anyDelete(MAuditType entity);

        public MAuditType Get(string id);
        public List<MAuditType> GetAll();
    }

    public class MAuditTypeRepository : GenericRepository<MAuditType>, IMAuditTypeRepository
    {
        public MAuditTypeRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public MAuditTypeViewModel.ReadAuditType SelectOne(string id)
        {
            return _context.MAuditTypes.Where(x => x.IsDeleted == false && x.AuditTypeId == id).Select(o =>
                new MAuditTypeViewModel.ReadAuditType
                {
                    AuditTypeId = o.AuditTypeId,
                    Name = o.Name
                }).FirstOrDefault();
        }

        public List<MAuditTypeViewModel.ReadAuditType> SelectAll()
        {
            return _context.MAuditTypes.Where(x => x.IsDeleted == false).Select(o =>
                new MAuditTypeViewModel.ReadAuditType
                {
                    AuditTypeId = o.AuditTypeId,
                    Name = o.Name
                }).ToList();
        }

        public MAuditType Get(string id)
        {
            return _context.MAuditTypes.Where(x => x.IsDeleted == false && x.AuditTypeId == id).FirstOrDefault();
        }

        public List<MAuditType> GetAll()
        {
            return _context.MAuditTypes.Where(x => x.IsDeleted == false).ToList();
        }

        public void Add(MAuditType entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<MAuditType>().Update(entity);
        }

        public void Update(MAuditType entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MAuditType>().Update(entity);
        }

        public void Delete(MAuditType entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MAuditType>().Update(entity);
        }

        public bool anyInsert(MAuditType entity)
        {
            return GetAll().Any(i => i.Name == entity.Name);
        }

        public bool anyUpdate(MAuditType entity)
        {
            return GetAll().Any(i => i.Name == entity.Name && i.AuditTypeId != entity.AuditTypeId);
        }

        public bool anyDelete(MAuditType entity)
        {
            return _context.TrIssues.Any(i => i.IsDeleted == false && i.AuditTypeId == entity.AuditTypeId);
        }
    }
}
