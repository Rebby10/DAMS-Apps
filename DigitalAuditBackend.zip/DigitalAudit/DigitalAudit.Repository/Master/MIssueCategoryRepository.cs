﻿using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Master
{
    public interface IMIssueCategoryRepository : IGenericRepository<MIssueCategory>
    {
        MIssueCategoryViewModel.ReadIssueCategory SelectOne(int id);
        List<MIssueCategoryViewModel.ReadIssueCategory> SelectAll();
        void Update(MIssueCategory entity, string user, DateTime actiondate);
        void Delete(MIssueCategory entity, string user, DateTime actiondate);
    }
    class MIssueCategoryRepository : GenericRepository<MIssueCategory>, IMIssueCategoryRepository
    {
        public MIssueCategoryRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public MIssueCategory Get(int id)
        {
            return _context.MIssueCategories.Where(x => x.IsDeleted == false && x.IssueCategoryId == id).FirstOrDefault();
        }

        public List<MIssueCategory> GetAll()
        {
            return _context.MIssueCategories.Where(x => x.IsDeleted == false).ToList();
        }

        public void Add(MIssueCategory entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<MIssueCategory>().Update(entity);
        }

        public void Delete(MIssueCategory entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MIssueCategory>().Update(entity);
        }

        public void Update(MIssueCategory entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MIssueCategory>().Update(entity);
        }

        public MIssueCategoryViewModel.ReadIssueCategory SelectOne(int id)
        {
            return _context.MIssueCategories.Where(x => x.IsDeleted == false && x.IssueCategoryId == id).Select(o =>
                new MIssueCategoryViewModel.ReadIssueCategory
                {
                    IssueCategoryId = o.IssueCategoryId,
                    Name = o.Name
                }).FirstOrDefault();
        }

        public List<MIssueCategoryViewModel.ReadIssueCategory> SelectAll()
        {
            return _context.MIssueCategories.Where(x => x.IsDeleted == false).Select(o =>
                new MIssueCategoryViewModel.ReadIssueCategory
                {
                    IssueCategoryId = o.IssueCategoryId,
                    Name = o.Name
                }).ToList();
        }
    }
}
