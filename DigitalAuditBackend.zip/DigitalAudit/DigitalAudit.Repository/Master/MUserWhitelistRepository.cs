﻿using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Master
{
    public interface IMUserWhitelistRepository : IGenericRepository<MUserWhitelist>
    {
        MUserWhitelistViewModel.ReadUserWhitelist SelectOne(string id);
        List<MUserWhitelistViewModel.ReadUserWhitelist> SelectAll(string userWhitelistId, string userId, int? email, string officialname);
        StatusViewModel SyncUserWhitelist();
        List<fn_Get_MUserWhitelist> Get_MUserWhitelist(string userWhitelistId, string userId, int? email, string officialname);
        void Update(MUserWhitelist entity, string user, DateTime actiondate);
        void Delete(MUserWhitelist entity, string user, DateTime actiondate);
        bool anyInsert(MUserWhitelist entity);
        bool anyUpdate(MUserWhitelist entity);
        MUserSyncAllViewModel.ReadUserLite GetUserLite(string id);

    }

    public class MUserWhitelistRepository : GenericRepository<MUserWhitelist>, IMUserWhitelistRepository
    {
        public MUserWhitelistRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public List<fn_Get_MUserWhitelist> Get_MUserWhitelist(string userWhitelistId, string userId, int? email, string officialname)
        {
            var result = _context.Set<fn_Get_MUserWhitelist>().FromSqlRaw("select * from dbo.fn_Get_MUserWhitelist({0},{1},{2},{3})", userWhitelistId, userId, email, officialname);
            return result.ToList();
        }

        public MUserWhitelistViewModel.ReadUserWhitelist SelectOne(string id)
        {
            return Get_MUserWhitelist(id, null, null, null).Select(o =>
                new MUserWhitelistViewModel.ReadUserWhitelist
                {
                    UserWhitelistId = o.UserWhitelistId,
                    User = new MUserSyncAllViewModel.ReadUserLite(o.UserId, o.DisplayName, o.Email)
                }).FirstOrDefault();
        }

        public MUserSyncAllViewModel.ReadUserLite GetUserLite(string id)
        {
            MUserSyncAllViewModel.ReadUserLite result = new MUserSyncAllViewModel.ReadUserLite();
            var data = _context.MUserSyncAlls;
            result = _context.MUserSyncAlls.Where(x => x.IsDeleted == false && x.UserId == id).Select(o =>
                new MUserSyncAllViewModel.ReadUserLite
                {
                    UserId = o.UserId,
                    DisplayName = o.DisplayName,
                    Email = o.Email
                }).FirstOrDefault();
            return result;
        }

        public List<MUserWhitelistViewModel.ReadUserWhitelist> SelectAll(string userWhitelistId, string userId, int? email, string officialname)
        {
            return Get_MUserWhitelist(userWhitelistId, userId, email, officialname).Select(o =>
                new MUserWhitelistViewModel.ReadUserWhitelist
                {
                    UserWhitelistId = o.UserWhitelistId,
                    User = new MUserSyncAllViewModel.ReadUserLite(o.UserId, o.DisplayName, o.Email)
                }).ToList();
        }

        public StatusViewModel SyncUserWhitelist()
        {
            IEnumerable<StatusViewModel> result = _context.Set<StatusViewModel>().FromSqlRaw("exec spUserWhitelist_Syncronize");
            return result.FirstOrDefault();
        }

        public void Add(MUserWhitelist entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<MUserWhitelist>().Update(entity);
        }

        public void Update(MUserWhitelist entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MUserWhitelist>().Update(entity);
        }

        public void Delete(MUserWhitelist entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MUserWhitelist>().Update(entity);
        }

        public bool anyInsert(MUserWhitelist entity)
        {
            return GetAll().Any(i => i.UserId == entity.UserId);
        }

        public bool anyUpdate(MUserWhitelist entity)
        {
            return GetAll().Any(i => i.UserId == entity.UserId && i.UserWhitelistId != entity.UserWhitelistId);
        }
    }
}
