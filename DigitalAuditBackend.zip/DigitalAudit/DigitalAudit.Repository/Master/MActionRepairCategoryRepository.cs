﻿using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DigitalAudit.Repository.Master
{
    public interface IMActionRepairCategoryRepository : IGenericRepository<MActionRepairCategory>
    {
        MActionRepairCategoryViewModel.ReadActionRepairCategory SelectOne(string id);
        List<MActionRepairCategoryViewModel.ReadActionRepairCategory> SelectAll();
        void Update(MActionRepairCategory entity, string user, DateTime actiondate);
        void Delete(MActionRepairCategory entity, string user, DateTime actiondate);
    }
    public class MActionRepairCategoryRepository : GenericRepository<MActionRepairCategory>, IMActionRepairCategoryRepository
    {
        public MActionRepairCategoryRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public void Delete(MActionRepairCategory entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MActionRepairCategory>().Update(entity);
        }

        public List<MActionRepairCategoryViewModel.ReadActionRepairCategory> SelectAll()
        {
            return _context.MActionRepairCategories.Where(x => x.IsDeleted == false)
                .OrderBy(o => o.Name)
                .Select(o =>
                new MActionRepairCategoryViewModel.ReadActionRepairCategory
                {
                    Id = o.ActionRepairCategoryId,
                    Name = o.Name
                }).ToList();
        }

        public MActionRepairCategoryViewModel.ReadActionRepairCategory SelectOne(string id)
        {
            return _context.MActionRepairCategories.Where(x => x.IsDeleted == false && x.ActionRepairCategoryId == id).Select(o =>
                new MActionRepairCategoryViewModel.ReadActionRepairCategory
                {
                    Id = o.ActionRepairCategoryId,
                    Name = o.Name
                }).SingleOrDefault();
        }

        public void Update(MActionRepairCategory entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MActionRepairCategory>().Update(entity);
        }
    }
}
