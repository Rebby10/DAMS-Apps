﻿using DigitalAudit.Helper;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Master
{
    public interface IMResponseListRepository : IGenericRepository<MResponseList>
    {
        MResponseListViewModel.ReadResponseList SelectOne(int id);
        List<MResponseListViewModel.ReadResponseList> SelectAll();

        void Add(MResponseList entity, string user, DateTime actiondate);
        void Update(MResponseList entity, string user, DateTime actiondate);
        void Delete(MResponseList entity, string user, DateTime actiondate);
        bool anyInsert(MResponseList entity);
        bool anyUpdate(MResponseList entity);
        bool anyDelete(MResponseList entity);
    }

    public class MResponseListRepository : GenericRepository<MResponseList>, IMResponseListRepository
    {
        public MResponseListRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public MResponseListViewModel.ReadResponseList SelectOne(int id)
        {
            return _context.MResponseLists.Where(x => x.IsDeleted == false && x.ListId == id).Select(o =>
                new MResponseListViewModel.ReadResponseList
                {
                    ListId = o.ListId,
                    ResponseId = o.ResponseId,
                    Name = o.Name,
                    Score = o.Score,
                    IsFailedResponse = o.IsFailedResponse,
                    SeqNo = o.SeqNo
                }).FirstOrDefault();
        }

        public List<MResponseListViewModel.ReadResponseList> SelectAll()
        {
            return _context.MResponseLists.Where(x => x.IsDeleted == false).Select(o =>
                new MResponseListViewModel.ReadResponseList
                {
                    ResponseId = o.ResponseId,
                    Name = o.Name
                }).ToList();
        }

        public MResponseList Get(int id)
        {
            return _context.MResponseLists.Where(x => x.IsDeleted == false && x.ListId == id).FirstOrDefault();
        }

        public List<MResponseList> GetAll()
        {
            return _context.MResponseLists.Where(x => x.IsDeleted == false).ToList();
        }

        public void Add(MResponseList entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<MResponseList>().Update(entity);
        }

        public void Update(MResponseList entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MResponseList>().Update(entity);
        }

        public void Delete(MResponseList entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MResponseList>().Update(entity);
        }

        public bool anyInsert(MResponseList entity)
        {
            return GetAll().Any(i => i.Name == entity.Name);
        }

        public bool anyUpdate(MResponseList entity)
        {
            return GetAll().Any(i => i.Name == entity.Name && i.ListId != entity.ListId);
        }

        public bool anyDelete(MResponseList entity)
        {
            return _context.MResponseLists.Any(i => i.IsDeleted == false && i.ListId == entity.ListId);
        }
    }
}
