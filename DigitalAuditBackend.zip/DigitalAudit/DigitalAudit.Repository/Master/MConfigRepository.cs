﻿using DigitalAudit.Helper;
using DigitalAudit.Model.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Master
{
    public interface IMConfigRepository : IGenericRepository<MConfig>
    {
        string GetConfigValue(string key);
        void Update(MConfig entity, string user, DateTime actiondate);
        void Delete(MConfig entity, string user, DateTime actiondate);
    }

    public class MConfigRepository : GenericRepository<MConfig>, IMConfigRepository
    {
        public MConfigRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public MConfig Get(int id)
        {
            return _context.MConfigs.Where(x => x.IsDeleted == false && x.ConfigId == id).FirstOrDefault();
        }

        public IEnumerable<MConfig> GetAll()
        {
            return _context.MConfigs.Where(x => x.IsDeleted == false);
        }

        public void Add(MConfig entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<MConfig>().Update(entity);
        }

        public void Update(MConfig entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MConfig>().Update(entity);
        }

        public void Delete(MConfig entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MConfig>().Update(entity);
        }

        public string GetConfigValue(string key)
        {
            string result = null;
            MConfig entity = _context.MConfigs.Where(x => x.IsDeleted == false && x.ConfigKey == key).FirstOrDefault();
            if (entity != null)
            {
                result = entity.ConfigValue;
            }
            return result;
        }
    }
}
