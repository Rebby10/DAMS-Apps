﻿using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Master
{
    public interface IMUserSyncUploadRepository : IGenericRepository<MUserSyncUpload>
    {
        void AddLists(List<MUserSyncUpload> entities);
        void Update(MUserSyncUpload entity, string user, DateTime actiondate);
        void Delete(MUserSyncUpload entity, string user, DateTime actiondate);
        StatusViewModel SyncronizeUserSync_Syncronize(string sessionId);
    }

    public class MUserSyncUploadRepository : GenericRepository<MUserSyncUpload>, IMUserSyncUploadRepository
    {
        public MUserSyncUploadRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public MUserRole Get(string id)
        {
            return _context.MUserRoles.Where(x => x.IsDeleted == false && x.UserRoleId == id).FirstOrDefault();
        }

        public IEnumerable<MUserSyncUpload> GetAll()
        {
            return _context.MUserSyncUploads.Where(x => x.IsDeleted == false);
        }

        public void Add(MUserSyncUpload entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<MUserSyncUpload>().Update(entity);
        }

        public void AddLists(List<MUserSyncUpload> entities)
        {
            _context.Set<MUserSyncUpload>().AddRange(entities);
        }

        public void Update(MUserSyncUpload entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MUserSyncUpload>().Update(entity);
        }

        public void Delete(MUserSyncUpload entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MUserSyncUpload>().Update(entity);
        }

        public StatusViewModel SyncronizeUserSync_Syncronize(string sessionId)
        {
            IEnumerable<StatusViewModel> result = _context.Set<StatusViewModel>().FromSqlRaw("exec spUserSync_Syncronize {0}", sessionId);
            return result.FirstOrDefault();
        }

    }
}
