﻿using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace DigitalAudit.Repository.Master
{
    public interface IMIssueStatusRepository : IGenericRepository<MIssueStatus>
    {
        MIssueStatusViewModel.ReadIssueStatus SelectOne(int id);
        List<MIssueStatusViewModel.ReadIssueStatus> SelectAll();

        void Update(MIssueStatus entity, string user, DateTime actiondate);
        void Delete(MIssueStatus entity, string user, DateTime actiondate);
    }
    public class MIssueStatusRepository : GenericRepository<MIssueStatus>, IMIssueStatusRepository
    {
        public MIssueStatusRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public MIssueStatus Get(int id)
        {
            return _context.MIssueStatuses.Where(x => x.IsDeleted == false && x.StatusId == id).FirstOrDefault();
        }

        public List<MIssueStatus> GetAll()
        {
            return _context.MIssueStatuses.Where(x => x.IsDeleted == false).ToList();
        }

        public void Add(MIssueStatus entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<MIssueStatus>().Update(entity);
        }

        public void Delete(MIssueStatus entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MIssueStatus>().Update(entity);
        }

        public void Update(MIssueStatus entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MIssueStatus>().Update(entity);
        }

        public MIssueStatusViewModel.ReadIssueStatus SelectOne(int id)
        {
            return _context.MIssueStatuses.Where(x => x.IsDeleted == false && x.StatusId == id).Select(o =>
                new MIssueStatusViewModel.ReadIssueStatus
                {
                    StatusId = o.StatusId,
                    Name = o.Name
                }).FirstOrDefault();
        }

        public List<MIssueStatusViewModel.ReadIssueStatus> SelectAll()
        {
            return _context.MIssueStatuses.Where(x => x.IsDeleted == false).Select(o =>
                new MIssueStatusViewModel.ReadIssueStatus
                {
                    StatusId = o.StatusId,
                    Name = o.Name
                }).ToList();
        }
    }
}
