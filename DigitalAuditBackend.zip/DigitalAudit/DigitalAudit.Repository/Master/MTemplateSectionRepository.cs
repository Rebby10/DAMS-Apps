﻿using DigitalAudit.Helper;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Master
{
    public interface IMTemplateSectionRepository : IGenericRepository<MTemplateSection>
    {
        MTemplateSectionViewModel.ReadTemplateSection SelectOne(string id);
        List<MTemplateSectionViewModel.ReadTemplateSection> SelectAll();

        void Add(MTemplateSection entity, string user, DateTime actiondate);
        void Update(MTemplateSection entity, string user, DateTime actiondate);
        void Delete(MTemplateSection entity, string user, DateTime actiondate);
        //bool anyInsert(MTemplateSection entity);
        //bool anyUpdate(MTemplateSection entity);
        //bool anyDelete(MTemplateSection entity);
    }

    public class MTemplateSectionRepository : GenericRepository<MTemplateSection>, IMTemplateSectionRepository
    {
        public MTemplateSectionRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public MTemplateSectionViewModel.ReadTemplateSection SelectOne(string id)
        {
            return _context.MTemplateSections.Where(x => x.IsDeleted == false && x.SectionId == id).Select(o =>
                new MTemplateSectionViewModel.ReadTemplateSection
                {
                    SectionId = o.SectionId,
                    PageId = o.PageId,
                    Name = o.Name,
                    SeqNo = o.SeqNo
                }).FirstOrDefault();
        }

        public List<MTemplateSectionViewModel.ReadTemplateSection> SelectAll()
        {
            return _context.MTemplateSections.Where(x => x.IsDeleted == false).Select(o =>
                new MTemplateSectionViewModel.ReadTemplateSection
                {
                    SectionId = o.SectionId,
                    PageId = o.PageId,
                    Name = o.Name,
                    SeqNo = o.SeqNo
                }).ToList();
        }

        public MTemplateSection Get(string id)
        {
            return _context.MTemplateSections.Where(x => x.IsDeleted == false && x.SectionId == id).FirstOrDefault();
        }

        public List<MTemplateSection> GetAll()
        {
            return _context.MTemplateSections.Where(x => x.IsDeleted == false).ToList();
        }

        public void Add(MTemplateSection entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<MTemplateSection>().Update(entity);
        }

        public void Update(MTemplateSection entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MTemplateSection>().Update(entity);
        }

        public void Delete(MTemplateSection entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MTemplateSection>().Update(entity);
        }

        //public bool anyInsert(MTemplateSection entity)
        //{
        //    return GetAll().Any(i => i.Name == entity.Name);
        //}

        //public bool anyUpdate(MTemplateSection entity)
        //{
        //    return GetAll().Any(i => i.Name == entity.Name && i.TemplateSectionId != entity.TemplateSectionId);
        //}

        //public bool anyDelete(MTemplateSection entity)
        //{
        //    return _context.MAuditLocations.Any(i => i.IsDeleted == false && i.TemplateSectionId == entity.TemplateSectionId);
        //}
    }
}
