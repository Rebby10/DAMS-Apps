﻿using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Master
{
    public interface IMLogTypeRepository : IGenericRepository<MLogType>
    {
        MLogTypeViewModel.ReadLogType SelectOne(int id);
        List<MLogTypeViewModel.ReadLogType> SelectAll();
        void Update(MLogType entity, string user, DateTime actiondate);
        void Delete(MLogType entity, string user, DateTime actiondate);
        public List<MLogType> GetAllLogType();
        public MLogType GetLogType(int id);

    }

    public class MLogTypeRepository : GenericRepository<MLogType>, IMLogTypeRepository
    {
        public MLogTypeRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public MLogType GetLogType(int id)
        {
            return _context.MLogTypes.Where(x => x.IsDeleted == false && x.LogTypeId == id).FirstOrDefault();
        }

        public List<MLogType> GetAllLogType()
        {
            return _context.MLogTypes.Where(x => x.IsDeleted == false).ToList();
        }

        public void Add(MLogType entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<MLogType>().Update(entity);
        }

        public void Delete(MLogType entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MLogType>().Update(entity);
        }

        public void Update(MLogType entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MLogType>().Update(entity);
        }

        public MLogTypeViewModel.ReadLogType SelectOne(int id)
        {
            return _context.MLogTypes.Where(x => x.IsDeleted == false && x.LogTypeId == id).Select(o =>
                new MLogTypeViewModel.ReadLogType
                {
                    LogTypeId = o.LogTypeId,
                    Name = o.Name
                }).FirstOrDefault();
        }

        public List<MLogTypeViewModel.ReadLogType> SelectAll()
        {
            return _context.MLogTypes.Where(x => x.IsDeleted == false).Select(o =>
                new MLogTypeViewModel.ReadLogType
                {
                    LogTypeId = o.LogTypeId,
                    Name = o.Name
                }).ToList();
        }
    }
}
