﻿using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Master
{
    public interface IMUserSyncWhitelistRepository : IGenericRepository<MUserSyncWhitelist>
    {
        MUserSyncWhitelist SelectOne(string id);
        List<MUserSyncWhitelist> SelectAll();
        void AddLists(List<MUserSyncWhitelist> entities);
        StatusViewModel DeleteUserSyncWhitelist();

    }

    public class MUserSyncWhitelistRepository : GenericRepository<MUserSyncWhitelist>, IMUserSyncWhitelistRepository
    {
        public MUserSyncWhitelistRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public MUserSyncWhitelist SelectOne(string id)
        {
            return _context.MUserSyncWhitelists.Where(x => x.UserSyncWhitelistId == id).FirstOrDefault();
        }

        public List<MUserSyncWhitelist> SelectAll()
        {
            return _context.MUserSyncWhitelists.ToList();
        }

        public void AddLists(List<MUserSyncWhitelist> entities)
        {
            _context.Set<MUserSyncWhitelist>().AddRange(entities);
        }

        public StatusViewModel DeleteUserSyncWhitelist()
        {
            IEnumerable<StatusViewModel> result = _context.Set<StatusViewModel>().FromSqlRaw("exec sp_DeleteUserSyncWhitelist");
            return result.FirstOrDefault();
        }

    }
}
