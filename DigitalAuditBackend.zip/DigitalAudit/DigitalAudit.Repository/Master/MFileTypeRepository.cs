﻿using DigitalAudit.Model.Database;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;


namespace DigitalAudit.Repository.Master
{
    public interface IMFileTypeRepository : IGenericRepository<MFileType>
    {
        void Update(MFileType entity, string user, DateTime actiondate);
        void Delete(MFileType entity, string user, DateTime actiondate);

    }

    public class MFileTypeRepository : GenericRepository<MFileType>, IMFileTypeRepository
    {
        public MFileTypeRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public MFileType Get(int id)
        {
            return GetAll().Where(x => x.IsDeleted == false && x.FileTypeId == id).FirstOrDefault();
        }

        public IQueryable<MFileType> GetAll()
        {
            return _context.MFileTypes.AsQueryable();
        }

        public void Add(MFileType entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<MFileType>().Update(entity);
        }

        public void Update(MFileType entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MFileType>().Update(entity);
        }

        public void Delete(MFileType entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MFileType>().Update(entity);
        }

    }
}
