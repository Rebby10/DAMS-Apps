﻿using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Master
{
    public interface IMPriorityRepository : IGenericRepository<MPriority>
    {
        MPriorityViewModel.ReadPriority SelectOne(int id);
        List<MPriorityViewModel.ReadPriority> SelectAll();
        void Update(MPriority entity, string user, DateTime actiondate);
        void Delete(MPriority entity, string user, DateTime actiondate);
        public List<MPriority> GetAllPriority();
        public MPriority GetPriority(int id);

    }

    public class MPriorityRepository : GenericRepository<MPriority>, IMPriorityRepository
    {
        public MPriorityRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public MPriority GetPriority(int id)
        {
            return _context.MPriorities.Where(x => x.IsDeleted == false && x.PriorityId == id).FirstOrDefault();
        }

        public List<MPriority> GetAllPriority()
        {
            return _context.MPriorities.Where(x => x.IsDeleted == false).ToList();
        }

        public void Add(MPriority entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<MPriority>().Update(entity);
        }

        public void Delete(MPriority entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MPriority>().Update(entity);
        }

        public void Update(MPriority entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MPriority>().Update(entity);
        }

        public MPriorityViewModel.ReadPriority SelectOne(int id)
        {
            return _context.MPriorities.Where(x => x.IsDeleted == false && x.PriorityId == id).Select(o =>
                new MPriorityViewModel.ReadPriority
                {
                    PriorityId = o.PriorityId,
                    Name = o.Name
                }).FirstOrDefault();
        }

        public List<MPriorityViewModel.ReadPriority> SelectAll()
        {
            return _context.MPriorities.Where(x => x.IsDeleted == false).Select(o =>
                new MPriorityViewModel.ReadPriority
                {
                    PriorityId = o.PriorityId,
                    Name = o.Name
                }).ToList();
        }
    }
}
