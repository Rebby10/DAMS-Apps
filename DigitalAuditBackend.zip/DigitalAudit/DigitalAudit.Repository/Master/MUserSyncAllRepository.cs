﻿using DigitalAudit.Helper;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Master
{
    public interface IMUserSyncAllRepository : IGenericRepository<MUserSyncAll>
    {
        void Update(MUserSyncAll entity, string user, DateTime actiondate);
        void Delete(MUserSyncAll entity, string user, DateTime actiondate);
        List<MUserSyncAllViewModel.ReadUserSyncAll> SelectAll();
    }

    public class MUserSyncAllRepository : GenericRepository<MUserSyncAll>, IMUserSyncAllRepository
    {
        public MUserSyncAllRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public MUserSyncAll Get(string id)
        {
            return _context.MUserSyncAlls.Where(x => x.IsDeleted == false && x.UserSyncAllId == id).FirstOrDefault();
        }

        public List<MUserSyncAll> GetAll()
        {
            return _context.MUserSyncAlls.Where(x => x.IsDeleted == false).ToList();
        }

        public void Add(MUserSyncAll entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<MUserSyncAll>().Update(entity);
        }

        public void Update(MUserSyncAll entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MUserSyncAll>().Update(entity);
        }

        public void Delete(MUserSyncAll entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MUserSyncAll>().Update(entity);
        }

        public List<MUserSyncAllViewModel.ReadUserSyncAll> SelectAll()
        {
            return _context.MUserSyncAlls.Where(x => x.IsDeleted == false).Select(o =>
                new MUserSyncAllViewModel.ReadUserSyncAll
                {
                    UserSyncAllId = o.UserSyncAllId,
                    UserId = o.UserId,
                    OrganizationId = o.OrganizationId,
                    PositionId = o.PositionId,
                    CompanyCode = o.CompanyCode,
                    City = o.City,
                    CompanyName = o.CompanyName,
                    Country = o.Country,
                    Department = o.Department,
                    DisplayName = o.DisplayName,
                    EmployeeId = o.EmployeeId,
                    FirstName = o.FirstName,
                    LastName = o.LastName,
                    JobTitle = o.JobTitle,
                    Email = o.Email,
                    MobilePhone = o.MobilePhone,
                    OfficeLocation = o.OfficeLocation,
                    Username = o.Username
                }).ToList();
        }
    }
}
