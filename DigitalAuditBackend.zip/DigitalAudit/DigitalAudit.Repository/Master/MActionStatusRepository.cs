﻿using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DigitalAudit.Repository.Master
{
    public interface IMActionStatusRepository : IGenericRepository<MActionStatus>
    {
        MActionStatusViewModel.ReadActionStatus SelectOne(int id);
        List<MActionStatusViewModel.ReadActionStatus> SelectAll();

        void Update(MActionStatus entity, string user, DateTime actiondate);
        void Delete(MActionStatus entity, string user, DateTime actiondate);
    }
    public class MActionStatusRepository : GenericRepository<MActionStatus>, IMActionStatusRepository
    {
        public MActionStatusRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public MActionStatus Get(int id)
        {
            return _context.MActionStatuses.Where(x => x.IsDeleted == false && x.StatusId == id).FirstOrDefault();
        }

        public List<MActionStatus> GetAll()
        {
            return _context.MActionStatuses.Where(x => x.IsDeleted == false).ToList();
        }

        public void Add(MActionStatus entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<MActionStatus>().Update(entity);
        }

        public void Delete(MActionStatus entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MActionStatus>().Update(entity);
        }

        public void Update(MActionStatus entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MActionStatus>().Update(entity);
        }

        public MActionStatusViewModel.ReadActionStatus SelectOne(int id)
        {
            return _context.MActionStatuses.Where(x => x.IsDeleted == false && x.StatusId == id).Select(o =>
                new MActionStatusViewModel.ReadActionStatus
                {
                    StatusId = o.StatusId,
                    Name = o.Name
                }).FirstOrDefault();
        }

        public List<MActionStatusViewModel.ReadActionStatus> SelectAll()
        {
            return _context.MIssueStatuses.Where(x => x.IsDeleted == false).Select(o =>
                new MActionStatusViewModel.ReadActionStatus
                {
                    StatusId = o.StatusId,
                    Name = o.Name
                }).ToList();
        }
    }
}
