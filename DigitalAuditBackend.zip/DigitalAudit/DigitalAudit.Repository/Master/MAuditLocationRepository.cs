﻿using DigitalAudit.Helper;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Master
{
    public interface IMAuditLocationRepository : IGenericRepository<MAuditLocation>
    {
        void Update(MAuditLocation entity, string user, DateTime actiondate);
        void Delete(MAuditLocation entity, string user, DateTime actiondate);
        MAuditLocationViewModel.ReadAuditLocation SelectOne(string id);
        List<MAuditLocationViewModel.ReadAuditLocation> SelectAll();
        bool anyInsert(MAuditLocation entity);
        bool anyUpdate(MAuditLocation entity);
        bool anyDelete(MAuditLocation entity);
        List<fn_Get_MAuditLocation> Get_MAuditLocation(string auditLocationId, string name, string regionId);
    }

    public class MAuditLocationRepository : GenericRepository<MAuditLocation>, IMAuditLocationRepository
    {
        public MAuditLocationRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public MAuditLocation Get(string id)
        {
            return _context.MAuditLocations.Where(x => x.IsDeleted == false && x.AuditLocationId == id).FirstOrDefault();
        }

        public List<MAuditLocation> GetAll()
        {
            return _context.MAuditLocations.Where(x => x.IsDeleted == false).ToList();
        }

        public void Add(MAuditLocation entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<MAuditLocation>().Update(entity);
        }

        public void Update(MAuditLocation entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MAuditLocation>().Update(entity);
        }

        public void Delete(MAuditLocation entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MAuditLocation>().Update(entity);
        }

        public MAuditLocationViewModel.ReadAuditLocation SelectOne(string id)
        {
            return Get_MAuditLocation(id, null, null).Select(o =>
                new MAuditLocationViewModel.ReadAuditLocation
                {
                    AuditLocationId = o.AuditLocationId,
                    Name = o.Name,
                    Address = o.Address,
                    ZipCode = o.ZipCode,
                    LatLong = o.LatLong,
                    Region = new MRegionViewModel.ReadRegion(o.RegionId, o.RegionName)
                }).FirstOrDefault();
        }

        public List<MAuditLocationViewModel.ReadAuditLocation> SelectAll()
        {
            return Get_MAuditLocation(null, null, null).Select(o =>
                new MAuditLocationViewModel.ReadAuditLocation
                {
                    AuditLocationId = o.AuditLocationId,
                    Name = o.Name,
                    Address = o.Address,
                    ZipCode = o.ZipCode,
                    LatLong = o.LatLong,
                    Region = new MRegionViewModel.ReadRegion(o.RegionId, o.RegionName)
                }).ToList();
        }

        public bool anyInsert(MAuditLocation entity)
        {
            return GetAll().Any(i => i.Name == entity.Name.Trim());
        }

        public bool anyUpdate(MAuditLocation entity)
        {
            return GetAll().Any(i => i.Name == entity.Name.Trim() && i.AuditLocationId != entity.AuditLocationId);
        }

        public List<fn_Get_MAuditLocation> Get_MAuditLocation(string auditLocationId, string name, string regionId)
        {
            return _context.Set<fn_Get_MAuditLocation>().FromSqlRaw("select * from dbo.fn_Get_MAuditLocation({0},{1},{2})", auditLocationId, name, regionId).ToList();
        }

        public bool anyDelete(MAuditLocation entity)
        {
            bool result = false;

            if(_context.TrIssues.Any(i => i.IsDeleted == false && i.AuditLocationId == entity.AuditLocationId))
            {
                result = true;
            }

            return result;
        }
    }
}
