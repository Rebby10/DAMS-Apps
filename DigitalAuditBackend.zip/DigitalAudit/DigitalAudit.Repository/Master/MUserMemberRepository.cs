﻿using DigitalAudit.Helper;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Master
{
    public interface IMUserMemberRepository : IGenericRepository<MUserMember>
    {
        void Update(MUserMember entity, string user, DateTime actiondate);
        void Delete(MUserMember entity, string user, DateTime actiondate);
        MUserMemberViewModel.ReadUserMember SelectOne(string id);
        List<MUserMemberViewModel.ReadUserMember> SelectAll();
        List<fn_Get_MUserMember> Get_MUserMember(string userMemberId, string userGroupId, string userTypeId);
        bool anyInsert(MUserMember entity);
        bool anyUpdate(MUserMember entity);
    }

    public class MUserMemberRepository : GenericRepository<MUserMember>, IMUserMemberRepository
    {
        public MUserMemberRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public MUserMember Get(string id)
        {
            return _context.MUserMembers.Where(x => x.IsDeleted == false && x.UserMemberId == id).FirstOrDefault();
        }

        public List<MUserMember> GetAll()
        {
            return _context.MUserMembers.Where(x => x.IsDeleted == false).ToList();
        }

        public void Add(MUserMember entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<MUserMember>().Update(entity);
        }

        public void Update(MUserMember entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MUserMember>().Update(entity);
        }

        public void Delete(MUserMember entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MUserMember>().Update(entity);
        }

        public MUserMemberViewModel.ReadUserMember SelectOne(string id)
        {
            return Get_MUserMember(id, null, null).Select(o =>
                new MUserMemberViewModel.ReadUserMember
                {
                    UserMemberId = o.UserMemberId,
                    UserGroup = new MUserGroupViewModel.ReadUserGroup(o.UserGroupId, new MUserTypeViewModel.ReadUserType(o.UserTypeId, o.UserType), o.GroupName, o.UserIdGroup, o.UsernameGroup, o.OfficialNameGroup),
                    UserId = o.UserIdMember,
                    Username = o.UsernameMember,
                    OfficialName = o.OfficialNameMember
                }).FirstOrDefault();
        }

        public List<MUserMemberViewModel.ReadUserMember> SelectAll()
        {
            return Get_MUserMember(null, null, null).Select(o =>
                new MUserMemberViewModel.ReadUserMember
                {
                    UserMemberId = o.UserMemberId,
                    UserGroup = new MUserGroupViewModel.ReadUserGroup(o.UserGroupId, new MUserTypeViewModel.ReadUserType(o.UserTypeId, o.UserType), o.GroupName, o.UserIdGroup, o.UsernameGroup, o.OfficialNameGroup),
                    UserId = o.UserIdMember,
                    Username = o.UsernameMember,
                    OfficialName = o.OfficialNameMember
                }).ToList();
        }

        public List<fn_Get_MUserMember> Get_MUserMember(string userMemberId, string userGroupId, string userTypeId)
        {
            return _context.Set<fn_Get_MUserMember>().FromSqlRaw("select * from dbo.fn_Get_MUserMember({0},{1},{2})", userMemberId, userGroupId, userTypeId).ToList();
        }

        public bool anyInsert(MUserMember entity)
        {
            return false;
        }

        public bool anyUpdate(MUserMember entity)
        {
            return false;
        }
    }
}
