﻿using DigitalAudit.Helper;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Master
{
    public interface IMUserSyncRepository : IGenericRepository<MUserSync>
    {
        void Update(MUserSync entity, string user, DateTime actiondate);
        void Delete(MUserSync entity, string user, DateTime actiondate);
        IQueryable<MUserSyncViewModel.ReadUserSync> SelectAll();
        //bool anyInsert(MUserSync entity);
        //bool anyUpdate(MUserSync entity);
    }

    public class MUserSyncRepository : GenericRepository<MUserSync>, IMUserSyncRepository
    {
        public MUserSyncRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public MUserSync Get(string id)
        {
            return _context.MUserSyncs.Where(x => x.IsDeleted == false && x.UserSyncId == id).FirstOrDefault();
        }

        public List<MUserSync> GetAll()
        {
            return _context.MUserSyncs.Where(x => x.IsDeleted == false).ToList();
        }

        public void Add(MUserSync entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<MUserSync>().Update(entity);
        }

        public void Update(MUserSync entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MUserSync>().Update(entity);
        }

        public void Delete(MUserSync entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<MUserSync>().Update(entity);
        }

        public IQueryable<MUserSyncViewModel.ReadUserSync> SelectAll()
        {
            return _context.MUserSyncs.Where(x => x.IsDeleted == false).Select(o =>
                new MUserSyncViewModel.ReadUserSync
                {
                    UserSyncId = o.UserSyncId,
                    UserId = o.UserId,
                    OrganizationId = o.OrganizationId,
                    PositionId = o.PositionId,
                    CompanyCode = o.CompanyCode,
                    City = o.City,
                    CompanyName = o.CompanyName,
                    Country = o.Country,
                    Department = o.Department,
                    DisplayName = o.DisplayName,
                    EmployeeId = o.EmployeeId,
                    FirstName = o.FirstName,
                    LastName = o.LastName,
                    JobTitle = o.JobTitle,
                    Email = o.Email,
                    MobilePhone = o.MobilePhone,
                    OfficeLocation = o.OfficeLocation,
                    Username = o.Username
                });
        }

        //public bool anyInsert(MUserSync entity)
        //{
        //    return GetAll().Any(i => i.Name == entity.Name);
        //}

        //public bool anyUpdate(MUserSync entity)
        //{
        //    return GetAll().Any(i => i.Name == entity.Name && i.UserSyncId != entity.UserSyncId);
        //}
    }
}
