﻿using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace DigitalAudit.Repository.Transaction
{
    public interface ITrActionImportRepository : IGenericRepository<TrActionImport>
    {
        void AddLists(List<TrActionImport> entities);
        void Update(TrActionImport entity, string user, DateTime actiondate);
        void Delete(TrActionImport entity, string user, DateTime actiondate);
        StatusViewModel ActionImportValidate(string sessionId, string username);
        IEnumerable<fn_Get_ActionImport> GetActionImport(string sessionId);
    }

    public class TrActionImportRepository : GenericRepository<TrActionImport>, ITrActionImportRepository
    {
        public TrActionImportRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public TrActionImport Get(string id)
        {
            return _context.TrActionImports.Where(x => x.IsDeleted == false && x.ActionImportId == id).FirstOrDefault();
        }

        public IEnumerable<TrActionImport> GetAll()
        {
            return _context.TrActionImports.Where(x => x.IsDeleted == false);
        }

        public void Add(TrActionImport entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<TrActionImport>().Update(entity);
        }

        public void AddLists(List<TrActionImport> entities)
        {
            _context.Set<TrActionImport>().AddRange(entities);
        }

        public void Update(TrActionImport entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrActionImport>().Update(entity);
        }

        public void Delete(TrActionImport entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrActionImport>().Update(entity);
        }

        public StatusViewModel ActionImportValidate(string sessionId, string username)
        {
            IEnumerable<StatusViewModel> result = _context.Set<StatusViewModel>().FromSqlRaw("exec spActionImportValidate {0},{1}", sessionId, username);
            return result.FirstOrDefault();
        }

        public IEnumerable<fn_Get_ActionImport> GetActionImport(string sessionId)
        {
            return _context.Set<fn_Get_ActionImport>()
                .FromSqlRaw("select * from dbo.fn_Get_ActionImport({0},{1},{2},{3},{4},{5})", sessionId, null, null, null, null, null);
        }
    }
}
