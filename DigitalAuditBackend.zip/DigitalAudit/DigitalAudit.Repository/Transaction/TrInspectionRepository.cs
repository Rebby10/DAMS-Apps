﻿using DigitalAudit.Helper;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DigitalAudit.Repository.Transaction
{
    public interface ITrInspectionRepository : IGenericRepository<TrInspection>
    {
        void Update(TrInspection entity, string user, DateTime actiondate);
        void Delete(TrInspection entity, string user, DateTime actiondate);
        List<fn_Get_Inspection> Get_Inspection(string InspectionId, int? StatusId, string regionId, string locationId);
        List<TrInspectionViewModel.ReadInspection> SelectByRole(string InspectionId, int? StatusId, string regionId, string locationId);
        public TrInspection GetLastInspection(string InspectionId, string LocationId, string TemplateId);
        public ReportInspectionViewModel.ReportOverview ReportOverview(string InspectionId);
        public ReportInspectionViewModel.ReportSummary ReportSummary(string InspectionId);
        public double GetScoreInspection(string InspectionId);
    }
    public class TrInspectionRepository : GenericRepository<TrInspection>, ITrInspectionRepository
    {
        public TrInspectionRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public TrInspection Get(string id)
        {
            return GetAll().Where(x => x.IsDeleted == false && x.InspectionId == id).FirstOrDefault();
        }

        public IQueryable<TrInspection> GetAll()
        {
            return _context.TrInspections.AsQueryable();
        }

        public void Add(TrInspection entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<TrInspection>().Update(entity);
        }

        public void Update(TrInspection entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrInspection>().Update(entity);
        }

        public void Delete(TrInspection entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrInspection>().Update(entity);
        }

        public List<fn_Get_Inspection> Get_Inspection(string InspectionId, int? StatusId, string regionId, string locationId)
        {
            return _context.Set<fn_Get_Inspection>().FromSqlRaw("select * from dbo.fn_Get_Inspection({0},{1},{2},{3})", InspectionId, StatusId, regionId, locationId).ToList();
        }

        public TrInspectionPICViewModel.ReadInspectionPIC GetAuditorAuditee(string inspectionId, string userTypeId)
        {
            TrInspectionPICViewModel.ReadInspectionPIC result = new TrInspectionPICViewModel.ReadInspectionPIC();
            TrInspectionPIC pic = _context.TrInspectionPICs.Where(x => x.IsDeleted == false && x.InspectionId == inspectionId && x.UserTypeId == userTypeId).FirstOrDefault();
            result.PicId = pic.PicId;
            result.InspectionId = inspectionId;
            result.UserType = _context.MUserTypes.Where(x => x.IsDeleted == false && x.UserTypeId == userTypeId).Select(o =>
                new MUserTypeViewModel.ReadUserType
                {
                    UserTypeId = o.UserTypeId,
                    Name = o.Name
                }).FirstOrDefault();


            if (!string.IsNullOrEmpty(pic.UserId)) //user
            {
                MUserSyncViewModel.ReadUserSync user = _context.MUserSyncs.Where(x => x.IsDeleted == false && x.UserId == pic.UserId).Select(o =>
                new MUserSyncViewModel.ReadUserSync
                {
                    UserSyncId = o.UserSyncId,
                    UserId = o.UserId,
                    OrganizationId = o.OrganizationId,
                    PositionId = o.PositionId,
                    CompanyCode = o.CompanyCode,
                    City = o.City,
                    CompanyName = o.CompanyName,
                    Country = o.Country,
                    Department = o.Department,
                    DisplayName = o.DisplayName,
                    EmployeeId = o.EmployeeId,
                    FirstName = o.FirstName,
                    LastName = o.LastName,
                    JobTitle = o.JobTitle,
                    Email = o.Email,
                    MobilePhone = o.MobilePhone,
                    OfficeLocation = o.OfficeLocation,
                    Username = o.Username
                }).FirstOrDefault();

                result.Users = user;
            }
            else //group
            {
                MUserGroupViewModel.ReadUserGroupMember group = Get_MUserGroup(pic.UserGroupId, null).ToList().Select(o =>
                new MUserGroupViewModel.ReadUserGroupMember
                {
                    UserGroupId = o.UserGroupId,
                    UserType = new MUserTypeViewModel.ReadUserType(o.UserTypeId, o.UserType),
                    Name = o.Name,
                    UserId = o.UserId,
                    Username = o.Username,
                    OfficialName = o.OfficialName,
                    UserMember = Get_MUserMember(null, o.UserGroupId, o.UserTypeId).ToList().Select(o => new MUserMemberViewModel.ReadUserMember
                    {
                        UserMemberId = o.UserMemberId,
                        UserId = o.UserIdMember,
                        Username = o.UsernameMember,
                        OfficialName = o.OfficialNameMember
                    }).ToList()
                }).FirstOrDefault();

                result.Groups = group;
            }
            return result;
        }

        public List<fn_Get_MUserMember> Get_MUserMember(string userMemberId, string userGroupId, string userTypeId)
        {
            var result = _context.Set<fn_Get_MUserMember>().FromSqlRaw("select * from dbo.fn_Get_MUserMember({0},{1},{2})", userMemberId, userGroupId, userTypeId);
            return result.ToList();
        }

        public List<fn_Get_MUserGroup> Get_MUserGroup(string userGroupId, string userTypeId)
        {
            var result = _context.Set<fn_Get_MUserGroup>().FromSqlRaw("select * from dbo.fn_Get_MUserGroup({0},{1})", userGroupId, userTypeId);
            return result.ToList();
        }


        public List<TrInspectionViewModel.ReadInspection> SelectByRole(string InspectionId, int? StatusId, string regionId, string locationId)
        {
            return Get_Inspection(InspectionId, StatusId, regionId, locationId).Select(o =>
                new TrInspectionViewModel.ReadInspection
                {
                    InspectionId = o.InspectionId,
                    ScheduleId = o.ScheduleId,
                    AuditLocation = new MAuditLocationViewModel.ReadAuditLocation(o.LocationId, o.LocationName, o.Address, o.ZipCode, o.LatLong, o.RegionId, o.RegionName),
                    StartDate = o.StartDate,
                    EndDate = o.EndDate,
                    Template = new TrInspectionViewModel.ReadTemplate(o.TemplateId, o.TemplateTitle),
                    Status = new MInspectionStatusViewModel.ReadInspectiontatus(o.StatusId, o.StatusInspection),
                    Auditor = GetAuditorAuditee(o.InspectionId, Constants.USER_TYPE.AUDITOR),
                    Auditee = GetAuditorAuditee(o.InspectionId, Constants.USER_TYPE.AUDITEE),
                    DateCreated = o.DateCreated,
                    DateModified = o.DateModified
                }).ToList();
        }

        public TrInspection GetLastInspection(string InspectionId, string LocationId, string TemplateId)
        {
            var inspection = Get(InspectionId);
            var lastInspection = GetAll()
                    .FirstOrDefault(x =>
                        x.IsDeleted == false &&
                        x.LocationId == LocationId &&
                        x.TemplateId == TemplateId &&
                        x.InspectionId != InspectionId &&
                        x.StartDate < inspection.StartDate);

            return lastInspection;
        }

        public List<ReportInspectionViewModel.Issue> GetIssueGroupbyStatus(string InspectionId)
        {
            IEnumerable<ReportInspectionViewModel.Issue> dataQuery = _context.Set<ReportInspectionViewModel.Issue>()
                .FromSqlRaw("select IssueStatus AS Status, Count(*) Total from dbo.fn_Get_Issue({0},{1},{2},{3},{4},{5},{6},{7},{8},{9}, {10}, {11}) Group by IssueStatus",
                null, null, null, null, null, null, null, null, null, null, null, InspectionId);

            return dataQuery.ToList();
        }

        public List<ReportInspectionViewModel.Action> GetActionGroupbyStatus(string InspectionId)
        {
            IEnumerable<ReportInspectionViewModel.Action> dataQuery = _context.Set<ReportInspectionViewModel.Action>()
                .FromSqlRaw("select * from dbo.fn_Get_Action_Inspection({0})", InspectionId);

            return dataQuery.ToList();
        }

        public ReportInspectionViewModel.ReportOverview ReportOverview(string InspectionId)
        {
            IEnumerable<ReportInspectionViewModel.ReportOverview> dataQuery = _context.Set<ReportInspectionViewModel.ReportOverview>().FromSqlRaw("exec spReportOverview {0}", InspectionId);

            return dataQuery.FirstOrDefault();
        }

        public double GetScoreInspection(string InspectionId)
        {
            IEnumerable<ReportInspectionViewModel.Score> dataQuery = _context.Set<ReportInspectionViewModel.Score>().FromSqlRaw("SELECT ISNULL([dbo].[fn_Score_Inspection] ({0}), 0) ScoreInspection", InspectionId);

            return dataQuery.FirstOrDefault().ScoreInspection;
        }

        public List<TrInspectionFile> Get_FILE()
        {
            var result = _context.Set<TrInspectionFile>().FromSqlRaw("select * from dbo.TrInspectionFile");
            return result.ToList();
        }

        public List<ReportInspectionViewModel.Image> GetImages(string InspectionId)
        {
            var inspectionFiles = Get_FILE()
                    .Where(x => x.IsDeleted == false && x.FileTypeId == Constants.FILE_TYPE.IMAGE && x.InspectionId == InspectionId)
                    .Select(o => new ReportInspectionViewModel.Image
                    {
                        link = o.FileId

                    });

            return inspectionFiles.ToList();
        }


        public ReportInspectionViewModel.ReportSummary ReportSummary(string InspectionId)
        {
            ReportInspectionViewModel.ReportSummary summary = new ReportInspectionViewModel.ReportSummary();
            List<ReportInspectionViewModel.Issue> issues = new List<ReportInspectionViewModel.Issue>();
            List<ReportInspectionViewModel.Action> actions = new List<ReportInspectionViewModel.Action>();

            var inspection = Get(InspectionId);
            var lastInspection = GetLastInspection(inspection.InspectionId, inspection.LocationId, inspection.TemplateId);

            if (lastInspection != null)
            {
                issues = GetIssueGroupbyStatus(lastInspection.InspectionId);
                actions = GetActionGroupbyStatus(lastInspection.InspectionId);

                summary.PreviousRecomendation = new ReportInspectionViewModel.Recomendation(issues, actions);
            }
            else
            {
                summary.PreviousRecomendation = new ReportInspectionViewModel.Recomendation(issues, actions);
            }

            issues = GetIssueGroupbyStatus(InspectionId);
            actions = GetActionGroupbyStatus(InspectionId);

            summary.CurrentRecomendation = new ReportInspectionViewModel.Recomendation(issues, actions);

            summary.Score = GetScoreInspection(InspectionId);

            summary.InspectionId = InspectionId;

            summary.Images = GetImages(InspectionId);

            return summary;
            
        }
    }
}
