﻿using DigitalAudit.Model.Database;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;


namespace DigitalAudit.Repository.Transaction
{
    public interface ITrActionLogRepository : IGenericRepository<TrActionLog>
    {
        IQueryable<TrActionLog> SelectAllLogAction(string ActionId);
    }

    public class TrActionLogRepository : GenericRepository<TrActionLog>, ITrActionLogRepository
    {
        public TrActionLogRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public TrActionLog Get(string id)
        {
            return GetAll().Where(x => x.IsDeleted == false && x.LogId == id).FirstOrDefault();
        }

        public IQueryable<TrActionLog> GetAll()
        {
            return _context.TrActionLogs.AsQueryable();
        }

        public void Add(TrActionLog entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<TrActionLog>().Update(entity);
        }

        public void Update(TrActionLog entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrActionLog>().Update(entity);
        }

        public void Delete(TrActionLog entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrActionLog>().Update(entity);
        }

        public IQueryable<TrActionLog> SelectAllLogAction(string ActionId)
        {
            var dataQuery = GetAll().Where(x => x.IsDeleted == false && x.ActionId.Equals(ActionId));
            dataQuery = dataQuery.Include(x => x.LogType);
            dataQuery = dataQuery.Select(x => new TrActionLog
            {
                LogId = x.LogId,
                ActionId = x.ActionId,
                UserId = x.UserId,
                Username = x.Username,
                TextLog = x.TextLog,
                DatetimeLog = x.DatetimeLog,
                Filename = x.Filename,
                LinkFile = x.LinkFile,
                LogType = new MLogType
                {
                    LogTypeId = x.LogType.LogTypeId,
                    Name = x.LogType.Name
                }
            });

            return dataQuery.OrderBy(o => o.DatetimeLog);
        }
    }
}
