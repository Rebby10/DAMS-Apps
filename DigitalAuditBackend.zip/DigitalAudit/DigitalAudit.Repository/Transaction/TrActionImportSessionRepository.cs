﻿using DigitalAudit.Model.Database;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Transaction
{
    public interface ITrActionImportSessionRepository : IGenericRepository<TrActionImportSession>
    {
        void Add(TrActionImportSession entity, string user, DateTime actiondate);
        void Update(TrActionImportSession entity, string user, DateTime actiondate);
        void Delete(TrActionImportSession entity, string user, DateTime actiondate);
    }

    public class TrActionImportSessionRepository : GenericRepository<TrActionImportSession>, ITrActionImportSessionRepository
    {
        public TrActionImportSessionRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public TrActionImportSession Get(string id)
        {
            return _context.TrActionImportSessions.Where(x => x.IsDeleted == false && x.SessionId == id).FirstOrDefault();
        }

        public IEnumerable<TrActionImportSession> GetAll()
        {
            return _context.TrActionImportSessions.Where(x => x.IsDeleted == false);
        }

        public void Add(TrActionImportSession entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<TrActionImportSession>().Update(entity);
        }

        public void Update(TrActionImportSession entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrActionImportSession>().Update(entity);
        }

        public void Delete(TrActionImportSession entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrActionImportSession>().Update(entity);
        }
    }
}
