﻿using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DigitalAudit.Repository.Transaction
{
    public interface ITrInspectionSignatureRepository : IGenericRepository<TrInspectionSignature>
    {
        void Update(TrInspectionSignature entity, string user, DateTime actiondate);
        void Delete(TrInspectionSignature entity, string user, DateTime actiondate);
        TrInspectionSignatureViewModel.ReadInspectionSignature SelectOne(string SignatureId);
        IQueryable<TrInspectionSignatureViewModel.ReadInspectionSignature> Select(string InspectionId);

    }

    public class TrInspectionSignatureRepository : GenericRepository<TrInspectionSignature>, ITrInspectionSignatureRepository
    {
        public TrInspectionSignatureRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public TrInspectionSignature Get(string id)
        {
            return GetAll().Where(x => x.IsDeleted == false && x.SignatureId == id).FirstOrDefault();
        }

        public IQueryable<TrInspectionSignature> GetAll()
        {
            return _context.TrInspectionSignatures.AsQueryable();
        }

        public IQueryable<TrInspectionSignatureViewModel.ReadInspectionSignature> Select(string InspectionId)
        {
            return GetAll()
                .Where(x => x.IsDeleted == false && x.InspectionId == InspectionId)
                .Select(o => new TrInspectionSignatureViewModel.ReadInspectionSignature
                {
                    SignatureId = o.SignatureId,
                    InspectionId = o.InspectionId,
                    Name = o.Name,
                    Title = o.Title,
                    Signature = o.Signature
                });
        }

        public TrInspectionSignatureViewModel.ReadInspectionSignature SelectOne(string SignatureId)
        {
            return GetAll()
                .Where(x => x.IsDeleted == false && x.SignatureId == SignatureId)
                .Select(o => new TrInspectionSignatureViewModel.ReadInspectionSignature
                {
                    SignatureId = o.SignatureId,
                    InspectionId = o.InspectionId,
                    Name = o.Name,
                    Title = o.Title,
                    Signature = o.Signature
                }).FirstOrDefault();
        }
        public void Add(TrInspectionSignature entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<TrInspectionSignature>().Update(entity);
        }

        public void Update(TrInspectionSignature entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrInspectionSignature>().Update(entity);
        }

        public void Delete(TrInspectionSignature entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrInspectionSignature>().Update(entity);
        }

    }
}
