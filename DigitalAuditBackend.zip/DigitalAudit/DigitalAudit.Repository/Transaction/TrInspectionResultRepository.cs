﻿using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DigitalAudit.Repository.Transaction
{
    public interface ITrInspectionResultRepository : IGenericRepository<TrInspectionResult>
    {
        void Update(TrInspectionResult entity, string user, DateTime actiondate);
        void Delete(TrInspectionResult entity, string user, DateTime actiondate);
        MTemplateMainViewModel GetTemplate(string templateId, string inspectionId, string pageId);
        List<MTemplatePageViewModel.ReadTemplatePageDetail> SelectTemplatePageDetail(string templateId, string inspectionId, string pageId);
        List<MTemplatePageViewModel.ReadTemplatePageDetail> GetResult(string templateId, string inspectionId);

    }
    public class TrInspectionResultRepository : GenericRepository<TrInspectionResult>, ITrInspectionResultRepository
    {
        public TrInspectionResultRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public TrInspectionResult Get(string id)
        {
            return GetAll().Where(x => x.IsDeleted == false && x.ResultId == id).FirstOrDefault();
        }

        public IQueryable<TrInspectionResult> GetAll()
        {
            return _context.TrInspectionResults.AsQueryable();
        }

        public void Add(TrInspectionResult entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<TrInspectionResult>().Update(entity);
        }

        public void Update(TrInspectionResult entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrInspectionResult>().Update(entity);
        }

        public void Delete(TrInspectionResult entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrInspectionResult>().Update(entity);
        }

        public MTemplateMainViewModel GetTemplate(string templateId, string inspectionId, string pageId)
        {
            MTemplateMainViewModel result = new MTemplateMainViewModel();
            MTemplate templateHeader = new MTemplate();
            templateHeader = GetTemplateHeader(templateId);
            result.TemplateId = templateHeader.TemplateId;
            result.Code = templateHeader.Code;
            result.Title = templateHeader.Title;
            result.Descriptions = templateHeader.Descriptions;
            result.TemplateCategory = this.GetTemplateCategory(templateHeader.CategoryId);
            result.TemplatePermissionType = this.GetTemplatePermissionType(templateHeader.TemplatePermissionTypeId);
            result.TemplatePermission = this.GetTemplatePermission(templateHeader.TemplateId, null, null, null);
            result.TemplatePage = this.SelectTemplatePageDetail(templateHeader.TemplateId, inspectionId, pageId);
            
            //result.TemplatePage = this.gette

            return result;
        }

        public List<MTemplatePageViewModel.ReadTemplatePageDetail> GetResult(string templateId, string inspectionId)
        {
            //List<MTemplatePageViewModel.ReadTemplatePageDetail> result = new List<MTemplatePageViewModel.ReadTemplatePageDetail>();
            MTemplate templateHeader = new MTemplate();
            templateHeader = GetTemplateHeader(templateId);
            var result = this.SelectTemplatePageDetail(templateHeader.TemplateId, inspectionId, null);

            return result;
        }

        public MTemplate GetTemplateHeader(string id)
        {
            return _context.MTemplates.Where(x => x.IsDeleted == false && x.TemplateId == id).FirstOrDefault();
        }

        public List<MTemplateViewModel.Permission> GetTemplatePermission(string templateId, string userId, string usergroupid, string officialname)
        {
            List<MTemplateViewModel.Permission> result = new List<MTemplateViewModel.Permission>();
            result = Get_MTemplatePermission(templateId, userId, usergroupid, officialname).Select(o =>
                new MTemplateViewModel.Permission
                {
                    UserId = o.UserId,
                    Username = o.Username,
                    OfficialName = o.OfficialName
                }).ToList();
            return result;
        }

        public MTemplateCategoryViewModel.ReadTemplateCategory GetTemplateCategory(int categoryId)
        {
            MTemplateCategoryViewModel.ReadTemplateCategory result = new MTemplateCategoryViewModel.ReadTemplateCategory();
            result = _context.MTemplateCategories.Where(x => x.IsDeleted == false && x.CategoryId == categoryId).Select(o =>
                new MTemplateCategoryViewModel.ReadTemplateCategory
                {
                    CategoryId = o.CategoryId,
                    Name = o.Name,
                }).FirstOrDefault();
            return result;
        }

        public MTemplatePermissionTypeViewModel.ReadMTemplatePermissionType GetTemplatePermissionType(int id)
        {
            MTemplatePermissionTypeViewModel.ReadMTemplatePermissionType result = new MTemplatePermissionTypeViewModel.ReadMTemplatePermissionType();
            result = _context.MTemplatePermissionTypes.Where(x => x.IsDeleted == false && x.TemplatePermissionTypeId == id).Select(o =>
                new MTemplatePermissionTypeViewModel.ReadMTemplatePermissionType
                {
                    TemplatePermissionTypeId = o.TemplatePermissionTypeId,
                    Name = o.PermissionType,
                }).FirstOrDefault();
            return result;
        }

        public List<MTemplatePageViewModel.ReadTemplatePageDetail> SelectTemplatePageDetail(string templateId, string inspectionId, string pageId)
        {
            //List<MTemplatePageViewModel.ReadTemplatePageDetail> result = new List<MTemplatePageViewModel.ReadTemplatePageDetail>();
            var result = Get_MTemplatePage().Where(x => x.IsDeleted == false && x.TemplateId == templateId)
                .OrderBy(o => o.SeqNo)
                .Select(o =>
                new MTemplatePageViewModel.ReadTemplatePageDetail
                {
                    PageId = o.PageId,
                    TemplateId = o.TemplateId,
                    Title = o.Title,
                    Descriptions = o.Descriptions,
                    Score = GetScoreInspection(inspectionId),
                    SeqNo = o.SeqNo,
                    Question = GetTemplateQuestion(o.PageId, inspectionId),
                    Section = SelectTemplateSectionDetail(o.PageId, inspectionId)
                });

            if (pageId != null)
            {
                result = result.Where(x => x.PageId == pageId);
            }

            return result.ToList();
        }

        public double GetScoreInspection(string InspectionId)
        {
            IEnumerable<ReportInspectionViewModel.Score> dataQuery = _context.Set<ReportInspectionViewModel.Score>().FromSqlRaw("SELECT ISNULL([dbo].[fn_Score_Inspection] ({0}), 0) ScoreInspection", InspectionId);

            return dataQuery.FirstOrDefault().ScoreInspection;
        }

        public List<fn_Get_MTemplatePermission> Get_MTemplatePermission(string templateId, string userId, string usergroupid, string officialname)
        {
            var result = _context.Set<fn_Get_MTemplatePermission>().FromSqlRaw("select * from dbo.fn_Get_MTemplatePermission({0},{1},{2},{3},{4},{5},{6},{7})", templateId, null, null, null, null, userId, usergroupid, officialname);
            return result.ToList();
        }

        public List<MTemplatePage> Get_MTemplatePage()
        {
            var result = _context.Set<MTemplatePage>().FromSqlRaw("select * from dbo.MTemplatePage");
            return result.ToList();
        }

        public List<MTemplateQuestionViewModel.ReadTemplateQuestion> GetTemplateQuestion(string page_id, string inspectionId)
        {
            List<MTemplateQuestionViewModel.ReadTemplateQuestion> result = new List<MTemplateQuestionViewModel.ReadTemplateQuestion>();
            result = Get_MTemplateQuestion().Where(x => x.IsDeleted == false && x.PageId == page_id && x.SectionId == null).OrderBy(o => o.SeqNo).Select(o =>
                new MTemplateQuestionViewModel.ReadTemplateQuestion
                {
                    QuestionId = o.QuestionId,
                    PageId = o.PageId,
                    Code = o.Code,
                    SeqNo = o.SeqNo,
                    Question = o.Question,
                    IsMandatory = o.IsMandatory,
                    SectionId = o.SectionId,
                    Response = GetResponse(o.ResponseId),
                    Answer = GetInspectionResult(inspectionId, o.QuestionId)
                }).ToList();

            return result;
        }

        public List<MTemplateQuestionViewModel.ReadTemplateQuestion> GetTemplateQuestionBySectionId(string section_id, string inspectionId)
        {
            List<MTemplateQuestionViewModel.ReadTemplateQuestion> result = new List<MTemplateQuestionViewModel.ReadTemplateQuestion>();
            result = Get_MTemplateQuestion().Where(x => x.IsDeleted == false && x.SectionId == section_id).OrderBy(o => o.SeqNo).Select(o =>
                new MTemplateQuestionViewModel.ReadTemplateQuestion
                {
                    QuestionId = o.QuestionId,
                    PageId = o.PageId,
                    Code = o.Code,
                    SeqNo = o.SeqNo,
                    Question = o.Question,
                    IsMandatory = o.IsMandatory,
                    SectionId = o.SectionId,
                    Response = GetResponse(o.ResponseId),
                    Answer = GetInspectionResult(inspectionId, o.QuestionId)
                }).ToList();

            return result;
        }

        public List<MTemplateSectionViewModel.ReadTemplateSectionDetail> SelectTemplateSectionDetail(string pageId, string inspectionId)
        {
            List<MTemplateSectionViewModel.ReadTemplateSectionDetail> result = new List<MTemplateSectionViewModel.ReadTemplateSectionDetail>();
            result = Get_MTemplateSection().Where(x => x.IsDeleted == false && x.PageId == pageId).OrderBy(o => o.SeqNo).Select(o =>
                new MTemplateSectionViewModel.ReadTemplateSectionDetail
                {
                    SectionId = o.SectionId,
                    PageId = o.PageId,
                    Name = o.Name,
                    SeqNo = o.SeqNo,
                    Question = GetTemplateQuestionBySectionId(o.SectionId, inspectionId)
                }).ToList();

            return result;
        }
        public List<MTemplateQuestion> Get_MTemplateQuestion()
        {
            var result = _context.Set<MTemplateQuestion>().FromSqlRaw("select * from dbo.MTemplateQuestion");
            return result.ToList();
        }
        public MResponseViewModel.ReadResponse GetResponse(int response_id)
        {
            MResponseViewModel.ReadResponse result = new MResponseViewModel.ReadResponse();
            result = Get_MResponse().Where(x => x.IsDeleted == false && x.ResponseId == response_id).Select(o =>
               new MResponseViewModel.ReadResponse
               {
                   ResponseId = o.ResponseId,
                   Name = o.Name,
                   ResponseType = this.GetResponseType(o.TypeId),
                   ResponseList = this.GetResponseList(o.ResponseId).ToList()
               }).FirstOrDefault();
            return result;
        }

        public MResponseTypeViewModel.ReadMResponseType GetResponseType(int id)
        {
            return _context.MResponseTypes.Where(x => x.IsDeleted == false && x.TypeId == id).Select(o =>
                new MResponseTypeViewModel.ReadMResponseType
                {
                    TypeId = o.TypeId,
                    Name = o.Name
                }).FirstOrDefault();
        }

        public List<MResponseListViewModel.ReadResponseList> GetResponseList(int reponse_id)
        {
            return _context.MResponseLists.Where(x => x.IsDeleted == false && x.ResponseId == reponse_id).Select(o =>
                new MResponseListViewModel.ReadResponseList
                {
                    //Response = this.GetMResponse(o.ResponseId),
                    ResponseId = o.ResponseId,
                    IsFailedResponse = o.IsFailedResponse,
                    ListId = o.ListId,
                    Score = o.Score,
                    SeqNo = o.SeqNo,
                    Name = o.Name
                }).ToList();
        }

        public List<MTemplateSection> Get_MTemplateSection()
        {
            var result = _context.Set<MTemplateSection>().FromSqlRaw("select * from dbo.MTemplateSection");
            return result.ToList();
        }
        public List<MResponse> Get_MResponse()
        {
            var result = _context.Set<MResponse>().FromSqlRaw("select * from dbo.MResponse");
            return result.ToList();
        }

        public TrInspectionResultViewModel.ReadInspectionResult GetInspectionResult(string inspectionId, int questionId)
        {
            var result = _context.Set<TrInspectionResult>()
                .FromSqlRaw("select * from dbo.TrInspectionResult")
                .Where(x => x.IsDeleted == false && x.InspectionId == inspectionId && x.QuestionId == questionId)
                .Select(o =>
                new TrInspectionResultViewModel.ReadInspectionResult 
                { 
                    ResultId = o.ResultId,
                    AnswerId = o.AnswerId,
                    AnswerText = o.AnswerText,
                    LinkFile = o.LinkFile,
                    Notes = o.Notes                    
                });

            return result.FirstOrDefault();
        }
    }
}
