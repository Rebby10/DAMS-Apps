﻿using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DigitalAudit.Repository.Transaction
{
    public interface ITrInspectionInfoRepository : IGenericRepository<TrInspectionInfo>
    {
        void Update(TrInspectionInfo entity, string user, DateTime actiondate);
        void Delete(TrInspectionInfo entity, string user, DateTime actiondate);
        IQueryable<TrInspectionInfoViewModel.ReadInspectionInfo> Select(string InspectionId);
        TrInspectionInfoViewModel.ReadInspectionInfo SelectOne(string InfoId);

    }

    public class TrInspectionInfoRepository : GenericRepository<TrInspectionInfo>, ITrInspectionInfoRepository
    {
        public TrInspectionInfoRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public TrInspectionInfo Get(string id)
        {
            return GetAll().Where(x => x.IsDeleted == false && x.InfoId == id).FirstOrDefault();
        }

        public IQueryable<TrInspectionInfo> GetAll()
        {
            return _context.TrInspectionInfos.AsQueryable();
        }

        public IQueryable<TrInspectionInfoViewModel.ReadInspectionInfo> Select(string InspectionId)
        {
            return GetAll()
                .Where(x => x.IsDeleted == false && x.InspectionId == InspectionId)
                .Select(o => new TrInspectionInfoViewModel.ReadInspectionInfo 
                {
                    InfoId = o.InfoId,
                    InspectionId = o.InspectionId,
                    Notes = o.Notes,
                    Title = o.Title
                });
        }

        public TrInspectionInfoViewModel.ReadInspectionInfo SelectOne(string InfoId)
        {
            return GetAll()
                .Where(x => x.IsDeleted == false && x.InfoId == InfoId)
                .Select(o => new TrInspectionInfoViewModel.ReadInspectionInfo
                {
                    InfoId = o.InfoId,
                    InspectionId = o.InspectionId,
                    Notes = o.Notes,
                    Title = o.Title
                }).FirstOrDefault();
        }

        public void Add(TrInspectionInfo entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<TrInspectionInfo>().Update(entity);
        }

        public void Update(TrInspectionInfo entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrInspectionInfo>().Update(entity);
        }

        public void Delete(TrInspectionInfo entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrInspectionInfo>().Update(entity);
        }

    }
}
