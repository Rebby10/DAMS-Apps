﻿using DigitalAudit.Model.Database;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Transaction
{
    public interface ITrIssueImportSessionRepository : IGenericRepository<TrIssueImportSession>
    {
        void Add(TrIssueImportSession entity, string user, DateTime actiondate);
        void Update(TrIssueImportSession entity, string user, DateTime actiondate);
        void Delete(TrIssueImportSession entity, string user, DateTime actiondate);
    }

    public class TrIssueImportSessionRepository : GenericRepository<TrIssueImportSession>, ITrIssueImportSessionRepository
    {
        public TrIssueImportSessionRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public TrIssueImportSession Get(string id)
        {
            return _context.TrIssueImportSessions.Where(x => x.IsDeleted == false && x.SessionId == id).FirstOrDefault();
        }

        public IEnumerable<TrIssueImportSession> GetAll()
        {
            return _context.TrIssueImportSessions.Where(x => x.IsDeleted == false);
        }

        public void Add(TrIssueImportSession entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<TrIssueImportSession>().Update(entity);
        }

        public void Update(TrIssueImportSession entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrIssueImportSession>().Update(entity);
        }

        public void Delete(TrIssueImportSession entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrIssueImportSession>().Update(entity);
        }

    }
}
