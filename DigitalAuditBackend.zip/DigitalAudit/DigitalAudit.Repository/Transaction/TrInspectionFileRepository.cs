﻿using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DigitalAudit.Repository.Transaction
{
    public interface ITrInspectionFileRepository : IGenericRepository<TrInspectionFile>
    {
        void Update(TrInspectionFile entity, string user, DateTime actiondate);
        void Delete(TrInspectionFile entity, string user, DateTime actiondate);
        IQueryable<TrInspectionFileViewModel.ReadInspectionFile> Select(string inspectionId, int questionId, int fileTypeId);
    }
    public class TrInspectionFileRepository : GenericRepository<TrInspectionFile>, ITrInspectionFileRepository
    {
        public TrInspectionFileRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public TrInspectionFile Get(string id)
        {
            return GetAll().Where(x => x.IsDeleted == false && x.FileId == id).FirstOrDefault();
        }

        public IQueryable<TrInspectionFile> GetAll()
        {
            return _context.TrInspectionFiles.AsQueryable();
        }

        public IQueryable<TrInspectionFileViewModel.ReadInspectionFile> Select(string inspectionId, int questionId, int fileTypeId)
        {
            var inspectionFiles = GetAll()
                .Where(x => x.IsDeleted == false && x.QuestionId == questionId && x.FileTypeId == fileTypeId && x.InspectionId == inspectionId)
                .Select(o => new TrInspectionFileViewModel.ReadInspectionFile
                {
                    FileId = o.FileId,
                    InspectionId = o.InspectionId,
                    QuestionId = o.QuestionId,
                    FileTypeId = o.FileTypeId,
                    Filename = o.Filename,
                    LinkFile = o.LinkFile
                });

            return inspectionFiles;
        }

        public void Add(TrInspectionFile entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<TrInspectionFile>().Update(entity);
        }

        public void Update(TrInspectionFile entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrInspectionFile>().Update(entity);
        }

        public void Delete(TrInspectionFile entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrInspectionFile>().Update(entity);
        }

    }
}
