﻿using DigitalAudit.Model.Database;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DigitalAudit.Repository.Transaction
{
    public interface ITrInspectionPICRepository : IGenericRepository<TrInspectionPIC>
    {
        void Update(TrInspectionPIC entity, string user, DateTime actiondate);
        void Delete(TrInspectionPIC entity, string user, DateTime actiondate);

        void AddLists(List<TrInspectionPIC> entities);

    }
    public class TrInspectionPICRepository : GenericRepository<TrInspectionPIC>, ITrInspectionPICRepository
    {
        public TrInspectionPICRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public TrInspectionPIC Get(string id)
        {
            return GetAll().Where(x => x.IsDeleted == false && x.PicId == id).FirstOrDefault();
        }

        public IQueryable<TrInspectionPIC> GetAll()
        {
            return _context.TrInspectionPICs.AsQueryable();
        }

        public void Add(TrInspectionPIC entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<TrInspectionPIC>().Update(entity);
        }

        public void Update(TrInspectionPIC entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrInspectionPIC>().Update(entity);
        }

        public void Delete(TrInspectionPIC entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrInspectionPIC>().Update(entity);
        }

        public void AddLists(List<TrInspectionPIC> entities)
        {
            _context.Set<TrInspectionPIC>().AddRange(entities);
        }


    }
}
