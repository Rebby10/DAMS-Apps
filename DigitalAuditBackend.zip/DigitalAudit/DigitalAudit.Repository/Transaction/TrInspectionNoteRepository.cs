﻿using DigitalAudit.Model.Database;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DigitalAudit.Repository.Transaction
{
    public interface ITrInspectionNoteRepository : IGenericRepository<TrInspectionNote>
    {
        void Update(TrInspectionNote entity, string user, DateTime actiondate);
        void Delete(TrInspectionNote entity, string user, DateTime actiondate);
       
    }
    public class TrInspectionNoteRepository : GenericRepository<TrInspectionNote>, ITrInspectionNoteRepository
    {
        public TrInspectionNoteRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public TrInspectionNote Get(string id)
        {
            return GetAll().Where(x => x.IsDeleted == false && x.NoteId == id).FirstOrDefault();
        }

        public IQueryable<TrInspectionNote> GetAll()
        {
            return _context.TrInspectionNotes.AsQueryable();
        }

        public void Add(TrInspectionNote entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<TrInspectionNote>().Update(entity);
        }

        public void Update(TrInspectionNote entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrInspectionNote>().Update(entity);
        }

        public void Delete(TrInspectionNote entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrInspectionNote>().Update(entity);
        }

    }
}
