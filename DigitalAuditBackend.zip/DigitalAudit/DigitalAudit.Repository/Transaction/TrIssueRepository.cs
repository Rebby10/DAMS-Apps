﻿using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Transaction
{
    public interface ITrIssueRepository : IGenericRepository<TrIssue>
    {
        void Update(TrIssue entity, string user, DateTime actiondate);
        void Delete(TrIssue entity, string user, DateTime actiondate);
        IEnumerable<fn_Get_Issue> SelectOne(string IssueId);
        IEnumerable<fn_Get_Issue> GetIssueInspection(string InspectionId);
        IEnumerable<fn_Get_Issue> SelectAll(string IssueId, string AuditLocationId, int? PriorityId, int? StatusId, string UserCreated, string AssignUser, DateTime? StartDate, DateTime? EndDate, string AuditTypeId, string title, bool? IsConnectedToAction, string RegionId);
        //bool anyInsert(TrIssue entity);
        //bool anyUpdate(TrIssue entity);
        IEnumerable<fn_Get_Issue> GetIssue(string IssueId, string AuditLocationId, int? PriorityId, int? StatusId, string UserCreated, string AssignUser, DateTime? StartDate, DateTime? EndDate, string AuditTypeId, string title, bool? IsConnectedToAction, string RegionId, string InspectionId);

        public StatusViewModel AddIssueFromInspection(string InspectionId, int QuestionId, string UserCreated);
    }

    public class TrIssueRepository : GenericRepository<TrIssue>, ITrIssueRepository
    {
        public TrIssueRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public TrIssue Get(string id)
        {
            return _context.TrIssues.Where(x => x.IsDeleted == false && x.IssueId == id).FirstOrDefault();
        }

        public IEnumerable<TrIssue> GetAll()
        {
            return _context.TrIssues.Where(x => x.IsDeleted == false);
        }

        public void Add(TrIssue entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<TrIssue>().Update(entity);
        }

        public void Update(TrIssue entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrIssue>().Update(entity);
        }

        public void Delete(TrIssue entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrIssue>().Update(entity);
        }


        public IEnumerable<fn_Get_Issue> SelectOne(string IssueId)
        {
            return GetIssue(IssueId, null, null, null, null, null, null, null, null, null, null, null, null);
        }

        public IEnumerable<fn_Get_Issue> SelectAll(string IssueId, string AuditLocationId, int? PriorityId, int? StatusId, string UserCreated, string AssignUser, DateTime? StartDate, DateTime? EndDate, string AuditTypeId, string title, bool? IsConnectedToAction, string RegionId)
        {
            return GetIssue(IssueId, AuditLocationId, PriorityId, StatusId, UserCreated, AssignUser, StartDate, EndDate, AuditTypeId, title, IsConnectedToAction, RegionId, null);
        }

        public IEnumerable<fn_Get_Issue> GetIssueInspection(string InspectionId)
        {
            return GetIssue(null, null, null, null, null, null, null, null, null, null, null, null, InspectionId);
        }

        //public bool anyInsert(TrIssue entity)
        //{
        //    return GetAll().Any(i => i.UserId == entity.UserId);
        //}

        //public bool anyUpdate(TrIssue entity)
        //{
        //    return GetAll().Any(i => i.UserId == entity.UserId && i.UserRoleId != entity.UserRoleId);
        //}

        public IEnumerable<fn_Get_Issue> GetIssue(string IssueId, string AuditLocationId, int? PriorityId, int? StatusId, string UserCreated, string AssignUser
            , DateTime? StartDate, DateTime? EndDate, string AuditTypeId, string title, bool? IsConnectedToAction, string RegionId, string InspectionId)
        {
            var dataQuery = _context.Set<fn_Get_Issue>()
                .FromSqlRaw("select * from dbo.fn_Get_Issue({0},{1},{2},{3},{4},{5},{6},{7},{8},{9}, {10}, {11})", 
                IssueId, AuditLocationId, PriorityId, StatusId, UserCreated, AssignUser, StartDate, EndDate, AuditTypeId, title, RegionId, InspectionId);

            if (IsConnectedToAction != null)
            {
                if (Convert.ToBoolean(IsConnectedToAction))
                {
                    dataQuery = dataQuery.Where(x => x.TotalAction > 0);
                }
                else
                {
                    dataQuery = dataQuery.Where(x => x.TotalAction == 0);
                }

            }

            return dataQuery;
        }

        public StatusViewModel AddIssueFromInspection(string InspectionId, int QuestionId, string UserCreated)
        {
            IEnumerable<StatusViewModel> dataQuery = _context.Set<StatusViewModel>().FromSqlRaw("exec dbo.spIssueFromInspection {0},{1}, {2}", InspectionId, QuestionId, UserCreated);
                        
           return dataQuery.FirstOrDefault();
        }
    }
}
