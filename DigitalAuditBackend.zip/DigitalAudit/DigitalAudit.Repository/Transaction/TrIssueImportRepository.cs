﻿using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Transaction
{
    public interface ITrIssueImportRepository : IGenericRepository<TrIssueImport>
    {
        void AddLists(List<TrIssueImport> entities);
        void Update(TrIssueImport entity, string user, DateTime actiondate);
        void Delete(TrIssueImport entity, string user, DateTime actiondate);
        StatusViewModel IssueImportValidate(string sessionId, string username);
        IEnumerable<fn_Get_IssueImport> GetIssueImport(string sessionId);
        IEnumerable<fn_Get_IssueImportStatus> GetIssueImportStatus(string sessionId);
    }

    public class TrIssueImportRepository : GenericRepository<TrIssueImport>, ITrIssueImportRepository
    {
        public TrIssueImportRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public TrIssueImport Get(string id)
        {
            return _context.TrIssueImports.Where(x => x.IsDeleted == false && x.IssueImportId == id).FirstOrDefault();
        }

        public IEnumerable<TrIssueImport> GetAll()
        {
            return _context.TrIssueImports.Where(x => x.IsDeleted == false);
        }

        public void Add(TrIssueImport entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<TrIssueImport>().Update(entity);
        }

        public void AddLists(List<TrIssueImport> entities)
        {
            _context.Set<TrIssueImport>().AddRange(entities);
        }

        public void Update(TrIssueImport entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrIssueImport>().Update(entity);
        }

        public void Delete(TrIssueImport entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrIssueImport>().Update(entity);
        }

        public StatusViewModel IssueImportValidate(string sessionId, string username)
        {
            IEnumerable<StatusViewModel> result = _context.Set<StatusViewModel>().FromSqlRaw("exec spIssueImportValidate {0},{1}", sessionId, username);
            return result.FirstOrDefault();
        }

        public IEnumerable<fn_Get_IssueImport> GetIssueImport(string sessionId)
        {
            return _context.Set<fn_Get_IssueImport>()
                .FromSqlRaw("select * from dbo.fn_Get_IssueImport({0},{1},{2},{3},{4},{5})", sessionId, null, null, null, null, null);
        }

        public IEnumerable<fn_Get_IssueImportStatus> GetIssueImportStatus(string sessionId)
        {
            return _context.Set<fn_Get_IssueImportStatus>()
                .FromSqlRaw("select * from dbo.fn_Get_IssueImportStatus({0})", sessionId);
        }
    }
}
