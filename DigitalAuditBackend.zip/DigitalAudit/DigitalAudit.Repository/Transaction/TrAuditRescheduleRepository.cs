﻿using DigitalAudit.Helper;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Transaction
{
    public interface ITrAuditRescheduleRepository : IGenericRepository<TrAuditReschedule>
    {
        void Add(TrAuditReschedule entity, string user, DateTime actiondate);
        void Update(TrAuditReschedule entity, string user, DateTime actiondate);
        void Delete(TrAuditReschedule entity, string user, DateTime actiondate);

        List<fn_Get_TrAuditReschedule> Get_TrAuditReschedule(int? statusId, string userId);
        //TrAuditRescheduleViewModel.ReadAuditReschedule SelectOne(string id);
        //    List<TrAuditRescheduleViewModel.ReadAuditReschedule> SelectAll();
        //    List<fn_Get_TrAuditReschedule> Get_TrAuditReschedule(string scheduleId, string auditTypeId, int? statusId, string auditLocationId, string name, string regionId);
    }

    public class TrAuditRescheduleRepository : GenericRepository<TrAuditReschedule>, ITrAuditRescheduleRepository
    {
        public TrAuditRescheduleRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public TrAuditReschedule Get(string id)
        {
            return _context.TrAuditReschedules.Where(x => x.IsDeleted == false && x.RescheduleId == id).FirstOrDefault();
        }

        public List<TrAuditReschedule> GetAll()
        {
            return _context.TrAuditReschedules.Where(x => x.IsDeleted == false).ToList();
        }

        public void Add(TrAuditReschedule entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<TrAuditReschedule>().Add(entity);
        }

        public void Update(TrAuditReschedule entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrAuditReschedule>().Update(entity);
        }

        public void Delete(TrAuditReschedule entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrAuditReschedule>().Update(entity);
        }

        public List<fn_Get_TrAuditReschedule> Get_TrAuditReschedule(int? statusId , string userId)
        {
            var result = _context.Set<fn_Get_TrAuditReschedule>().FromSqlRaw("select * from dbo.fn_Get_TrAuditReschedule({0},{1},{2},{3},{4},{5},{6},{7})", null, null, statusId, null, null, null, userId, null);
            return result.ToList();
        }


        //public TrAuditRescheduleViewModel.ReadAuditReschedule SelectOne(string id)
        //{
        //    return Get_TrAuditReschedule(id, null, null, null, null, null).Select(o =>
        //        new TrAuditRescheduleViewModel.ReadAuditReschedule
        //        {
        //            ScheduleId = o.ScheduleId,
        //            AuditLocation = new MAuditLocationViewModel.ReadAuditLocation(o.AuditLocationId, o.LocationName, o.Address, o.ZipCode, o.LatLong, o.RegionId, o.RegionName),
        //            StartDate = o.StartDate,
        //            EndDate = o.EndDate,
        //            AuditType = new MAuditTypeViewModel.ReadAuditType(o.AuditTypeId, o.AuditType),
        //            Status = new MScheduleStatusViewModel.ReadScheduleStatus(o.StatusId, o.Status),
        //            Auditor = GetAuditorAuditee(o.ScheduleId, Constants.USER_TYPE.AUDITOR),
        //            Auditee = GetAuditorAuditee(o.ScheduleId, Constants.USER_TYPE.AUDITEE)
        //        }).FirstOrDefault();
        //}

        //public List<fn_Get_MUserGroup> Get_MUserGroup(string userGroupId, string userTypeId)
        //{
        //    var result = _context.Set<fn_Get_MUserGroup>().FromSqlRaw("select * from dbo.fn_Get_MUserGroup({0},{1})", userGroupId, userTypeId);
        //    return result.ToList();
        //}

        //public List<fn_Get_MUserMember> Get_MUserMember(string userMemberId, string userGroupId, string userTypeId)
        //{
        //    var result = _context.Set<fn_Get_MUserMember>().FromSqlRaw("select * from dbo.fn_Get_MUserMember({0},{1},{2})", userMemberId, userGroupId, userTypeId);
        //    return result.ToList();
        //}

        //public TrAuditReschedulePICViewModel.ReadAuditReschedulePIC GetAuditorAuditee(string scheduleId, string userTypeId)
        //{
        //    TrAuditReschedulePICViewModel.ReadAuditReschedulePIC result = new TrAuditReschedulePICViewModel.ReadAuditReschedulePIC();
        //    TrAuditReschedulePIC pic = _context.TrAuditReschedulePICs.Where(x => x.IsDeleted == false && x.ScheduleId == scheduleId && x.UserTypeId == userTypeId).FirstOrDefault();
        //    result.PicId = pic.PicId;
        //    result.ScheduleId = scheduleId;
        //    result.UserType = _context.MUserTypes.Where(x => x.IsDeleted == false && x.UserTypeId == userTypeId).Select(o =>
        //        new MUserTypeViewModel.ReadUserType
        //        {
        //            UserTypeId = o.UserTypeId,
        //            Name = o.Name
        //        }).FirstOrDefault();

        //    result.Status = _context.MScheduleStatuses.Where(x => x.IsDeleted == false && x.StatusId == pic.StatusId).Select(o =>
        //        new MScheduleStatusViewModel.ReadScheduleStatus
        //        {
        //            StatusId = o.StatusId,
        //            Name = o.Name
        //        }).FirstOrDefault();

        //    if (!string.IsNullOrEmpty(pic.UserId)) //user
        //    {
        //        MUserSyncViewModel.ReadUserSync user = _context.MUserSyncs.Where(x => x.IsDeleted == false).Select(o =>
        //        new MUserSyncViewModel.ReadUserSync
        //        {
        //            UserSyncId = o.UserSyncId,
        //            UserId = o.UserId,
        //            OrganizationId = o.OrganizationId,
        //            PositionId = o.PositionId,
        //            CompanyCode = o.CompanyCode,
        //            City = o.City,
        //            CompanyName = o.CompanyName,
        //            Country = o.Country,
        //            Department = o.Department,
        //            DisplayName = o.DisplayName,
        //            EmployeeId = o.EmployeeId,
        //            FirstName = o.FirstName,
        //            LastName = o.LastName,
        //            JobTitle = o.JobTitle,
        //            Email = o.Email,
        //            MobilePhone = o.MobilePhone,
        //            OfficeLocation = o.OfficeLocation,
        //            Username = o.Username
        //        }).FirstOrDefault();

        //        result.Users = user;
        //    }
        //    else //group
        //    {
        //        MUserGroupViewModel.ReadUserGroupMember group = Get_MUserGroup(null, null).ToList().Select(o =>
        //        new MUserGroupViewModel.ReadUserGroupMember
        //        {
        //            UserGroupId = o.UserGroupId,
        //            UserType = new MUserTypeViewModel.ReadUserType(o.UserTypeId, o.UserType),
        //            Name = o.Name,
        //            UserId = o.UserId,
        //            Username = o.Username,
        //            OfficialName = o.OfficialName,
        //            UserMember = Get_MUserMember(null, o.UserGroupId, o.UserTypeId).ToList().Select(o => new MUserMemberViewModel.ReadUserMember
        //            {
        //                UserMemberId = o.UserMemberId,
        //                UserId = o.UserIdMember,
        //                Username = o.UsernameMember,
        //                OfficialName = o.OfficialNameMember
        //            }).ToList()
        //        }).FirstOrDefault();

        //        result.Groups = group;
        //    }
        //    return result;
        //}

        //public List<TrAuditRescheduleViewModel.ReadAuditReschedule> SelectAll()
        //{
        //    return Get_TrAuditReschedule(null, null, null, null, null, null).Select(o =>
        //        new TrAuditRescheduleViewModel.ReadAuditReschedule
        //        {
        //            ScheduleId = o.ScheduleId,
        //            AuditLocation = new MAuditLocationViewModel.ReadAuditLocation(o.AuditLocationId, o.LocationName, o.Address, o.ZipCode, o.LatLong, o.RegionId, o.RegionName),
        //            StartDate = o.StartDate,
        //            EndDate = o.EndDate,
        //            AuditType = new MAuditTypeViewModel.ReadAuditType(o.AuditTypeId, o.AuditType),
        //            Status = new MScheduleStatusViewModel.ReadScheduleStatus(o.StatusId, o.Status),
        //            Auditor = GetAuditorAuditee(o.ScheduleId, Constants.USER_TYPE.AUDITOR),
        //            Auditee = GetAuditorAuditee(o.ScheduleId, Constants.USER_TYPE.AUDITEE)
        //        }).ToList();
        //}


        //public List<fn_Get_TrAuditReschedule> Get_TrAuditReschedule(string scheduleId, string auditTypeId, int? statusId, string auditLocationId, string name, string regionId)
        //{
        //    return _context.Set<fn_Get_TrAuditReschedule>().FromSqlRaw("select * from dbo.fn_Get_TrAuditReschedule({0},{1},{2},{3},{4},{5})", scheduleId, auditTypeId, statusId, auditLocationId, name, regionId).ToList();
        //}
    }
}
