﻿using DigitalAudit.Model.Database;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DigitalAudit.Repository.Transaction
{
    public interface ITrIssueLogRepository : IGenericRepository<TrIssueLog>
    {
        IQueryable<TrIssueLog> SelectAllLogIssue(string IssueId);
    }

    public class TrIssueLogRepository : GenericRepository<TrIssueLog>, ITrIssueLogRepository
    {
        public TrIssueLogRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public TrIssueLog Get(string id)
        {
            return GetAll().Where(x => x.IsDeleted == false && x.LogId == id).FirstOrDefault();
        }

        public IQueryable<TrIssueLog> GetAll()
        {
            return _context.TrIssueLogs.AsQueryable();
        }

        public void Add(TrIssueLog entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<TrIssueLog>().Update(entity);
        }

        public void Update(TrIssueLog entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrIssueLog>().Update(entity);
        }

        public void Delete(TrIssueLog entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrIssueLog>().Update(entity);
        }

        public IQueryable<TrIssueLog> SelectAllLogIssue(string IssueId)
        {            
            var dataQuery = GetAll().Where(x => x.IsDeleted == false && x.IssueId.Equals(IssueId));
            dataQuery = dataQuery.Include(x => x.LogType);
            dataQuery = dataQuery.Select(x => new TrIssueLog
            {
                LogId = x.LogId,
                IssueId = x.IssueId,
                UserId = x.UserId,
                Username = x.Username,
                TextLog = x.TextLog,
                DatetimeLog = x.DatetimeLog,
                Filename = x.Filename,
                LinkFile = x.LinkFile,
                LogType = new MLogType
                {
                    LogTypeId = x.LogType.LogTypeId,
                    Name = x.LogType.Name
                }
            });

            return dataQuery.OrderBy(o => o.DatetimeLog);
        }
    }
}
