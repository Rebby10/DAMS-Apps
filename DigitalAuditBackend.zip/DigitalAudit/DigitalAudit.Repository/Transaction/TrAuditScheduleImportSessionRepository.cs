﻿using DigitalAudit.Model.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Transaction
{
    public interface ITrAuditScheduleImportSessionRepository : IGenericRepository<TrAuditScheduleImportSession>
    {
        void Add(TrAuditScheduleImportSession entity, string user, DateTime actiondate);
        void Update(TrAuditScheduleImportSession entity, string user, DateTime actiondate);
        void Delete(TrAuditScheduleImportSession entity, string user, DateTime actiondate);
    }
    public class TrAuditScheduleImportSessionRepository : GenericRepository<TrAuditScheduleImportSession>, ITrAuditScheduleImportSessionRepository
    {
        public TrAuditScheduleImportSessionRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public TrAuditScheduleImportSession Get(string id)
        {
            return _context.TrAuditScheduleImportSessions.Where(x => x.IsDeleted == false && x.SessionId == id).FirstOrDefault();
        }

        public IEnumerable<TrAuditScheduleImportSession> GetAll()
        {
            return _context.TrAuditScheduleImportSessions.Where(x => x.IsDeleted == false);
        }

        public void Add(TrAuditScheduleImportSession entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<TrAuditScheduleImportSession>().Update(entity);
        }

        public void Update(TrAuditScheduleImportSession entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrAuditScheduleImportSession>().Update(entity);
        }

        public void Delete(TrAuditScheduleImportSession entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrAuditScheduleImportSession>().Update(entity);
        }
    }
}
