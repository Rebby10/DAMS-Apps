﻿using DigitalAudit.Helper;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Transaction
{
    public interface ITrAuditSchedulePICRepository : IGenericRepository<TrAuditSchedulePIC>
    {
        void Add(TrAuditSchedulePIC entity, string user, DateTime actiondate);
        void Update(TrAuditSchedulePIC entity, string user, DateTime actiondate);
        void Delete(TrAuditSchedulePIC entity, string user, DateTime actiondate);
        void AddLists(List<TrAuditSchedulePIC> entities);

        List<fn_Get_TrAuditSchedulePICID> Get_AuditSchedulePICID(string scheduleId, string userId);
    }

    public class TrAuditSchedulePICRepository : GenericRepository<TrAuditSchedulePIC>, ITrAuditSchedulePICRepository
    {
        public TrAuditSchedulePICRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public TrAuditSchedulePIC Get(string id)
        {
            return _context.TrAuditSchedulePICs.Where(x => x.IsDeleted == false && x.PicId == id).FirstOrDefault();
        }

        public List<TrAuditSchedulePIC> GetAll()
        {
            return _context.TrAuditSchedulePICs.Where(x => x.IsDeleted == false).ToList();
        }

        public void Add(TrAuditSchedulePIC entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<TrAuditSchedulePIC>().Add(entity);
        }

        public void AddLists(List<TrAuditSchedulePIC> entities)
        {
            _context.Set<TrAuditSchedulePIC>().AddRange(entities);
        }

        public void Update(TrAuditSchedulePIC entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrAuditSchedulePIC>().Update(entity);
        }

        public void Delete(TrAuditSchedulePIC entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrAuditSchedulePIC>().Update(entity);
        }

        public List<fn_Get_TrAuditSchedulePICID> Get_AuditSchedulePICID(string scheduleId, string userId)
        {
            var result = _context.Set<fn_Get_TrAuditSchedulePICID>().FromSqlRaw("select * from dbo.fn_Get_TrAuditSchedulePICID({0},{1})", scheduleId, userId);
            return result.ToList();
        }
    }
}
