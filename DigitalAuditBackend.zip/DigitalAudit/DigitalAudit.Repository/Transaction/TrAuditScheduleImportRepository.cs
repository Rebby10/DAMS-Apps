﻿using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitalAudit.Repository.Transaction
{
    public interface ITrAuditScheduleImportRepository : IGenericRepository<TrAuditScheduleImport>
    {
        void AddLists(List<TrAuditScheduleImport> entities);
        void Update(TrAuditScheduleImport entity, string user, DateTime actiondate);
        void Delete(TrAuditScheduleImport entity, string user, DateTime actiondate);
        StatusViewModel ScheduleImportValidate(string sessionId, string username);
        IEnumerable<fn_Get_ScheduleImport> GetScheduleImport(string sessionId);
    }

    public class TrAuditScheduleImportRepository : GenericRepository<TrAuditScheduleImport>, ITrAuditScheduleImportRepository
    {
        public TrAuditScheduleImportRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public TrAuditScheduleImport Get(string id)
        {
            return _context.TrAuditScheduleImports.Where(x => x.IsDeleted == false && x.ScheduleImportId == id).FirstOrDefault();
        }

        public IEnumerable<TrAuditScheduleImport> GetAll()
        {
            return _context.TrAuditScheduleImports.Where(x => x.IsDeleted == false);
        }

        public void Add(TrAuditScheduleImport entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<TrAuditScheduleImport>().Update(entity);
        }

        public void AddLists(List<TrAuditScheduleImport> entities)
        {
            _context.Set<TrAuditScheduleImport>().AddRange(entities);
        }

        public void Update(TrAuditScheduleImport entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrAuditScheduleImport>().Update(entity);
        }

        public void Delete(TrAuditScheduleImport entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrAuditScheduleImport>().Update(entity);
        }

        public StatusViewModel ScheduleImportValidate(string sessionId, string username)
        {
            IEnumerable<StatusViewModel> result = _context.Set<StatusViewModel>().FromSqlRaw("exec spScheduleImportValidate {0},{1}", sessionId, username);
            return result.FirstOrDefault();
        }

        public IEnumerable<fn_Get_ScheduleImport> GetScheduleImport(string sessionId)
        {
            return _context.Set<fn_Get_ScheduleImport>()
                .FromSqlRaw("select * from dbo.fn_Get_ScheduleImport({0},{1},{2},{3})", sessionId, null, null, null);
        }
    }
}
