﻿using DigitalAudit.Model.Database;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;

namespace DigitalAudit.Repository.Transaction
{
    public interface ITrActionRepairRepository : IGenericRepository<TrActionRepair>
    {
        void Update(TrActionRepair entity, string user, DateTime actiondate);
        void Delete(TrActionRepair entity, string user, DateTime actiondate);
        TrActionRepair SelectOne(string Id);
        IQueryable<TrActionRepair> SelectAll(string ActionRepairId, string ActionId, string RootCause, string RootCauseCategoryId, string ActionRepair, string ActionRepairCategoryId, DateTime? StartDate, DateTime? EndDate);
    }

    public class TrActionRepairRepository : GenericRepository<TrActionRepair>, ITrActionRepairRepository
    {
        public TrActionRepairRepository(DigitalAuditDbContext context) : base(context)
        {
        }

        public void Delete(TrActionRepair entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrActionRepair>().Update(entity);
        }

        public IQueryable<TrActionRepair> SelectAll(string ActionRepairId, string ActionId, string RootCause, string RootCauseCategoryId, string ActionRepair, string ActionRepairCategoryId, DateTime? StartDate, DateTime? EndDate)
        {
            var dataQuery = GetAll().Where(x => x.IsDeleted == false);
            dataQuery = dataQuery.Include(x => x.Action);
            dataQuery = dataQuery.Include(x => x.ActionRepairCategory);
            dataQuery = dataQuery.Include(x => x.RootCauseCategory);

            if (!string.IsNullOrEmpty(ActionRepairId))
            {
                dataQuery = dataQuery.Where(x => x.ActionRepairId.Equals(ActionRepairId));
            }

            if (!string.IsNullOrEmpty(ActionId))
            {
                dataQuery = dataQuery.Where(x => x.ActionId.Equals(ActionId));
            }

            if (!string.IsNullOrEmpty(RootCause))
            {
                dataQuery = dataQuery.Where(x => x.RootCause.ToLower().Contains(RootCause));
            }

            if (!string.IsNullOrEmpty(RootCauseCategoryId))
            {
                dataQuery = dataQuery.Where(x => x.RootCauseCategoryId.Equals(RootCauseCategoryId));
            }

            if (!string.IsNullOrEmpty(ActionRepair))
            {
                dataQuery = dataQuery.Where(x => x.ActionRepair.ToLower().Contains(ActionRepair));
            }

            if (!string.IsNullOrEmpty(ActionRepairCategoryId))
            {
                dataQuery = dataQuery.Where(x => x.ActionRepairCategoryId.Equals(ActionRepairCategoryId));
            }

            if (StartDate != null)
            {
                dataQuery = dataQuery.Where(x => x.DateCreated >= StartDate);
            }
            if (EndDate != null)
            {
                dataQuery = dataQuery.Where(x => x.DateCreated <= EndDate);
            }

            dataQuery = dataQuery.Select(x => new TrActionRepair
            {
                ActionRepairId = x.ActionRepairId,
                ActionId = x.ActionId,
                Action = x.Action != null ? new TrAction
                {
                    ActionId = x.Action.ActionId,
                    Title = x.Action.Title
                } : new TrAction(),
                RootCause = x.RootCause,
                RootCauseCategoryId = x.RootCauseCategoryId,
                RootCauseCategory = x.RootCauseCategory != null ? new MRootCauseCategory
                {
                    RootCauseCategoryId = x.RootCauseCategory.RootCauseCategoryId,
                    Name = x.RootCauseCategory.Name
                } : new MRootCauseCategory(),
                ActionRepair = x.ActionRepair,
                ActionRepairCategoryId = x.ActionRepairCategoryId,
                ActionRepairCategory = x.ActionRepairCategory != null? new MActionRepairCategory
                {
                    ActionRepairCategoryId = x.ActionRepairCategory.ActionRepairCategoryId,
                    Name = x.ActionRepairCategory.Name
                } : new MActionRepairCategory(),
                RepairDate = x.RepairDate,
                Filename = x.Filename,
                LinkFile = x.LinkFile,
                IsDeleted = x.IsDeleted,
                UserCreated = x.UserCreated,
                DateCreated = x.DateCreated,
                UserModified = x.UserModified,
                DateModified = x.DateModified
            });

            return dataQuery;
        }

        public IQueryable<TrActionRepair> GetAll()
        {
            return _context.TrActionRepairs.AsQueryable();
        }

        public TrActionRepair SelectOne(string Id)
        {
            var dataQuery = GetAll().Where(x => x.IsDeleted == false && x.ActionRepairId == Id).FirstOrDefault();

            return dataQuery;
        }

        public void Update(TrActionRepair entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrActionRepair>().Update(entity);
        }

        public void Add(TrActionRepair entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<TrActionRepair>().Update(entity);
        }
    }
}
