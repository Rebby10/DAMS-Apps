﻿using DigitalAudit.Model.Database;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;

namespace DigitalAudit.Repository.Transaction
{
    public interface ITrActionRepository : IGenericRepository<TrAction>
    {
        void Update(TrAction entity, string user, DateTime actiondate);
        void Delete(TrAction entity, string user, DateTime actiondate);
        fn_Get_Action SelectOne(string ActionId);
        IQueryable<fn_Get_Action> SelectAll(string ActionId, string Title, string AuditLocationId, int? PriorityId, int? StatusId, string UserCreated, string AssignUser, DateTime? StartDate, DateTime? EndDate, string AuditTypeId, bool? IsConnectedToIssue, string RegionId, string IssueId);
    }

    class TrActionRepository : GenericRepository<TrAction>, ITrActionRepository
    {
        public TrActionRepository(DigitalAuditDbContext context) : base(context)
        {

        }

        public TrAction Get(string id)
        {
            return _context.TrActions.Where(x => x.IsDeleted == false && x.ActionId == id).FirstOrDefault();
        }

        public IQueryable<TrAction> GetAll()
        {
            return _context.TrActions.AsQueryable();
        }

        public void Add(TrAction entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = false;
            entity.UserCreated = user;
            entity.DateCreated = actiondate;
            _context.Set<TrAction>().Update(entity);
        }

        public void Update(TrAction entity, string user, DateTime actiondate)
        {
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrAction>().Update(entity);
        }

        public void Delete(TrAction entity, string user, DateTime actiondate)
        {
            entity.IsDeleted = true;
            entity.UserModified = user;
            entity.DateModified = actiondate;
            _context.Set<TrAction>().Update(entity);
        }

        public fn_Get_Action SelectOne(string ActionId)
        {
            return GetAction(ActionId, null, null, null, null, null, null, null, null, null, null, null, null).FirstOrDefault();
        }

        public IQueryable<fn_Get_Action> SelectAll(string ActionId, string Title, string AuditLocationId, int? PriorityId, int? StatusId, string UserCreated, string AssignUser, 
            DateTime? StartDate, DateTime? EndDate, string AuditTypeId, bool? IsConnectedToIssue, string RegionId, string issueId)
        {
            return GetAction(ActionId, Title, AuditLocationId, PriorityId, StatusId, UserCreated, AssignUser, StartDate, EndDate, AuditTypeId, IsConnectedToIssue, RegionId, issueId);
        }

        public IQueryable<fn_Get_Action> GetAction(string ActionId, string Title, string AuditLocationId, int? PriorityId, int? StatusId, string UserCreated, string AssignUser
            , DateTime? StartDate, DateTime? EndDate, string AuditTypeId, bool? IsConnectedToIssue, string RegionId, string issueId)
        {
            var dataQuery = _context.Set<fn_Get_Action>()
                .FromSqlRaw("select * from dbo.fn_Get_Action({0},{1},{2},{3},{4},{5},{6},{7},{8},{9}, {10}, {11})", ActionId, Title, AuditLocationId, PriorityId, StatusId, UserCreated, AssignUser, StartDate, EndDate, AuditTypeId, RegionId, issueId);

            if (IsConnectedToIssue != null)
            {
                if (Convert.ToBoolean(IsConnectedToIssue))
                {
                    dataQuery = dataQuery.Where(x => x.IssueId != null);
                }
                else
                {
                    dataQuery = dataQuery.Where(x => x.IssueId == null);
                }

            }

            return dataQuery;
        }
    }
}
