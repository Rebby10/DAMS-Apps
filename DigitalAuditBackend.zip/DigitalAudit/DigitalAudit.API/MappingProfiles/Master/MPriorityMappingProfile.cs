﻿using AutoMapper;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DigitalAudit.API.MappingProfiles.Master
{
    public class MPriorityMappingProfile : Profile
    {
        public MPriorityMappingProfile()
        {
            CreateMap<MPriority, MPriorityViewModel.ReadPriority>()
                .ForMember(d => d.PriorityId, o => o.MapFrom(src => src.PriorityId))
                .ForMember(d => d.Name, o => o.MapFrom(src => src.Name))
                ;
        }
    }
}
