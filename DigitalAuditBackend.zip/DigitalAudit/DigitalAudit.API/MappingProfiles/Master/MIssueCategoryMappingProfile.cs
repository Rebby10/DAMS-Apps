﻿using AutoMapper;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DigitalAudit.API.MappingProfiles.Master
{
    public class MIssueCategoryMappingProfile : Profile
    {
        public MIssueCategoryMappingProfile()
        {
            CreateMap<MIssueCategory, MIssueCategoryViewModel.ReadIssueCategory>()
                .ForMember(d => d.IssueCategoryId, o => o.MapFrom(src => src.IssueCategoryId))
                .ForMember(d => d.Name, o => o.MapFrom(src => src.Name))
                ;
        }
    }
}
