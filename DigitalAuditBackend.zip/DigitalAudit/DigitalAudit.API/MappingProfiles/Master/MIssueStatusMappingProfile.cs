﻿using AutoMapper;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DigitalAudit.API.MappingProfiles.Master
{
    public class MIssueStatusMappingProfile : Profile
    {
        public MIssueStatusMappingProfile()
        {
            CreateMap<MIssueStatus, MIssueStatusViewModel.ReadIssueStatus>()
                .ForMember(d => d.StatusId, o => o.MapFrom(src => src.StatusId))
                .ForMember(d => d.Name, o => o.MapFrom(src => src.Name))
                ;
        }
    }
}
