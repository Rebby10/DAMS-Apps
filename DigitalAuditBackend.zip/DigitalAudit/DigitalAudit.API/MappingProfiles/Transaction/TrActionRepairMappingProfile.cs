﻿using AutoMapper;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using System.Globalization;

namespace DigitalAudit.API.MappingProfiles.Transaction
{
    public class TrActionRepairMappingProfile : Profile
    {
        public TrActionRepairMappingProfile()
        {
            CreateMap<TrActionRepair, TrActionRepairViewModel.ReadActionRepair>()
                .ForMember(d => d.ActionRepairId, o => o.MapFrom(src => src.ActionRepairId))
                .ForMember(d => d.Action, o => o.MapFrom((src, dest) => new TrActionViewModel.ReadActionRepair
                {
                    ActionId = src.Action.ActionId,
                    Title = src.Action.Title
                }))
                .ForMember(d => d.RootCause, o => o.MapFrom(src => src.RootCause))
                .ForMember(d => d.RootCauseCategory, o => o.MapFrom((src, dest) => new MRootCauseCategoryViewModel.ReadRootCauseCategory
                {
                    Id = src.RootCauseCategory.RootCauseCategoryId,
                    Name = src.RootCauseCategory.Name
                }))
                .ForMember(d => d.ActionRepair, o => o.MapFrom(src => src.ActionRepair))
                .ForMember(d => d.ActionRepairCategory, o => o.MapFrom((src, dest) => new MActionRepairCategoryViewModel.ReadActionRepairCategory
                {
                    Id = src.ActionRepairCategory.ActionRepairCategoryId,
                    Name = src.ActionRepairCategory.Name
                }))
                .ForMember(d => d.RepairDate, o => o.MapFrom((src, dest) =>
                {
                    return src.RepairDate == null ? null : src.RepairDate.ToString("s", DateTimeFormatInfo.InvariantInfo);
                }))
                .ForMember(d => d.Filename, o => o.MapFrom(src => src.Filename))
                //.ForMember(d => d.LinkFile, o => o.MapFrom(src => src.LinkFile))
                ;
        }
    }
}
