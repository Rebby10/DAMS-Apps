﻿using AutoMapper;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using System;
using System.Globalization;

namespace DigitalAudit.API.MappingProfiles.Transaction
{
    public class TrIssueMappingProfile : Profile
    {
        public TrIssueMappingProfile()
        {
            CreateMap<fn_Get_Issue, TrIssueViewModel.ReadIssue>()
                .ForMember(d => d.IssueId, o => o.MapFrom(src => src.IssueId))
                .ForMember(d => d.Title, o => o.MapFrom(src => src.Title))
                .ForMember(d => d.Descriptions, o => o.MapFrom(src => src.Descriptions))
                .ForMember(d => d.QuestionId, o => o.MapFrom(src => src.QuestionId))
                .ForMember(d => d.Code, o => o.MapFrom(src => src.Code))
                .ForMember(d => d.Question, o => o.MapFrom(src => src.Question))
                //.ForMember(d => d.AuditTypeId, o => o.MapFrom(src => src.AuditTypeId))
                //.ForMember(d => d.AuditType, o => o.MapFrom(src => src.AuditType))
                .ForMember(d => d.AuditType, o => o.MapFrom((src, dest) => new MAuditTypeViewModel.ReadAuditType
                {
                    AuditTypeId = src.AuditTypeId,
                    Name = src.AuditType
                }))
                //.ForMember(d => d.AuditLocationId, o => o.MapFrom(src => src.AuditLocationId))
                //.ForMember(d => d.LocationName, o => o.MapFrom(src => src.LocationName))
                .ForMember(d => d.AuditLocation, o => o.MapFrom((src, dest) =>
                {
                    if (src.AuditLocationId == null) return new MAuditLocationViewModel.ReadAuditLocation();

                    var auditLocation = new MAuditLocationViewModel.ReadAuditLocation
                    {
                        AuditLocationId = src.AuditLocationId,
                        Name = src.LocationName,
                        Address = src.AuditLocationAddress,
                        ZipCode = src.AuditLocationZipCode,
                        LatLong = src.LatLong,
                        Region = new MRegionViewModel.ReadRegion
                        {
                            RegionId = src.RegionId,
                            Name = src.Region
                        }
                    };

                    return auditLocation;
                }))
                //.ForMember(d => d.RegionId, o => o.MapFrom(src => src.RegionId))
                //.ForMember(d => d.Region, o => o.MapFrom(src => src.Region))
                //.ForMember(d => d.LatLong, o => o.MapFrom(src => src.LatLong))
                //.ForMember(d => d.AssignGroup, o => o.MapFrom(src => src.AssignGroup))
                //.ForMember(d => d.UserGroupName, o => o.MapFrom(src => src.UserGroupName))
                //.ForMember(d => d.GroupLeader, o => o.MapFrom(src => src.GroupLeader))
                .ForMember(d => d.AssignGroup, o => o.MapFrom((src, dest) =>
                {
                    if (src.AssignGroup == null) return new MUserGroupViewModel.ReadUserGroup();

                    var assignGroup = new MUserGroupViewModel.ReadUserGroup
                    {
                        UserGroupId = src.AssignGroup,
                        Name = src.UserGroupName,
                        UserId = src.GroupLeader,
                        UserType = new MUserTypeViewModel.ReadUserType
                        {
                            UserTypeId = src.UserGroupTypeId,
                            Name = src.UserGroupTypeName
                        },
                        Username = src.GroupLeaderName
                    };

                    return assignGroup;
                }))
                //.ForMember(d => d.AssignUser, o => o.MapFrom(src => src.AssignUser))
                .ForMember(d => d.AssignUser, o => o.MapFrom((src, dest) => new MUserSyncViewModel.ReadUserLite
                {
                    UserId = src.AssignUser,
                    DisplayName = src.AssignUserName,
                    Email = src.AssignUserEmail
                }))
                //.ForMember(d => d.Creator, o => o.MapFrom(src => src.Creator))
                .ForMember(d => d.Creator, o => o.MapFrom((src, dest) => new MUserSyncViewModel.ReadUserLite
                {
                    UserId = src.Creator,
                    DisplayName = src.CreatorName,
                    Email = src.CreatorEmail
                }))
                //.ForMember(d => d.PriorityId, o => o.MapFrom(src => src.PriorityId))
                //.ForMember(d => d.Priority, o => o.MapFrom(src => src.Priority))
                .ForMember(d => d.Priority, o => o.MapFrom((src, dest) => new MPriorityViewModel.ReadPriority
                {
                    PriorityId = src.PriorityId,
                    Name = src.Priority
                }))
                .ForMember(d => d.TargetClosing, o => o.MapFrom((src, dest) =>
                 {
                     return src.TargetClosing == null ? null : src.TargetClosing.ToString("s", DateTimeFormatInfo.InvariantInfo);
                 }))
                //.ForMember(d => d.IssueCategory, o => o.MapFrom(src => src.IssueCategory))
                .ForMember(d => d.IssueCategory, o => o.MapFrom((src, dest) => new MIssueCategoryViewModel.ReadIssueCategory
                {
                    IssueCategoryId = src.IssueCategoryId,
                    Name = src.IssueCategory
                }))
                 .ForMember(d => d.Status, o => o.MapFrom((src, dest) => new MIssueStatusViewModel.ReadIssueStatus
                 {
                     StatusId = src.StatusId,
                     Name = src.IssueStatus
                 }))
                //.ForMember(d => d.StatusId, o => o.MapFrom(src => src.StatusId))
                //.ForMember(d => d.IssueStatus, o => o.MapFrom(src => src.IssueStatus))
                .ForMember(d => d.RecurringFinding, o => o.MapFrom(src => src.RecurringFinding))
                .ForMember(d => d.UserCreated, o => o.MapFrom(src => src.UserCreated))
                .ForMember(d => d.DateCreated, o => o.MapFrom((src, dest) =>
                {
                    return src.DateCreated == null ? null : src.DateCreated.ToString("s", DateTimeFormatInfo.InvariantInfo);
                }))
                .ForMember(d => d.UserModified, o => o.MapFrom(src => src.UserModified))
                .ForMember(d => d.DateModified, o => o.MapFrom((src, dest) =>
                {
                    return src.DateModified == null ? src.DateCreated.ToString("s", DateTimeFormatInfo.InvariantInfo) : Convert.ToDateTime(src.DateModified).ToString("s", DateTimeFormatInfo.InvariantInfo);
                }))
                .ForMember(d => d.LastUpdate, o => o.MapFrom(src => src.LastUpdate))
                .ForMember(d => d.IsConnectedToAction, o => o.MapFrom((src, dest) =>
                {
                    return src.TotalAction > 0 ? true : false;
                }))
                ;
        }
    }
}
