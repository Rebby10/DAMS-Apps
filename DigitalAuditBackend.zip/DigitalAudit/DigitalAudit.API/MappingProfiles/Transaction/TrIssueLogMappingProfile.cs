﻿using AutoMapper;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using System.Globalization;

namespace DigitalAudit.API.MappingProfiles.Transaction
{
    public class TrIssueLogMappingProfile : Profile
    {
        public TrIssueLogMappingProfile()
        {
            CreateMap<TrIssueLog, TrIssueLogViewModel.ReadIssueLog>()
                .ForMember(d => d.Id, o => o.MapFrom(src => src.LogId))
                .ForMember(d => d.IssueId, o => o.MapFrom(src => src.IssueId))
                .ForMember(d => d.Text, o => o.MapFrom(src => src.TextLog))
                .ForMember(d => d.Datetime, o => o.MapFrom(src => src.DatetimeLog))
                .ForMember(d => d.Datetime, o => o.MapFrom((src, dest) =>
                {
                    return src.DatetimeLog == null ? null : src.DatetimeLog.ToString("s", DateTimeFormatInfo.InvariantInfo);
                }))
                .ForMember(d => d.Filename, o => o.MapFrom(src => src.Filename))
                .ForMember(d => d.Link, o => o.MapFrom(src => src.LinkFile))
                .ForMember(d => d.User, o => o.MapFrom((src, dest) => new UserIdamanViewModel.UserRead
                {
                    UserId = src.UserId,
                    DisplayName = src.Username
                }))
                .ForMember(d => d.Type, o => o.MapFrom((src, dest) => new MLogTypeViewModel.ReadLogType
                {
                    LogTypeId = src.LogType.LogTypeId,
                    Name = src.LogType.Name
                }))
                
                ;
        }
    }
}
