﻿using AutoMapper;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using System;
using System.Globalization;

namespace DigitalAudit.API.MappingProfiles.Transaction
{
    public class TrActionMappingProfile : Profile
    {
        public TrActionMappingProfile()
        {
            CreateMap<fn_Get_Action, TrActionViewModel.ReadAction>()
                .ForMember(d => d.ActionId, o => o.MapFrom(src => src.ActionId))
                .ForMember(d => d.Title, o => o.MapFrom(src => src.Title))
                .ForMember(d => d.Descriptions, o => o.MapFrom(src => src.Descriptions))
                .ForMember(d => d.QuestionId, o => o.MapFrom(src => src.QuestionId))
                .ForMember(d => d.Code, o => o.MapFrom(src => src.Code))
                .ForMember(d => d.Question, o => o.MapFrom(src => src.Question))
                .ForMember(d => d.AuditType, o => o.MapFrom((src, dest) => new MAuditTypeViewModel.ReadAuditType
                {
                    AuditTypeId = src.AuditTypeId,
                    Name = src.AuditTypeName
                }))
                .ForMember(d => d.Issue, o => o.MapFrom((src, dest) => new TrIssueViewModel.ReadIssueLite
                {
                    IssueId = src.IssueId,
                    Title = src.IssueTitle
                })) 
                .ForMember(d => d.AuditLocation, o => o.MapFrom((src, dest) => 
                {
                    if (src.AuditLocationId == null) return new MAuditLocationViewModel.ReadAuditLocation();

                    var auditLocation = new MAuditLocationViewModel.ReadAuditLocation
                    {
                        AuditLocationId = src.AuditLocationId,
                        Name = src.AuditLocationName,
                        Address = src.AuditLocationAddress,
                        ZipCode = src.AuditLocationZipCode,
                        LatLong = src.AuditLocationLatLong,
                        Region = new MRegionViewModel.ReadRegion
                        {
                            RegionId = src.AuditLocationRegionId,
                            Name = src.RegionName
                        }
                    };

                    return auditLocation;
                }))
                .ForMember(d => d.AssignGroup, o => o.MapFrom((src, dest) =>
                {
                    if (src.AssignGroup == null) return new MUserGroupViewModel.ReadUserGroup();

                    var assignGroup = new MUserGroupViewModel.ReadUserGroup
                    {
                        UserGroupId = src.AssignGroup,
                        Name = src.AssignGroupName,
                        UserId = src.AssignGroupUserId,
                        UserType = new MUserTypeViewModel.ReadUserType
                        {
                            UserTypeId = src.AssignGroupTypeId,
                            Name = src.AssignGroupTypeName
                        },
                        Username = src.AssignGroupUserName
                    };

                    return assignGroup;
                }))
                .ForMember(d => d.AssignUser, o => o.MapFrom((src, dest) => new MUserSyncViewModel.ReadUserLite
                {
                    UserId = src.AssignUser,
                    DisplayName = src.AssignUserDisplayName,
                    Email = src.AssignUserEmail
                }))
                .ForMember(d => d.Creator, o => o.MapFrom((src, dest) => new MUserSyncViewModel.ReadUserLite
                {
                    UserId = src.Creator,
                    DisplayName = src.CreatorDisplayName,
                    Email = src.CreatorEmail
                }))
                .ForMember(d => d.Priority, o => o.MapFrom((src, dest) => new MPriorityViewModel.ReadPriority
                {
                    PriorityId = src.PriorityId,
                    Name = src.PriorityName
                }))
                .ForMember(d => d.TargetClosing, o => o.MapFrom((src, dest) =>
                {
                    return src.TargetClosing == null ? null : src.TargetClosing.ToString("s", DateTimeFormatInfo.InvariantInfo);
                }))
                .ForMember(d => d.Status, o => o.MapFrom((src, dest) => new MIssueStatusViewModel.ReadIssueStatus
                {
                    StatusId = src.StatusId,
                    Name = src.StatusName
                }))
                .ForMember(d => d.InspectionId, o => o.MapFrom(src => src.InspectionId))
                .ForMember(d => d.DateCreated, o => o.MapFrom((src, dest) =>
                {
                    return src.DateCreated == null ? null : src.DateCreated.ToString("s", DateTimeFormatInfo.InvariantInfo);
                }))
                .ForMember(d => d.DateModified, o => o.MapFrom((src, dest) =>
                {
                    return src.DateModified == null ? null : Convert.ToDateTime(src.DateModified).ToString("s", DateTimeFormatInfo.InvariantInfo);
                }))
                ;
        }
    }
}
