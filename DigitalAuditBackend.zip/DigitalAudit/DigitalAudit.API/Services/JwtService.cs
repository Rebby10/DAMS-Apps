﻿using DigitalAudit.Model.Database;
using DigitalAudit.Model.Util;
using DigitalAudit.Model.ViewModel;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace DigitalAudit.API.Services
{
    public class JwtService
    {
        private readonly string _secret;
        private readonly string _expDate;
        private readonly string _validIssuer;
        private readonly string _validAudience;

        public JwtService(IConfiguration config)
        {
            _secret = config.GetSection("JwtConfig").GetSection("secret").Value;
            _expDate = config.GetSection("JwtConfig").GetSection("expirationInMinutes").Value;
            _validIssuer = config.GetSection("JwtConfig").GetSection("validIssuer").Value;
            _validAudience = config.GetSection("JwtConfig").GetSection("validAudience").Value;
        }

        //public string GenerateSecurityToken(string userId)
        //{
        //var claims = new List<Claim>();
        //Claim userIdClaim = new Claim("UserId", "12345");
        //claims.Add(userIdClaim);
        ////Avoid Replay attack
        //claims.Add(new Claim(ClaimTypes.GivenName, "User GivenName"));
        //claims.Add(new Claim(ClaimTypes.Surname, "UserSurname"));
        //claims.Add(new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()));

        //string[] roles = "Role1,Role2,Role23".Split(",");

        //foreach (string role in roles)
        //{
        //    claims.Add(new Claim(role, ""));
        //}

        //var tokenHandler = new JwtSecurityTokenHandler();
        //var key = Encoding.ASCII.GetBytes(_secret);
        //var tokenDescriptor = new SecurityTokenDescriptor
        //{
        //    Subject = new ClaimsIdentity(claims),
        //    Expires = DateTime.UtcNow.AddMinutes(double.Parse(_expDate)),
        //    SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
        //};

        //var token = tokenHandler.CreateToken(tokenDescriptor);

        //return tokenHandler.WriteToken(token);

        //}

        public TokenModel GenerateSecurityToken(UserIdamanViewModel user)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_secret));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new List<Claim>();
            Claim userIdClaim = new Claim("UserId", user.UserId);
            claims.Add(userIdClaim);
            //Avoid Replay attack
            claims.Add(new Claim(ClaimTypes.GivenName, user.DisplayName));
            claims.Add(new Claim(ClaimTypes.Surname, user.DisplayName));
            claims.Add(new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()));

            string[] roles = "Role1,Role2,Role23".Split(",");

            foreach (string role in roles)
            {
                claims.Add(new Claim(role, ""));
            }

            var token = new JwtSecurityToken(
                issuer: _validIssuer,
                audience: _validAudience,
                claims: claims,
                expires: DateTime.UtcNow.AddMinutes(double.Parse(_expDate)),
                signingCredentials: credentials
                );

            string tokenKey = new JwtSecurityTokenHandler().WriteToken(token);
            //MUserSyncViewModel.ReadUserToken readUserToken = new MUserSyncViewModel.ReadUserToken(user.UserId, user.OrganizationId, user.PositionId, user.CompanyCode
            //    , user.City, user.CompanyName, user.Country, user.Department, user.DisplayName, user.EmployeeId, user.FirstName, user.LastName, user.JobTitle, user.Email, user.MobilePhone, user.OfficeLocation, user.Username);
            TokenModel tokenModel = new TokenModel(tokenKey, DateTime.UtcNow.AddMinutes(double.Parse(_expDate)), user);

            return tokenModel;

        }
    }
}
