﻿using AutoMapper;
using DigitalAudit.Model.ViewModel;
using Microsoft.Extensions.Configuration;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using DigitalAudit.Helper;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using DigitalAudit.Model.ViewModel.Idaman;

namespace DigitalAudit.API.Services
{
    public interface IIdamanService
    {
        Task<BaseApiResultViewModel<UserIdamanViewModel>> GetUsersAsync(string email);
        Task<BaseApiResultViewModel<UserIdamanViewModel>> GetUserDetail(string id);
        Task<BaseApiResultViewModel<UserIdamanAllViewModels>> GetAllUser(int start, int take);
        Task<BaseApiResultViewModel<List<RoleIdamanAllViewModel>>> GetAllRole(string userId);
        Task<BaseApiResultViewModel<UserWhitelistIdamanAllViewModel>> GetUserWhitelist(string userId, int start, int take);
    }

    public class IdamanService : IIdamanService
    {
        private HttpClient _client;
        private readonly string DigitalAuditApplicationId;
        private IConfiguration _config;

        public IdamanService(IConfiguration configuration)
        {
            _config = configuration;

            DigitalAuditApplicationId = configuration.GetValue<string>("Api:DigitalAuditApplicationId");
        }

        public async Task<BaseApiResultViewModel<UserIdamanViewModel>> GetUsersAsync(string email)
        {
            _client = IdamanAuthHelper.ClientIdamanBearear(new AppSettingsViewModel
            {
                IdamanClientId = _config.GetValue<string>("Api:ClientId"),
                IdamanClientSecret = _config.GetValue<string>("Api:ClientSecret"),
                IdamanScopes = _config.GetValue<string>("Api:Scope"),
                IdamanUrlLogin = _config.GetValue<string>("Api:LoginUrl"),
                IdamanUrlApi = _config.GetValue<string>("Api:BaseApiUrl")
            });

            var response = await _client.GetAsync("Users/" + email);
            var result = new BaseApiResultViewModel<UserIdamanViewModel>
            {
                Data = new UserIdamanViewModel(),
                StatusCode = (int)response.StatusCode,
                Message = response.StatusCode.ToString()
            };

            if (result.StatusCode == 200)
            {
                var contents = await response.Content.ReadAsStringAsync();
                result.Data = JsonConvert.DeserializeObject<UserIdamanViewModel>(contents);
            }
            return result;

        }

        public async Task<BaseApiResultViewModel<UserIdamanAllViewModels>> GetAllUser(int start, int take)
        {
            _client = IdamanAuthHelper.ClientIdamanBearear(new AppSettingsViewModel
            {
                IdamanClientId = _config.GetValue<string>("Api:ClientId"),
                IdamanClientSecret = _config.GetValue<string>("Api:ClientSecret"),
                IdamanScopes = _config.GetValue<string>("Api:Scope"),
                IdamanUrlLogin = _config.GetValue<string>("Api:LoginUrl"),
                IdamanUrlApi = _config.GetValue<string>("Api:BaseApiUrl")
            });

            var response = await _client.GetAsync("Users/?start=" + start + "&take="+ take);
            var result = new BaseApiResultViewModel<UserIdamanAllViewModels>
            {
                Data = new UserIdamanAllViewModels(),
                StatusCode = (int)response.StatusCode,
                Message = response.StatusCode.ToString()
            };

            if (result.StatusCode == 200)
            {
                var contents = await response.Content.ReadAsStringAsync();
                result.Data = JsonConvert.DeserializeObject<UserIdamanAllViewModels>(contents);
            }
            return result;
        }

        public async Task<BaseApiResultViewModel<List<RoleIdamanAllViewModel>>> GetAllRole(string userId)
        {
            _client = IdamanAuthHelper.ClientIdamanBearear(new AppSettingsViewModel
            {
                IdamanClientId = _config.GetValue<string>("Api:ClientId"),
                IdamanClientSecret = _config.GetValue<string>("Api:ClientSecret"),
                IdamanScopes = _config.GetValue<string>("Api:Scope"),
                IdamanUrlLogin = _config.GetValue<string>("Api:LoginUrl"),
                IdamanUrlApi = _config.GetValue<string>("Api:BaseApiUrl")
            });

            var response = await _client.GetAsync("Roles/" + userId);
            var result = new BaseApiResultViewModel<List<RoleIdamanAllViewModel>>
            {
                Data = new List<RoleIdamanAllViewModel>(),
                StatusCode = (int)response.StatusCode,
                Message = response.StatusCode.ToString()
            };

            if (result.StatusCode == 200)
            {
                var contents = await response.Content.ReadAsStringAsync();
                result.Data = JsonConvert.DeserializeObject<List<RoleIdamanAllViewModel>>(contents);
            }
            return result;
        }

        public async Task<BaseApiResultViewModel<UserIdamanViewModel>> GetUserDetail(string id)
        {
            _client = IdamanAuthHelper.ClientIdamanBearear(new AppSettingsViewModel
            {
                IdamanClientId = _config.GetValue<string>("Api:ClientId"),
                IdamanClientSecret = _config.GetValue<string>("Api:ClientSecret"),
                IdamanScopes = _config.GetValue<string>("Api:Scope"),
                IdamanUrlLogin = _config.GetValue<string>("Api:LoginUrl"),
                IdamanUrlApi = _config.GetValue<string>("Api:BaseApiUrl")
            });

            var response = await _client.GetAsync("Users/" + id);
            var result = new BaseApiResultViewModel<UserIdamanViewModel>
            {
                Data = new UserIdamanViewModel(),
                StatusCode = (int)response.StatusCode,
                Message = response.StatusCode.ToString()
            };

            if (result.StatusCode == 200)
            {
                var contents = await response.Content.ReadAsStringAsync();
                result.Data = JsonConvert.DeserializeObject<UserIdamanViewModel>(contents);
            }
            return result;

        }

        public async Task<BaseApiResultViewModel<UserWhitelistIdamanAllViewModel>> GetUserWhitelist(string userId, int start, int take)
        {
            _client = IdamanAuthHelper.ClientIdamanBearear(new AppSettingsViewModel
            {
                IdamanClientId = _config.GetValue<string>("Api:ClientId"),
                IdamanClientSecret = _config.GetValue<string>("Api:ClientSecret"),
                IdamanScopes = _config.GetValue<string>("Api:Scope"),
                IdamanUrlLogin = _config.GetValue<string>("Api:LoginUrl"),
                IdamanUrlApi = _config.GetValue<string>("Api:BaseApiUrl")
            });

            var response = await _client.GetAsync("Users/Whitelist/" + userId +"?start=" + start + "&take=" + take);
            var result = new BaseApiResultViewModel<UserWhitelistIdamanAllViewModel>
            {
                Data = new UserWhitelistIdamanAllViewModel(),
                StatusCode = (int)response.StatusCode,
                Message = response.StatusCode.ToString()
            };

            if (result.StatusCode == 200)
            {
                var contents = await response.Content.ReadAsStringAsync();
                result.Data = JsonConvert.DeserializeObject<UserWhitelistIdamanAllViewModel>(contents);
            }

            return result;
        }
    }
}
