﻿using AutoMapper;
using DigitalAudit.Helper;
using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using DigitalAudit.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Claims;

namespace DigitalAudit.API.Controllers.Report
{
    [Authorize]
    [ApiController]
    [Route("Report/Inspection")]
    public class ReportInspectionController : ControllerBase
    {
        private readonly ILogger<ReportInspectionController> _logger;
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;
        private readonly IWebHostEnvironment _webHostEnvironment;
        private string _userId;


        public ReportInspectionController(
            IUnitOfWork unitOfWork,
            ILogger<ReportInspectionController> logger,
            IMapper mapper,
            IWebHostEnvironment webHostEnvironment,
            IHttpContextAccessor httpContextAccessor)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
            _mapper = mapper;
            _webHostEnvironment = webHostEnvironment;
            _userId = httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
        }

        [HttpGet("Overview/{InspectionId}")]
        public IActionResult ReportOverview(string InspectionId)
        {
            try
            {
                var reportOverview = _unitOfWork.TrInspectionRepository.ReportOverview(InspectionId);

                if (reportOverview == null)
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }

                return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, reportOverview, 1, 1));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, InspectionId);
                return BadRequest(new StatusModel(ex));
            }
            
        }

        [HttpGet("Summary/{InspectionId}")]
        public IActionResult ReportSummary(string InspectionId)
        {
            try
            {
                string baseURL = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}";

                var summary = _unitOfWork.TrInspectionRepository.ReportSummary(InspectionId);

                if (summary == null)
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }

                if (summary.Images.Count() > 0)
                {
                    summary.Images.Select(x =>
                    {
                        if (!string.IsNullOrEmpty(x.link))
                        {
                            x.link = baseURL + "/" + "inspection/file/download" + "/" + x.link;
                        }
                        return x;

                    }).ToList();
                }


                return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, summary, 1, 1));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, InspectionId);
                return BadRequest(new StatusModel(ex));
            }
            
        }

        [HttpGet("TitlePage/{InspectionId}")]
        public IActionResult ReportTitlePage(string InspectionId)
        {
            try
            {
                var inspection = _unitOfWork.TrInspectionRepository.Get(InspectionId);

                if (inspection == null)
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }

                var page = _unitOfWork.MTemplatePageRepository.GetAll()
                    .Where(x => x.IsDeleted == false && x.TemplateId == inspection.TemplateId)
                    .OrderBy(o => o.SeqNo)
                    .FirstOrDefault();

                var template = _unitOfWork.TrInspectionResultRepository.GetTemplate(inspection.TemplateId, InspectionId, page.PageId);

                if (template == null)
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }

                return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, template, 1, 1));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, InspectionId);
                return BadRequest(new StatusDataModel(ex));
            }
        }

        [HttpGet("Result/{InspectionId}")]
        public IActionResult ReportResult(string InspectionId)
        {
            try
            {
                var inspection = _unitOfWork.TrInspectionRepository.Get(InspectionId);

                if (inspection == null)
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }

                var template = _unitOfWork.TrInspectionResultRepository.GetResult(inspection.TemplateId, InspectionId);

                if (template == null)
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }

                return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, template, 1, 1));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, InspectionId);
                return BadRequest(new StatusDataModel(ex));
            }
        }

        [HttpGet("Failed/{InspectionId}")]
        public IActionResult ReportFailed(string InspectionId)
        {
            try
            {
                //Cek Issue di last inspection
                var issues = _unitOfWork.TrIssueRepository.GetIssueInspection(InspectionId);

                if (issues.Count() == 0)
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }

                var responseData = _mapper.Map<List<fn_Get_Issue>, List<TrIssueViewModel.ReadIssue>>(issues.ToList());
                return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.CREATE, responseData, responseData.Count(), responseData.Count()));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, InspectionId);
                return BadRequest(new StatusModel(ex));
            }

        }
        [HttpGet("Info/{InspectionId}")]
        public IActionResult ReportInfo(string InspectionId)
        {
            try
            {
                var inspectionInfo = _unitOfWork.TrInspectionInfoRepository.Select(InspectionId);

                if (inspectionInfo.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, inspectionInfo, inspectionInfo.Count(), inspectionInfo.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpGet("All/{InspectionId}")]
        public IActionResult ReportAll(string InspectionId)
        {
            try
            {
                string baseURL = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}";

                var inspection = _unitOfWork.TrInspectionRepository.Get(InspectionId);
                
                if (inspection == null)
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }

                var page = _unitOfWork.MTemplatePageRepository.GetAll()
                    .Where(x => x.IsDeleted == false && x.TemplateId == inspection.TemplateId)
                    .OrderBy(o => o.SeqNo)
                    .FirstOrDefault();

                var titlePage = _unitOfWork.TrInspectionResultRepository.GetTemplate(inspection.TemplateId, InspectionId, page.PageId);

                var result = _unitOfWork.TrInspectionResultRepository.GetResult(inspection.TemplateId, InspectionId);
                
                var reportOverview = _unitOfWork.TrInspectionRepository.ReportOverview(InspectionId);
                
                var inspectionInfo = _unitOfWork.TrInspectionInfoRepository.Select(InspectionId);
                
                var issues = _unitOfWork.TrIssueRepository.GetIssueInspection(InspectionId);

                if (issues.Count() == 0)
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }

                var FailedItems = _mapper.Map<List<fn_Get_Issue>, List<TrIssueViewModel.ReadIssue>>(issues.ToList());

                var summary = _unitOfWork.TrInspectionRepository.ReportSummary(InspectionId);
                if (summary.Images.Count() > 0)
                {
                    summary.Images.Select(x =>
                    {
                        if (!string.IsNullOrEmpty(x.link))
                        {
                            x.link = baseURL + "/" + "inspection/file/download" + "/" + x.link;
                        }
                        return x;

                    }).ToList();
                }

                ReportInspectionViewModel.ReportAll all = new ReportInspectionViewModel.ReportAll(reportOverview, summary, titlePage, result, FailedItems, inspectionInfo.ToList());

                return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, all, 1, 1));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [Route("Download/pdf/{InspectionId}")]
        [HttpGet]
        //[AllowAnonymous]
        public ActionResult DownloadPdf(string InspectionId)
        {
            string webRootPath = _webHostEnvironment.ContentRootPath;
            string configTemplate = Configs.AppConfig.UploadPath.ImportFileInspection;
            string path = webRootPath + configTemplate;
            string fullPath = Path.Combine(path, "Laporan.pdf");

            var provider = new FileExtensionContentTypeProvider();
            string contentType;

            if (!provider.TryGetContentType(fullPath, out contentType))
            {
                contentType = "application/octet-stream";
            }

            return PhysicalFile(fullPath, contentType, Constants.GETID() + ".pdf");
        }

        [Route("Download/word/{InspectionId}")]
        [HttpGet]
        //[AllowAnonymous]
        public ActionResult DownloadWord(string InspectionId)
        {
            string webRootPath = _webHostEnvironment.ContentRootPath;
            string configTemplate = Configs.AppConfig.UploadPath.ImportFileInspection;
            string path = webRootPath + configTemplate;
            string fullPath = Path.Combine(path, "Laporan.docx");

            var provider = new FileExtensionContentTypeProvider();
            string contentType;

            if (!provider.TryGetContentType(fullPath, out contentType))
            {
                contentType = "application/octet-stream";
            }

            return PhysicalFile(fullPath, contentType, Constants.GETID() + ".docx");
        }
    }
}
