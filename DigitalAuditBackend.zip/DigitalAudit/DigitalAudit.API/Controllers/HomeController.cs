﻿using AutoMapper;
using DigitalAudit.Helper;
using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using DigitalAudit.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
namespace DigitalAudit.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("Home/Overview")]
    public class HomeController : ControllerBase
    {
        private readonly ILogger<MAuditLocationController> _logger;
        private readonly IUnitOfWork _unitOfWork;
        private ClaimsPrincipal _principal;
        private IMapper _mapper;

        public HomeController(IUnitOfWork unitOfWork, ILogger<MAuditLocationController> logger, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
            _mapper = mapper;
        }

        [HttpGet]
        [Route("Search")]
        public IActionResult Search([FromQuery] HomeViewModel.QuerySearchOverview param)
        {
            try
            {
                if(param.page_number == null || param.page_number == 0)
                {
                    param.page_number = 1;
                }

                if (param.page_size == null || param.page_size == 0)
                {
                    param.page_size = 25;
                }

                #region  check user role
                //var userRole = _unitOfWork.MUserRoleRepository.SelectAll(null, null, null, param.user_id).FirstOrDefault();
                var userRole = _unitOfWork.MUserRoleRepository.GetAll().FirstOrDefault(f => f.UserId == param.user_id);

                string regionId = null;
                string locationId = null;

                if (userRole != null)
                {
                    if (userRole.RoleId == Constants.ROLE.ADMIN_PUSAT)
                    {
                        param.user_id = null; // admin pusat bisa lihat semua data, tidak di filter berdasarkan userId
                    }
                    else if (userRole.RoleId == Constants.ROLE.ADMIN_REGION)
                    {
                        regionId = userRole.RegionId;
                        param.user_id = null;
                    }
                    else if (userRole.RoleId == Constants.ROLE.ADMIN_LOKASI)
                    {
                        locationId = userRole.AuditLocationId;
                        param.user_id = null;
                    }
                }
                
                #endregion


                #region schedule 
                IEnumerable<TrAuditScheduleViewModel.ReadAuditSchedule> itemSchedule = _unitOfWork.TrAuditScheduleRepository.SelectByRole(locationId, regionId);
               
                if (!string.IsNullOrEmpty(param.search))
                    itemSchedule = itemSchedule.Where(i => i.Template.Title.ToLower().Contains(param.search.Trim().ToLower()));

                if (!string.IsNullOrEmpty(param.user_id))
                    itemSchedule = itemSchedule.Where(i =>
                        i.Auditee.Users.UserId == param.user_id
                        ||
                        i.Auditee.Groups.UserId == param.user_id
                        ||
                        i.Auditor.Users.UserId == param.user_id
                        ||
                        i.Auditor.Groups.UserId == param.user_id
                        );


                var schedule = new
                {
                    TotalData = itemSchedule.Count(),
                    Data = itemSchedule
                };
                #endregion

                #region issue
                var dataIssues = _unitOfWork.TrIssueRepository
                    //.SelectAll(null, null, null, null, null, null, null, null, null, null, null);
                    .GetIssue(null, locationId, null, null, null, null, null, null, null, null, null, regionId, null);

                List<TrIssueViewModel.ReadIssue> itemIssues = _mapper.Map<List<fn_Get_Issue>, List<TrIssueViewModel.ReadIssue>>(dataIssues.ToList());

                if (!string.IsNullOrEmpty(param.search))
                    itemIssues = itemIssues.Where(i => i.Title.ToLower().Contains(param.search.Trim()) || (i.AuditType.Name.ToLower().Contains(param.search.Trim()) && i.AuditType != null)).ToList();

                if (!string.IsNullOrEmpty(param.user_id))
                    itemIssues = itemIssues.Where(i => i.AssignUser.UserId == param.user_id || i.AssignGroup.UserId == param.user_id || i.Creator.UserId == param.user_id).ToList();


                var issue = new
                {
                    TotalData = itemIssues.Count(),
                    Data = itemIssues
                };
                #endregion

                #region action
                var dataActions = _unitOfWork.TrActionRepository
                    .SelectAll(null, null, null, null, null, null, null, null, null, null, null, null, null);

                List<TrActionViewModel.ReadAction> itemActions = _mapper.Map<List<fn_Get_Action>, List<TrActionViewModel.ReadAction>>(dataActions.ToList());


                if (!string.IsNullOrEmpty(param.search))
                    itemActions = itemActions.Where(i => i.Title.ToLower().Contains(param.search.Trim()) || (i.AuditType.Name.ToLower().Contains(param.search.Trim()) && i.AuditType != null)).ToList();

                if (!string.IsNullOrEmpty(param.user_id))
                    itemActions = itemActions.Where(i => i.AssignUser.UserId == param.user_id || i.AssignGroup.UserId == param.user_id || i.Creator.UserId == param.user_id).ToList();

                var action = new
                {
                    TotalData = itemActions.Count(),
                    Data = itemActions
                };
                #endregion

                #region inspection 
                IEnumerable<TrInspectionViewModel.ReadInspection> itemInspection = _unitOfWork.TrInspectionRepository.SelectByRole(null, null, locationId, regionId);

                if (!string.IsNullOrEmpty(param.search))
                    itemInspection = itemInspection.Where(i => i.Template.Title.ToLower().Contains(param.search.Trim().ToLower()));

                if (!string.IsNullOrEmpty(param.user_id))
                    itemInspection = itemInspection.Where(i =>
                        i.Auditee.Users.UserId == param.user_id
                        ||
                        i.Auditee.Groups.UserId == param.user_id
                        ||
                        i.Auditor.Users.UserId == param.user_id
                        ||
                        i.Auditor.Groups.UserId == param.user_id
                        );


                var inspection = new
                {
                    TotalData = itemInspection.Count(),
                    Data = itemInspection
                };
                #endregion



                var response = new
                {
                    Schedule = schedule,
                    Issue = issue,
                    Action = action,
                    Inspection = inspection
                };

                return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.READ, response));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }
    }
}
