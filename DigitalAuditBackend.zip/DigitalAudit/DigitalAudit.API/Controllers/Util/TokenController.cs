﻿using DigitalAudit.API.Services;
using DigitalAudit.Helper;
using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.Util;
using DigitalAudit.Model.ViewModel;
using DigitalAudit.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace DigitalAudit.API.Controllers.Util
{
    [Authorize]
    [Route("Util/[controller]")]
    [ApiController]
    public class TokenController : ControllerBase
    {
        private IConfiguration _config;
        private readonly ILogger<TokenController> _logger;
        private readonly IUnitOfWork _unitOfWork;
        private readonly IIdamanService _idamanService; //// idaman error 07 juli 2021

        public TokenController(IUnitOfWork unitOfWork, ILogger<TokenController> logger, IConfiguration config
            , IIdamanService idamanService  //// idaman error 07 juli 2021
            )
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
            _config = config;
            _idamanService = idamanService; //// idaman error 07 juli 2021
        }

        [AllowAnonymous]
        [HttpPost]
        [Route("Login")]
        public async Task<IActionResult> PostLogin(TokenViewModel.Token param)
        {
            try
            {
                // idaman error 07 juli 2021
                var userIdaman = await _idamanService.GetUserDetail(param.TokenUser);
                if (userIdaman.StatusCode == 204 || param.TokenPassword != Constants.TokenPassword)
                {
                    throw new Exception("Invalid userId or password");
                }

                var userWhitelist = _unitOfWork.MUserSyncAllRepository.SelectAll().Where(i => i.UserId == param.TokenUser).FirstOrDefault();
                if (userWhitelist == null)
                {
                    throw new Exception("User tidak di whitelist");
                }

                UserIdamanViewModel user = userIdaman.Data;

                var jwt = new JwtService(_config);
                var token = jwt.GenerateSecurityToken(user);
                return Ok(new StatusModel(true, "Success get token", token));
                //return Ok();

            }
            catch (Exception ex)
            {
                return BadRequest(new StatusModel(ex));
            }

        }

        //[AllowAnonymous]
        //[HttpPost]
        //[Route("Login")]
        //public IActionResult PostLogin(TokenViewModel.Token param)
        //{
        //    try
        //    {
        //        var jwt = new JwtService(_config);

        //        MUserSync user = _unitOfWork.MUserSyncRepository.GetAll().Where(i => i.IsDeleted == false && i.Email == param.TokenUser).FirstOrDefault();
        //        if(user == null)
        //        {
        //            throw new Exception("Invalid userId or password");
        //        }
                
        //        var token = jwt.GenerateSecurityToken(user);
        //        return Ok(new StatusModel(true, "Success get token", token));
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
        //        return Ok(new StatusModel(ex));
        //    }

        //}


        [AllowAnonymous]
        [HttpPost]
        public IActionResult Post(TokenViewModel.Token param)
        {
            try
            {
                MTokenUser token = new MTokenUser(null, param.TokenUser, param.TokenPassword, false, "", Constants.GETDATE(), null, null);
                Helpers.Validate(token);
                if (_unitOfWork.TokenRepository.IsAuthenticated(token))
                {
                    string tokenUserID = _unitOfWork.TokenRepository.GetTokenUserID(token);
                    TokenModel item = _unitOfWork.TokenRepository.GetToken(token, tokenUserID);

                    //var jwt = new JwtService(_config);
                    //var token = jwt.GenerateSecurityToken("fake@email.com");
                    return Ok(new StatusModel(true, "Success get token", item));
                }
                else
                {
                    return Ok(new StatusModel(false, "Failed get token", null));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return Ok(new StatusModel(ex));
            }

        }
    }
}
