﻿using DigitalAudit.Helper;
using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using DigitalAudit.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace DigitalAudit.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("Master/Template/Question")]
    public class MTemplateQuestionController : ControllerBase
    {
        private readonly ILogger<MTemplateQuestionController> _logger;
        private readonly IUnitOfWork _unitOfWork;
        private ClaimsPrincipal _principal;
        private string _userId;

        public MTemplateQuestionController(IUnitOfWork unitOfWork, ILogger<MTemplateQuestionController> logger, IHttpContextAccessor httpContextAccessor)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
            _userId = httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
        }

        // GET: api/Master/Template/Question
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var items = _unitOfWork.MTemplateQuestionRepository.SelectAll().OrderBy(o => o.PageId);
                int totalData = items.Count();
                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, items.Count(), items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpGet]
        [Route("query")]
        public IActionResult Get(
            [FromQuery] MTemplateQuestionViewModel.QueryTemplateQuestion param)
        {
            try
            {
                IEnumerable<MTemplateQuestionViewModel.ReadTemplateQuestion> items = _unitOfWork.MTemplateQuestionRepository.SelectAll();

                if (param.id != null)
                    items = items.Where(i => i.QuestionId == param.id);

                if (!string.IsNullOrEmpty(param.page_id))
                    items = items.Where(i => i.PageId == param.page_id.Trim());

                if (!string.IsNullOrEmpty(param.section_id))
                    items = items.Where(i => i.SectionId == param.section_id.Trim());

                if (!string.IsNullOrEmpty(param.code))
                    items = items.Where(i => i.Code.ToLower().Contains(param.code.Trim().ToLower()));

                if (!string.IsNullOrEmpty(param.question))
                    items = items.Where(i => i.Question.ToLower().Contains(param.question.Trim().ToLower()));

                int totalData = items.Count();


                if (!string.IsNullOrEmpty(param.sort_by))
                {
                    var orderByExpression = Helpers.GetOrderByExpression<MTemplateQuestionViewModel.ReadTemplateQuestion>(param.sort_by);
                    items = Helpers.OrderByDir<MTemplateQuestionViewModel.ReadTemplateQuestion>(items, param.order_by, orderByExpression).AsEnumerable();
                }
                else
                {
                    var orderByExpression = Helpers.GetOrderByExpression<MTemplateQuestionViewModel.ReadTemplateQuestion>("PageId");
                    items = Helpers.OrderByDir<MTemplateQuestionViewModel.ReadTemplateQuestion>(items, param.order_by, orderByExpression).AsEnumerable();
                }

                if (param.page_size != null && param.page_number != null)
                {
                    items = Helpers.Page<MTemplateQuestionViewModel.ReadTemplateQuestion>(items, param.page_size.Value, param.page_number.Value);
                }

                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, totalData, items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, param);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            try
            {
                var data = _unitOfWork.MTemplateQuestionRepository.SelectOne(id);

                if (data != null)
                {
                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.READ, data));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, id);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpPut]
        public IActionResult Put([FromBody] MTemplateQuestionViewModel.UpdateTemplateQuestion item)
        {
            try
            {
                Helpers.Validate(item);
                MTemplateQuestion data = _unitOfWork.MTemplateQuestionRepository.Get(item.QuestionId);

                if (data != null)
                {
                    data.PageId = item.PageId;
                    data.SeqNo = item.SeqNo;
                    data.Code = item.Code.Trim();
                    data.Question = item.Question.Trim();
                    data.IsMandatory = item.IsMandatory;
                    data.SectionId = item.SectionId;
                    data.ResponseId = item.ResponseId;

                    //if (_unitOfWork.MTemplateQuestionRepository.anyUpdate(data))
                    //{
                    //    throw new Exception("Data already exists");
                    //}

                    _unitOfWork.MTemplateQuestionRepository.Update(data, _userId, Constants.GETDATE());
                    _unitOfWork.Complete();

                    MTemplateQuestionViewModel.ReadTemplateQuestion read = _unitOfWork.MTemplateQuestionRepository.SelectOne(data.QuestionId);

                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.UPDATE, read));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, item));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, item);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpPost]
        public IActionResult Post([FromBody] MTemplateQuestionViewModel.CreateTemplateQuestion item)
        {
            try
            {
                Helpers.Validate(item);
                MTemplateQuestion data = new MTemplateQuestion(
                    0,
                    item.PageId.Trim(),
                    item.SeqNo,
                    item.Code,
                    item.Question,
                    item.IsMandatory,
                    item.SectionId,
                    item.ResponseId,
                    false,
                    _userId,
                    Constants.GETDATE(),
                    null,
                    null);
                //if (_unitOfWork.MTemplateQuestionRepository.anyInsert(data))
                //{
                //    throw new Exception("Data already exists");
                //}
                _unitOfWork.MTemplateQuestionRepository.Add(data);
                _unitOfWork.Complete();

                data = _unitOfWork.MTemplateQuestionRepository.Get(data.QuestionId);

                MTemplateQuestionViewModel.ReadTemplateQuestion read = _unitOfWork.MTemplateQuestionRepository.SelectOne(data.QuestionId);

                return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.CREATE, read));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, item);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                MTemplateQuestion data = _unitOfWork.MTemplateQuestionRepository.Get(id);
                if (data != null)
                {
                    //if (_unitOfWork.MTemplateQuestionRepository.anyUpdate(data))
                    //{
                    //    throw new Exception("Data masih digunakan di transaksi");
                    //}

                    _unitOfWork.MTemplateQuestionRepository.Delete(data, _userId, Constants.GETDATE());
                    _unitOfWork.Complete();

                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.DELETE, null));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, id);
                return BadRequest(new StatusModel(ex));
            }
        }
    }
}
