﻿using DigitalAudit.Helper;
using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using DigitalAudit.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;


namespace DigitalAudit.API.Controllers.Master
{
    [Authorize]
    [ApiController]
    [Route("Master")]
    public class MasterController : ControllerBase
    {
        private readonly ILogger<MasterController> _logger;
        private readonly IUnitOfWork _unitOfWork;
        private string _userId;
        public MasterController(IUnitOfWork unitOfWork, ILogger<MasterController> logger, IHttpContextAccessor httpContextAccessor)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
            _userId = httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
        }

        // GET: api/Master
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                MasterViewModel master = new MasterViewModel();
                master.IssueCategory = _unitOfWork.MIssueCategoryRepository.SelectAll();
                master.IssueStatus = _unitOfWork.MIssueStatusRepository.SelectAll();
                master.Priority = _unitOfWork.MPriorityRepository.SelectAll();
                master.RootCauseCategory = _unitOfWork.MRootCauseCategoryRepository.SelectAll();
                master.ActionRepairCategory = _unitOfWork.MActionRepairCategoryRepository.SelectAll();
                master.InspectionStatus = _unitOfWork.MInspectionStatusRepository.SelectAll();

                return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.READ, master));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }
    }
}
