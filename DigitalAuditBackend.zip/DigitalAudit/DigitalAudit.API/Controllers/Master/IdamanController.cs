﻿using DigitalAudit.API.Services;
using DigitalAudit.Helper;
using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using DigitalAudit.Model.ViewModel.Idaman;
using DigitalAudit.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace DigitalAudit.API.Controllers.Master
{
    [Authorize]
    [ApiController]
    [Route("Master/Idaman/User")]
    public class IdamanController : ControllerBase
    {
        private readonly IIdamanService _idamanService;
        private readonly IUnitOfWork _unitOfWork;
        private string _userId;

        public IdamanController(IUnitOfWork unitOfWork, IIdamanService idamanService, IHttpContextAccessor httpContextAccessor)
        {
            _unitOfWork = unitOfWork;
            _idamanService = idamanService;
            _userId = httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier) == null ? "" : httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
        }

        [HttpGet]
        public async Task<IActionResult> GetUserAsync(string email)
        {
            try
            {
                var userIdaman = await _idamanService.GetUsersAsync(email);
                if (userIdaman.StatusCode == 204)
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }

                return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.READ, userIdaman.Data));
            }
            catch (Exception ex)
            {
                return BadRequest(new StatusModel(ex));
            }
            
        }

        [HttpGet]
        [Route("Detail/{id}")]
        public async Task<IActionResult> UserDetail(string id)
        {
            try
            {
                var userIdaman = await _idamanService.GetUserDetail(id);
                if (userIdaman.StatusCode == 204)
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }

                return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.READ, userIdaman.Data));
            }
            catch (Exception ex)
            {
                return BadRequest(new StatusModel(ex));
            }

        }

        [HttpGet]
        [Route("All")]
        public async Task<IActionResult> GetAllUser(int start = 0, int take = 25)
        {
            try
            {
                var userIdaman = await _idamanService.GetAllUser(start, take);
                if (userIdaman.Data.Value.Count == 0)
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }

                return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.READ, userIdaman.Data.Value));
            }
            catch (Exception ex)
            {
                return BadRequest(new StatusModel(ex));
            }

            //var userIdaman = await _idamanService.GetAllUser(start, take);
            //return Ok(userIdaman);
        }

        [HttpGet]
        [Route("Roles/{id}")]
        public async Task<IActionResult> GetRoleAsync(string id)
        {
            try
            {
                var data = await _idamanService.GetAllRole(id);
                if (data.StatusCode == 204)
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }

                return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.READ, data.Data));
            }
            catch (Exception ex)
            {
                return BadRequest(new StatusModel(ex));
            }

        }

        //[HttpGet]
        //[Route("Users/Whitelist/{id}")]
        //public async Task<IActionResult> GetUserWhitelist(string id, int start = 0, int take = 25)
        //{
        //    try
        //    {
        //        var data = await _idamanService.GetUserWhitelist(id, start, take);
        //        if (data.Data.Value.Count == 0)
        //        {
        //            return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
        //        }

        //        List<UserWhitelistIdamanViewModel> userWhiteList = data.Data.Value;
        //        List<MUserSyncWhitelist> listAllow = new List<MUserSyncWhitelist>();
        //        List<MUserSyncWhitelist> listUserWhitelist = _unitOfWork.MUserSyncWhitelistRepository.SelectAll();

        //        _unitOfWork.MUserSyncWhitelistRepository.DeleteUserSyncWhitelist();
        //        _unitOfWork.Complete();

        //        foreach (UserWhitelistIdamanViewModel d in userWhiteList)
        //        {
        //            if (d.role.Count() > 0)
        //            {
        //                int role = d.role.Where(i => i.application.id == Constants.DigitalAuditApplicationId).Count();
        //                if (role > 0)
        //                {
        //                    listAllow.Add(new MUserSyncWhitelist(Constants.GETID(), id, Constants.DigitalAuditApplicationId, Constants.GETDATE()));

        //                    MUserSyncWhitelist wh = new MUserSyncWhitelist(Constants.GETID(), id, Constants.DigitalAuditApplicationId, Constants.GETDATE());
        //                    _unitOfWork.MUserSyncWhitelistRepository.Add(wh);
        //                    _unitOfWork.Complete();
        //                }
        //            }
        //        }

        //        listAllow = listAllow.Distinct().ToList();
        //        _unitOfWork.MUserSyncWhitelistRepository.AddLists(listAllow);
        //        _unitOfWork.Complete();


        //        return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.READ, data.Data.Value));
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(new StatusModel(ex));
        //    }

        //    //var userIdaman = await _idamanService.GetAllUser(start, take);
        //    //return Ok(userIdaman);
        //}

        [AllowAnonymous]
        [HttpGet]
        [Route("Users/Whitelist/Validate/{id}")]
        public async Task<IActionResult> GetUserWhitelistValidate(string id)
        {
            try
            {
                int start = 0; 
                int take = 25;
                var data = await _idamanService.GetUserWhitelist(id, start, take);
                if (data.Data.Value == null)
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }

                List<UserWhitelistIdamanViewModel> userWhiteList = data.Data.Value;
                List<MUserSyncWhitelist> listAllow = new List<MUserSyncWhitelist>();
                List<MUserSyncWhitelist> listUserWhitelist = _unitOfWork.MUserSyncWhitelistRepository.SelectAll();

                //_unitOfWork.MUserSyncWhitelistRepository.DeleteUserSyncWhitelist();
                //_unitOfWork.Complete();

                int ctx = 0;
                if(userWhiteList.Count() > 0)
                {
                    foreach (UserWhitelistIdamanViewModel d in userWhiteList)
                    {
                        if (d.role.Count() > 0)
                        {
                            int role = d.role.Where(i => i.application.id == Constants.DigitalAuditApplicationId).Count();
                            if (role > 0)
                            {
                                //listAllow.Add(new MUserSyncWhitelist(Constants.GETID(), id, Constants.DigitalAuditApplicationId, Constants.GETDATE()));

                                //MUserSyncWhitelist wh = new MUserSyncWhitelist(Constants.GETID(), id, Constants.DigitalAuditApplicationId, Constants.GETDATE());
                                //_unitOfWork.MUserSyncWhitelistRepository.Add(wh);
                                //_unitOfWork.Complete();
                                ctx = ctx + 1;
                            }
                        }
                    }
                }

                if(ctx > 0)
                {
                    return Ok(new StatusModel(true, "User berhasil akses", null));
                }
                else
                {
                    return Ok(new StatusModel(false, "User tidak ada akses", null));
                }

                
            }
            catch (Exception ex)
            {
                return BadRequest(new StatusModel(ex));
            }
        }
    }
}