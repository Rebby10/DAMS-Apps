﻿using DigitalAudit.Helper;
using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using DigitalAudit.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace DigitalAudit.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("Master/User/Group")]
    public class MUserGroupController : ControllerBase
    {
        private readonly ILogger<MUserGroupController> _logger;
        private readonly IUnitOfWork _unitOfWork;
        private string _userId;
        public MUserGroupController(IUnitOfWork unitOfWork, ILogger<MUserGroupController> logger, IHttpContextAccessor httpContextAccessor)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
            _userId = httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
        }

        // GET: api/Master/UserGroup
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var items = _unitOfWork.MUserGroupRepository.SelectAll().OrderBy(o => o.Name);
                int totalData = items.Count();

                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, items.Count(), items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return Ok(new StatusModel(ex));
            }
        }

        [HttpGet]
        [Route("Member/{user_group_id?}/{user_type_id?}")]
        public IActionResult Member([FromQuery] string user_group_id, [FromQuery] string user_type_id)
        {
            try
            {
                var items = _unitOfWork.MUserGroupRepository.SelectUserGroupMember(user_group_id, user_type_id);
                int totalData = items.Count();
                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, items.Count(), items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return Ok(new StatusModel(ex));
            }
        }

        [HttpGet]
        [Route("query")]
        public IActionResult Get(
            [FromQuery] MUserGroupViewModel.QueryUserGroup param)
        {
            try
            {
                IEnumerable<MUserGroupViewModel.ReadUserGroup> items = _unitOfWork.MUserGroupRepository.SelectAll();

                if (!string.IsNullOrEmpty(param.id))
                    items = items.Where(i => i.UserGroupId == param.id.Trim());

                if (!string.IsNullOrEmpty(param.name))
                    items = items.Where(i => i.Name.ToLower().Contains(param.name.Trim().ToLower()));

                int totalData = items.Count();


                if (!string.IsNullOrEmpty(param.sort_by))
                {
                    var orderByExpression = Helpers.GetOrderByExpression<MUserGroupViewModel.ReadUserGroup>(param.sort_by);
                    items = Helpers.OrderByDir<MUserGroupViewModel.ReadUserGroup>(items, param.order_by, orderByExpression).AsEnumerable();
                }
                else
                {
                    var orderByExpression = Helpers.GetOrderByExpression<MUserGroupViewModel.ReadUserGroup>("Name");
                    items = Helpers.OrderByDir<MUserGroupViewModel.ReadUserGroup>(items, param.order_by, orderByExpression).AsEnumerable();
                }

                if (param.page_size != null && param.page_number != null)
                {
                    items = Helpers.Page<MUserGroupViewModel.ReadUserGroup>(items, param.page_size.Value, param.page_number.Value);
                }

                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, totalData, items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpGet("{id}")]
        public IActionResult Get(string id)
        {
            try
            {
                var userGroup = _unitOfWork.MUserGroupRepository.SelectOne(id.Trim());
                if (userGroup != null)
                {
                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.READ, userGroup));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, id);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpPut]
        public IActionResult Put([FromBody] MUserGroupViewModel.UpdateUserGroup item)
        {
            try
            {
                Helpers.Validate(item);
                MUserGroup data = _unitOfWork.MUserGroupRepository.Get(item.UserGroupId.Trim());

                if (data != null)
                {
                    data.UserTypeId = item.UserTypeId.Trim();
                    data.Name = item.Name.Trim();
                    data.UserId = item.UserId.Trim();
                    data.Username = item.Username.Trim();

                    if (_unitOfWork.MUserGroupRepository.anyUpdate(data))
                    {
                        throw new Exception("Data already exists");
                    }

                    _unitOfWork.MUserGroupRepository.Update(data, _userId, Constants.GETDATE());
                    _unitOfWork.Complete();

                    MUserGroupViewModel.ReadUserGroup read = _unitOfWork.MUserGroupRepository.SelectOne(data.UserGroupId.Trim());

                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.UPDATE, read));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpPost]
        public IActionResult Post([FromBody] MUserGroupViewModel.CreateUserGroup item)
        {
            try
            {
                Helpers.Validate(item);
                MUserGroup data = new MUserGroup(Constants.GETID(), 0, item.UserTypeId, item.Name, item.UserId, item.Username, false, _userId, Constants.GETDATE(), null, null);
                if (_unitOfWork.MUserGroupRepository.anyInsert(data))
                {
                    throw new Exception("Data already exists");
                }
                _unitOfWork.MUserGroupRepository.Add(data);
                _unitOfWork.Complete();

                data = _unitOfWork.MUserGroupRepository.Get(data.UserGroupId.Trim());

                MUserGroupViewModel.ReadUserGroup read = _unitOfWork.MUserGroupRepository.SelectOne(data.UserGroupId.Trim());

                return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.CREATE, read));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, item);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(string id)
        {
            try
            {
                MUserGroup data = _unitOfWork.MUserGroupRepository.Get(id.Trim());
                if (data != null)
                {
                    _unitOfWork.MUserGroupRepository.Delete(data, _userId, Constants.GETDATE());
                    _unitOfWork.Complete();

                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.DELETE, null));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }
    }
}
