﻿using DigitalAudit.Helper;
using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using DigitalAudit.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace DigitalAudit.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("Master/Audit/KboLocation")]
    public class MKboAuditLocationController : ControllerBase
    {
        private readonly ILogger<MKboAuditLocationController> _logger;
        private readonly IUnitOfWork _unitOfWork;
        private string _userId;
        public MKboAuditLocationController(IUnitOfWork unitOfWork, ILogger<MKboAuditLocationController> logger, IHttpContextAccessor httpContextAccessor)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
            _userId = httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
        }

        [HttpPost]
        [Route("Sync")]
        public IActionResult Sync()
        {
            try
            {
                StatusViewModel sycnStatus = _unitOfWork.MKboAuditLocationRepository.SyncronizeKboSync_Syncronize();

                return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.CREATE, sycnStatus));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        // GET: api/Master/Audit/KboLocation
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var items = _unitOfWork.MKboAuditLocationRepository.SelectAll().OrderByDescending(o => o.Kbo);
                int totalData = items.Count();

                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, items.Count(), items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpGet]
        [Route("query")]
        public IActionResult Get(
            [FromQuery] MKboAuditLocationViewModel.QueryKboAuditLocation param)
        {
            try
            {
                IEnumerable<MKboAuditLocationViewModel.ReadKboAuditLocation> items = _unitOfWork.MKboAuditLocationRepository.SelectAll();

                if (!string.IsNullOrEmpty(param.kbo))
                    items = items.Where(i => i.Kbo.ToLower().Contains(param.kbo.Trim().ToLower()));

                if (!string.IsNullOrEmpty(param.AuditLocationId))
                    items = items.Where(i => i.AuditLocation.AuditLocationId == param.AuditLocationId);

                if (!string.IsNullOrEmpty(param.LocationName))
                    items = items.Where(i => i.AuditLocation.Name.ToLower().Contains(param.LocationName.Trim().ToLower()));

                if (!string.IsNullOrEmpty(param.RegionId))
                    items = items.Where(i => i.AuditLocation.Region.RegionId == param.RegionId);

                if (!string.IsNullOrEmpty(param.RegionName))
                    items = items.Where(i => i.AuditLocation.Region.Name.ToLower().Contains(param.RegionName.Trim().ToLower()));

                int totalData = items.Count();


                if (!string.IsNullOrEmpty(param.sort_by))
                {
                    var orderByExpression = Helpers.GetOrderByExpression<MKboAuditLocationViewModel.ReadKboAuditLocation>(param.sort_by);
                    items = Helpers.OrderByDir<MKboAuditLocationViewModel.ReadKboAuditLocation>(items, param.order_by, orderByExpression).AsEnumerable();
                }
                else
                {
                    var orderByExpression = Helpers.GetOrderByExpression<MKboAuditLocationViewModel.ReadKboAuditLocation>("Kbo");
                    items = Helpers.OrderByDir<MKboAuditLocationViewModel.ReadKboAuditLocation>(items, "DESC", orderByExpression).AsEnumerable();
                }

                if (param.page_size != null && param.page_number != null)
                {
                    items = Helpers.Page<MKboAuditLocationViewModel.ReadKboAuditLocation>(items, param.page_size.Value, param.page_number.Value);
                }

                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, totalData, items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, param);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpGet("{id}")]
        public IActionResult Get(string id)
        {
            try
            {
                var KboAuditLocation = _unitOfWork.MKboAuditLocationRepository.SelectOne(id.Trim());

                if (KboAuditLocation != null)
                {
                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.READ, KboAuditLocation));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpPut]
        public IActionResult Put([FromBody] MKboAuditLocationViewModel.UpdateKboAuditLocation item)
        {
            try
            {
                Helpers.Validate(item);
                MKboAuditLocation data = _unitOfWork.MKboAuditLocationRepository.Get(item.KboAuditLocationId.Trim());

                if (data != null)
                {
                    data.Kbo = item.Kbo.Trim();
                    data.AuditLocationId = item.AuditLocationId.Trim();

                    if (_unitOfWork.MKboAuditLocationRepository.anyUpdate(data))
                    {
                        throw new Exception("Data already exists");
                    }

                    _unitOfWork.MKboAuditLocationRepository.Update(data, _userId, Constants.GETDATE());
                    _unitOfWork.Complete();

                    MKboAuditLocationViewModel.ReadKboAuditLocation read = _unitOfWork.MKboAuditLocationRepository.SelectOne(data.KboAuditLocationId.Trim());

                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.UPDATE, read));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpPost]
        public IActionResult Post([FromBody] MKboAuditLocationViewModel.CreateKboAuditLocation item)
        {
            try
            {
                Helpers.Validate(item);
                MKboAuditLocation data = new MKboAuditLocation(
                    Constants.GETID(),
                    item.Kbo.Trim(),
                    item.AuditLocationId.Trim(),
                    false,
                    _userId,
                    Constants.GETDATE(),
                    null,
                    null);
                if (_unitOfWork.MKboAuditLocationRepository.anyInsert(data))
                {
                    throw new Exception("Data already exists");
                }
                Validate(data, Constants.CRUD.CREATE);
                _unitOfWork.MKboAuditLocationRepository.Add(data);
                _unitOfWork.Complete();

                data = _unitOfWork.MKboAuditLocationRepository.Get(data.KboAuditLocationId.Trim());

                MKboAuditLocationViewModel.ReadKboAuditLocation read = _unitOfWork.MKboAuditLocationRepository.SelectOne(data.KboAuditLocationId.Trim());

                return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.CREATE, item));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(string id)
        {
            try
            {
                MKboAuditLocation data = _unitOfWork.MKboAuditLocationRepository.Get(id);
                if (data != null)
                {
                    _unitOfWork.MKboAuditLocationRepository.Delete(data, _userId, Constants.GETDATE());
                    _unitOfWork.Complete();

                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.DELETE, null));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }


        [ApiExplorerSettings(IgnoreApi = true)]
        public void Validate(MKboAuditLocation model, string func)
        {

            if (func == Constants.CRUD.CREATE || func == Constants.CRUD.UPDATE)
            {
                if (!_unitOfWork.MAuditLocationRepository.GetAll().Any(i => i.IsDeleted == false && i.AuditLocationId == model.AuditLocationId))
                {
                    throw new Exception("Lokasi audit tidak valid");
                }
            }
        }
    }
}
