﻿using DigitalAudit.Helper;
using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using DigitalAudit.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.Extensions.Logging;
using Swashbuckle.AspNetCore.Annotations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;

namespace DigitalAudit.API.Controllers.Master
{
    [Authorize]
    [ApiController]
    [Route("Master/User/Role")]
    public class MUserRoleController : ControllerBase
    {
        private readonly ILogger<MUserRoleController> _logger;
        private readonly IUnitOfWork _unitOfWork;
        private string _userId;
        public MUserRoleController(IUnitOfWork unitOfWork, ILogger<MUserRoleController> logger, IHttpContextAccessor httpContextAccessor)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
            _userId = httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
        }

        // GET: api/Master/User/Role
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var items = _unitOfWork.MUserRoleRepository.SelectAll(null, null, null, null);
                int totalData = items.Count();

                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, items.Count(), items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpGet]
        [Route("query")]
        public IActionResult Get(
            [FromQuery] MUserRoleViewModel.QueryUserRole param)
        {
            try
            {
                IEnumerable<fn_Get_MUserRole> items = _unitOfWork.MUserRoleRepository.SelectAll(param.UserRoleId, param.Username, param.Email, param.UserId);
                int totalData = items.Count();

                if (!string.IsNullOrEmpty(param.sort_by))
                {
                    var orderByExpression = Helpers.GetOrderByExpression<fn_Get_MUserRole>(param.sort_by);
                    items = Helpers.OrderByDir(items, param.order_by, orderByExpression).AsEnumerable();
                }

                if (param.page_size != null && param.page_number != null)
                {
                    items = Helpers.Page(items, param.page_size.Value, param.page_number.Value);
                }

                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, totalData, items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpGet]
        [Route("query/All")]
        public IActionResult GetAllUser(
            [FromQuery] MUserRoleViewModel.QueryUserRole param)
        {
            try
            {
                IEnumerable<fn_Get_MUserRole_AllUser> items = _unitOfWork.MUserRoleRepository.SelectAllUser(param.UserRoleId, param.Username, param.Email, param.UserId);
                int totalData = items.Count();

                if (!string.IsNullOrEmpty(param.sort_by))
                {
                    var orderByExpression = Helpers.GetOrderByExpression<fn_Get_MUserRole_AllUser>(param.sort_by);
                    items = Helpers.OrderByDir(items, param.order_by, orderByExpression);
                }

                if (param.page_size != null && param.page_number != null)
                {
                    items = Helpers.Page(items, param.page_size.Value, param.page_number.Value);
                }

                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, totalData, items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [Route("{id}")]
        [HttpGet]
        public IActionResult Get(string id)
        {
            try
            {
                var userRole = _unitOfWork.MUserRoleRepository.SelectOne(id.Trim());

                if (userRole != null)
                {
                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.READ, userRole));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }
                
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, id);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpPut]
        public IActionResult Put([FromBody] MUserRoleViewModel.UpdateUserRole item)
        {
            try
            {
                Helpers.Validate(item);
                MUserRole data = _unitOfWork.MUserRoleRepository.Get(item.UserRoleId.Trim());

                if (data != null)
                {
                    data.Username = item.Username.Trim();
                    data.Email = item.Email.Trim();
                    data.RoleId = item.RoleId.Trim();

                    if (item.RoleId.Equals(Constants.ROLE.ADMIN_REGION))
                    {
                        data.RegionId = item.OtorisasiId.Trim();
                        data.AuditLocationId = null;
                    }
                    else if (item.RoleId.Equals(Constants.ROLE.ADMIN_LOKASI) || item.RoleId.Equals(Constants.ROLE.USER))
                    {
                        data.RegionId = null;
                        data.AuditLocationId = item.OtorisasiId.Trim();
                    }
                    else
                    {
                        data.RegionId = null;
                        data.AuditLocationId = null;
                    }

                    if (_unitOfWork.MUserRoleRepository.anyUpdate(data))
                    {
                        throw new Exception("Data already exists");
                    }

                    _unitOfWork.MUserRoleRepository.Update(data, _userId, Constants.GETDATE());
                    _unitOfWork.Complete();

                    var read = _unitOfWork.MUserRoleRepository.SelectOne(data.UserRoleId.Trim());

                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.UPDATE, read));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpPost]
        public IActionResult Post([FromBody] MUserRoleViewModel.CreateUserRole item)
        {
            try
            {
                Helpers.Validate(item);
                MUserRole data = new MUserRole();

                data.UserRoleId = Constants.GETID();
                data.UserId = item.UserId.Trim();
                data.Username = item.Username.Trim();
                data.Email = item.Email.Trim();
                data.RoleId = item.RoleId.Trim();
                data.IsDeleted = false;
                data.UserCreated = _userId;
                data.DateCreated = Constants.GETDATE();

                if (item.RoleId.Equals(Constants.ROLE.ADMIN_REGION))
                {
                    data.RegionId = item.OtorisasiId.Trim();
                    data.AuditLocationId = null;
                }
                else if (item.RoleId.Equals(Constants.ROLE.ADMIN_LOKASI) || item.RoleId.Equals(Constants.ROLE.USER))
                {
                    data.RegionId = null;
                    data.AuditLocationId = item.OtorisasiId.Trim();
                }
                else
                {
                    data.RegionId = null;
                    data.AuditLocationId = null;
                }

                if (_unitOfWork.MUserRoleRepository.anyInsert(data))
                {
                    throw new Exception("Data already exists");
                }

                _unitOfWork.MUserRoleRepository.Add(data);
                _unitOfWork.Complete();

                data = _unitOfWork.MUserRoleRepository.Get(data.UserRoleId.Trim());

                var read = _unitOfWork.MUserRoleRepository.SelectOne(data.UserRoleId.Trim());

                return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.CREATE, read));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(string id)
        {
            try
            {
                MUserRole data = _unitOfWork.MUserRoleRepository.Get(id);
                if (data != null)
                {
                    _unitOfWork.MUserRoleRepository.Delete(data, _userId, Constants.GETDATE());
                    _unitOfWork.Complete();

                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.DELETE, null));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        //[Route("ReadFile")]
        //[HttpPost]
        //public IActionResult ReadFile(string name)
        //{
        //    var test = name;
        //    var files = HttpContext.Request.Form.Files;
        //    return Ok();
                
        //}
    }
}