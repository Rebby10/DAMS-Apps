﻿using DigitalAudit.Helper;
using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using DigitalAudit.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace DigitalAudit.API.Controllers.Master
{
    [Authorize]
    [ApiController]
    [Route("Master/Response")]
    public class MResponseController : ControllerBase
    {
        private readonly ILogger<MResponseController> _logger;
        private readonly IUnitOfWork _unitOfWork;
        private ClaimsPrincipal _principal;
        private string _userId;

        public MResponseController(IUnitOfWork unitOfWork, ILogger<MResponseController> logger, IHttpContextAccessor httpContextAccessor)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
            _userId = httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
        }

        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var items = _unitOfWork.MResponseRepository.SelectAll();
                int totalData = items.Count();

                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, items.Count(), items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpGet]
        [Route("query")]
        public IActionResult Get(
           [FromQuery] MResponseViewModel.QueryResponse param)
        {
            try
            {
                IEnumerable<MResponseViewModel.ReadResponse> items = _unitOfWork.MResponseRepository.SelectAll();

                if (param.id != 0)
                    items = items.Where(i => i.ResponseId == param.id);

                if (param.type_id != 0)
                    items = items.Where(i => i.ResponseType.TypeId == param.type_id);

                if (!string.IsNullOrEmpty(param.name))
                    items = items.Where(i => i.Name.ToLower().Contains(param.name.Trim().ToLower()));

                int totalData = items.Count();

                if (!string.IsNullOrEmpty(param.sort_by))
                {
                    var orderByExpression = Helpers.GetOrderByExpression<MResponseViewModel.ReadResponse>(param.sort_by);
                    items = Helpers.OrderByDir<MResponseViewModel.ReadResponse>(items, param.order_by, orderByExpression).AsEnumerable();
                }

                if (param.page_size != null && param.page_number != null)
                {
                    items = Helpers.Page<MResponseViewModel.ReadResponse>(items, param.page_size.Value, param.page_number.Value);
                }

                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, totalData, items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            try
            {
                var userType = _unitOfWork.MResponseRepository.SelectOne(id);

                if (userType != null)
                {
                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.READ, userType));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpPut]
        public IActionResult Put([FromBody] MResponseViewModel.UpdateResponse item)
        {
            try
            {
                Helpers.Validate(item);
                MResponse data = _unitOfWork.MResponseRepository.Get(item.ResponseId);

                if (data != null)
                {
                    data.ResponseId = item.ResponseId;
                    data.Name = item.Name.Trim();
                    data.TypeId = item.TypeId;
                    data.AnswerTypeId = item.AnswerTypeId;

                    if (_unitOfWork.MResponseRepository.anyUpdate(data))
                    {
                        throw new Exception("Data already exists");
                    }

                    _unitOfWork.MResponseRepository.Update(data, _userId, Constants.GETDATE());
                    _unitOfWork.Complete();

                    MResponseViewModel.ReadResponse read = _unitOfWork.MResponseRepository.SelectOne(data.ResponseId);

                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.UPDATE, read));
                }
                else
                {
                    return Ok(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, item));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return Ok(new StatusModel(ex));
            }
        }

        [HttpPost]
        public IActionResult Post([FromBody] MResponseViewModel.CreateResponse item)
        {
            try
            {
                Helpers.Validate(item);
                MResponse data = new MResponse(
                    0,  
                    item.Name.Trim(),
                    item.TypeId,
                    item.AnswerTypeId,
                    false,
                    _userId,
                    Constants.GETDATE(),
                    null,
                    null);
                if (_unitOfWork.MResponseRepository.anyInsert(data))
                {
                    throw new Exception("Data already exists");
                }
                _unitOfWork.MResponseRepository.Add(data);
                _unitOfWork.Complete();

                data = _unitOfWork.MResponseRepository.Get(data.ResponseId);

                MResponseViewModel.ReadResponse read = _unitOfWork.MResponseRepository.SelectOne(data.ResponseId);

                return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.CREATE, read));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return Ok(new StatusModel(ex));
            }
        }

        [HttpDelete]
        public IActionResult Delete([FromBody] MResponseViewModel.DestroyResponse item)
        {
            try
            {
                MResponse data = _unitOfWork.MResponseRepository.Get(item.ResponseId);
                if (data != null)
                {
                    _unitOfWork.MResponseRepository.Delete(data, _userId, Constants.GETDATE());
                    _unitOfWork.Complete();

                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.DELETE, null));
                }
                else
                {
                    return Ok(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return Ok(new StatusModel(ex));
            }
        }
    }
}
