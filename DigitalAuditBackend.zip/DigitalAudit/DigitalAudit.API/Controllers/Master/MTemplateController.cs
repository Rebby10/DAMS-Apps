﻿using DigitalAudit.Helper;
using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using DigitalAudit.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace DigitalAudit.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("Master/Template")]
    public class MTemplateController : ControllerBase
    {
        private readonly ILogger<MTemplateController> _logger;
        private readonly IUnitOfWork _unitOfWork;
        private string _userId;

        public MTemplateController(IUnitOfWork unitOfWork, ILogger<MTemplateController> logger, IHttpContextAccessor httpContextAccessor)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
            _userId = httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
        }

        // GET: api/Master/Template
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var items = _unitOfWork.MTemplateRepository.SelectAll(null, null, null, null, null, null, null, null);
                int totalData = items.Count();

                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, items.Count(), items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpGet]
        [Route("query")]
        public IActionResult Get(
            [FromQuery] MTemplateViewModel.QueryMTemplate param)
        {
            try
            {
                IEnumerable<MTemplateViewModel.ReadMTemplate> items = _unitOfWork.MTemplateRepository.SelectAll(param.template_id, param.category_id, param.template_permission_type_id, param.title, param.description, param.user_id, param.user_group_id, param.official_name);

                if (!string.IsNullOrEmpty(param.template_id))
                    items = items.Where(i => i.TemplateId == param.template_id.Trim());


                if(param.is_show_issue != null)
                {
                    items = items.Where(i => i.IsShowIssue == param.is_show_issue);
                }

                int totalData = items.Count();

                if (!string.IsNullOrEmpty(param.sort_by))
                {
                    var orderByExpression = Helpers.GetOrderByExpression<MTemplateViewModel.ReadMTemplate>(param.sort_by);
                    items = Helpers.OrderByDir<MTemplateViewModel.ReadMTemplate>(items, param.order_by, orderByExpression).AsEnumerable();
                }

                if (param.page_size != null && param.page_number != null)
                {
                    items = Helpers.Page<MTemplateViewModel.ReadMTemplate>(items, param.page_size.Value, param.page_number.Value);
                }

                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, totalData, items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, param);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpGet("{id}")]
        public IActionResult Get(string id)
        {
            try
            {
                //MResponseViewModel.ReadResponse tes = _unitOfWork.MTemplateRepository.GetResponse(1);
                //MTemplateMainTesViewModel tes = _unitOfWork.MTemplateRepository.GetTemplates();
                var item = _unitOfWork.MTemplateRepository.GetTemplate(id.Trim());

                
                if (item != null)
                {
                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.READ, item));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, id);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpPut]
        public IActionResult Put([FromBody] MTemplateViewModel.UpdateMTemplate item)
        {
            try
            {
                Helpers.Validate(item);
                MTemplate data = _unitOfWork.MTemplateRepository.Get(item.TemplateId.Trim());

                if (data != null)
                {
                    data.Code = item.Code.Trim();
                    data.Title = item.Title.Trim();
                    data.Descriptions = item.Descriptions.Trim();
                    data.CategoryId = item.CategoryId;
                    data.IsShowIssue = item.IsShowIssue;

                    if (data.TemplatePermissionTypeId == 0)
                    {
                        throw new Exception("Template Permission Type Id Is Required");
                    }

                    if (data.CategoryId == 0)
                    {
                        throw new Exception("Category Id Is Required");
                    }


                    if (
                        (data.TemplatePermissionTypeId == Constants.TEMPLATE_PERMISSION_TYPE.GROUP || data.TemplatePermissionTypeId == Constants.TEMPLATE_PERMISSION_TYPE.USER)
                        &&
                        string.IsNullOrEmpty(data.PermissionEntityId)
                    )
                    {
                        throw new Exception("User Id/ User Group Id is required");
                    }

                    //if (_unitOfWork.MTemplateRepository.anyUpdate(data))
                    //{
                    //    throw new Exception("Data already exists");
                    //}

                    _unitOfWork.MTemplateRepository.Update(data, _userId, Constants.GETDATE());
                    _unitOfWork.Complete();

                    MTemplateViewModel.ReadMTemplate read = _unitOfWork.MTemplateRepository.SelectOne(data.TemplateId.Trim());

                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.UPDATE, read));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, item);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpPost]
        public IActionResult Post([FromBody] MTemplateViewModel.CreateMTemplate item)
        {
            try
            {
                Helpers.Validate(item);
                MTemplate data = new MTemplate(
                    Constants.GETID(),
                    0,
                    item.TemplatePermissionTypeId, 
                    item.PermissionEntityId,
                    item.Code.Trim(),
                    item.Title.Trim(),
                    item.Descriptions.Trim(),
                    item.CategoryId,
                    item.IsShowIssue,
                    false,
                    _userId,
                    Constants.GETDATE(),
                    null,
                    null);


                if(data.TemplatePermissionTypeId == 0)
                {
                    throw new Exception("Template Permission Type Id Is Required");
                }

                if (data.CategoryId == 0)
                {
                    throw new Exception("Category Id Is Required");
                }


                if (
                        (data.TemplatePermissionTypeId == Constants.TEMPLATE_PERMISSION_TYPE.GROUP || data.TemplatePermissionTypeId == Constants.TEMPLATE_PERMISSION_TYPE.USER)
                        &&
                        string.IsNullOrEmpty(data.PermissionEntityId)
                    )
                {
                    throw new Exception("User Id/ User Group Id is required");
                }

                if (_unitOfWork.MTemplateRepository.anyInsert(data))
                {
                    throw new Exception("Data already exists");
                }
                _unitOfWork.MTemplateRepository.Add(data);
                _unitOfWork.Complete();

                data = _unitOfWork.MTemplateRepository.Get(data.TemplateId.Trim());

                MTemplateViewModel.ReadMTemplate read = _unitOfWork.MTemplateRepository.SelectOne(data.TemplateId.Trim());

                return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.CREATE, read));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, item);
                return Ok(new StatusModel(ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(string id)
        {
            try
            {
                var item = _unitOfWork.MTemplateRepository.Get(id.Trim());
                if (item != null)
                {
                    _unitOfWork.MTemplateRepository.Delete(item, _userId, Constants.GETDATE());
                    _unitOfWork.Complete();

                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.DELETE, null));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, id);
                return Ok(new StatusModel(ex));
            }
        }
    }
}
