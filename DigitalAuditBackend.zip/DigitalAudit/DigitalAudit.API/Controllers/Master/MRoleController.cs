﻿using DigitalAudit.Helper;
using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace DigitalAudit.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("Master/Role")]
    public class MRoleController : ControllerBase
    {
        private readonly ILogger<MRoleController> _logger;
        private readonly IUnitOfWork _unitOfWork;
        private string _userId;
        public MRoleController(IUnitOfWork unitOfWork, ILogger<MRoleController> logger, IHttpContextAccessor httpContextAccessor)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
            _userId = httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
        }

        // GET: api/Master/Role
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var items = _unitOfWork.MRoleRepository.GetAll();
                int totalData = items.Count();

                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, items.Count(), items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpGet("{id}")]
        public IActionResult Get(string id)
        {
            try
            {
                var role = _unitOfWork.MRoleRepository.Get(id);
                if (role != null)
                {
                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.READ, role));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, id);
                return Ok(new StatusModel(ex));
            }
        }

        //[HttpGet]
        //[Route("query")]
        //public IActionResult Get(
        //    [FromQuery] string id,
        //    [FromQuery] string name,
        //    [FromQuery] string sort_by,
        //    [FromQuery] string order_by,
        //    [FromQuery] int? page_size,
        //    [FromQuery] int? page_number)
        //{
        //    try
        //    {
        //        IEnumerable<MRole> items = _unitOfWork.MRoleRepository.GetAll();

        //        if (!string.IsNullOrEmpty(id))
        //            items = items.Where(i => i.RoleId == id);

        //        if (!string.IsNullOrEmpty(name))
        //            items = items.Where(i => i.Name.ToLower().Contains(name.ToLower()));


        //        if (!string.IsNullOrEmpty(sort_by))
        //        {
        //            var orderByExpression = Helpers.GetOrderByExpression<MRole>(sort_by);
        //            items = Helpers.OrderByDir<MRole>(items, order_by, orderByExpression).AsEnumerable();
        //        }

        //        if (page_size != null && page_number != null)
        //        {
        //            items = Helpers.Page<MRole>(items, page_size.Value, page_number.Value);
        //        }

        //        return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.READ, items));
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
        //        return Ok(new StatusModel(ex));
        //    }
        //}



        //[HttpPut]
        //public IActionResult Put([FromBody] MRole item)
        //{
        //    try
        //    {
        //        MRole data = _unitOfWork.MRoleRepository.Get(item.RoleId);
        //        if (data != null)
        //        {
        //            data.Name = item.Name;
        //            _unitOfWork.MRoleRepository.Update(data, Constants.DEFAULT_USER, Constants.GETDATE());
        //            _unitOfWork.Complete();

        //            data = _unitOfWork.MRoleRepository.Get(data.RoleId);

        //            return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.UPDATE, data));
        //        }
        //        else
        //        {
        //            return Ok(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, item));
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
        //        return Ok(new StatusModel(ex));
        //    }
        //}

        //[HttpPost]
        //public IActionResult Post([FromBody] MRole item)
        //{
        //    try
        //    {
        //        Helpers.Validate(item);

        //        item.RoleId = Constants.GETID();
        //        item.DateCreated = Constants.GETDATE();
        //        item.UserCreated = Constants.DEFAULT_USER;
        //        _unitOfWork.MRoleRepository.Add(item);
        //        _unitOfWork.Complete();

        //        item = _unitOfWork.MRoleRepository.Get(item.RoleId);

        //        return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.CREATE, item));
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
        //        return Ok(new StatusModel(ex));
        //    }
        //}

        //[HttpDelete]
        //public IActionResult Delete([FromBody] MRole item)
        //{
        //    try
        //    {
        //        item = _unitOfWork.MRoleRepository.Get(item.RoleId);
        //        if (item != null)
        //        {
        //            _unitOfWork.MRoleRepository.Delete(item, Constants.DEFAULT_USER, Constants.GETDATE());
        //            _unitOfWork.Complete();

        //            return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.DELETE, null));
        //        }
        //        else
        //        {
        //            return Ok(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
        //        return Ok(new StatusModel(ex));
        //    }
        //}
    }
}
