﻿using DigitalAudit.Helper;
using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using DigitalAudit.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace DigitalAudit.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("Master/Region")]
    public class MRegionController : ControllerBase
    {
        private readonly ILogger<MRegionController> _logger;
        private readonly IUnitOfWork _unitOfWork;
        private string _userId;

        public MRegionController(IUnitOfWork unitOfWork, ILogger<MRegionController> logger, IHttpContextAccessor httpContextAccessor)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
            _userId = httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
        }

        // GET: api/Master/Region
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var items = _unitOfWork.MRegionRepository.SelectAll().OrderBy(o => o.Name);
                int totalData = items.Count();
                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, items.Count(), items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpGet]
        [Route("query")]
        public IActionResult Get(
            [FromQuery] MRegionViewModel.QueryRegion param)
        {
            try
            {
                IEnumerable<MRegionViewModel.ReadRegion> items = _unitOfWork.MRegionRepository.SelectAll();

                if (!string.IsNullOrEmpty(param.id))
                    items = items.Where(i => i.RegionId == param.id.Trim());

                if (!string.IsNullOrEmpty(param.name))
                    items = items.Where(i => i.Name.ToLower().Contains(param.name.Trim().ToLower()));

                int totalData = items.Count();


                if (!string.IsNullOrEmpty(param.sort_by))
                {
                    var orderByExpression = Helpers.GetOrderByExpression<MRegionViewModel.ReadRegion>(param.sort_by);
                    items = Helpers.OrderByDir<MRegionViewModel.ReadRegion>(items, param.order_by, orderByExpression).AsEnumerable();
                }
                else
                {
                    var orderByExpression = Helpers.GetOrderByExpression<MRegionViewModel.ReadRegion>("Name");
                    items = Helpers.OrderByDir<MRegionViewModel.ReadRegion>(items, param.order_by, orderByExpression).AsEnumerable();
                }

                if (param.page_size != null && param.page_number != null)
                {
                    items = Helpers.Page<MRegionViewModel.ReadRegion>(items, param.page_size.Value, param.page_number.Value);
                }

                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, totalData, items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, param);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpGet("{id}")]
        public IActionResult Get(string id)
        {
            try
            {
                var region = _unitOfWork.MRegionRepository.SelectOne(id.Trim());

                if (region != null)
                {
                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.READ, region));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }
                
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, id);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpPut]
        public IActionResult Put([FromBody] MRegionViewModel.UpdateRegion item)
        {
            try
            {
                Helpers.Validate(item);
                MRegion data = _unitOfWork.MRegionRepository.Get(item.RegionId.Trim());

                if (data != null)
                {
                    data.Name = item.Name.Trim();

                    if (_unitOfWork.MRegionRepository.anyUpdate(data))
                    {
                        throw new Exception("Data already exists");
                    }

                    _unitOfWork.MRegionRepository.Update(data, _userId, Constants.GETDATE());
                    _unitOfWork.Complete();

                    MRegionViewModel.ReadRegion read = _unitOfWork.MRegionRepository.SelectOne(data.RegionId.Trim());

                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.UPDATE, read));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, item));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, item);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpPost]
        public IActionResult Post([FromBody] MRegionViewModel.CreateRegion item)
        {
            try
            {
                Helpers.Validate(item);
                MRegion data = new MRegion(
                    Constants.GETID(),
                    item.Name.Trim(),
                    false,
                    _userId,
                    Constants.GETDATE(),
                    null,
                    null);
                if (_unitOfWork.MRegionRepository.anyInsert(data))
                {
                    throw new Exception("Data already exists");
                }
                _unitOfWork.MRegionRepository.Add(data);
                _unitOfWork.Complete();

                data = _unitOfWork.MRegionRepository.Get(data.RegionId.Trim());

                MRegionViewModel.ReadRegion read = _unitOfWork.MRegionRepository.SelectOne(data.RegionId.Trim());

                return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.CREATE, read));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, item);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(string id)
        {
            try
            {
                MRegion data = _unitOfWork.MRegionRepository.Get(id.Trim());
                if (data != null)
                {
                    if (_unitOfWork.MRegionRepository.anyUpdate(data))
                    {
                        throw new Exception("Data masih digunakan di transaksi");
                    }

                    _unitOfWork.MRegionRepository.Delete(data, _userId, Constants.GETDATE());
                    _unitOfWork.Complete();

                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.DELETE, null));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, id);
                return BadRequest(new StatusModel(ex));
            }
        }
    }
}
