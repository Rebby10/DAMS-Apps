﻿using DigitalAudit.API.Services;
using DigitalAudit.Helper;
using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using DigitalAudit.Model.ViewModel.Idaman;
using DigitalAudit.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace DigitalAudit.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("Master/User/Whitelist")]
    public class MUserWhitelistController : ControllerBase
    {
        private readonly IIdamanService _idamanService;
        private readonly ILogger<MUserWhitelistController> _logger;
        private readonly IUnitOfWork _unitOfWork;
		private string _userId;
		public MUserWhitelistController(IUnitOfWork unitOfWork, ILogger<MUserWhitelistController> logger, IIdamanService idamanService, IHttpContextAccessor httpContextAccessor)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
            _idamanService = idamanService;
			_userId = httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
		}

        [HttpPost]
        [Route("Sync")]
        public IActionResult Sync()
        {
            try
            {
				StatusViewModel res = _unitOfWork.MUserWhitelistRepository.SyncUserWhitelist();

                return Ok(new StatusModel(res.IsSuccess, res.Messages, null));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, null);
                return Ok(new StatusModel(ex));
            }
        }

        [HttpGet]
        [Route("Users")]
        public IActionResult Users(
           [FromQuery] MUserSyncAllViewModel.QueryUserSyncAll param)
        {
            try
            {
                IEnumerable<MUserSyncAllViewModel.ReadUserSyncAll> items = _unitOfWork.MUserSyncAllRepository.SelectAll();

                if (!string.IsNullOrEmpty(param.id))
                    items = items.Where(i => i.UserId == param.id.Trim());

                if (!string.IsNullOrEmpty(param.name))
                    items = items.Where(i => i.DisplayName.ToLower().Contains(param.name.Trim().ToLower()));

                int totalData = items.Count();

                if (!string.IsNullOrEmpty(param.sort_by))
                {
                    var orderByExpression = Helpers.GetOrderByExpression<MUserSyncAllViewModel.ReadUserSyncAll>(param.sort_by);
                    items = Helpers.OrderByDir<MUserSyncAllViewModel.ReadUserSyncAll>(items, param.order_by, orderByExpression).AsEnumerable();
                }

                if (param.page_size != null && param.page_number != null)
                {
                    items = Helpers.Page<MUserSyncAllViewModel.ReadUserSyncAll>(items, param.page_size.Value, param.page_number.Value);
                }

                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, totalData, items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, param);
                return BadRequest(new StatusModel(ex));
            }
        }

		[HttpGet]
		public IActionResult Get()
		{
			try
			{
				var items = _unitOfWork.MUserWhitelistRepository.SelectAll(null, null, null, null);
				int totalData = items.Count();

				if (items.Count() > 0)
				{
					return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, items.Count(), items.Count()));
				}
				else
				{
					return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
				}
			}
			catch (Exception ex)
			{
				_logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
				return BadRequest(new StatusModel(ex));
			}
		}

		[HttpGet]
		[Route("query")]
		public IActionResult Get(
			[FromQuery] MUserWhitelistViewModel.QueryUserWhitelist param)
		{
			try
			{
				IEnumerable<MUserWhitelistViewModel.ReadUserWhitelist> items = _unitOfWork.MUserWhitelistRepository.SelectAll(null, null, null, null);

				if (!string.IsNullOrEmpty(param.id))
					items = items.Where(i => i.UserWhitelistId == param.id.Trim());

				if (!string.IsNullOrEmpty(param.user_id))
					items = items.Where(i => i.User.UserId == param.user_id.Trim());

				if (!string.IsNullOrEmpty(param.official_name))
					items = items.Where(i => i.User.DisplayName.ToLower().Contains(param.official_name.Trim().ToLower()));


				if (!string.IsNullOrEmpty(param.email))
					items = items.Where(i => i.User.Email.ToLower().Contains(param.email.Trim().ToLower()));

				int totalData = items.Count();

				if (!string.IsNullOrEmpty(param.sort_by))
				{
					var orderByExpression = Helpers.GetOrderByExpression<MUserWhitelistViewModel.ReadUserWhitelist>(param.sort_by);
					items = Helpers.OrderByDir<MUserWhitelistViewModel.ReadUserWhitelist>(items, param.order_by, orderByExpression).AsEnumerable();
				}

				if (param.page_size != null && param.page_number != null)
				{
					items = Helpers.Page<MUserWhitelistViewModel.ReadUserWhitelist>(items, param.page_size.Value, param.page_number.Value);
				}

				if (items.Count() > 0)
				{
					return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, totalData, items.Count()));
				}
				else
				{
					return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
				}
			}
			catch (Exception ex)
			{
				_logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, param);
				return BadRequest(new StatusModel(ex));
			}
		}

		[HttpGet("{id}")]
		public IActionResult Get(string id)
		{
			try
			{
				var faq = _unitOfWork.MUserWhitelistRepository.SelectOne(id.Trim());

				if (faq != null)
				{
					return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.READ, faq));
				}
				else
				{
					return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
				}

			}
			catch (Exception ex)
			{
				_logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, id);
				return BadRequest(new StatusModel(ex));
			}
		}

		[HttpPost]
		public IActionResult Post([FromBody] MUserWhitelistViewModel.CreateUserWhitelist item)
		{
			try
			{
				Helpers.Validate(item);
				MUserWhitelist data = new MUserWhitelist(
					Constants.GETID(),
					item.UserId.Trim(),
					false,
					_userId,
					Constants.GETDATE(),
					null,
					null);
				if (_unitOfWork.MUserWhitelistRepository.anyInsert(data))
				{
					throw new Exception("Data already exists");
				}
				_unitOfWork.MUserWhitelistRepository.Add(data);
				_unitOfWork.Complete();

				data = _unitOfWork.MUserWhitelistRepository.Get(data.UserWhitelistId.Trim());

				MUserWhitelistViewModel.ReadUserWhitelist read = _unitOfWork.MUserWhitelistRepository.SelectOne(data.UserWhitelistId.Trim());

				return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.CREATE, read));
			}
			catch (Exception ex)
			{
				_logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, item);
				return Ok(new StatusModel(ex));
			}
		}

		[HttpDelete("{id}")]
		public IActionResult Delete(string id)
		{
			try
			{
				var item = _unitOfWork.MUserWhitelistRepository.Get(id.Trim());
				if (item != null)
				{
					_unitOfWork.MUserWhitelistRepository.Delete(item, _userId, Constants.GETDATE());
					_unitOfWork.Complete();

					return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.DELETE, null));
				}
				else
				{
					return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
				}
			}
			catch (Exception ex)
			{
				_logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, id);
				return Ok(new StatusModel(ex));
			}
		}
	}
}
