﻿using DigitalAudit.Helper;
using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using DigitalAudit.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace DigitalAudit.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("Master/Template/PermissionType")]
    public class MTemplatePermissionTypeController : ControllerBase
    {
        private readonly ILogger<MTemplatePermissionTypeController> _logger;
        private readonly IUnitOfWork _unitOfWork;
        private ClaimsPrincipal _principal;
        public MTemplatePermissionTypeController(IUnitOfWork unitOfWork, ILogger<MTemplatePermissionTypeController> logger)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
        }

        // GET: api/Master/Template/PermissionType
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var items = _unitOfWork.MTemplatePermissionTypeRepository.SelectAll();
                int totalData = items.Count();

                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, items.Count(), items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpGet]
        [Route("query")]
        public IActionResult Get(
            [FromQuery] MTemplatePermissionTypeViewModel.QueryMTemplatePermissionType param)
        {
            try
            {
                IEnumerable<MTemplatePermissionTypeViewModel.ReadMTemplatePermissionType> items = _unitOfWork.MTemplatePermissionTypeRepository.SelectAll();

                if (param.id != null)
                    items = items.Where(i => i.TemplatePermissionTypeId == param.id);

                if (!string.IsNullOrEmpty(param.name))
                    items = items.Where(i => i.Name.ToLower().Contains(param.name.Trim().ToLower()));

                int totalData = items.Count();

                if (!string.IsNullOrEmpty(param.sort_by))
                {
                    var orderByExpression = Helpers.GetOrderByExpression<MTemplatePermissionTypeViewModel.ReadMTemplatePermissionType>(param.sort_by);
                    items = Helpers.OrderByDir<MTemplatePermissionTypeViewModel.ReadMTemplatePermissionType>(items, param.order_by, orderByExpression).AsEnumerable();
                }

                if (param.page_size != null && param.page_number != null)
                {
                    items = Helpers.Page<MTemplatePermissionTypeViewModel.ReadMTemplatePermissionType>(items, param.page_size.Value, param.page_number.Value);
                }

                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, totalData, items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            try
            {
                var data = _unitOfWork.MTemplatePermissionTypeRepository.SelectOne(id);

                if (data != null)
                {
                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.READ, data));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }
    }
}
