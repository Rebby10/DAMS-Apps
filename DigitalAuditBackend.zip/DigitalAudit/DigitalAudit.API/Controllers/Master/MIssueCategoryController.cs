﻿using AutoMapper;
using DigitalAudit.Helper;
using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using DigitalAudit.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace DigitalAudit.API.Controllers.Master
{
    [Authorize]
    [ApiController]
    [Route("Master/Issue/Category")]
    public class MIssueCategoryController : ControllerBase
    {
        private readonly ILogger<MIssueCategoryController> _logger;
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;
        private string _userId;
        public MIssueCategoryController(IUnitOfWork unitOfWork, ILogger<MIssueCategoryController> logger, IMapper mapper, IHttpContextAccessor httpContextAccessor)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
            _mapper = mapper;
            _userId = httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
        }

        // GET: api/Master/Issue/Category
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var items = _unitOfWork.MIssueCategoryRepository.GetAll()
                    .Select(s => new MIssueCategoryViewModel.ReadIssueCategory
                    {
                        IssueCategoryId = s.IssueCategoryId,
                        Name = s.Name
                    });
                int totalData = items.Count();

                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, items.Count(), items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            try
            {
                var issueCategory = _unitOfWork.MIssueCategoryRepository.Get(id);

                var responseData = _mapper.Map<MIssueCategory, MIssueCategoryViewModel.ReadIssueCategory>(issueCategory);

                if (responseData != null)
                {
                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.READ, responseData));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, id);
                return BadRequest(new StatusModel(ex));
            }
        }
    }
}