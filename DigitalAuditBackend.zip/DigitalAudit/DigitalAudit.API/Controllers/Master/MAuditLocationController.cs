﻿using DigitalAudit.Helper;
using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using DigitalAudit.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace DigitalAudit.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("Master/Audit/Location")]
    public class MAuditLocationController : ControllerBase
    {
        private readonly ILogger<MAuditLocationController> _logger;
        private readonly IUnitOfWork _unitOfWork;
        private string _userId;
        public MAuditLocationController(IUnitOfWork unitOfWork, ILogger<MAuditLocationController> logger, IHttpContextAccessor httpContextAccessor)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
            _userId = httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
        }

        // GET: api/Master/Audit/Location
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var items = _unitOfWork.MAuditLocationRepository.SelectAll().OrderBy(o => o.Name);


                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, items.Count(), items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpGet]
        [Route("query")]
        public IActionResult Get(
            [FromQuery] MAuditLocationViewModel.QueryAuditLocation param)
        {
            try
            {
                IEnumerable<MAuditLocationViewModel.ReadAuditLocation> items = _unitOfWork.MAuditLocationRepository.SelectAll();

                if (!string.IsNullOrEmpty(param.id))
                    items = items.Where(i => i.AuditLocationId == param.id.Trim());

                if (!string.IsNullOrEmpty(param.name))
                    items = items.Where(i => i.Name.ToLower().Contains(param.name.Trim().ToLower()));

                if (!string.IsNullOrEmpty(param.address))
                    items = items.Where(i => i.Address.ToLower().Contains(param.address.Trim().ToLower()));

                if (!string.IsNullOrEmpty(param.region_id))
                    items = items.Where(i => i.Region.RegionId.ToLower().Contains(param.region_id.Trim().ToLower()));

                if (!string.IsNullOrEmpty(param.region_name))
                    items = items.Where(i => i.Region.Name.ToLower().Contains(param.region_name.Trim().ToLower()));


                int totalData = items.Count();


                if (!string.IsNullOrEmpty(param.sort_by))
                {
                    var orderByExpression = Helpers.GetOrderByExpression<MAuditLocationViewModel.ReadAuditLocation>(param.sort_by);
                    items = Helpers.OrderByDir<MAuditLocationViewModel.ReadAuditLocation>(items, param.order_by, orderByExpression).AsEnumerable();
                }
                else 
                {
                    var orderByExpression = Helpers.GetOrderByExpression<MAuditLocationViewModel.ReadAuditLocation>("Name");
                    items = Helpers.OrderByDir<MAuditLocationViewModel.ReadAuditLocation>(items, param.order_by, orderByExpression).AsEnumerable();
                }

                if (param.page_size != null && param.page_number != null)
                {
                    items = Helpers.Page<MAuditLocationViewModel.ReadAuditLocation>(items, param.page_size.Value, param.page_number.Value);
                }

                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, totalData, items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, param);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpGet("{id}")]
        public IActionResult Get(string id)
        {
            try
            {
                var auditLocation = _unitOfWork.MAuditLocationRepository.SelectOne(id.Trim());

                if (auditLocation != null)
                {
                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.READ, auditLocation));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpPut]
        public IActionResult Put([FromBody] MAuditLocationViewModel.UpdateAuditLocation item)
        {
            try
            {
                Helpers.Validate(item);
                MAuditLocation data = _unitOfWork.MAuditLocationRepository.Get(item.AuditLocationId.Trim());

                if (data != null)
                {
                    data.Name = item.Name.Trim();
                    data.Address = item.Address.Trim();
                    data.ZipCode = item.ZipCode.Trim();
                    data.LatLong = item.LatLong.Trim();
                    data.RegionId = item.RegionId.Trim();

                    if (_unitOfWork.MAuditLocationRepository.anyUpdate(data))
                    {
                        throw new Exception("Data already exists");
                    }

                    _unitOfWork.MAuditLocationRepository.Update(data, _userId, Constants.GETDATE());
                    _unitOfWork.Complete();

                    MAuditLocationViewModel.ReadAuditLocation read = _unitOfWork.MAuditLocationRepository.SelectOne(data.AuditLocationId.Trim());

                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.UPDATE, read));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpPost]
        public IActionResult Post([FromBody] MAuditLocationViewModel.CreateAuditLocation item)
        {
            try
            {
                Helpers.Validate(item);
                MAuditLocation data = new MAuditLocation(
                    Constants.GETID(),
                    0,
                    item.Name.Trim(), 
                    item.Address.Trim(), 
                    item.ZipCode.Trim(), 
                    item.LatLong.Trim(), 
                    item.RegionId.Trim(), 
                    false, 
                    _userId, 
                    Constants.GETDATE(), 
                    null, 
                    null);
                if (_unitOfWork.MAuditLocationRepository.anyInsert(data))
                {
                    throw new Exception("Data already exists");
                }
                Validate(data, Constants.CRUD.CREATE);
                _unitOfWork.MAuditLocationRepository.Add(data);
                _unitOfWork.Complete();

                data = _unitOfWork.MAuditLocationRepository.Get(data.AuditLocationId.Trim());

                MAuditLocationViewModel.ReadAuditLocation read = _unitOfWork.MAuditLocationRepository.SelectOne(data.AuditLocationId.Trim());

                return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.CREATE, item));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(string id)
        {
            try
            {
                MAuditLocation data = _unitOfWork.MAuditLocationRepository.Get(id);
                if (data != null)
                {
                    if (_unitOfWork.MAuditLocationRepository.anyDelete(data))
                    {
                        throw new Exception("Data masih digunakan di transaksi");
                    }

                    _unitOfWork.MAuditLocationRepository.Delete(data, _userId, Constants.GETDATE());
                    _unitOfWork.Complete();

                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.DELETE, null));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }


        [ApiExplorerSettings(IgnoreApi = true)]
        public void Validate(MAuditLocation model, string func)
        {
           
            if(func == Constants.CRUD.CREATE || func == Constants.CRUD.UPDATE)
            {
                if(!_unitOfWork.MRegionRepository.GetAll().Any(i=> i.IsDeleted == false && i.RegionId == model.RegionId))
                {
                    throw new Exception("Region tidak valid");
                }
            }
        }
    }
}
