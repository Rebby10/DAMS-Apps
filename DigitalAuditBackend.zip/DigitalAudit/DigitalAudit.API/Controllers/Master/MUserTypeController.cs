﻿using DigitalAudit.Helper;
using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using DigitalAudit.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace DigitalAudit.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("Master/User/Type")]
    public class MUserTypeController : ControllerBase
    {
        private readonly ILogger<MUserTypeController> _logger;
        private readonly IUnitOfWork _unitOfWork;
        private string _userId;
        public MUserTypeController(IUnitOfWork unitOfWork, ILogger<MUserTypeController> logger, IHttpContextAccessor httpContextAccessor)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
            _userId = httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
        }

        // GET: api/Master/UserType
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var items = _unitOfWork.MUserTypeRepository.SelectAll();
                int totalData = items.Count();

                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, items.Count(), items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpGet]
        [Route("query")]
        public IActionResult Get(
            [FromQuery] MUserTypeViewModel.QueryUserType param)
        {
            try
            {
                IEnumerable<MUserTypeViewModel.ReadUserType> items = _unitOfWork.MUserTypeRepository.SelectAll();

                if (!string.IsNullOrEmpty(param.id))
                    items = items.Where(i => i.UserTypeId == param.id.Trim());

                if (!string.IsNullOrEmpty(param.name))
                    items = items.Where(i => i.Name.ToLower().Contains(param.name.Trim().ToLower()));

                int totalData = items.Count();

                if (!string.IsNullOrEmpty(param.sort_by))
                {
                    var orderByExpression = Helpers.GetOrderByExpression<MUserTypeViewModel.ReadUserType>(param.sort_by);
                    items = Helpers.OrderByDir<MUserTypeViewModel.ReadUserType>(items, param.order_by, orderByExpression).AsEnumerable();
                }

                if (param.page_size != null && param.page_number != null)
                {
                    items = Helpers.Page<MUserTypeViewModel.ReadUserType>(items, param.page_size.Value, param.page_number.Value);
                }

                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, totalData, items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpGet("{id}")]
        public IActionResult Get(string id)
        {
            try
            {
                var userType = _unitOfWork.MUserTypeRepository.SelectOne(id.Trim());

                if (userType != null)
                {
                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.READ, userType));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }
                
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        //[HttpPut]
        //public IActionResult Put([FromBody] MUserTypeViewModel.UpdateUserType item)
        //{
        //    try
        //    {
        //        Helpers.Validate(item);
        //        MUserType data = _unitOfWork.MUserTypeRepository.Get(item.UserTypeId.Trim());

        //        if (data != null)
        //        {
        //            data.Name = item.Name.Trim();

        //            if (_unitOfWork.MUserTypeRepository.anyUpdate(data))
        //            {
        //                throw new Exception("Data already exists");
        //            }

        //            _unitOfWork.MUserTypeRepository.Update(data, Constants.DEFAULT_USER, Constants.GETDATE());
        //            _unitOfWork.Complete();

        //            MUserTypeViewModel.ReadUserType read = _unitOfWork.MUserTypeRepository.SelectOne(data.UserTypeId.Trim());

        //            return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.UPDATE, read));
        //        }
        //        else
        //        {
        //            return Ok(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, item));
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
        //        return Ok(new StatusModel(ex));
        //    }
        //}

        //[HttpPost]
        //public IActionResult Post([FromBody] MUserTypeViewModel.CreateUserType item)
        //{
        //    try
        //    {
        //        Helpers.Validate(item);
        //        MUserType data = new MUserType(
        //            Constants.GETID(),
        //            item.Name.Trim(),
        //            false,
        //            Constants.DEFAULT_USER,
        //            Constants.GETDATE(),
        //            null,
        //            null);
        //        if (_unitOfWork.MUserTypeRepository.anyInsert(data))
        //        {
        //            throw new Exception("Data already exists");
        //        }
        //        _unitOfWork.MUserTypeRepository.Add(data);
        //        _unitOfWork.Complete();

        //        data = _unitOfWork.MUserTypeRepository.Get(data.UserTypeId.Trim());

        //        MUserTypeViewModel.ReadUserType read = _unitOfWork.MUserTypeRepository.SelectOne(data.UserTypeId.Trim());

        //        return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.CREATE, read));
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
        //        return Ok(new StatusModel(ex));
        //    }
        //}

        //[HttpDelete]
        //public IActionResult Delete([FromBody] MUserTypeViewModel.DestroyUserType item)
        //{
        //    try
        //    {
        //        MUserType data = _unitOfWork.MUserTypeRepository.Get(item.UserTypeId.Trim());
        //        if (data != null)
        //        {
        //            _unitOfWork.MUserTypeRepository.Delete(data, Constants.DEFAULT_USER, Constants.GETDATE());
        //            _unitOfWork.Complete();

        //            return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.DELETE, null));
        //        }
        //        else
        //        {
        //            return Ok(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
        //        return Ok(new StatusModel(ex));
        //    }
        //}
    }
}
