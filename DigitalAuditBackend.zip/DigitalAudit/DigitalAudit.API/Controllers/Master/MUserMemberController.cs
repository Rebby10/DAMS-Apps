﻿using DigitalAudit.Helper;
using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using DigitalAudit.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace DigitalAudit.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("Master/User/Member")]
    public class MUserMemberController : ControllerBase
    {
        private readonly ILogger<MUserMemberController> _logger;
        private readonly IUnitOfWork _unitOfWork;
        private string _userId;
        public MUserMemberController(IUnitOfWork unitOfWork, ILogger<MUserMemberController> logger, IHttpContextAccessor httpContextAccessor)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
            _userId = httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
        }

        // GET: api/Master/UserMember
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var items = _unitOfWork.MUserMemberRepository.SelectAll();
                int totalData = items.Count();

                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, items.Count(), items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpGet]
        [Route("query")]
        public IActionResult Get(
            [FromQuery] MUserMemberViewModel.QueryUserMember param)
        {
            try
            {
                IEnumerable<MUserMemberViewModel.ReadUserMember> items = _unitOfWork.MUserMemberRepository.SelectAll();

                if (!string.IsNullOrEmpty(param.id))
                    items = items.Where(i => i.UserMemberId == param.id.Trim());

                if (!string.IsNullOrEmpty(param.user_group_id))
                    items = items.Where(i => i.UserGroup.UserGroupId.ToLower().Contains(param.user_group_id.Trim().ToLower()));

                int totalData = items.Count();

                if (!string.IsNullOrEmpty(param.sort_by))
                {
                    var orderByExpression = Helpers.GetOrderByExpression<MUserMemberViewModel.ReadUserMember>(param.sort_by);
                    items = Helpers.OrderByDir<MUserMemberViewModel.ReadUserMember>(items, param.order_by, orderByExpression).AsEnumerable();
                }

                if (param.page_size != null && param.page_number != null)
                {
                    items = Helpers.Page<MUserMemberViewModel.ReadUserMember>(items, param.page_size.Value, param.page_number.Value);
                }

                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, totalData, items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpGet("{id}")]
        public IActionResult Get(string id)
        {
            try
            {
                var userMember = _unitOfWork.MUserMemberRepository.SelectOne(id.Trim());

                if (userMember != null)
                {
                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.READ, userMember));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpPut]
        public IActionResult Put([FromBody] MUserMemberViewModel.UpdateUserMember item)
        {
            try
            {
                Helpers.Validate(item);
                MUserMember data = _unitOfWork.MUserMemberRepository.Get(item.UserMemberId.Trim());

                if (data != null)
                {
                    data.UserGroupId = item.UserGroupId.Trim();
                    data.UserId = item.UserId.Trim();
                    data.Username = item.Username.Trim();

                    if (_unitOfWork.MUserMemberRepository.anyUpdate(data))
                    {
                        throw new Exception("Data already exists");
                    }

                    MUserGroup ug = _unitOfWork.MUserGroupRepository.GetAll().Where(i => i.UserGroupId == item.UserGroupId && i.IsDeleted == false).FirstOrDefault();
                    if (ug.UserId == item.UserId)
                    {
                        throw new Exception("Lead user tidak boleh sama dengan member");
                    }

                    _unitOfWork.MUserMemberRepository.Update(data, _userId, Constants.GETDATE());
                    _unitOfWork.Complete();

                    MUserMemberViewModel.ReadUserMember read = _unitOfWork.MUserMemberRepository.SelectOne(data.UserMemberId.Trim());

                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.UPDATE, read));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpPost]
        public IActionResult Post([FromBody] MUserMemberViewModel.CreateUserMember item)
        {
            try
            {
                Helpers.Validate(item);
                MUserMember data = new MUserMember(Constants.GETID(), item.UserGroupId, item.UserId, item.Username, false, _userId, Constants.GETDATE(), null, null);
                if (_unitOfWork.MUserMemberRepository.anyInsert(data))
                {
                    throw new Exception("Data already exists");
                }

                MUserGroup ug = _unitOfWork.MUserGroupRepository.GetAll().Where(i => i.UserGroupId == item.UserGroupId && i.IsDeleted == false).FirstOrDefault();
                if(ug.UserId == item.UserId)
                {
                    throw new Exception("Lead user tidak boleh sama dengan member");
                }

                _unitOfWork.MUserMemberRepository.Add(data);
                _unitOfWork.Complete();

                data = _unitOfWork.MUserMemberRepository.Get(data.UserMemberId.Trim());

                MUserMemberViewModel.ReadUserMember read = _unitOfWork.MUserMemberRepository.SelectOne(data.UserMemberId.Trim());

                return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.CREATE, read));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(string id)
        {
            try
            {
                MUserMember data = _unitOfWork.MUserMemberRepository.Get(id.Trim());
                if (data != null)
                {
                    _unitOfWork.MUserMemberRepository.Delete(data, _userId, Constants.GETDATE());
                    _unitOfWork.Complete();

                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.DELETE, null));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }
    }
}
