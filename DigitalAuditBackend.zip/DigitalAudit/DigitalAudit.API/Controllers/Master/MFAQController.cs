﻿using DigitalAudit.Helper;
using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using DigitalAudit.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace DigitalAudit.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("Master/FAQ")]
    public class MFAQController : ControllerBase
    {
        private readonly ILogger<MFAQController> _logger;
        private readonly IUnitOfWork _unitOfWork;
        private string _userId;

        public MFAQController(IUnitOfWork unitOfWork, ILogger<MFAQController> logger, IHttpContextAccessor httpContextAccessor)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
            _userId = httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
        }

        // GET: api/Master/FAQ
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var items = _unitOfWork.MFAQRepository.SelectAll();
                int totalData = items.Count();

                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, items.Count(), items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpGet]
        [Route("query")]
        public IActionResult Get(
            [FromQuery] MFAQViewModel.QueryFAQ param)
        {
            try
            {
                IEnumerable<MFAQViewModel.ReadFAQ> items = _unitOfWork.MFAQRepository.SelectAll();

                if (!string.IsNullOrEmpty(param.id))
                    items = items.Where(i => i.FaqId == param.id.Trim());

                if (!string.IsNullOrEmpty(param.question))
                    items = items.Where(i => i.Question.ToLower().Contains(param.question.Trim().ToLower()));

                int totalData = items.Count();

                if (!string.IsNullOrEmpty(param.sort_by))
                {
                    var orderByExpression = Helpers.GetOrderByExpression<MFAQViewModel.ReadFAQ>(param.sort_by);
                    items = Helpers.OrderByDir<MFAQViewModel.ReadFAQ>(items, param.order_by, orderByExpression).AsEnumerable();
                }

                if (param.page_size != null && param.page_number != null)
                {
                    items = Helpers.Page<MFAQViewModel.ReadFAQ>(items, param.page_size.Value, param.page_number.Value);
                }

                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, totalData, items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, param);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpGet("{id}")]
        public IActionResult Get(string id)
        {
            try
            {
                var faq = _unitOfWork.MFAQRepository.SelectOne(id.Trim());

                if (faq != null)
                {
                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.READ, faq));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, id);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpPut]
        public IActionResult Put([FromBody] MFAQViewModel.UpdateFAQ item)
        {
            try
            {
                Helpers.Validate(item);
                MFAQ data = _unitOfWork.MFAQRepository.Get(item.FaqId.Trim());

                if (data != null)
                {
                    data.Question = item.Question.Trim();
                    data.Answer = item.Answer.Trim();

                    if (_unitOfWork.MFAQRepository.anyUpdate(data))
                    {
                        throw new Exception("Data already exists");
                    }

                    _unitOfWork.MFAQRepository.Update(data, _userId, Constants.GETDATE());
                    _unitOfWork.Complete();

                    MFAQViewModel.ReadFAQ read = _unitOfWork.MFAQRepository.SelectOne(data.FaqId.Trim());

                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.UPDATE, read));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, item));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, item);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpPost]
        public IActionResult Post([FromBody] MFAQViewModel.CreateFAQ item)
        {
            try
            {
                Helpers.Validate(item);
                MFAQ data = new MFAQ(
                    Constants.GETID(),
                    item.Question.Trim(),
                    item.Answer.Trim(),
                    false,
                    _userId,
                    Constants.GETDATE(),
                    null,
                    null);
                if (_unitOfWork.MFAQRepository.anyInsert(data))
                {
                    throw new Exception("Data already exists");
                }
                _unitOfWork.MFAQRepository.Add(data);
                _unitOfWork.Complete();

                data = _unitOfWork.MFAQRepository.Get(data.FaqId.Trim());

                MFAQViewModel.ReadFAQ read = _unitOfWork.MFAQRepository.SelectOne(data.FaqId.Trim());

                return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.CREATE, read));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, item);
                return Ok(new StatusModel(ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(string id)
        {
            try
            {
                var item = _unitOfWork.MFAQRepository.Get(id.Trim());
                if (item != null)
                {
                    _unitOfWork.MFAQRepository.Delete(item, _userId, Constants.GETDATE());
                    _unitOfWork.Complete();

                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.DELETE, null));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, id);
                return Ok(new StatusModel(ex));
            }
        }
    }
}
