﻿using DigitalAudit.API.Services;
using DigitalAudit.Helper;
using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using DigitalAudit.Model.ViewModel.Idaman;
using DigitalAudit.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace DigitalAudit.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("Master/UserSync")]
    public class MUserSyncController : ControllerBase
    {
        private readonly IIdamanService _idamanService;
        private readonly ILogger<MUserSyncController> _logger;
        private readonly IUnitOfWork _unitOfWork;
        private string _userId;
        public MUserSyncController(IUnitOfWork unitOfWork, ILogger<MUserSyncController> logger, IIdamanService idamanService, IHttpContextAccessor httpContextAccessor)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
            _idamanService = idamanService;
            _userId = httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
        }

        // GET: api/Master/User
        [HttpPost]
        [Route("Sync")]
        public async Task<IActionResult> SyncAsync()
        {
            try
            {
                BaseApiResultViewModel<UserIdamanAllViewModels> userIdaman = await _idamanService.GetAllUser(0, int.MaxValue);
                //int totalData = userIdaman.Data.Total;
                //userIdaman = await _idamanService.GetAllUser(1, totalData);
                List<UserIdamanViewModel> data = userIdaman.Data.Value.ToList();
                ////List<UserIdamanViewModel> data = new List<UserIdamanViewModel>();

                ////int PageSizeData = 1000;
                ////int pageCountData = (totalData + PageSizeData - 1) / PageSizeData;

                ////IEnumerable<int> pageRangeData = Enumerable.Range(1, pageCountData);

                ////foreach (int i in pageRangeData)
                ////{
                ////    int start = ((i * PageSizeData) - PageSizeData) + 1;
                ////    int end = i * PageSizeData;
                ////    userIdaman = await _idamanService.GetAllUser(start, end);
                ////    data.AddRange(userIdaman.Data.Value.ToList());
                ////}

                string SessionId = Constants.GETID();
                DateTime dateNow = Constants.GETDATE();

                List<MUserSyncUpload> dataUpload = data.Select(s => new MUserSyncUpload
                {
                    UserSyncUploadId = Constants.GETID(),
                    SessionId = SessionId,
                    UserId = s.UserId,
                    OrganizationId = s.Position.Organization.OrganizationId,
                    PositionId = s.Position.PositionId,
                    CompanyCode = s.Position.Organization.CompanyCode,
                    Kbo = s.Position.KBO,
                    IsActive = s.IsActive,
                    Birthday = s.Birthday,
                    City = s.City,
                    CompanyName = s.CompanyName,
                    Country = s.Country,
                    Department = s.Department,
                    DisplayName = s.DisplayName,
                    EmployeeId = s.EmployeeId,
                    LastName = s.LastName,
                    HireDate = s.HireDate,
                    JobTitle = s.JobTitle,
                    Email = s.Email,
                    MobilePhone = s.MobilePhone,
                    Website = s.Website,
                    AboutMe = s.AboutMe,
                    OfficeLocation = s.OfficeLocation,
                    PostalCode = s.PostalCode,
                    Username = s.Username,
                    FirstName = s.FirstName,
                    Address = s.Address,
                    UserType = s.UserType,
                    Photo = s.Photo,
                    ExtensionAttributes = null,
                    Idp = s.Idp,
                    DirectoryId = s.DirectoryId,
                    CreatedBy = s.CreatedBy,
                    Created = s.Created,
                    Updated = s.Updated,
                    EmployeeNumber = s.EmployeeNumber,
                    EmployeeType = s.EmployeeType,
                    Manager = s.Manager,
                    RoomNumber = s.RoomNumber,
                    State = s.State,
                    Division = s.Division,
                    CultureInfo = s.CultureInfo,
                    Language = s.Language,
                    DateFormat = s.DateFormat,
                    TimeFormat = s.TimeFormat,
                    IsCheif = null,
                    IsDeleted = false,
                    DateCreated = dateNow,
                    UserCreated = _userId,
                    DateModified = null,
                    UserModified = null
                }).ToList();

                //int PageSize = 300;
                //int pageCount = (dataUpload.Count + PageSize - 1) / PageSize;

                //IEnumerable<int> pageRange = Enumerable.Range(1, pageCount);

                //foreach(int i in pageRange)
                //{
                //    List<MUserSyncUpload> iterate = Helpers.Page<MUserSyncUpload>(dataUpload, PageSize, i).ToList();
                //    _unitOfWork.MUserSyncUploadRepository.AddLists(iterate);
                //    _unitOfWork.Complete();

                //    StatusViewModel sycnStatus = _unitOfWork.MUserSyncUploadRepository.SyncronizeUserSync_Syncronize(SessionId);
                //}
                _unitOfWork.MUserSyncUploadRepository.AddLists(dataUpload);
                _unitOfWork.Complete();

                StatusViewModel sycnStatus = _unitOfWork.MUserSyncUploadRepository.SyncronizeUserSync_Syncronize(SessionId);

                //////List<MUserSync> lstUser = _unitOfWork.MUserSyncRepository.GetAll().Where(i => i.IsDeleted == false && i.UserId == "4afefbfb-1d3c-40a2-babd-5f4756754b23").ToList();
                ////List<MUserSync> lstUser = _unitOfWork.MUserSyncRepository.GetAll().Where(i => i.IsDeleted == false).ToList();
                ////foreach(MUserSync ur in lstUser)
                ////{
                ////    var uw = await _idamanService.GetUserWhitelist(ur.UserId, 0, 25);
                ////    if(uw.Data.Value != null)
                ////    {
                ////        if (uw.Data.Value.Count > 0)
                ////        {
                ////            List<UserWhitelistIdamanViewModel> userWhiteList = uw.Data.Value;
                ////            List<MUserSyncWhitelist> listAllow = new List<MUserSyncWhitelist>();
                ////            List<MUserSyncWhitelist> listUserWhitelist = _unitOfWork.MUserSyncWhitelistRepository.SelectAll();

                ////            _unitOfWork.MUserSyncWhitelistRepository.DeleteUserSyncWhitelist();
                ////            _unitOfWork.Complete();

                ////            foreach (UserWhitelistIdamanViewModel d in userWhiteList)
                ////            {
                ////                if (d.role.Count() > 0)
                ////                {
                ////                    int role = d.role.Where(i => i.application.id == Constants.DigitalAuditApplicationId).Count();
                ////                    if (role > 0)
                ////                    {
                ////                        MUserSyncWhitelist wh = new MUserSyncWhitelist(Constants.GETID(), ur.UserId, Constants.DigitalAuditApplicationId, Constants.GETDATE());
                ////                        _unitOfWork.MUserSyncWhitelistRepository.Add(wh);
                ////                        _unitOfWork.Complete();
                ////                    }
                ////                }
                ////            }
                ////        }
                ////    }
                    

                    
                ////}

                return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.UPDATE, null));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, null);
                return Ok(new StatusModel(ex));
            }
        }

        [HttpGet]
        [Route("query")]
        public IActionResult Get(
           [FromQuery] MUserSyncViewModel.QueryUserSync param)
        {
            try
            {
                IEnumerable<MUserSyncViewModel.ReadUserSync> items = _unitOfWork.MUserSyncRepository.SelectAll();

                if (!string.IsNullOrEmpty(param.id))
                    items = items.Where(i => i.UserId == param.id.Trim());

                if (!string.IsNullOrEmpty(param.name))
                    items = items.Where(i => i.DisplayName.ToLower().Contains(param.name.Trim().ToLower()));

                int totalData = items.Count();

                if (!string.IsNullOrEmpty(param.sort_by))
                {
                    var orderByExpression = Helpers.GetOrderByExpression<MUserSyncViewModel.ReadUserSync>(param.sort_by);
                    items = Helpers.OrderByDir<MUserSyncViewModel.ReadUserSync>(items, param.order_by, orderByExpression).AsEnumerable();
                }

                if (param.page_size != null && param.page_number != null)
                {
                    items = Helpers.Page<MUserSyncViewModel.ReadUserSync>(items, param.page_size.Value, param.page_number.Value);
                }

                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, totalData, items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, param);
                return BadRequest(new StatusModel(ex));
            }
        }


    }
}
