﻿using DigitalAudit.Helper;
using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using DigitalAudit.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace DigitalAudit.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("Master/Template/Page")]
    public class MTemplatePageController : ControllerBase
    {
        private readonly ILogger<MTemplatePageController> _logger;
        private readonly IUnitOfWork _unitOfWork;
        private ClaimsPrincipal _principal;
        private string _userId;
        public MTemplatePageController(IUnitOfWork unitOfWork, ILogger<MTemplatePageController> logger, IHttpContextAccessor httpContextAccessor)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
            _userId = httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
        }

        // GET: api/Master/Template/Page
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var items = _unitOfWork.MTemplatePageRepository.SelectAll().OrderBy(o => o.TemplateId);
                int totalData = items.Count();
                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, items.Count(), items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpGet]
        [Route("query")]
        public IActionResult Get(
            [FromQuery] MTemplatePageViewModel.QueryTemplatePage param)
        {
            try
            {
                IEnumerable<MTemplatePageViewModel.ReadTemplatePage> items = _unitOfWork.MTemplatePageRepository.SelectAll();

                if (!string.IsNullOrEmpty(param.id))
                    items = items.Where(i => i.PageId == param.id.Trim());

                if (!string.IsNullOrEmpty(param.template_id))
                    items = items.Where(i => i.TemplateId == param.template_id.Trim());

                if (!string.IsNullOrEmpty(param.title))
                    items = items.Where(i => i.Title.ToLower().Contains(param.title.Trim().ToLower()));

                if (!string.IsNullOrEmpty(param.descriptions))
                    items = items.Where(i => i.Descriptions.ToLower().Contains(param.descriptions.Trim().ToLower()));

                int totalData = items.Count();


                if (!string.IsNullOrEmpty(param.sort_by))
                {
                    var orderByExpression = Helpers.GetOrderByExpression<MTemplatePageViewModel.ReadTemplatePage>(param.sort_by);
                    items = Helpers.OrderByDir<MTemplatePageViewModel.ReadTemplatePage>(items, param.order_by, orderByExpression).AsEnumerable();
                }
                else
                {
                    var orderByExpression = Helpers.GetOrderByExpression<MTemplatePageViewModel.ReadTemplatePage>("TemplateId");
                    items = Helpers.OrderByDir<MTemplatePageViewModel.ReadTemplatePage>(items, param.order_by, orderByExpression).AsEnumerable();
                }

                if (param.page_size != null && param.page_number != null)
                {
                    items = Helpers.Page<MTemplatePageViewModel.ReadTemplatePage>(items, param.page_size.Value, param.page_number.Value);
                }

                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, totalData, items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, param);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpGet("{id}")]
        public IActionResult Get(string id)
        {
            try
            {
                var data = _unitOfWork.MTemplatePageRepository.SelectOne(id.Trim());

                if (data != null)
                {
                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.READ, data));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, id);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpPut]
        public IActionResult Put([FromBody] MTemplatePageViewModel.UpdateTemplatePage item)
        {
            try
            {
                Helpers.Validate(item);
                MTemplatePage data = _unitOfWork.MTemplatePageRepository.Get(item.PageId.Trim());

                if (data != null)
                {
                    data.TemplateId = item.TemplateId;
                    data.Title = item.Title.Trim();
                    data.Descriptions = item.Descriptions.Trim();
                    data.SeqNo = item.SeqNo;

                    //if (_unitOfWork.MTemplatePageRepository.anyUpdate(data))
                    //{
                    //    throw new Exception("Data already exists");
                    //}

                    _unitOfWork.MTemplatePageRepository.Update(data, _userId, Constants.GETDATE());
                    _unitOfWork.Complete();

                    MTemplatePageViewModel.ReadTemplatePage read = _unitOfWork.MTemplatePageRepository.SelectOne(data.PageId.Trim());

                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.UPDATE, read));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, item));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, item);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpPost]
        public IActionResult Post([FromBody] MTemplatePageViewModel.CreateTemplatePage item)
        {
            try
            {
                Helpers.Validate(item);
                MTemplatePage data = new MTemplatePage(
                    Constants.GETID(),
                    item.TemplateId.Trim(),
                    item.Title,
                    item.Descriptions,
                    item.SeqNo,
                    false,
                    _userId,
                    Constants.GETDATE(),
                    null,
                    null);
                //if (_unitOfWork.MTemplatePageRepository.anyInsert(data))
                //{
                //    throw new Exception("Data already exists");
                //}
                _unitOfWork.MTemplatePageRepository.Add(data);
                _unitOfWork.Complete();

                data = _unitOfWork.MTemplatePageRepository.Get(data.PageId.Trim());

                MTemplatePageViewModel.ReadTemplatePage read = _unitOfWork.MTemplatePageRepository.SelectOne(data.PageId.Trim());

                return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.CREATE, read));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, item);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(string id)
        {
            try
            {
                MTemplatePage data = _unitOfWork.MTemplatePageRepository.Get(id.Trim());
                if (data != null)
                {
                    //if (_unitOfWork.MTemplatePageRepository.anyUpdate(data))
                    //{
                    //    throw new Exception("Data masih digunakan di transaksi");
                    //}

                    _unitOfWork.MTemplatePageRepository.Delete(data, _userId, Constants.GETDATE());
                    _unitOfWork.Complete();

                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.DELETE, null));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, id);
                return BadRequest(new StatusModel(ex));
            }
        }
    }
}
