﻿using AutoMapper;
using DigitalAudit.API.Services;
using DigitalAudit.Helper;
using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using DigitalAudit.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace DigitalAudit.API.Controllers.Transaction
{
    [Authorize]
    [ApiController]
    [Route("Issue")]
    public class TrIssueController : ControllerBase
    {
        private readonly ILogger<TrIssueController> _logger;
        private readonly IUnitOfWork _unitOfWork;
        private IHostingEnvironment _hostingEnvironment;
        private readonly IIdamanService _idamanService;
        private string _userId;
        private IMapper _mapper;

        public TrIssueController(IUnitOfWork unitOfWork, ILogger<TrIssueController> logger, 
            IHostingEnvironment hostingEnvironment, IIdamanService idamanService, IMapper mapper, IHttpContextAccessor httpContextAccessor)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
            _hostingEnvironment = hostingEnvironment;
            _idamanService = idamanService;
            _mapper = mapper;
            _userId = httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier) == null ? "" : httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
        }

        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var issues = _unitOfWork.TrIssueRepository.SelectAll(null, null, null, null, null, null, null, null, null, null, null, null);
                int totalData = issues.Count();
                if (issues.Count() > 0)
                {                   
                    var items = _mapper.Map<List<fn_Get_Issue>, List<TrIssueViewModel.ReadIssue>>(issues.ToList());
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, items.Count(), items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpGet]
        [Route("query")]
        public IActionResult Get([FromQuery] TrIssueViewModel.QueryIssue param)
        {
            try
            {
                #region  check user role
                var userRole = _unitOfWork.MUserRoleRepository.GetAll().FirstOrDefault(f => f.UserId == _userId);

                if (userRole != null)
                {
                    if (userRole.RoleId == Constants.ROLE.ADMIN_PUSAT)
                    {
                        _userId = null; // admin pusat bisa lihat semua data, tidak di filter berdasarkan userId
                    }
                    else if (userRole.RoleId == Constants.ROLE.ADMIN_REGION)
                    {
                        if (param.RegionId == null) // Jika param region gk diisi, ngikutin region user role
                        {
                            param.RegionId = userRole.RegionId;
                            _userId = null;
                        }
                    }
                    else if (userRole.RoleId == Constants.ROLE.ADMIN_LOKASI)
                    {
                        if (param.AuditLocationId == null) //Jika param lokasi audit tidak diisi, ngikutin lokasi user role
                        {
                            param.AuditLocationId = userRole.AuditLocationId;
                            _userId = null;
                        }
                    }
                }

                #endregion

                var items = _unitOfWork.TrIssueRepository
                    .SelectAll(param.IssueId, param.AuditLocationId, param.PriorityId, param.StatusId, _userId, 
                    param.AssignUser, param.StartDate, param.EndDate, param.AuditTypeId, param.Title, param.IsConnectedToAction, param.RegionId);
                

                if (!string.IsNullOrEmpty(param.Title))
                    items = items.Where(i => i.Title.ToLower().Contains(param.Title.Trim()));

                int totalData = items.Count();

                if (!string.IsNullOrEmpty(param.sort_by))
                {
                    var orderByExpression = Helpers.GetOrderByExpression<fn_Get_Issue>(ConvertSortParameter(param.sort_by));
                    items = Helpers.OrderByDir(items, param.order_by, orderByExpression).AsEnumerable();
                }

                if (param.page_size != null && param.page_number != null)
                {
                    items = Helpers.Page(items, param.page_size.Value, param.page_number.Value);
                }

                if (items.Count() > 0)
                {
                    var responseData = _mapper.Map<List<fn_Get_Issue>, List<TrIssueViewModel.ReadIssue>>(items.ToList());
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, responseData, totalData, responseData.Count() ));
                }
                else
                {
                    items = null;
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, items,  0,  0 ));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return Ok(new StatusModel(ex));
            }
        }

        [HttpGet]
        [Route("auditee")]
        public IActionResult GetAuditee([FromQuery] MUserSyncViewModel.QueryUserSync param)
        {
            try
            {
                var items = _unitOfWork.MUserRoleRepository.SelectAll(null, null, null, null)
                    .Select(x => new MUserSyncViewModel.ReadUserAuditee
                    {
                        Id = x.UserId,
                        DisplayName = x.DisplayName + " (" + x.Username + ")",
                        IsGroup = false
                    })
                    .Union(_unitOfWork.MUserGroupRepository
                    .GetAll()
                    .Where(w => w.IsDeleted == false)
                    .Select(x => new MUserSyncViewModel.ReadUserAuditee
                    {
                        Id = x.UserGroupId,
                        DisplayName = x.Name,
                        IsGroup = true
                    }));
                
                if (!string.IsNullOrEmpty(param.id))
                {
                    items = items.Where(x => x.Id.ToLower().Equals(param.id));
                }

                if (!string.IsNullOrEmpty(param.name))
                {
                    items = items.Where(x => x.DisplayName.ToLower().Contains(param.name.ToLower()));
                }

                if (!string.IsNullOrEmpty(param.sort_by))
                {
                    var orderByExpression = Helpers.GetOrderByExpression<MUserSyncViewModel.ReadUserAuditee>(ConvertSortParameter(param.sort_by));
                    items = Helpers.OrderByDir(items, param.order_by, orderByExpression).AsEnumerable();
                }
                else
                {
                    items = items.OrderBy(o => o.IsGroup).ThenBy(o => o.DisplayName);
                }

                if (param.page_size != null && param.page_number != null)
                {
                    items = Helpers.Page(items, param.page_size.Value, param.page_number.Value);
                }

                if (items.Count() > 0)
                {
                    //items = items.OrderBy(o => o.IsGroup).ThenBy(o => o.DisplayName);
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, items.Count(), items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return Ok(new StatusModel(ex));
            }
        }

        [HttpGet("{id}")]
        public IActionResult Get(string id)
        {
            try
            {
                var issues = _unitOfWork.TrIssueRepository.SelectAll(id, null, null, null, null, null, null, null, null, null, null, null);

                if (issues.Count() > 0)
                {
                    var responseData = _mapper.Map<fn_Get_Issue, TrIssueViewModel.ReadIssue>(issues.FirstOrDefault());
                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.READ, responseData));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return Ok(new StatusModel(ex));
            }
        }

        [HttpPost]
        public IActionResult Post([FromBody] TrIssueViewModel.CreateIssue item)
        {
            try
            {
                Helpers.Validate(item);

                //item.Creator = item.Creator == null ? "" : _unitOfWork.MUserSyncRepository.GetAll().FirstOrDefault(x => x.IsDeleted == false && x.UserId.Equals(item.Creator)).UserSyncId;

                TrIssue data = new TrIssue(Constants.GETID(), item.Title, item.Descriptions, null, null, null, item.AuditLocationId, null,
                    item.AssignGroup, item.AssignUser, item.Creator, item.PriorityId, item.TargetClosing, item.IssueCategoryId,
                    item.StatusId, null, false, _userId, Constants.GETDATE(), null, null);

                Validate(data, Constants.CRUD.CREATE);

                _unitOfWork.TrIssueRepository.Add(data);
                _unitOfWork.Complete();

                data = _unitOfWork.TrIssueRepository.Get(data.IssueId.Trim());

                var read = _unitOfWork.TrIssueRepository.SelectAll(data.IssueId.Trim(), null, null, null, null, null, null, null, null, null, null, null).ToList();

                // Create Log
                var user = _unitOfWork.MUserSyncRepository.GetAll().Where(x => x.UserId.Equals(_userId)).FirstOrDefault();

                string TextLog = "telah membuat issue ini";
                //CreateLog(data, Convert.ToInt32(Constants.LOG_TYPE.STATUS), TextLog, userIdaman.Data.DisplayName);
                CreateLog(data, Convert.ToInt32(Constants.LOG_TYPE.STATUS), TextLog, user == null? "" : user.DisplayName);

                var responseData = _mapper.Map<List<fn_Get_Issue>, List<TrIssueViewModel.ReadIssue>>(read.ToList());
                return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.CREATE, responseData));
                //return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.CREATE, read));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, item);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpPut]
        public IActionResult Put([FromBody] TrIssueViewModel.UpdateIssue item)
        {
            try
            {
                Helpers.Validate(item);
                
                TrIssue data = _unitOfWork.TrIssueRepository.Get(item.IssueId.Trim());

                if (data != null)
                {
                    string TextLog = "";
                    if (data.PriorityId != item.PriorityId)
                    {
                        var priorityOld = _unitOfWork.MPriorityRepository.SelectOne(data.PriorityId);
                        var priorityNew = _unitOfWork.MPriorityRepository.SelectOne(item.PriorityId);

                        TextLog += "memperbaharui priority dari '" + priorityOld.Name + "' menjadi '" + priorityNew.Name + "'";
                    }

                    if (data.IssueCategoryId != item.IssueCategoryId)
                    {
                        var categoryOld = _unitOfWork.MIssueCategoryRepository.SelectOne(data.IssueCategoryId);
                        var categoryNew = _unitOfWork.MIssueCategoryRepository.SelectOne(item.IssueCategoryId);

                        if (!string.IsNullOrEmpty(TextLog))
                        {
                            TextLog += ", memperbaharui kategori dari '" + categoryOld.Name + "' menjadi '" + categoryNew.Name + "'";
                        }
                        else
                        {
                            TextLog += "memperbaharui kategori dari '" + categoryOld.Name + "' menjadi '" + categoryNew.Name + "'";
                        }
                        
                    }

                    if (data.StatusId != item.StatusId)
                    {
                        var statusOld = _unitOfWork.MIssueStatusRepository.SelectOne(data.StatusId);
                        var statusNew = _unitOfWork.MIssueStatusRepository.SelectOne(item.StatusId);

                        if (!string.IsNullOrEmpty(TextLog))
                        {
                            TextLog += ", memperbaharui status dari '" + statusOld.Name + "' menjadi '" + statusNew.Name + "'";
                        }
                        else
                        {
                            TextLog += "memperbaharui status dari '" + statusOld.Name + "' menjadi '" + statusNew.Name + "'";
                        }                        
                    }


                    data.Title = item.Title;
                    data.Descriptions = item.Descriptions;
                    data.AuditLocationId = item.AuditLocationId;
                    data.AssignGroup = item.AssignGroup;
                    data.AssignUser = item.AssignUser;
                    data.Creator = item.Creator;
                    data.PriorityId = item.PriorityId;
                    data.TargetClosing = item.TargetClosing;
                    data.IssueCategoryId = item.IssueCategoryId;
                    data.StatusId = item.StatusId;

                    Validate(data, Constants.CRUD.UPDATE);
                    _unitOfWork.TrIssueRepository.Update(data, _userId, Constants.GETDATE());
                    _unitOfWork.Complete();

                    var read = _unitOfWork.TrIssueRepository.SelectAll(data.IssueId.Trim(), null, null, null, null, null, null, null, null, null, null, null).ToList();

                    // Create Log
                    var user = _unitOfWork.MUserSyncRepository.GetAll().Where(x => x.UserId.Equals(_userId)).FirstOrDefault();

                    CreateLog(data, Convert.ToInt32(Constants.LOG_TYPE.STATUS), TextLog, user == null ? "" :  user.DisplayName);

                    var responseData = _mapper.Map<List<fn_Get_Issue>, List<TrIssueViewModel.ReadIssue>>(read.ToList());
                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.UPDATE, responseData));
                    //return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.UPDATE, read));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(string id)
        {
            try
            {
                TrIssue data = _unitOfWork.TrIssueRepository.Get(id.Trim());
                if (data != null)
                {
                    _unitOfWork.TrIssueRepository.Delete(data, _userId, Constants.GETDATE());
                    _unitOfWork.Complete();

                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.DELETE, null));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpPost]
        [Route("delete")]
        public IActionResult MultipleDelete([FromBody] TrIssueViewModel.MultipleDeleteIssue item)
        {
            try
            {
                DeleteValidation(item);

                foreach (var id in item.IssueId)
                {
                    TrIssue data = _unitOfWork.TrIssueRepository.Get(id);

                    if (data != null)
                    {
                        _unitOfWork.TrIssueRepository.Delete(data, _userId, Constants.GETDATE());
                        _unitOfWork.Complete();
                    }
                    else
                    {
                        return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                    }
                }

                return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.DELETE, null));

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        private void DeleteValidation(TrIssueViewModel.MultipleDeleteIssue item)
        {

            var userRole = _unitOfWork.MUserRoleRepository.SelectAll(null, null, null, _userId).FirstOrDefault();

            if (!userRole.RoleId.Equals(Constants.ROLE.ADMIN_PUSAT))
            {
                foreach (var id in item.IssueId)
                {
                    TrIssue data = _unitOfWork.TrIssueRepository.Get(id);

                    if (data != null)
                    {
                        if (!data.UserCreated.Equals(_userId))
                        {
                            throw new Exception("Tidak diizinkan menghapus issue " + data.Title);
                        }

                    }
                }
            }            
        }

        //[AllowAnonymous]
        [Route("DownloadError/{id}")]
        [HttpGet]
        public async Task<IActionResult> DownloadError(string id)
        {
            string sFileName = Guid.NewGuid().ToString() + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".xlsx";

            string sWebRootFolder = _hostingEnvironment.ContentRootPath;

            string configPath = Configs.AppConfig.UploadPath.DownloadErrorIssue;
            string path = sWebRootFolder + configPath;

            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }

            var memory = new MemoryStream();
            using (var fs = new FileStream(Path.Combine(path, sFileName), FileMode.Create, FileAccess.Write))
            {
                IWorkbook workbook;
                workbook = new XSSFWorkbook();
                ISheet excelSheet = workbook.CreateSheet("Issue");
                IRow row = excelSheet.CreateRow(0);

                string[] header = { "Title", "Description", "Question Id", "Question Code", "Question"
                        , "Audit Location", "Region", "Lat Long", "Group Name", "Group Leader"
                        , "Assign User", "Creator", "Priority", "Audit Type", "Target Closing", "Issue Category", "Issue Status", "Error Message"  };

                int idx_header = 0;
                foreach(string i in header.ToList())
                {
                    row.CreateCell(idx_header).SetCellValue(i);
                    idx_header = idx_header + 1;
                }

                var items = _unitOfWork.TrIssueImportRepository.GetIssueImport(id);

                int idx_data = 0;
                foreach(var d in items)
                {
                    idx_data = idx_data + 1;
                    row = excelSheet.CreateRow(idx_data);
                    row.CreateCell(0).SetCellValue(d.Title);
                    row.CreateCell(1).SetCellValue(d.Descriptions);
                    row.CreateCell(2).SetCellValue(d.QuestionId);
                    row.CreateCell(3).SetCellValue(d.Code);
                    row.CreateCell(4).SetCellValue(d.Question);
                    row.CreateCell(5).SetCellValue(d.LocationName);
                    row.CreateCell(6).SetCellValue(d.Region);
                    row.CreateCell(7).SetCellValue(d.LatLong);
                    row.CreateCell(8).SetCellValue(d.UserGroupName);
                    row.CreateCell(9).SetCellValue(d.GroupLeader);
                    row.CreateCell(10).SetCellValue(d.AssignUser);
                    row.CreateCell(11).SetCellValue(d.Creator);
                    row.CreateCell(12).SetCellValue(d.Priority);
                    row.CreateCell(13).SetCellValue(d.AuditType);
                    row.CreateCell(14).SetCellValue(d.TargetClosing.ToString("g"));
                    row.CreateCell(15).SetCellValue(d.IssueCategory);
                    row.CreateCell(16).SetCellValue(d.IssueStatus);
                    row.CreateCell(17).SetCellValue(d.ErrorMessage);
                }

                workbook.Write(fs);
            }
            using (var stream = new FileStream(Path.Combine(path, sFileName), FileMode.Open))
            {
                await stream.CopyToAsync(memory);
            }
            memory.Position = 0;
            return File(memory, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", sFileName);
        }


        //[AllowAnonymous]
        [HttpGet]
        [Route("Template")]
        public async Task<ActionResult> GenerateTemplateAsync()
        {
            XSSFWorkbook wb;
            XSSFSheet sh;
            XSSFSheet shAuditLocation;
            XSSFSheet shUserGroup;
            XSSFSheet shPriority;
            XSSFSheet shAuditType;
            XSSFSheet shIssueCategory;
            XSSFSheet shIssueStatus;

            string filename = Guid.NewGuid() + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".xlsx";

            string sWebRootFolder = _hostingEnvironment.ContentRootPath;

            string configTemplate = Configs.AppConfig.UploadPath.TemplateIssue;
            string pathTemplate = sWebRootFolder + configTemplate;

            if (!Directory.Exists(pathTemplate))
            {
                Directory.CreateDirectory(pathTemplate);
            }

            string URL = string.Format("{0}://{1}/{2}", Request.Scheme, Request.Host, filename);
            FileInfo file = new FileInfo(Path.Combine(pathTemplate, filename));
            var memory = new MemoryStream();
            using (var fs = new FileStream(Path.Combine(pathTemplate, filename), FileMode.Create, FileAccess.Write))
            {
                wb = new XSSFWorkbook();

                #region STYLING HEADER
                IFont boldFont = wb.CreateFont();
                boldFont.Boldweight = (short)FontBoldWeight.Bold;
                ICellStyle HeaderStyle = wb.CreateCellStyle();
                HeaderStyle.SetFont(boldFont);

                HeaderStyle.BorderBottom = BorderStyle.Thin;
                HeaderStyle.BorderTop = BorderStyle.Thin;
                HeaderStyle.BorderLeft = BorderStyle.Thin;
                HeaderStyle.BorderRight = BorderStyle.Thin;

                HeaderStyle.FillForegroundColor = NPOI.HSSF.Util.HSSFColor.LightOrange.Index;
                HeaderStyle.FillPattern = FillPattern.SolidForeground;
                #endregion

                #region STYLING BODY
                IFont NormalFont = wb.CreateFont();
                ICellStyle BodyStyle = wb.CreateCellStyle();
                BodyStyle.SetFont(NormalFont);

                BodyStyle.BorderBottom = BorderStyle.Thin;
                BodyStyle.BorderTop = BorderStyle.Thin;
                BodyStyle.BorderLeft = BorderStyle.Thin;
                BodyStyle.BorderRight = BorderStyle.Thin;
                #endregion

                #region CREATE SHEET TEMPLATE
                sh = (XSSFSheet)wb.CreateSheet("Sheet1");

                int i = 0;

                if (sh.GetRow(i) == null)
                    sh.CreateRow(i);

                if (sh.GetRow(i).GetCell(0) == null)
                {
                    sh.GetRow(i).CreateCell(0).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(0).SetCellValue("Title");
                }

                if (sh.GetRow(i).GetCell(1) == null)
                {
                    sh.GetRow(i).CreateCell(1).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(1).SetCellValue("Description");
                }

                if (sh.GetRow(i).GetCell(2) == null)
                {
                    sh.GetRow(i).CreateCell(2).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(2).SetCellValue("Question Id");
                }

                if (sh.GetRow(i).GetCell(3) == null)
                {
                    sh.GetRow(i).CreateCell(3).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(3).SetCellValue("Question Code");
                }

                if (sh.GetRow(i).GetCell(4) == null)
                {
                    sh.GetRow(i).CreateCell(4).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(4).SetCellValue("Question");
                }

                if (sh.GetRow(i).GetCell(5) == null)
                {
                    sh.GetRow(i).CreateCell(5).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(5).SetCellValue("Audit Location Id");
                }

                //if (sh.GetRow(i).GetCell(6) == null)
                //{
                //    sh.GetRow(i).CreateCell(6).CellStyle = HeaderStyle;
                //    sh.GetRow(i).GetCell(6).SetCellValue("Location Name");
                //}

                //if (sh.GetRow(i).GetCell(7) == null)
                //{
                //    sh.GetRow(i).CreateCell(7).CellStyle = HeaderStyle;
                //    sh.GetRow(i).GetCell(7).SetCellValue("Region");
                //}

                if (sh.GetRow(i).GetCell(6) == null)
                {
                    sh.GetRow(i).CreateCell(6).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(6).SetCellValue("Assign Group");
                }

                //if (sh.GetRow(i).GetCell(9) == null)
                //{
                //    sh.GetRow(i).CreateCell(9).CellStyle = HeaderStyle;
                //    sh.GetRow(i).GetCell(9).SetCellValue("Group Name");
                //}

                //if (sh.GetRow(i).GetCell(10) == null)
                //{
                //    sh.GetRow(i).CreateCell(10).CellStyle = HeaderStyle;
                //    sh.GetRow(i).GetCell(10).SetCellValue("Group Leader");
                //}


                if (sh.GetRow(i).GetCell(7) == null)
                {
                    sh.GetRow(i).CreateCell(7).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(7).SetCellValue("Assign User");
                }

                if (sh.GetRow(i).GetCell(8) == null)
                {
                    sh.GetRow(i).CreateCell(8).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(8).SetCellValue("Creator");
                }

                if (sh.GetRow(i).GetCell(9) == null)
                {
                    sh.GetRow(i).CreateCell(9).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(9).SetCellValue("Priority Id");
                }

                //if (sh.GetRow(i).GetCell(14) == null)
                //{
                //    sh.GetRow(i).CreateCell(14).CellStyle = HeaderStyle;
                //    sh.GetRow(i).GetCell(14).SetCellValue("Priority");
                //}

                if (sh.GetRow(i).GetCell(10) == null)
                {
                    sh.GetRow(i).CreateCell(10).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(10).SetCellValue("Target Closing");
                }

                if (sh.GetRow(i).GetCell(11) == null)
                {
                    sh.GetRow(i).CreateCell(11).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(11).SetCellValue("Issue Category Id");
                }

                //if (sh.GetRow(i).GetCell(17) == null)
                //{
                //    sh.GetRow(i).CreateCell(17).CellStyle = HeaderStyle;
                //    sh.GetRow(i).GetCell(17).SetCellValue("Issue Category");
                //}

                if (sh.GetRow(i).GetCell(12) == null)
                {
                    sh.GetRow(i).CreateCell(12).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(12).SetCellValue("Issue Status Id");
                }

                if (sh.GetRow(i).GetCell(13) == null)
                {
                    sh.GetRow(i).CreateCell(13).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(13).SetCellValue("Audit Type Id");
                }

                //if (sh.GetRow(i).GetCell(19) == null)
                //{
                //    sh.GetRow(i).CreateCell(19).CellStyle = HeaderStyle;
                //    sh.GetRow(i).GetCell(19).SetCellValue("Issue Status");
                //}
                #endregion

                #region CREATE SHEET MASTER AUDIT LOCATION
                shAuditLocation = (XSSFSheet)wb.CreateSheet("Audit Location");

                i = 0;

                #region HEADER
                if (shAuditLocation.GetRow(i) == null)
                    shAuditLocation.CreateRow(i);

                if (shAuditLocation.GetRow(i).GetCell(0) == null)
                {
                    shAuditLocation.GetRow(i).CreateCell(0).CellStyle = HeaderStyle;
                    shAuditLocation.GetRow(i).GetCell(0).SetCellValue("Audit Location ID");
                }

                if (shAuditLocation.GetRow(i).GetCell(1) == null)
                {
                    shAuditLocation.GetRow(i).CreateCell(1).CellStyle = HeaderStyle;
                    shAuditLocation.GetRow(i).GetCell(1).SetCellValue("Location Name");
                }

                //if (shAuditLocation.GetRow(i).GetCell(2) == null)
                //{
                //    shAuditLocation.GetRow(i).CreateCell(2).CellStyle = HeaderStyle;
                //    shAuditLocation.GetRow(i).GetCell(2).SetCellValue("Address");
                //}

                //if (shAuditLocation.GetRow(i).GetCell(3) == null)
                //{
                //    shAuditLocation.GetRow(i).CreateCell(3).CellStyle = HeaderStyle;
                //    shAuditLocation.GetRow(i).GetCell(3).SetCellValue("Zip Code");
                //}

                if (shAuditLocation.GetRow(i).GetCell(2) == null)
                {
                    shAuditLocation.GetRow(i).CreateCell(2).CellStyle = HeaderStyle;
                    shAuditLocation.GetRow(i).GetCell(2).SetCellValue("Region");
                }
                #endregion

                #region BODY
                List<fn_Get_MAuditLocation> ListAuditLocation = _unitOfWork.MAuditLocationRepository.Get_MAuditLocation(null, null, null);

                i += 1;

                foreach (fn_Get_MAuditLocation AuditLocation in ListAuditLocation.OrderBy(O => O.AuditLocationId))
                {
                    if (shAuditLocation.GetRow(i) == null)
                        shAuditLocation.CreateRow(i);

                    if (shAuditLocation.GetRow(i).GetCell(0) == null)
                    {
                        shAuditLocation.GetRow(i).CreateCell(0).CellStyle = BodyStyle;
                        shAuditLocation.GetRow(i).GetCell(0).SetCellValue(AuditLocation.ID);
                    }

                    if (shAuditLocation.GetRow(i).GetCell(1) == null)
                    {
                        shAuditLocation.GetRow(i).CreateCell(1).CellStyle = BodyStyle;
                        shAuditLocation.GetRow(i).GetCell(1).SetCellValue(AuditLocation.Name);
                    }

                    if (shAuditLocation.GetRow(i).GetCell(2) == null)
                    {
                        shAuditLocation.GetRow(i).CreateCell(2).CellStyle = BodyStyle;
                        shAuditLocation.GetRow(i).GetCell(2).SetCellValue(AuditLocation.RegionName);
                    }

                    //if (shAuditLocation.GetRow(i).GetCell(3) == null)
                    //{
                    //    shAuditLocation.GetRow(i).CreateCell(3).CellStyle = BodyStyle;
                    //    shAuditLocation.GetRow(i).GetCell(3).SetCellValue(AuditLocation.ZipCode);
                    //}

                    //if (shAuditLocation.GetRow(i).GetCell(4) == null)
                    //{
                    //    shAuditLocation.GetRow(i).CreateCell(4).CellStyle = BodyStyle;
                    //    shAuditLocation.GetRow(i).GetCell(4).SetCellValue(AuditLocation.RegionName);
                    //}

                    i += 1;
                }
                #endregion

                #endregion

                #region CREATE SHEET MASTER USER GROUP
                shUserGroup = (XSSFSheet)wb.CreateSheet("User Group");

                i = 0;

                #region HEADER
                if (shUserGroup.GetRow(i) == null)
                    shUserGroup.CreateRow(i);

                if (shUserGroup.GetRow(i).GetCell(0) == null)
                {
                    shUserGroup.GetRow(i).CreateCell(0).CellStyle = HeaderStyle;
                    shUserGroup.GetRow(i).GetCell(0).SetCellValue("User Group ID");
                }

                if (shUserGroup.GetRow(i).GetCell(1) == null)
                {
                    shUserGroup.GetRow(i).CreateCell(1).CellStyle = HeaderStyle;
                    shUserGroup.GetRow(i).GetCell(1).SetCellValue("Group Name");
                }

                if (shUserGroup.GetRow(i).GetCell(2) == null)
                {
                    shUserGroup.GetRow(i).CreateCell(2).CellStyle = HeaderStyle;
                    shUserGroup.GetRow(i).GetCell(2).SetCellValue("Group Leader");
                }

                if (shUserGroup.GetRow(i).GetCell(3) == null)
                {
                    shUserGroup.GetRow(i).CreateCell(3).CellStyle = HeaderStyle;
                    shUserGroup.GetRow(i).GetCell(3).SetCellValue("User Type");
                }
                #endregion

                #region BODY
                i += 1;
                List<fn_Get_MUserGroup> ListUserGroup = _unitOfWork.MUserGroupRepository.Get_MUserGroup(null, null);

                foreach (fn_Get_MUserGroup item in ListUserGroup)
                {
                    if (shUserGroup.GetRow(i) == null)
                        shUserGroup.CreateRow(i);

                    if (shUserGroup.GetRow(i).GetCell(0) == null)
                    {
                        shUserGroup.GetRow(i).CreateCell(0).CellStyle = BodyStyle;
                        shUserGroup.GetRow(i).GetCell(0).SetCellValue(item.ID);
                    }

                    if (shUserGroup.GetRow(i).GetCell(1) == null)
                    {
                        shUserGroup.GetRow(i).CreateCell(1).CellStyle = BodyStyle;
                        shUserGroup.GetRow(i).GetCell(1).SetCellValue(item.Name);
                    }

                    if (shUserGroup.GetRow(i).GetCell(2) == null)
                    {
                        shUserGroup.GetRow(i).CreateCell(2).CellStyle = BodyStyle;
                        shUserGroup.GetRow(i).GetCell(2).SetCellValue(item.UserId);
                    }

                    if (shUserGroup.GetRow(i).GetCell(3) == null)
                    {
                        shUserGroup.GetRow(i).CreateCell(3).CellStyle = BodyStyle;
                        shUserGroup.GetRow(i).GetCell(3).SetCellValue(item.UserType);
                    }

                    i += 1;
                }


                #endregion

                #endregion

                #region CREATE SHEET MASTER PRIORITY
                shPriority = (XSSFSheet)wb.CreateSheet("Priority");

                i = 0;

                #region HEADER
                if (shPriority.GetRow(i) == null)
                    shPriority.CreateRow(i);

                if (shPriority.GetRow(i).GetCell(0) == null)
                {
                    shPriority.GetRow(i).CreateCell(0).CellStyle = HeaderStyle;
                    shPriority.GetRow(i).GetCell(0).SetCellValue("Priority ID");
                }

                if (shPriority.GetRow(i).GetCell(1) == null)
                {
                    shPriority.GetRow(i).CreateCell(1).CellStyle = HeaderStyle;
                    shPriority.GetRow(i).GetCell(1).SetCellValue("Name");
                }

                #endregion

                #region BODY
                i += 1;
                List<MPriority> ListPriority = _unitOfWork.MPriorityRepository.GetAllPriority();

                foreach (MPriority item in ListPriority)
                {
                    if (shPriority.GetRow(i) == null)
                        shPriority.CreateRow(i);

                    if (shPriority.GetRow(i).GetCell(0) == null)
                    {
                        shPriority.GetRow(i).CreateCell(0).CellStyle = BodyStyle;
                        shPriority.GetRow(i).GetCell(0).SetCellValue(item.PriorityId);
                    }

                    if (shPriority.GetRow(i).GetCell(1) == null)
                    {
                        shPriority.GetRow(i).CreateCell(1).CellStyle = BodyStyle;
                        shPriority.GetRow(i).GetCell(1).SetCellValue(item.Name);
                    }


                    i += 1;
                }


                #endregion

                #endregion



                #region CREATE SHEET MASTER AUDIT TYPE
                shAuditType = (XSSFSheet)wb.CreateSheet("Audit Type");

                i = 0;

                #region HEADER
                if (shAuditType.GetRow(i) == null)
                    shAuditType.CreateRow(i);

                if (shAuditType.GetRow(i).GetCell(0) == null)
                {
                    shAuditType.GetRow(i).CreateCell(0).CellStyle = HeaderStyle;
                    shAuditType.GetRow(i).GetCell(0).SetCellValue("Audit Type ID");
                }

                if (shAuditType.GetRow(i).GetCell(1) == null)
                {
                    shAuditType.GetRow(i).CreateCell(1).CellStyle = HeaderStyle;
                    shAuditType.GetRow(i).GetCell(1).SetCellValue("Name");
                }

                #endregion

                #region BODY
                i += 1;
                List<MAuditType> ListAuditType = _unitOfWork.MAuditTypeRepository.GetAll().ToList();

                foreach (MAuditType item in ListAuditType)
                {
                    if (shAuditType.GetRow(i) == null)
                        shAuditType.CreateRow(i);

                    if (shAuditType.GetRow(i).GetCell(0) == null)
                    {
                        shAuditType.GetRow(i).CreateCell(0).CellStyle = BodyStyle;
                        shAuditType.GetRow(i).GetCell(0).SetCellValue(item.ID);
                    }

                    if (shAuditType.GetRow(i).GetCell(1) == null)
                    {
                        shAuditType.GetRow(i).CreateCell(1).CellStyle = BodyStyle;
                        shAuditType.GetRow(i).GetCell(1).SetCellValue(item.Name);
                    }


                    i += 1;
                }


                #endregion

                #endregion


                #region CREATE SHEET MASTER ISSUE CATEGORY
                shIssueCategory = (XSSFSheet)wb.CreateSheet("Issue Category");

                i = 0;

                #region HEADER
                if (shIssueCategory.GetRow(i) == null)
                    shIssueCategory.CreateRow(i);

                if (shIssueCategory.GetRow(i).GetCell(0) == null)
                {
                    shIssueCategory.GetRow(i).CreateCell(0).CellStyle = HeaderStyle;
                    shIssueCategory.GetRow(i).GetCell(0).SetCellValue("Issue Category ID");
                }

                if (shIssueCategory.GetRow(i).GetCell(1) == null)
                {
                    shIssueCategory.GetRow(i).CreateCell(1).CellStyle = HeaderStyle;
                    shIssueCategory.GetRow(i).GetCell(1).SetCellValue("Name");
                }

                #endregion

                #region BODY
                i += 1;
                List<MIssueCategory> ListIssueCategory = _unitOfWork.MIssueCategoryRepository.GetAll().ToList();

                foreach (MIssueCategory item in ListIssueCategory)
                {
                    if (shIssueCategory.GetRow(i) == null)
                        shIssueCategory.CreateRow(i);

                    if (shIssueCategory.GetRow(i).GetCell(0) == null)
                    {
                        shIssueCategory.GetRow(i).CreateCell(0).CellStyle = BodyStyle;
                        shIssueCategory.GetRow(i).GetCell(0).SetCellValue(item.IssueCategoryId);
                    }

                    if (shIssueCategory.GetRow(i).GetCell(1) == null)
                    {
                        shIssueCategory.GetRow(i).CreateCell(1).CellStyle = BodyStyle;
                        shIssueCategory.GetRow(i).GetCell(1).SetCellValue(item.Name);
                    }


                    i += 1;
                }


                #endregion

                #endregion



                #region CREATE SHEET MASTER ISSUE STATUS
                shIssueStatus = (XSSFSheet)wb.CreateSheet("Issue Status");

                i = 0;

                #region HEADER
                if (shIssueStatus.GetRow(i) == null)
                    shIssueStatus.CreateRow(i);

                if (shIssueStatus.GetRow(i).GetCell(0) == null)
                {
                    shIssueStatus.GetRow(i).CreateCell(0).CellStyle = HeaderStyle;
                    shIssueStatus.GetRow(i).GetCell(0).SetCellValue("Issue Status ID");
                }

                if (shIssueStatus.GetRow(i).GetCell(1) == null)
                {
                    shIssueStatus.GetRow(i).CreateCell(1).CellStyle = HeaderStyle;
                    shIssueStatus.GetRow(i).GetCell(1).SetCellValue("Name");
                }

                #endregion

                #region BODY
                i += 1;
                List<MIssueStatus> ListIssueStatus = _unitOfWork.MIssueStatusRepository.GetAll().ToList();

                foreach (MIssueStatus item in ListIssueStatus)
                {
                    if (shIssueStatus.GetRow(i) == null)
                        shIssueStatus.CreateRow(i);

                    if (shIssueStatus.GetRow(i).GetCell(0) == null)
                    {
                        shIssueStatus.GetRow(i).CreateCell(0).CellStyle = BodyStyle;
                        shIssueStatus.GetRow(i).GetCell(0).SetCellValue(item.StatusId);
                    }

                    if (shIssueStatus.GetRow(i).GetCell(1) == null)
                    {
                        shIssueStatus.GetRow(i).CreateCell(1).CellStyle = BodyStyle;
                        shIssueStatus.GetRow(i).GetCell(1).SetCellValue(item.Name);
                    }


                    i += 1;
                }


                #endregion

                #endregion

                wb.Write(fs);
            }

            using (var stream = new FileStream(Path.Combine(pathTemplate, filename), FileMode.Open))
            {
                await stream.CopyToAsync(memory);
            }
            memory.Position = 0;
            return File(memory, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", filename);
        }

        [AllowAnonymous]
        [HttpPost]
        [Route("Import")]
        public ActionResult Import([FromForm] TrIssueViewModel.ImportIssue param)
        {
            try
            {
                string baseURL = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}";
                StatusViewModel statusUpload = new StatusViewModel();
                string sessionId = Constants.GETID();
                IFormFile file = param.File;
                string webRootPath = _hostingEnvironment.ContentRootPath;
                string configTemplate = Configs.AppConfig.UploadPath.ImportIssue;
                string pathTemplate = webRootPath + configTemplate;
                StringBuilder sb = new StringBuilder();
                if (!Directory.Exists(pathTemplate))
                {
                    Directory.CreateDirectory(pathTemplate);
                }

                string fileName = "Import_" + Constants.GETID() + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".xlsx";

                _unitOfWork.TrIssueImportSessionRepository.Add(new TrIssueImportSession(sessionId, Constants.GETDATE(), fileName, false, false, Constants.DEFAULT_USER, Constants.GETDATE(), null, null));
                _unitOfWork.Complete();

                if (file.Length > 0)
                {
                    string sFileExtension = Path.GetExtension(file.FileName).ToLower();
                    ISheet sheet;
                    string fullPath = Path.Combine(pathTemplate, fileName);
                    using (var stream = new FileStream(fullPath, FileMode.Create))
                    {
                        file.CopyTo(stream);
                        stream.Position = 0;
                        if (sFileExtension == ".xls")
                        {
                            HSSFWorkbook hssfwb = new HSSFWorkbook(stream); //This will read the Excel 97-2000 formats  
                            sheet = hssfwb.GetSheetAt(0); //get first sheet from workbook  
                        }
                        else if(sFileExtension == ".xlsx")
                        {
                            XSSFWorkbook hssfwb = new XSSFWorkbook(stream); //This will read 2007 Excel format  
                            sheet = hssfwb.GetSheetAt(0); //get first sheet from workbook   
                        }
                        else
                        {
                            throw new Exception("Hanya boleh upload .xls atau .xlsx");
                        }

                        IRow headerRow = sheet.GetRow(0); //Get Header Row
                        int cellCount = headerRow.LastCellNum;

                        int countIsColumnNotValid = 0;
                        List<TrIssueImport> trIssues = new List<TrIssueImport>();
                        for (int i = (sheet.FirstRowNum + 1); i <= sheet.LastRowNum; i++) //Read Excel File
                        {
                            IRow row = sheet.GetRow(i);
                            if (row == null) continue;
                            if (row.Cells.All(d => d.CellType == CellType.Blank)) continue;

                            //if(row.Cells.Count() < 20)
                            //{
                            //    countIsColumnNotValid = countIsColumnNotValid + 1;
                            //}

                        }

                        if(countIsColumnNotValid == 0)
                        {
                            for (int i = (sheet.FirstRowNum + 1); i <= sheet.LastRowNum; i++) //Read Excel File
                            {
                                IRow row = sheet.GetRow(i);
                                if (row == null) continue;
                                if (row.Cells.All(d => d.CellType == CellType.Blank)) continue;

                                var issue = new TrIssueImport
                                {
                                    IssueImportId = Constants.GETID(),
                                    SessionId = sessionId,
                                    Title = row.GetCell(0, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? "" : row.GetCell(0, MissingCellPolicy.RETURN_NULL_AND_BLANK).ToString(),
                                    Descriptions = row.GetCell(1, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? "" : row.GetCell(1, MissingCellPolicy.RETURN_NULL_AND_BLANK).ToString(),
                                    QuestionId = row.GetCell(2, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? null : row.GetCell(2, MissingCellPolicy.RETURN_NULL_AND_BLANK).ToString(),
                                    Code = row.GetCell(3, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? null : row.GetCell(3, MissingCellPolicy.RETURN_NULL_AND_BLANK).ToString(),
                                    Question = row.GetCell(4, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? null : row.GetCell(4, MissingCellPolicy.RETURN_NULL_AND_BLANK).ToString(),
                                    AuditLocationId = row.GetCell(5, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? "" : row.GetCell(5, MissingCellPolicy.RETURN_NULL_AND_BLANK).ToString(),
                                    AssignGroup = row.GetCell(6, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? null : row.GetCell(6, MissingCellPolicy.RETURN_NULL_AND_BLANK).ToString(),
                                    AssignUser = row.GetCell(7, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? null : row.GetCell(7, MissingCellPolicy.RETURN_NULL_AND_BLANK).ToString(),
                                    Creator = row.GetCell(8, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? null : row.GetCell(8, MissingCellPolicy.RETURN_NULL_AND_BLANK).ToString(),
                                    PriorityId = row.GetCell(9, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? "" : row.GetCell(9, MissingCellPolicy.RETURN_NULL_AND_BLANK).ToString(),
                                    TargetClosing = row.GetCell(10, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? "" : row.GetCell(10, MissingCellPolicy.RETURN_NULL_AND_BLANK).ToString(),
                                    IssueCategoryId = row.GetCell(11, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? "" : row.GetCell(11, MissingCellPolicy.RETURN_NULL_AND_BLANK).ToString(),
                                    StatusId = row.GetCell(12, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? "" : row.GetCell(12, MissingCellPolicy.RETURN_NULL_AND_BLANK).ToString(),
                                    AuditTypeId = row.GetCell(13, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? "" : row.GetCell(13, MissingCellPolicy.RETURN_NULL_AND_BLANK).ToString(),
                                    IsSuccess = null,
                                    ErrorMessage = null,
                                    IsDeleted = false,
                                    UserCreated = _userId, //row.GetCell(8, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? userId : row.GetCell(8, MissingCellPolicy.RETURN_NULL_AND_BLANK).ToString(),
                                    DateCreated = Constants.GETDATE(),
                                    UserModified = null,
                                    DateModified = null
                                };                                        

                                trIssues.Add(issue);
                            }
                            
                        }
                        else
                        {
                            throw new Exception("Template file excel tidak valid");
                        }

                        _unitOfWork.TrIssueImportRepository.AddLists(trIssues);
                        _unitOfWork.Complete();
                            
                        statusUpload = _unitOfWork.TrIssueImportRepository.IssueImportValidate(sessionId, Constants.DEFAULT_USER);
                    }
                }

                if(statusUpload.IsSuccess == false)
                {
                    statusUpload.Messages = "Please check this file to check error data";
                }

                fn_Get_IssueImportStatus importStatus = _unitOfWork.TrIssueImportRepository.GetIssueImportStatus(sessionId).FirstOrDefault();
                if(importStatus.IsSuccess == true)
                {
                    importStatus.SessionId = null;
                }
                var response = new { TotalData = importStatus.TotalData, TotalSuccess = importStatus.TotalSuccess, TotalError = importStatus.TotalError, ErrorId = importStatus.SessionId };
                //return Ok(new StatusModel(statusUpload.IsSuccess, statusUpload.Messages, baseURL + "/" + "Issue/DownloadError/" + sessionId));
                return Ok(new StatusModel(statusUpload.IsSuccess, statusUpload.Messages, response));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
            
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        public void Validate(TrIssue model, string func)
        {

            if (func == Constants.CRUD.CREATE || func == Constants.CRUD.UPDATE)
            {
                //if (!_unitOfWork.MAuditLocationRepository.GetAll().Any(i => i.IsDeleted == false && i.AuditLocationId == model.AuditLocationId))
                //{
                //    throw new Exception("Audit lokasi tidak valid");
                //}
                //else if (!_unitOfWork.MIssueCategoryRepository.GetAll().Any(i => i.IsDeleted == false && i.IssueCategoryId == model.IssueCategoryId))
                //{
                //    throw new Exception("Issue kategori tidak valid");
                //}
                //else if (!_unitOfWork.MPriorityRepository.GetAll().Any(i => i.IsDeleted == false && i.PriorityId == model.PriorityId))
                //{
                //    throw new Exception("Priority tidak valid");
                //}
                //else if (!_unitOfWork.MIssueStatusRepository.GetAll().Any(i => i.IsDeleted == false && i.StatusId == model.StatusId))
                //{
                //    throw new Exception("Issue status tidak valid");
                //}
                //else if (!_unitOfWork.MUserGroupRepository.GetAll().Any(i => i.IsDeleted == false && i.UserGroupId == model.AssignGroup))
                //{
                //    throw new Exception("Group tidak valid");
                //}

                if (model.AuditTypeId != null)
                {
                    if (!_unitOfWork.MAuditTypeRepository.GetAll().Any(i => i.IsDeleted == false && i.AuditTypeId == model.AuditTypeId))
                    {
                        throw new Exception("Tipe audit tidak valid");
                    }
                }

                if (model.AuditLocationId != null)
                {
                    if (!_unitOfWork.MAuditLocationRepository.GetAll().Any(i => i.IsDeleted == false && i.AuditLocationId == model.AuditLocationId))
                    {
                        throw new Exception("Lokasi audit tidak valid");
                    }
                }
                if (model.AssignGroup != null)
                {
                    if (!_unitOfWork.MUserGroupRepository.GetAll().Any(i => i.IsDeleted == false && i.UserGroupId == model.AssignGroup))
                    {
                        throw new Exception("User group tidak valid");
                    }
                }
                if (model.AssignUser != null)
                {
                    if (!_unitOfWork.MUserSyncRepository.GetAll().Any(i => i.IsDeleted == false && i.UserId == model.AssignUser))
                    {
                        throw new Exception("Assignee tidak valid");
                    }
                }
                if (model.Creator != null)
                {
                    if (!_unitOfWork.MUserSyncRepository.GetAll().Any(i => i.IsDeleted == false && i.UserId == model.Creator))
                    {
                        throw new Exception("Creator tidak valid");
                    }
                }
                if (model.PriorityId > 0)
                {
                    if (!_unitOfWork.MPriorityRepository.GetAll().Any(i => i.IsDeleted == false && i.PriorityId == model.PriorityId))
                    {
                        throw new Exception("Priority tidak valid");
                    }
                }
                else
                {
                    throw new Exception("Priority tidak valid");
                }
                if (model.StatusId > 0)
                {
                    if (!_unitOfWork.MIssueStatusRepository.GetAll().Any(i => i.IsDeleted == false && i.StatusId == model.StatusId))
                    {
                        throw new Exception("Status tidak valid");
                    }
                }
                else
                {
                    throw new Exception("Status tidak valid");
                }

                if (model.IssueCategoryId > 0)
                {
                    if (!_unitOfWork.MIssueCategoryRepository.GetAll().Any(i => i.IsDeleted == false && i.IssueCategoryId == model.IssueCategoryId))
                    {
                        throw new Exception("Kategori issue tidak valid");
                    }
                }
                else
                {
                    throw new Exception("Kategori issue tidak valid");
                }

                if (func == Constants.CRUD.CREATE)
                {
                    if (model.TargetClosing != null)
                    {
                        if (model.TargetClosing.Date < DateTime.Now.Date)
                        {
                            throw new Exception("Target closing tidak boleh lebih kecil dari tanggal saat ini");
                        }
                    }
                    else
                    {
                        throw new Exception("Target closing tidak valid");
                    }
                }
                
            }

        }

        [ApiExplorerSettings(IgnoreApi = true)]
        public void CreateLog(TrIssue issue, int logType, string textLog, string userName)
        {
            var issueLog = new TrIssueLog
            {
                LogId = Constants.GETID(),
                IssueId = issue.IssueId,
                UserId = issue.UserCreated,
                Username = userName,
                DatetimeLog = Constants.GETDATE(),
                TextLog = userName + " " + textLog,
                LogTypeId = logType,
                IsDeleted = false,
                UserCreated = _userId,
                DateCreated = Constants.GETDATE()
            };

            _unitOfWork.TrIssueLogRepository.Add(issueLog);
            _unitOfWork.Complete();
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        public string ConvertSortParameter(string param)
        {
            string sortField = param;
            if (param.ToLower().Equals("duedate"))
            {
                sortField = "TargetClosing";
            }
            else if (param.ToLower().Equals("lastupdated"))
            {
                sortField = "LastUpdate";
            }
            else if (param.ToLower().Equals("datecreated"))
            {
                sortField = "DateCreated";
            }
            else if (param.ToLower().Equals("priority"))
            {
                sortField = "PriorityId";
            }


            return sortField;
        }
    }

    
}