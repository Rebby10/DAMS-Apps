﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using AutoMapper;
using DigitalAudit.API.Services;
using DigitalAudit.Helper;
using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using DigitalAudit.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.Extensions.Logging;

namespace DigitalAudit.API.Controllers.Transaction
{
    [Authorize]
    [ApiController]
    [Route("Issue/Log")]
    public class TrIssueLogController : ControllerBase
    {
        private readonly ILogger<TrIssueLogController> _logger;
        private readonly IUnitOfWork _unitOfWork;
        private IHostingEnvironment _hostingEnvironment;
        private readonly IMapper _mapper;
        private readonly IIdamanService _idamanService;
        private string _userId;

        public TrIssueLogController(
            IUnitOfWork unitOfWork, 
            ILogger<TrIssueLogController> logger, 
            IHostingEnvironment hostingEnvironment, 
            IMapper mapper,
            IIdamanService idamanService, 
            IHttpContextAccessor httpContextAccessor)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
            _hostingEnvironment = hostingEnvironment;
            _mapper = mapper;
            _idamanService = idamanService;
            _userId = httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier) == null? "": httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
        }

        [HttpGet]
        [Route("query")]
        public IActionResult Get([FromQuery] TrIssueLogViewModel.QueryIssueLog param)
        {
            try
            {
                var items = _unitOfWork.TrIssueLogRepository
                    .SelectAllLogIssue(param.IssueId);

                if (param.LastDate != null)
                {
                    items = items.Where(x => x.DatetimeLog > param.LastDate);
                }
                
                if (items.Count() > 0)
                {
                    string baseURL = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}";

                    var responseData = _mapper.Map<List<TrIssueLog>, List<TrIssueLogViewModel.ReadIssueLog>>(items.ToList());

                    responseData.Select(x =>
                    {
                        if (!string.IsNullOrEmpty(x.Filename))
                        {
                            x.Link = baseURL + "/" + "Issue/Log/Download/" + x.Id;
                        }
                        return x;

                    }).ToList();
                    
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, responseData, responseData.Count(), responseData.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpPost]
        public async Task<IActionResult> PostAsync([FromForm] TrIssueLogViewModel.CreateIssueLog param)
        {
            try
            {
                var issue = _unitOfWork.TrIssueRepository.SelectOne(param.IssueId).FirstOrDefault();

                if (issue == null)
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }

                string webRootPath = _hostingEnvironment.ContentRootPath;
                string configTemplate = Configs.AppConfig.UploadPath.ImportFileLogIssue;
                string path = webRootPath + configTemplate + "\\" + param.IssueId;

                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                var userIdaman = _unitOfWork.MUserSyncRepository.SelectAll().FirstOrDefault(f => f.UserId == _userId);

                var files = HttpContext.Request.Form.Files;
                
                foreach (var file in files)
                {
                    var fileName = file.FileName;
                    string fullPath = Path.Combine(path, fileName);

                    if (System.IO.File.Exists(fullPath))
                    {
                        string extension = Path.GetExtension(fileName).ToLower();
                        fileName = Path.GetFileNameWithoutExtension(fileName) + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + extension;
                        fullPath = Path.Combine(path, fileName);
                    }

                    using (var stream = new FileStream(fullPath, FileMode.Create))
                    {
                        await file.CopyToAsync(stream);

                        var issueLog = new TrIssueLog
                        {
                            LogId = Constants.GETID(),
                            IssueId = param.IssueId,
                            UserId = param.UserCreated,
                            Username = userIdaman.DisplayName,
                            DatetimeLog = Constants.GETDATE(),
                            Filename = fileName,
                            LogTypeId = Convert.ToInt32(Constants.LOG_TYPE.FILE),
                            IsDeleted = false,
                            UserCreated = param.UserCreated,
                            DateCreated = Constants.GETDATE()
                        };

                        _unitOfWork.TrIssueLogRepository.Add(issueLog);
                        _unitOfWork.Complete();
                    }                   
                }

                if (!string.IsNullOrEmpty(param.text))
                {
                    var issueLog = new TrIssueLog
                    {
                        LogId = Constants.GETID(),
                        IssueId = param.IssueId,
                        UserId = param.UserCreated,
                        Username = userIdaman.DisplayName,
                        DatetimeLog = Constants.GETDATE(),
                        TextLog = param.text,
                        LogTypeId = Convert.ToInt32(Constants.LOG_TYPE.TEXT),
                        IsDeleted = false,
                        UserCreated = param.UserCreated,
                        DateCreated = Constants.GETDATE()
                    };

                    _unitOfWork.TrIssueLogRepository.Add(issueLog);
                    _unitOfWork.Complete();
                }


                return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.CREATE, ""));
            }
            catch (Exception ex)
            {
                //_logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
            
        }

        [Route("Download/{id}")]
        [HttpGet]
        [AllowAnonymous]
        public ActionResult Download(string id)
        {
            var issueLog = _unitOfWork.TrIssueLogRepository.Get(id);

            string webRootPath = _hostingEnvironment.ContentRootPath;
            string configTemplate = Configs.AppConfig.UploadPath.ImportFileLogIssue;
            string path = webRootPath + configTemplate + "\\" + issueLog.IssueId;
            string fullPath = Path.Combine(path, issueLog.Filename);

            var provider = new FileExtensionContentTypeProvider();
            string contentType;

            if (!provider.TryGetContentType(fullPath, out contentType))
            {
                contentType = "application/octet-stream";
            }

            return PhysicalFile(fullPath, contentType, issueLog.Filename);
        }
    }
}