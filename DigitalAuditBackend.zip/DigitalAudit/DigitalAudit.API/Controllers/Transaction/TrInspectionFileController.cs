﻿using AutoMapper;
using DigitalAudit.Helper;
using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using DigitalAudit.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace DigitalAudit.API.Controllers.Transaction
{
    [Authorize]
    [Route("Inspection/File")]
    [ApiController]
    public class TrInspectionFileController : ControllerBase
    {
        private readonly ILogger<TrInspectionFileController> _logger;
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;
        private readonly IWebHostEnvironment _webHostEnvironment;
        private ClaimsPrincipal _principal;
        private string _userId;


        public TrInspectionFileController(
            IUnitOfWork unitOfWork,
            ILogger<TrInspectionFileController> logger,
            IMapper mapper,
            IWebHostEnvironment webHostEnvironment,
            IHttpContextAccessor httpContextAccessor)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
            _mapper = mapper;
            _webHostEnvironment = webHostEnvironment;
            _userId = httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier) == null ? "" : httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
        }

        [HttpGet]
        [Route("query")]
        public IActionResult GetFile([FromQuery] TrInspectionFileViewModel.QueryTrInspectionFile param)
        {
            try
            {
                var inspectionFiles = _unitOfWork.TrInspectionFileRepository.Select(param.InspectionId, param.QuestionId, param.FileTypeId).ToList();
                string configInspection = Configs.AppConfig.UploadPath.ImportFileInspection;
                string baseURL = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}";

                if (inspectionFiles.Count() > 0)
                {
                    inspectionFiles.Select(x =>
                    {
                        if (!string.IsNullOrEmpty(x.Filename))
                        {
                            x.LinkFile = baseURL + "/" + "inspection/file/download" + "/" + x.FileId;
                        }
                        return x;

                    }).ToList();


                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, inspectionFiles, inspectionFiles.Count(), inspectionFiles.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
                
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [Route("Download/{id}")]
        [HttpGet]
        [AllowAnonymous]
        public ActionResult Download(string id)
        {
            var inspectionFile = _unitOfWork.TrInspectionFileRepository.Get(id);

            string webRootPath = _webHostEnvironment.ContentRootPath;
            string configTemplate = Configs.AppConfig.UploadPath.ImportFileInspection;
            string path = webRootPath + configTemplate + "\\" + inspectionFile.InspectionId + "\\" + inspectionFile.FileTypeId;
            string fullPath = Path.Combine(path, inspectionFile.Filename);

            var provider = new FileExtensionContentTypeProvider();
            string contentType;

            if (!provider.TryGetContentType(fullPath, out contentType))
            {
                contentType = "application/octet-stream";
            }

            return PhysicalFile(fullPath, contentType, inspectionFile.Filename);
        }

        [HttpPost]
        public async Task<IActionResult> PostAsync([FromForm] TrInspectionFileViewModel.CreateInspectionFile param)
        {
            try
            {
                _principal = HttpContext.User;
                string userId = Helpers.GetSessionToken(Helpers.GetListClaim(_principal), "UserId");

                var inspection = _unitOfWork.TrInspectionRepository.Get(param.InspectionId);

                if (inspection == null)
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }

                string webRootPath = _webHostEnvironment.ContentRootPath;
                string configInspection = Configs.AppConfig.UploadPath.ImportFileInspection;
                string path = webRootPath + configInspection + "\\" + param.InspectionId;

                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                path = path + "\\" + param.FileTypeId;

                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                var files = HttpContext.Request.Form.Files;

                foreach (var file in files)
                {
                    var fileName = file.FileName;
                    string fullPath = Path.Combine(path, fileName);

                    if (System.IO.File.Exists(fullPath))
                    {
                        string extension = Path.GetExtension(fileName).ToLower();
                        fileName = Path.GetFileNameWithoutExtension(fileName) + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + extension;
                        fullPath = Path.Combine(path, fileName);
                    }

                    using (var stream = new FileStream(fullPath, FileMode.Create))
                    {
                        await file.CopyToAsync(stream);

                        var inspectionFile = new TrInspectionFile
                        {
                            FileId = Constants.GETID(),
                            Filename = fileName,
                            FileTypeId = param.FileTypeId,
                            InspectionId = param.InspectionId,
                            QuestionId = param.QuestionId,
                            IsDeleted = false,
                            UserCreated = param.UserCreated,
                            DateCreated = Constants.GETDATE()
                            
                        };

                        _unitOfWork.TrInspectionFileRepository.Add(inspectionFile);
                        _unitOfWork.Complete();
                    }
                }

                var inspectionFiles = _unitOfWork.TrInspectionFileRepository.Select(param.InspectionId, param.QuestionId, param.FileTypeId).ToList();

                string baseURL = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}";

                inspectionFiles.Select(x =>
                {
                    if (!string.IsNullOrEmpty(x.Filename))
                    {
                        x.LinkFile = x.LinkFile = baseURL + "/" + "inspection/file/download" + "/" + x.FileId; 
                    }
                    return x;

                }).ToList();


                return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.CREATE, inspectionFiles));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }

        }

        [HttpDelete("{FileId}")]
        public IActionResult delete(string FileId)
        {
            try
            {
                _principal = HttpContext.User;
                string userId = Helpers.GetSessionToken(Helpers.GetListClaim(_principal), "UserId");

                var inspectionFile = _unitOfWork.TrInspectionFileRepository.Get(FileId);

                if (inspectionFile != null)
                {
                    inspectionFile.IsDeleted = true;
                    inspectionFile.UserModified = userId;
                    inspectionFile.DateModified = Constants.GETDATE();

                    _unitOfWork.TrInspectionFileRepository.Update(inspectionFile);
                    _unitOfWork.Complete();

                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.DELETE, null, 0, 0));

                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
            
        }

        
    }
}
