﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using AutoMapper;
using DigitalAudit.API.Services;
using DigitalAudit.Helper;
using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using DigitalAudit.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.Extensions.Logging;


namespace DigitalAudit.API.Controllers.Transaction
{
    [Authorize]
    [ApiController]
    [Route("Action/Log")]
    public class TrActionLogController : ControllerBase
    {
        private readonly ILogger<TrActionLogController> _logger;
        private readonly IUnitOfWork _unitOfWork;
        private IHostingEnvironment _hostingEnvironment;
        private readonly IMapper _mapper;
        private readonly IIdamanService _idamanService;
        private string _userId;

        public TrActionLogController(
            IUnitOfWork unitOfWork,
            ILogger<TrActionLogController> logger,
            IHostingEnvironment hostingEnvironment,
            IMapper mapper,
            IIdamanService idamanService, 
            IHttpContextAccessor httpContextAccessor)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
            _hostingEnvironment = hostingEnvironment;
            _mapper = mapper;
            _idamanService = idamanService;
            _userId = httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier) == null ? "" : httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value; 
        }

        [HttpGet]
        [Route("query")]
        public IActionResult Get([FromQuery] TrActionLogViewModel.QueryActionLog param)
        {
            try
            {
                var items = _unitOfWork.TrActionLogRepository
                    .SelectAllLogAction(param.ActionId);

                if (param.LastDate != null)
                {
                    items = items.Where(x => x.DatetimeLog > param.LastDate);
                }

                if (items.Count() > 0)
                {
                    string baseURL = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}";

                    var responseData = _mapper.Map<List<TrActionLog>, List<TrActionLogViewModel.ReadActionLog>>(items.ToList());

                    responseData.Select(x =>
                    {
                        if (!string.IsNullOrEmpty(x.Filename))
                        {
                            x.Link = baseURL + "/" + "Action/Log/Download/" + x.Id;
                        }
                        return x;

                    }).ToList();

                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, responseData, responseData.Count(), responseData.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpPost]
        public async Task<IActionResult> PostAsync([FromForm] TrActionLogViewModel.CreateActionLog param)
        {
            try
            {
                var action = _unitOfWork.TrActionRepository.SelectOne(param.ActionId);

                if (action == null)
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }

                string webRootPath = _hostingEnvironment.ContentRootPath;
                string configTemplate = Configs.AppConfig.UploadPath.ImportFileLogAction;
                string path = webRootPath + configTemplate + "\\" + param.ActionId;

                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                var user = _unitOfWork.MUserSyncRepository.SelectAll().FirstOrDefault(f => f.UserId == _userId);

                var files = HttpContext.Request.Form.Files;

                foreach (var file in files)
                {
                    var fileName = file.FileName;
                    string fullPath = Path.Combine(path, fileName);

                    if (System.IO.File.Exists(fullPath))
                    {
                        string extension = Path.GetExtension(fileName).ToLower();
                        fileName = Path.GetFileNameWithoutExtension(fileName) + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + extension;
                        fullPath = Path.Combine(path, fileName);
                    }

                    using (var stream = new FileStream(fullPath, FileMode.Create))
                    {
                        await file.CopyToAsync(stream);

                        var actionLog = new TrActionLog
                        {
                            LogId = Constants.GETID(),
                            ActionId = param.ActionId,
                            UserId = _userId,
                            Username = user.DisplayName,
                            DatetimeLog = Constants.GETDATE(),
                            Filename = fileName,
                            LogTypeId = Convert.ToInt32(Constants.LOG_TYPE.FILE),
                            IsDeleted = false,
                            UserCreated = _userId,
                            DateCreated = Constants.GETDATE()
                        };

                        _unitOfWork.TrActionLogRepository.Add(actionLog);
                        _unitOfWork.Complete();
                    }
                }

                if (!string.IsNullOrEmpty(param.text))
                {
                    var actionLog = new TrActionLog
                    {
                        LogId = Constants.GETID(),
                        ActionId = param.ActionId,
                        UserId = _userId,
                        Username = user.DisplayName,
                        DatetimeLog = Constants.GETDATE(),
                        TextLog = param.text,
                        LogTypeId = Convert.ToInt32(Constants.LOG_TYPE.TEXT),
                        IsDeleted = false,
                        UserCreated = _userId,
                        DateCreated = Constants.GETDATE()
                    };

                    _unitOfWork.TrActionLogRepository.Add(actionLog);
                    _unitOfWork.Complete();
                }


                return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.CREATE, ""));
            }
            catch (Exception ex)
            {
                //_logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }

        }

        [Route("Download/{id}")]
        [HttpGet]
        [AllowAnonymous]
        public ActionResult Download(string id)
        {
            var actionLog = _unitOfWork.TrActionLogRepository.Get(id);

            string webRootPath = _hostingEnvironment.ContentRootPath;
            string configTemplate = Configs.AppConfig.UploadPath.ImportFileLogAction;
            string path = webRootPath + configTemplate + "\\" + actionLog.ActionId;
            string fullPath = Path.Combine(path, actionLog.Filename);

            var provider = new FileExtensionContentTypeProvider();
            string contentType;

            if (!provider.TryGetContentType(fullPath, out contentType))
            {
                contentType = "application/octet-stream";
            }

            return PhysicalFile(fullPath, contentType, actionLog.Filename);
        }
    }
}