﻿using DigitalAudit.Helper;
using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using DigitalAudit.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;

namespace DigitalAudit.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("Reschedule")]
    public class TrAuditRescheduleController : ControllerBase
    {
        private readonly ILogger<TrAuditRescheduleController> _logger;
        private readonly IUnitOfWork _unitOfWork;
        private string _userId;

        public TrAuditRescheduleController(IUnitOfWork unitOfWork, ILogger<TrAuditRescheduleController> logger, IHttpContextAccessor httpContextAccessor)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
            _userId = httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
        }

        // GET: api/Schedule
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var items = _unitOfWork.TrAuditScheduleRepository.SelectAll();
                int totalData = items.Count();

                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, items.Count(), items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpGet]
        [Route("query")]
        public IActionResult Get(
            [FromQuery] TrAuditRescheduleViewModel.QueryTrAuditReschedule param)
        {
            try
            {
                IEnumerable<fn_Get_TrAuditReschedule> items = _unitOfWork.TrAuditRescheduleRepository.Get_TrAuditReschedule(param.status_id, _userId);


                int totalData = items.Count();

                if (!string.IsNullOrEmpty(param.sort_by))
                {
                    var orderByExpression = Helpers.GetOrderByExpression<fn_Get_TrAuditReschedule>(param.sort_by);
                    items = Helpers.OrderByDir<fn_Get_TrAuditReschedule>(items, param.order_by, orderByExpression).AsEnumerable();
                }

                if (param.page_size != null && param.page_number != null)
                {
                    items = Helpers.Page<fn_Get_TrAuditReschedule>(items, param.page_size.Value, param.page_number.Value);
                }

                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, totalData, items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, param);
                return BadRequest(new StatusModel(ex));
            }
        }


        [HttpPost]
        public IActionResult Post([FromBody] TrAuditRescheduleViewModel.CreateTrAuditReschedule item)
        {
            try
            {
                Helpers.Validate(item);


                bool isAdminPusat = false;
                fn_Get_TrAuditSchedulePICID pic = _unitOfWork.TrAuditSchedulePICRepository.Get_AuditSchedulePICID(item.ScheduleId, item.UserId).FirstOrDefault();

                if (pic == null)
                {
                    //throw new Exception("Schedule tidak valid");

                    MUserRole userAdminPusat = _unitOfWork.MUserRoleRepository.GetAll().Where(i => i.IsDeleted == false && i.UserId == item.UserId && i.RoleId != Constants.ROLE.USER).FirstOrDefault();
                    if(userAdminPusat == null)
                    {
                        throw new Exception("Schedule tidak valid");
                    }
                    else
                    {
                        isAdminPusat = true;
                    }
                }

                if(isAdminPusat == false)
                {

                    TrAuditReschedule reschedulePIC = _unitOfWork.TrAuditRescheduleRepository.GetAll().Where(i => i.IsDeleted == false && i.PicId == pic.PicId && i.IsApproved == null).FirstOrDefault();
                    if (reschedulePIC != null)
                    {
                        throw new Exception("Tidak bisa mmengajukan reschedule karena sedang dalam proses approval reschedule");
                    }

                    string picIdApprover = string.Empty;

                    if (pic.UserTypeId == Constants.USER_TYPE.AUDITOR)
                    {
                        fn_Get_TrAuditSchedulePICID picAppr = _unitOfWork.TrAuditSchedulePICRepository.Get_AuditSchedulePICID(item.ScheduleId, null).Where(i => i.UserTypeId == Constants.USER_TYPE.AUDITEE).FirstOrDefault();
                        picIdApprover = picAppr.PicId;
                        //if(picAppr.TeamType == "User")
                        //{
                        //    picIdApprover = picAppr.UserId;
                        //}
                        //else
                        //{
                        //    MUserGroupViewModel.ReadUserGroup userGroup = _unitOfWork.MUserGroupRepository.SelectAll().Where(i => i.UserGroupId == picAppr.UserGroupId).FirstOrDefault();
                        //    picIdApprover = userGroup.UserId;
                        //}
                    }
                    else
                    {
                        fn_Get_TrAuditSchedulePICID picAppr = _unitOfWork.TrAuditSchedulePICRepository.Get_AuditSchedulePICID(item.ScheduleId, null).Where(i => i.UserTypeId == Constants.USER_TYPE.AUDITOR).FirstOrDefault();
                        picIdApprover = picAppr.PicId;
                        //if (picAppr.TeamType == "User")
                        //{
                        //    picIdApprover = picAppr.UserId;
                        //}
                        //else
                        //{
                        //    MUserGroupViewModel.ReadUserGroup userGroup = _unitOfWork.MUserGroupRepository.SelectAll().Where(i => i.UserGroupId == picAppr.UserGroupId).FirstOrDefault();
                        //    picIdApprover = userGroup.UserId;
                        //}
                    }

                    if (string.IsNullOrEmpty(picIdApprover))
                    {
                        throw new Exception("Approver tidak valid");
                    }

                    TrAuditReschedule data = new TrAuditReschedule(Constants.GETID(), pic.ScheduleId, pic.PicId, item.StartDate, item.EndDate, item.Descriptions, picIdApprover, null, null, false, _userId, Constants.GETDATE(), null, null);

                    _unitOfWork.TrAuditRescheduleRepository.Add(data);

                    TrAuditSchedule schedule = _unitOfWork.TrAuditScheduleRepository.Get(item.ScheduleId);
                    schedule.StatusId = Constants.SCHEDULE_STATUS.RESCHEDULE;
                    _unitOfWork.TrAuditScheduleRepository.Update(schedule, _userId, Constants.GETDATE());

                    TrAuditSchedulePIC schedulePIC = _unitOfWork.TrAuditSchedulePICRepository.Get(pic.PicId);
                    schedulePIC.StatusId = Constants.SCHEDULE_STATUS.RESCHEDULE;
                    _unitOfWork.TrAuditSchedulePICRepository.Update(schedulePIC, _userId, Constants.GETDATE());

                    TrInspection inspection = _unitOfWork.TrInspectionRepository.GetAll().Where(i => i.IsDeleted == false && i.ScheduleId == item.ScheduleId).FirstOrDefault();
                    inspection.StatusId = Constants.INSPECTION_STATUS.RESCHEDULE;
                    _unitOfWork.TrInspectionRepository.Update(inspection, _userId, Constants.GETDATE());

                    _unitOfWork.Complete();

                    data = _unitOfWork.TrAuditRescheduleRepository.Get(data.RescheduleId.Trim());
                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.CREATE, data));
                }
                else
                {
                    TrAuditSchedule schedule = _unitOfWork.TrAuditScheduleRepository.GetAll().Where(i => i.IsDeleted == false && i.ScheduleId == item.ScheduleId).FirstOrDefault();
                    schedule.StartDate = item.StartDate;
                    schedule.EndDate = item.EndDate;
                    _unitOfWork.TrAuditScheduleRepository.Update(schedule, _userId, Constants.GETDATE());

                    TrInspection inspection = _unitOfWork.TrInspectionRepository.GetAll().Where(i => i.IsDeleted == false && i.ScheduleId == item.ScheduleId).FirstOrDefault();
                    //inspection.StatusId = Constants.INSPECTION_STATUS.SCHEDULED;
                    inspection.StartDate = item.StartDate;
                    inspection.EndDate = item.EndDate;

                    _unitOfWork.TrInspectionRepository.Update(inspection, _userId, Constants.GETDATE());

                    _unitOfWork.Complete();

                    TrAuditReschedule data = new TrAuditReschedule();

                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.CREATE, data));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, item);
                return Ok(new StatusModel(ex));
            }
        }

        [HttpPost]
        [Route("RescheduleApproval")]
        public IActionResult RescheduleApproval([FromBody] TrAuditRescheduleViewModel.RescheduleApproval item)
        {
            try
            {
                Helpers.Validate(item);
                TrAuditReschedule data = _unitOfWork.TrAuditRescheduleRepository.Get(item.RescheduleId);
                data.IsApproved = item.IsApproved;
                data.ApprovalDate = Constants.GETDATE();
                _unitOfWork.TrAuditRescheduleRepository.Update(data, _userId, Constants.GETDATE());


                TrAuditSchedule schedule = _unitOfWork.TrAuditScheduleRepository.Get(item.ScheduleId);
                if (item.IsApproved)
                {
                    schedule.StatusId = Constants.SCHEDULE_STATUS.CONFIRMED;
                    schedule.StartDate = data.StartDate;
                    schedule.EndDate = data.EndDate;
                }

                schedule.StatusId = Constants.SCHEDULE_STATUS.CONFIRMED;

                _unitOfWork.TrAuditScheduleRepository.Update(schedule, _userId, Constants.GETDATE());

                TrInspection inspection = _unitOfWork.TrInspectionRepository.GetAll().Where(i => i.IsDeleted == false && i.ScheduleId == item.ScheduleId).FirstOrDefault();
                inspection.StatusId = Constants.INSPECTION_STATUS.SCHEDULED;
                inspection.StartDate = data.StartDate;
                inspection.EndDate = data.EndDate;
                _unitOfWork.TrInspectionRepository.Update(inspection, _userId, Constants.GETDATE());

                _unitOfWork.Complete();

                return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.UPDATE, null));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, item);
                return BadRequest(new StatusModel(ex));
            }
        }


        //[HttpDelete("{id}")]
        //public IActionResult Delete(string id)
        //{
        //    try
        //    {
        //        _principal = HttpContext.User;
        //        string userId = Helpers.GetSessionToken(Helpers.GetListClaim(_principal), "UserId");
        //        var item = _unitOfWork.TrAuditScheduleRepository.Get(id.Trim());
        //        if (item != null)
        //        {
        //            _unitOfWork.TrAuditScheduleRepository.Delete(item, userId, Constants.GETDATE());
        //            _unitOfWork.Complete();

        //            return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.DELETE, null));
        //        }
        //        else
        //        {
        //            return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, id);
        //        return Ok(new StatusModel(ex));
        //    }
        //}

        //[ApiExplorerSettings(IgnoreApi = true)]
        //public void Validate(TrAuditSchedule model, string func)
        //{

        //    if (func == Constants.CRUD.CREATE || func == Constants.CRUD.UPDATE)
        //    {
        //        if (!_unitOfWork.MAuditLocationRepository.GetAll().Any(i => i.IsDeleted == false && i.AuditLocationId == model.AuditLocationId))
        //        {
        //            throw new Exception("Lokasi tidak valid");
        //        }
        //        else if (!_unitOfWork.MAuditTypeRepository.GetAll().Any(i => i.IsDeleted == false && i.AuditTypeId == model.AuditTypeId))
        //        {
        //            throw new Exception("Tipe audit tidak valid");
        //        }
        //    }
        //}
    }
}
