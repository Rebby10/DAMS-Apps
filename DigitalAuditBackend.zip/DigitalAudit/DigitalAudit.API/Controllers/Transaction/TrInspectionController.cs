﻿using AutoMapper;
using DigitalAudit.Helper;
using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using DigitalAudit.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using static DigitalAudit.Model.ViewModel.TrInspectionViewModel;

namespace DigitalAudit.API.Controllers.Transaction
{
    [Authorize]
    [ApiController]
    [Route("Inspection")]
    public class TrInspectionController : ControllerBase
    {
        private readonly ILogger<TrInspectionController> _logger;
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;
        private readonly IWebHostEnvironment _webHostEnvironment;
        private string _userId;


        public TrInspectionController(
            IUnitOfWork unitOfWork,
            ILogger<TrInspectionController> logger,
            IMapper mapper,
            IWebHostEnvironment webHostEnvironment, 
            IHttpContextAccessor httpContextAccessor)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
            _mapper = mapper;
            _webHostEnvironment = webHostEnvironment;
            _userId = httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
        }

        [HttpGet]
        [Route("query")]
        public IActionResult Get([FromQuery] TrInspectionViewModel.QueryInspection param)
        {
            try
            {
                #region  check user role
                var userRole = _unitOfWork.MUserRoleRepository.GetAll().FirstOrDefault(f => f.UserId == _userId);

                if (userRole != null)
                {
                    if (userRole.RoleId == Constants.ROLE.ADMIN_PUSAT)
                    {
                        _userId = null; // admin pusat bisa lihat semua data, tidak di filter berdasarkan userId
                    }
                    else if (userRole.RoleId == Constants.ROLE.ADMIN_REGION)
                    {
                        if (param.RegionId == null) // Jika param region gk diisi, ngikutin region user role
                        {
                            param.RegionId = userRole.RegionId;
                            _userId = null;
                        }
                    }
                    else if (userRole.RoleId == Constants.ROLE.ADMIN_LOKASI)
                    {
                        if (param.AuditLocationId == null) //Jika param lokasi audit tidak diisi, ngikutin lokasi user role
                        {
                            param.AuditLocationId = userRole.AuditLocationId;
                            _userId = null;
                        }
                    }
                }

                #endregion

                var items = _unitOfWork.TrInspectionRepository.SelectByRole(null, param.StatusId, param.RegionId, param.AuditLocationId).AsEnumerable();

                if (!string.IsNullOrEmpty(_userId))
                {
                    if (param.UserTypeId == Convert.ToInt32(Constants.USER_TYPE.AUDITEE))
                    {
                        items = items.Where(i =>
                           (i.Auditee.Users == null ? "" : i.Auditee.Users.UserId) == _userId
                           ||
                           (i.Auditee.Groups == null ? "" : i.Auditee.Groups.UserId) == _userId);
                    }
                    else if (param.UserTypeId == Convert.ToInt32(Constants.USER_TYPE.AUDITOR))
                    {
                        items = items.Where(i =>
                           (i.Auditor.Users == null ? "" : i.Auditor.Users.UserId) == _userId
                           ||
                           (i.Auditor.Groups == null ? "" : i.Auditor.Groups.UserId) == _userId
                           );
                    }
                    else
                    {
                        items = items.Where(i =>
                            (i.Auditee.Users == null ? "" : i.Auditee.Users.UserId) == _userId
                            ||
                            (i.Auditee.Groups == null ? "" : i.Auditee.Groups.UserId) == _userId
                            ||
                            (i.Auditor.Users == null ? "" : i.Auditor.Users.UserId) == _userId
                            ||
                            (i.Auditor.Groups == null ? "" : i.Auditor.Groups.UserId) == _userId
                            );
                    }
                }

                if (!string.IsNullOrEmpty(param.Text))
                {
                    items = items.Where(i =>
                        (i.Template.Title == null ? "" : i.Template.Title).ToLower().Contains(param.Text.ToLower())
                        || (i.AuditLocation.Name == null ? "" : i.AuditLocation.Name).ToLower().Contains(param.Text.ToLower())
                        || (i.Auditee.Users == null ? "" : i.Auditee.Users.DisplayName).ToLower().Contains(param.Text.ToLower())
                        || (i.Auditee.Groups == null ? "" : i.Auditee.Groups.Name).ToLower().Contains(param.Text.ToLower())
                        || (i.Auditor.Users == null ? "" : i.Auditor.Users.DisplayName).ToLower().Contains(param.Text.ToLower())
                        || (i.Auditor.Groups == null ? "" : i.Auditor.Groups.Name).ToLower().Contains(param.Text.ToLower())
                        );
                }

                if (!string.IsNullOrEmpty(param.sort_by))
                {
                    var orderByExpression = Helpers.GetOrderByExpression<TrInspectionViewModel.ReadInspection>(ConvertSortParameter(param.sort_by));
                    items = Helpers.OrderByDir(items, param.order_by, orderByExpression);
                }
                else
                {
                    var orderByExpression = Helpers.GetOrderByExpression<TrInspectionViewModel.ReadInspection>(ConvertSortParameter("DateCreated"));
                    items = Helpers.OrderByDir(items, "desc", orderByExpression);
                }

                if (param.page_size != null && param.page_number != null)
                {
                    items = Helpers.Page(items, param.page_size.Value, param.page_number.Value);
                }

                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, items.Count(), items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        

        [HttpGet("Start/{InspectionId}")]
        public IActionResult StartInspection(string InspectionId)
        {
            try
            {
                //    _principal = HttpContext.User;
                //    string userId = Helpers.GetSessionToken(Helpers.GetListClaim(_principal), "UserId");

                var inspection = _unitOfWork.TrInspectionRepository.Get(InspectionId);

                if (inspection == null)
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }


                if (inspection.StatusId == Constants.INSPECTION_STATUS.SCHEDULED)
                {
                    #region update status inspection
                    inspection.StatusId = Constants.INSPECTION_STATUS.ON_PROGRESS;
                    inspection.ConductedDate = Constants.GETDATE();
                    inspection.UserModified = _userId;
                    inspection.DateModified = Constants.GETDATE();

                    _unitOfWork.TrInspectionRepository.Update(inspection);
                    _unitOfWork.Complete();
                    #endregion
                }


                var page = _unitOfWork.MTemplatePageRepository.GetAll()
                    .Where(x => x.IsDeleted == false && x.TemplateId == inspection.TemplateId)
                    .OrderBy(o => o.SeqNo)
                    .FirstOrDefault();

                var template = _unitOfWork.TrInspectionResultRepository.GetTemplate(inspection.TemplateId, InspectionId, page.PageId);

                var inspectionDetail = _unitOfWork.TrInspectionRepository.SelectByRole(InspectionId, null, null, null).FirstOrDefault();

                

                if (template == null)
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }

                StartInspection startInspection = new StartInspection()
                {
                    Inspection = inspectionDetail,
                    TemplateId = template.TemplateId,
                    Code = template.Code,
                    Title = template.Title,                    
                    Descriptions = template.Descriptions,
                    TemplateCategory = template.TemplateCategory,
                    TemplatePermissionType = template.TemplatePermissionType,
                    TemplatePermission = template.TemplatePermission,
                    TemplatePage = template.TemplatePage
                };


                return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.READ, startInspection));
            }
            catch (Exception ex)
            {

                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, InspectionId);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpGet("Issue/{InspectionId}")]
        public IActionResult GetIssue(string InspectionId)
        {
            try
            {
                var inspection = _unitOfWork.TrInspectionRepository.Get(InspectionId);

                //Cek Inspection sebelum ini
                //var lastInspection = _unitOfWork.TrInspectionRepository.GetAll()
                //    .FirstOrDefault(x =>
                //        x.IsDeleted == false &&
                //        x.LocationId == inspection.LocationId &&
                //        x.TemplateId == inspection.TemplateId &&
                //        x.InspectionId != inspection.InspectionId);

                var lastInspection = _unitOfWork.TrInspectionRepository.GetLastInspection(inspection.InspectionId, inspection.LocationId, inspection.TemplateId);

                if (lastInspection == null)
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }

                //Cek Issue di last inspection
                var issues = _unitOfWork.TrIssueRepository.GetIssueInspection(lastInspection.InspectionId);
                    //.Select(s => new TrIssueViewModel.IssueInspection 
                    //{
                    //   IssueId = s.IssueId,
                    //    Title = s.Title,
                    //    Descriptions = s.Descriptions,
                    //    QuestionId = s.QuestionId,
                    //    Code = s.Code,
                    //    Question = s.Question,
                    //    AuditTypeId = s.AuditTypeId,
                    //    AuditType = s.AuditType,
                    //    AuditLocationId = s.AuditLocationId,
                    //    AuditLocationAddress = s.AuditLocationAddress,
                    //    AuditLocationZipCode = s.AuditLocationZipCode,
                    //    LocationName = s.LocationName,
                    //    RegionId = s.RegionId,
                    //    Region = s.Region,
                    //    LatLong = s.LatLong,
                    //    AssignGroup = s.AssignGroup,
                    //    UserGroupName = s.UserGroupName,
                    //    UserGroupTypeId = s.UserGroupTypeId,
                    //    UserGroupTypeName = s.UserGroupTypeName,
                    //    GroupLeader = s.GroupLeader,
                    //    GroupLeaderName = s.GroupLeaderName,
                    //    AssignUser = s.AssignUser,
                    //    AssignUserName = s.AssignUserName,
                    //    AssignUserEmail = s.AssignUserEmail,
                    //    Creator = s.Creator,
                    //    CreatorName = s.CreatorName,
                    //    CreatorEmail = s.CreatorEmail,
                    //    PriorityId = s.PriorityId,
                    //    Priority = s.Priority,
                    //    TargetClosing = s.TargetClosing,
                    //    IssueCategoryId = s.IssueCategoryId,
                    //    IssueCategory = s.IssueCategory,
                    //    StatusId = s.StatusId,
                    //    IssueStatus = s.IssueStatus,
                    //    RecurringFinding = s.RecurringFinding,
                    //    UserCreated = s.UserCreated,
                    //    DateCreated = s.DateCreated,
                    //    UserModified = s.UserModified,
                    //    DateModified = s.DateModified,
                    //    LastUpdate = s.LastUpdate,
                    //    TotalAction = s.TotalAction,
                    //    InspectionId = s.InspectionId,
                    //    Action = _unitOfWork.TrActionRepository.SelectAll(null, null, null, null, null, null, null, null,null, null,null, null, s.IssueId)
                    //    .Select(x => new TrActionViewModel.ReadAction
                    //    {
                    //        ActionId = x.ActionId,
                    //        Title = x.Title,
                    //        Descriptions = x.Descriptions,
                    //        QuestionId = x.QuestionId,
                    //        Code = x.Code,
                    //        Question = x.Question,
                    //        AuditType = new MAuditTypeViewModel.ReadAuditType()
                    //        {
                    //            AuditTypeId = x.AuditTypeId,
                    //            Name = x.AuditTypeName
                    //        },
                    //        Issue = new TrIssueViewModel.ReadIssueLite()
                    //        {
                    //            IssueId = x.IssueId,
                    //            Title = x.IssueTitle
                    //        },
                    //        AuditLocation = x.AuditLocationId == null? null : new MAuditLocationViewModel.ReadAuditLocation()
                    //        {
                    //            AuditLocationId = x.AuditLocationId,
                    //            Name = x.AuditLocationName,
                    //            Address = x.AuditLocationAddress,
                    //            ZipCode = x.AuditLocationZipCode,
                    //            LatLong = x.AuditLocationLatLong,
                    //            Region = new MRegionViewModel.ReadRegion
                    //            {
                    //                RegionId = x.AuditLocationRegionId,
                    //                Name = x.RegionName
                    //            }
                    //        },
                    //        AssignGroup = x.AssignGroup == null? null : new MUserGroupViewModel.ReadUserGroup()
                    //        {
                    //            UserGroupId = x.AssignGroup,
                    //            Name = x.AssignGroupName,
                    //            UserId = x.AssignGroupUserId,
                    //            UserType = new MUserTypeViewModel.ReadUserType
                    //            {
                    //                UserTypeId = x.AssignGroupTypeId,
                    //                Name = x.AssignGroupTypeName
                    //            },
                    //            Username = x.AssignGroupUserName
                    //        },
                    //        AssignUser = new MUserSyncViewModel.ReadUserLite()
                    //        {
                    //            UserId = x.AssignUser,
                    //            DisplayName = x.AssignUserDisplayName,
                    //            Email = x.AssignUserEmail
                    //        },
                    //        Creator = new MUserSyncViewModel.ReadUserLite()
                    //        {
                    //            UserId = x.Creator,
                    //            DisplayName = x.CreatorDisplayName,
                    //            Email = x.CreatorEmail
                    //        },
                    //        Priority = new MPriorityViewModel.ReadPriority()
                    //        {
                    //            PriorityId = x.PriorityId,
                    //            Name = x.PriorityName
                    //        },
                    //        TargetClosing = Convert.ToDateTime(x.TargetClosing.ToString("s", DateTimeFormatInfo.InvariantInfo)),
                    //        Status = new MIssueStatusViewModel.ReadIssueStatus()
                    //        {
                    //            StatusId = x.StatusId,
                    //            Name = x.StatusName
                    //        },
                    //        InspectionId = x.InspectionId,
                    //        DateCreated = Convert.ToDateTime(x.DateCreated.ToString("s", DateTimeFormatInfo.InvariantInfo)),
                    //        DateModified = x.DateModified

                    //    }).ToList()
                    //});


                if (issues.Count() == 0)
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }

                var responseData = _mapper.Map<List<fn_Get_Issue>, List<TrIssueViewModel.ReadIssue>>(issues.ToList());
                return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.CREATE, responseData, responseData.Count(), responseData.Count()));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, InspectionId);
                return BadRequest(new StatusModel(ex));
            }

        }

        [HttpGet("Page/{InspectionId}/{PageId}")]
        public IActionResult GetPage(string InspectionId, string PageId)
        {
            try
            {
                var inspection = _unitOfWork.TrInspectionRepository.Get(InspectionId);

                if (inspection == null)
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }

                var page = _unitOfWork.TrInspectionResultRepository.SelectTemplatePageDetail(inspection.TemplateId, InspectionId, PageId).FirstOrDefault();

                if (page == null)
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }

                page.Score = _unitOfWork.TrInspectionRepository.GetScoreInspection(InspectionId);

                return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.READ, page));
            }
            catch (Exception ex)
            {

                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpGet("Page/List/{InspectionId}")]
        public IActionResult GetPageList(string InspectionId)
        {
            try
            {
                var inspection = _unitOfWork.TrInspectionRepository.Get(InspectionId);

                if (inspection == null)
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }

                var pages = _unitOfWork.MTemplatePageRepository.SelectAll()
                    .Where(x => x.TemplateId == inspection.TemplateId)
                    .OrderBy(o => o.SeqNo).ToList();

                if (pages == null)
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }

                var lastInspection = _unitOfWork.TrInspectionRepository.GetLastInspection(inspection.InspectionId, inspection.LocationId, inspection.TemplateId);

                if (lastInspection != null)
                {
                    //Cek Issue di last inspection
                    var issues = _unitOfWork.TrIssueRepository.GetIssueInspection(lastInspection.InspectionId);

                    if (issues.Count() > 0)
                    {
                        MTemplatePageViewModel.ReadTemplatePage issuePage = new MTemplatePageViewModel.ReadTemplatePage();
                        issuePage.Title = "Issues from last inspection";
                        issuePage.SeqNo = 0;

                        pages.Add(issuePage);
                    }
                }

                

                return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.READ, pages));
            }
            catch (Exception ex)
            {

                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpPost]
        public IActionResult Post([FromBody] TrInspectionViewModel.CreateInspection item)
        {
            try
            {

                Validate(item);

                var inspection = new TrInspection
                {
                    InspectionId = Constants.GETID(),
                    LocationId = item.AuditLocationId,
                    StartDate = Constants.GETDATE(),
                    EndDate = Constants.GETDATE(),
                    TemplateId = item.TemplateId,
                    StatusId = Constants.INSPECTION_STATUS.SCHEDULED,
                    DateCreated = Constants.GETDATE(),
                    UserCreated = _userId

                };

                var inspectionPICAuditee = new TrInspectionPIC
                {
                    PicId = Constants.GETID(),
                    InspectionId = inspection.InspectionId,
                    UserId = item.Auditee.UserId,
                    UserGroupId = item.Auditee.UserGroupId,
                    UserTypeId = Constants.USER_TYPE.AUDITEE,
                    DateCreated = Constants.GETDATE(),
                    UserCreated = _userId
                };

                var inspectionPICAuditor = new TrInspectionPIC
                {
                    PicId = Constants.GETID(),
                    InspectionId = inspection.InspectionId,
                    UserId = item.Auditor.UserId,
                    UserGroupId = item.Auditor.UserGroupId,
                    UserTypeId = Constants.USER_TYPE.AUDITOR,
                    DateCreated = Constants.GETDATE(),
                    UserCreated = _userId
                };

                _unitOfWork.TrInspectionRepository.Add(inspection);
                _unitOfWork.TrInspectionPICRepository.Add(inspectionPICAuditee);
                _unitOfWork.TrInspectionPICRepository.Add(inspectionPICAuditor);
                _unitOfWork.Complete();

                var items = _unitOfWork.TrInspectionRepository.SelectByRole(inspection.InspectionId, null, null, null).AsEnumerable().FirstOrDefault();

                return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.CREATE, items));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpPost("Completed/{InspectionId}")]
        public IActionResult MarkAsCompleted(string InspectionId)
        {
            try
            {
                //_principal = HttpContext.User;
                //string userId = Helpers.GetSessionToken(Helpers.GetListClaim(_principal), "UserId");

                var inspection = _unitOfWork.TrInspectionRepository.Get(InspectionId);
                if (inspection == null)
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }
                else
                {
                    inspection.StatusId = Constants.INSPECTION_STATUS.COMPLETED;
                    inspection.CompletedBy = _userId;
                    inspection.CompletedDate = Constants.GETDATE();
                    inspection.DateModified = Constants.GETDATE();
                    inspection.UserModified = _userId;

                    _unitOfWork.TrInspectionRepository.Update(inspection);
                    _unitOfWork.Complete();

                    var items = _unitOfWork.TrInspectionRepository.SelectByRole(InspectionId, null, null, null).AsEnumerable();

                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.UPDATE, items));

                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpPost("Approval/{InspectionId}")]
        public IActionResult Approval(string InspectionId)
        {
            try
            {
                //_principal = HttpContext.User;
                //string userId = Helpers.GetSessionToken(Helpers.GetListClaim(_principal), "UserId");

                var inspection = _unitOfWork.TrInspectionRepository.Get(InspectionId);
                if (inspection == null)
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }
                else
                {
                    inspection.ApprovedBy = _userId;
                    inspection.ApprovedDate = Constants.GETDATE();
                    inspection.DateModified = Constants.GETDATE();
                    inspection.UserModified = _userId;

                    _unitOfWork.TrInspectionRepository.Update(inspection);
                    _unitOfWork.Complete();

                    var items = _unitOfWork.TrInspectionRepository.SelectByRole(InspectionId, null, null, null).AsEnumerable();

                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.UPDATE, items));

                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpDelete]
        public IActionResult Delete(string id)
        {
            try
            {
                var inspection = _unitOfWork.TrInspectionRepository.Get(id);

                if (inspection == null)
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }

                _unitOfWork.TrInspectionRepository.Delete(inspection, _userId, Constants.GETDATE());

                return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.DELETE, null));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        public void Validate(TrInspectionViewModel.CreateInspection model)
        {
            if (model.TemplateId != null)
            {
                if (!_unitOfWork.MTemplateRepository.GetAll().Any(i => i.IsDeleted == false && i.TemplateId == model.TemplateId))
                {
                    throw new Exception("Template Audit tidak valid");
                }
            }

            if (model.AuditLocationId != null)
            {
                if (!_unitOfWork.MAuditLocationRepository.GetAll().Any(i => i.IsDeleted == false && i.AuditLocationId == model.AuditLocationId))
                {
                    throw new Exception("Lokasi audit tidak valid");
                }
            }

            if (model.Auditee.UserGroupId != null)
            {
                if (!_unitOfWork.MUserGroupRepository.GetAll().Any(i => i.IsDeleted == false && i.UserGroupId == model.Auditee.UserGroupId))
                {
                    throw new Exception("Group auditee tidak valid");
                }
            }
            if (model.Auditee.UserId != null)
            {
                if (!_unitOfWork.MUserSyncRepository.GetAll().Any(i => i.IsDeleted == false && i.UserId == model.Auditee.UserId))
                {
                    throw new Exception("Auditee tidak valid");
                }
            }

            if (model.Auditor.UserGroupId != null)
            {
                if (!_unitOfWork.MUserGroupRepository.GetAll().Any(i => i.IsDeleted == false && i.UserGroupId == model.Auditor.UserGroupId))
                {
                    throw new Exception("Group auditor tidak valid");
                }
            }
            if (model.Auditor.UserId != null)
            {
                if (!_unitOfWork.MUserSyncRepository.GetAll().Any(i => i.IsDeleted == false && i.UserId == model.Auditor.UserId))
                {
                    throw new Exception("Auditor tidak valid");
                }
            }
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        public string ConvertSortParameter(string param)
        {
            string sortField = param;
            if (param.ToLower().Equals("duedate"))
            {
                sortField = "TargetClosing";
            }
            else if (param.ToLower().Equals("lastupdated"))
            {
                sortField = "DateModified";
            }
            else if (param.ToLower().Equals("datecreated"))
            {
                sortField = "DateCreated";
            }

            return sortField;
        }
    }
}
