﻿using AutoMapper;
using DigitalAudit.Helper;
using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using DigitalAudit.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace DigitalAudit.API.Controllers.Transaction
{
    [Authorize]
    [Route("Inspection/Info")]
    [ApiController]
    public class TrInspectionInfoController : ControllerBase
    {
        private readonly ILogger<TrInspectionInfoController> _logger;
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;
        private readonly IWebHostEnvironment _webHostEnvironment;
        private ClaimsPrincipal _principal;


        public TrInspectionInfoController(
            IUnitOfWork unitOfWork,
            ILogger<TrInspectionInfoController> logger,
            IMapper mapper,
            IWebHostEnvironment webHostEnvironment)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
            _mapper = mapper;
            _webHostEnvironment = webHostEnvironment;
        }

        [HttpGet("{InspectionId}")]
        public IActionResult Get(string InspectionId)
        {
            try
            {
                var inspectionInfo = _unitOfWork.TrInspectionInfoRepository.Select(InspectionId);                

                if (inspectionInfo.Count() > 0)
                {
                   

                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, inspectionInfo, inspectionInfo.Count(), inspectionInfo.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }
        
        [HttpPost]
        public IActionResult Post([FromBody]TrInspectionInfoViewModel.CreateInspectionInfo param)
        {
            try
            {
                var info = new TrInspectionInfo
                {
                    InspectionId = param.InspectionId,
                    InfoId = Constants.GETID(),
                    Notes = param.Notes,
                    Title = param.Title,
                    IsDeleted = false,
                    DateCreated = Constants.GETDATE(),
                    UserCreated = param.UserCreated
                };

                _unitOfWork.TrInspectionInfoRepository.Add(info);
                _unitOfWork.Complete();

                var result = _unitOfWork.TrInspectionInfoRepository.SelectOne(info.InfoId);

                return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.CREATE, result, 1, 1));

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpDelete("{InfoId}")]
        public IActionResult Delete(string InfoId)
        {
            try
            {
                _principal = HttpContext.User;
                string userId = Helpers.GetSessionToken(Helpers.GetListClaim(_principal), "UserId");

                var info = _unitOfWork.TrInspectionInfoRepository.Get(InfoId);

                if (info != null)
                {
                    info.IsDeleted = true;
                    info.DateModified = Constants.GETDATE();
                    info.UserModified = userId;

                    _unitOfWork.TrInspectionInfoRepository.Update(info);
                    _unitOfWork.Complete();

                    return Ok(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DELETE, null, 0, 0));

                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }
    }
}
