﻿using AutoMapper;
using DigitalAudit.Helper;
using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using DigitalAudit.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace DigitalAudit.API.Controllers.Transaction
{
    [Authorize]
    [Route("Inspection/Signature")]
    [ApiController]
    public class TrInspectionSignatureController : ControllerBase
    {
        private readonly ILogger<TrInspectionSignatureController> _logger;
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;
        private readonly IWebHostEnvironment _webHostEnvironment;
        private ClaimsPrincipal _principal;
        private string _userId;

        public TrInspectionSignatureController(
            IUnitOfWork unitOfWork,
            ILogger<TrInspectionSignatureController> logger,
            IMapper mapper,
            IWebHostEnvironment webHostEnvironment,
            IHttpContextAccessor httpContextAccessor)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
            _mapper = mapper;
            _webHostEnvironment = webHostEnvironment;
            _userId = httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier) == null ? "" : httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
        }

        [HttpGet("{InspectionId}")]
        public IActionResult Get(string InspectionId)
        {
            try
            {
                var inspectionSignature = _unitOfWork.TrInspectionSignatureRepository.Select(InspectionId).ToList();
                string baseURL = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}";

                if (inspectionSignature.Count() > 0)
                {
                    inspectionSignature.Select(x =>
                    {
                        if (!string.IsNullOrEmpty(x.Signature))
                        {
                            x.Signature = baseURL + "/" + "inspection/signature/download" + "/" + x.SignatureId;
                        }
                        return x;

                    }).ToList();

                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, inspectionSignature, inspectionSignature.Count(), inspectionSignature.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [Route("Download/{id}")]
        [HttpGet]
        [AllowAnonymous]
        public ActionResult Download(string id)
        {
            var sign = _unitOfWork.TrInspectionSignatureRepository.Get(id);

            string webRootPath = _webHostEnvironment.ContentRootPath;
            string configTemplate = Configs.AppConfig.UploadPath.ImportFileInspection;
            string path = webRootPath + configTemplate + "\\" + sign.InspectionId + "\\Signature";
            string fullPath = Path.Combine(path, sign.Signature);

            var provider = new FileExtensionContentTypeProvider();
            string contentType;

            if (!provider.TryGetContentType(fullPath, out contentType))
            {
                contentType = "application/octet-stream";
            }

            return PhysicalFile(fullPath, contentType, sign.Signature);
        }

        [HttpPost]
        public async Task<IActionResult> PostAsync([FromForm] TrInspectionSignatureViewModel.CreateInspectionSignature param)
        {
            try
            {
                string webRootPath = _webHostEnvironment.ContentRootPath;
                string configInspection = Configs.AppConfig.UploadPath.ImportFileInspection;
                string path = webRootPath + configInspection + "\\" + param.InspectionId;

                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                path = path + "\\Signature";

                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                var files = HttpContext.Request.Form.Files;
                var file = files.FirstOrDefault();
               
                var fileName = file.FileName;
                string fullPath = Path.Combine(path, fileName);

                if (System.IO.File.Exists(fullPath))
                {
                    string extension = Path.GetExtension(fileName).ToLower();
                    fileName = Path.GetFileNameWithoutExtension(fileName) + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + extension;
                    fullPath = Path.Combine(path, fileName);
                }

                using (var stream = new FileStream(fullPath, FileMode.Create))
                {
                    await file.CopyToAsync(stream);                    
                }

                var sign = new TrInspectionSignature
                {
                    InspectionId = param.InspectionId,
                    SignatureId = Constants.GETID(),
                    Name = param.Name,
                    Title = param.Title,
                    Signature = fileName,
                    IsDeleted = false,
                    DateCreated = Constants.GETDATE(),
                    UserCreated = param.UserCreated
                };

                _unitOfWork.TrInspectionSignatureRepository.Add(sign);
                _unitOfWork.Complete();

                var result = _unitOfWork.TrInspectionSignatureRepository.SelectOne(sign.SignatureId);

                return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.CREATE, result, 1, 1));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpDelete("{SignatureId}")]
        public IActionResult Delete(string SignatureId)
        {
            try
            {
                _principal = HttpContext.User;
                string userId = Helpers.GetSessionToken(Helpers.GetListClaim(_principal), "UserId");

                var sign = _unitOfWork.TrInspectionSignatureRepository.Get(SignatureId);

                if (sign != null)
                {
                    sign.IsDeleted = true;
                    sign.DateModified = Constants.GETDATE();
                    sign.UserModified = userId;

                    _unitOfWork.TrInspectionSignatureRepository.Update(sign);
                    _unitOfWork.Complete();

                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.DELETE, null, 0, 0));

                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }
    }
}
