﻿using AutoMapper;
using DigitalAudit.Helper;
using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using DigitalAudit.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace DigitalAudit.API.Controllers.Transaction
{
    [Authorize]
    [ApiController]
    [Route("Inspection/Result")]
    public class TrInspectionResultController : ControllerBase
    {
        private readonly ILogger<TrInspectionResultController> _logger;
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;
        private readonly IWebHostEnvironment _webHostEnvironment;
        private ClaimsPrincipal _principal;


        public TrInspectionResultController(
            IUnitOfWork unitOfWork,
            ILogger<TrInspectionResultController> logger,
            IMapper mapper,
            IWebHostEnvironment webHostEnvironment)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
            _mapper = mapper;
            _webHostEnvironment = webHostEnvironment;
        }

        

        [HttpPost]
        public IActionResult Post([FromBody] TrInspectionResultViewModel.CreateInspectionResult item)
        {
            try
            {
                _principal = HttpContext.User;
                string userId = Helpers.GetSessionToken(Helpers.GetListClaim(_principal), "UserId");

                //Validate(item);

                var result = _unitOfWork.TrInspectionResultRepository.GetAll()
                    .FirstOrDefault(x => x.IsDeleted == false && x.InspectionId == item.InspectionId && x.QuestionId == item.QuestionId);

                if (result != null)
                {
                    result.AnswerId = item.AnswerId;
                    result.AnswerText = item.AnswerText;
                    result.Notes = item.Notes;
                    result.DateModified = Constants.GETDATE();
                    result.UserModified = item.UserCreated;

                    _unitOfWork.TrInspectionResultRepository.Update(result);
                    _unitOfWork.Complete();

                    Issue(item.AnswerId, item.InspectionId, item.QuestionId, item.UserCreated);

                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.UPDATE, result));
                }
                else
                {
                    var inspectionResult = new TrInspectionResult
                    {
                        ResultId = Constants.GETID(),
                        InspectionId = item.InspectionId,
                        QuestionId = item.QuestionId,
                        AnswerId = item.AnswerId,
                        AnswerText = item.AnswerText,
                        Notes = item.Notes,
                        DateCreated = Constants.GETDATE(),
                        UserCreated = item.UserCreated

                    };

                    _unitOfWork.TrInspectionResultRepository.Add(inspectionResult);
                    _unitOfWork.Complete();

                    Issue(item.AnswerId, item.InspectionId, item.QuestionId, item.UserCreated);

                    var items = _unitOfWork.TrInspectionResultRepository.Get(inspectionResult.ResultId);

                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.CREATE, items));
                }
                
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        public void Issue(int? AnswerId, string InspectionId, int QuestionId, string UserId) 
        {
            #region Masuk ke Issue jika termasuk response gagal
            if (AnswerId != null)
            {
                var resultList = _unitOfWork.MResponseListRepository.SelectOne(Convert.ToInt32(AnswerId));

                if (resultList != null)
                {
                    if (resultList.IsFailedResponse)
                    {
                        #region insert to issue
                        var issue = _unitOfWork.TrIssueRepository.AddIssueFromInspection(InspectionId, QuestionId, UserId);
                        #endregion
                    }
                    else
                    {
                        var issues = _unitOfWork.TrIssueRepository.GetAll()
                            .Where(x => x.IsDeleted == false && x.QuestionId == QuestionId.ToString() && x.InspectionId == InspectionId);

                        foreach (var issue in issues)
                        {
                            issue.IsDeleted = true;
                            issue.DateModified = Constants.GETDATE();
                            issue.UserModified = UserId;

                            _unitOfWork.TrIssueRepository.Update(issue);
                            
                        }
                        _unitOfWork.Complete();
                    }
                }
            }

            #endregion
        }
    }
}
