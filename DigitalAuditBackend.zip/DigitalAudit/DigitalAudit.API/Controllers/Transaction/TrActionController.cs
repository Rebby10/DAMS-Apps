﻿using AutoMapper;
using DigitalAudit.Helper;
using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using DigitalAudit.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace DigitalAudit.API.Controllers.Transaction
{
    [Authorize]
    [ApiController]
    [Route("Action")]
    public class TrActionController : ControllerBase
    {
        private readonly ILogger<TrActionController> _logger;
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;
        private readonly IWebHostEnvironment _webHostEnvironment;
        private string _userId;


        public TrActionController(
            IUnitOfWork unitOfWork,
            ILogger<TrActionController> logger,
            IMapper mapper,
            IWebHostEnvironment webHostEnvironment, 
            IHttpContextAccessor httpContextAccessor)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
            _mapper = mapper;
            _webHostEnvironment = webHostEnvironment;
            _userId = httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier) == null ? "" : httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
        }

        [HttpGet]
        [Route("query")]
        public IActionResult Get([FromQuery] TrActionViewModel.QueryAction param)
        {
            try
            {
                #region  check user role
                var userRole = _unitOfWork.MUserRoleRepository.GetAll().FirstOrDefault(f => f.UserId == _userId);

                if (userRole != null)
                {
                    if (userRole.RoleId == Constants.ROLE.ADMIN_PUSAT)
                    {
                        _userId = null; // admin pusat bisa lihat semua data, tidak di filter berdasarkan userId
                    }
                    else if (userRole.RoleId == Constants.ROLE.ADMIN_REGION)
                    {
                        if (param.RegionId == null) // Jika param region gk diisi, ngikutin region user role
                        {
                            param.RegionId = userRole.RegionId;
                            _userId = null;
                        }
                    }
                    else if (userRole.RoleId == Constants.ROLE.ADMIN_LOKASI)
                    {
                        if (param.AuditLocationId == null) //Jika param lokasi audit tidak diisi, ngikutin lokasi user role
                        {
                            param.AuditLocationId = userRole.AuditLocationId;
                            _userId = null;
                        }
                    }
                }

                #endregion

                var items = _unitOfWork.TrActionRepository
                    .SelectAll(param.ActionId, param.Title, param.AuditLocationId, param.PriorityId, param.StatusId, _userId,
                    param.AssignUser, param.StartDate, param.EndDate, param.AuditTypeId, param.IsConnectedToIssue, param.RegionId, param.IssueId).AsEnumerable();


                if (!string.IsNullOrEmpty(param.QuestionId))
                    items = items.Where(i => i.QuestionId == param.QuestionId.Trim());

                if (!string.IsNullOrEmpty(param.InspectionId))
                    items = items.Where(i => i.InspectionId == param.InspectionId.Trim());

                if (!string.IsNullOrEmpty(param.sort_by))
                {
                    var orderByExpression = Helpers.GetOrderByExpression<fn_Get_Action>(ConvertSortParameter(param.sort_by));
                    items = Helpers.OrderByDir(items, param.order_by, orderByExpression);
                }
                else
                {
                    var orderByExpression = Helpers.GetOrderByExpression<fn_Get_Action>(ConvertSortParameter("DateCreated"));
                    items = Helpers.OrderByDir(items, "desc", orderByExpression);
                }

                if (param.page_size != null && param.page_number != null)
                {
                    items = Helpers.Page(items, param.page_size.Value, param.page_number.Value);
                }

                if (items.Count() > 0)
                {
                    var responseData = _mapper.Map<List<fn_Get_Action>, List<TrActionViewModel.ReadAction>>(items.ToList());
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, responseData, responseData.Count(), responseData.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpGet]
        [Route("assignee")]
        public IActionResult GetAssignee([FromQuery] MUserSyncViewModel.QueryUserSync param)
        {
            try
            {
                var items = _unitOfWork.MUserRoleRepository.SelectAll(null, null, null, null).Select(x => new MUserSyncViewModel.ReadUserAuditee
                {
                    Id = x.UserId,
                    DisplayName = x.DisplayName + " (" + x.Username + ")",
                    IsGroup = false
                })
                .Union(_unitOfWork.MUserGroupRepository.GetAll().Where(w => w.IsDeleted == false).Select(x => new MUserSyncViewModel.ReadUserAuditee
                {
                    Id = x.UserGroupId,
                    DisplayName = x.Name,
                    IsGroup = true
                }));

                if (!string.IsNullOrEmpty(param.id))
                {
                    items = items.Where(x => x.Id.ToLower().Equals(param.id));
                }

                if (!string.IsNullOrEmpty(param.name))
                {
                    items = items.Where(x => x.DisplayName.ToLower().Contains(param.name.ToLower()));
                }      

                if (!string.IsNullOrEmpty(param.sort_by))
                {
                    var orderByExpression = Helpers.GetOrderByExpression<MUserSyncViewModel.ReadUserAuditee>(ConvertSortParameter(param.sort_by));
                    items = Helpers.OrderByDir(items, param.order_by, orderByExpression).AsEnumerable();
                }
                else
                {
                    items = items.OrderBy(o => o.IsGroup).ThenBy(o => o.DisplayName);
                }

                if (param.page_size != null && param.page_number != null)
                {
                    items = Helpers.Page(items, param.page_size.Value, param.page_number.Value);
                }

                if (items.Count() > 0)
                {
                   // items = items.OrderBy(o => o.IsGroup).ThenBy(o => o.DisplayName);
                    //return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.READ, items.OrderBy(o => o.IsGroup).ThenBy(o => o.DisplayName).Skip(page_size * (page_number - 1)).Take(page_size)));
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, items.Count(), items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return Ok(new StatusModel(ex));
            }
        }

        [HttpGet("{id}")]
        public IActionResult Get(string id)
        {
            try
            {
                var items = _unitOfWork.TrActionRepository.SelectOne(id);

                if (items != null)
                {
                    var responseData = _mapper.Map<fn_Get_Action, TrActionViewModel.ReadAction>(items);
                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.READ, responseData));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [Route("DownloadError/{id}")]
        [HttpGet]
        public async Task<IActionResult> DownloadError(string id)
        {
            string sFileName = Guid.NewGuid().ToString() + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".xlsx";

            string sWebRootFolder = _webHostEnvironment.ContentRootPath;

            string configPath = Configs.AppConfig.UploadPath.DownloadErrorAction;
            string path = sWebRootFolder + configPath;

            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }

            var memory = new MemoryStream();
            using (var fs = new FileStream(Path.Combine(path, sFileName), FileMode.Create, FileAccess.Write))
            {
                IWorkbook workbook;
                workbook = new XSSFWorkbook();
                ISheet excelSheet = workbook.CreateSheet("Action");
                IRow row = excelSheet.CreateRow(0);

                string[] header = { "Title", "Description", "Question Id", "Question Code", "Question"
                        , "Audit Location", "Region", "Lat Long", "Group Name", "Group Leader"
                        , "Assign User", "Creator", "Priority", "Audit Type", "Target Closing", "Action Status", "Error Message"  };

                int idx_header = 0;
                foreach (string i in header.ToList())
                {
                    row.CreateCell(idx_header).SetCellValue(i);
                    idx_header = idx_header + 1;
                }

                var items = _unitOfWork.TrActionImportRepository.GetActionImport(id);

                int idx_data = 0;
                foreach (var d in items)
                {
                    idx_data = idx_data + 1;
                    row = excelSheet.CreateRow(idx_data);
                    row.CreateCell(0).SetCellValue(d.Title);
                    row.CreateCell(1).SetCellValue(d.Descriptions);
                    row.CreateCell(2).SetCellValue(d.QuestionId);
                    row.CreateCell(3).SetCellValue(d.Code);
                    row.CreateCell(4).SetCellValue(d.Question);
                    row.CreateCell(5).SetCellValue(d.LocationName);
                    row.CreateCell(6).SetCellValue(d.Region);
                    row.CreateCell(7).SetCellValue(d.LatLong);
                    row.CreateCell(8).SetCellValue(d.UserGroupName);
                    row.CreateCell(9).SetCellValue(d.GroupLeader);
                    row.CreateCell(10).SetCellValue(d.AssignUser);
                    row.CreateCell(11).SetCellValue(d.Creator);
                    row.CreateCell(12).SetCellValue(d.Priority);
                    row.CreateCell(13).SetCellValue(d.AuditType);
                    row.CreateCell(14).SetCellValue(d.TargetClosing.ToString("g"));
                    row.CreateCell(15).SetCellValue(d.ActionStatus);
                    row.CreateCell(16).SetCellValue(d.ErrorMessage);
                }

                workbook.Write(fs);
            }
            using (var stream = new FileStream(Path.Combine(path, sFileName), FileMode.Open))
            {
                await stream.CopyToAsync(memory);
            }
            memory.Position = 0;
            return File(memory, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", sFileName);
        }

        [HttpGet]
        [Route("Template")]
        public async Task<ActionResult> GenerateTemplateAsync()
        {
            XSSFWorkbook wb;
            XSSFSheet sh;
            XSSFSheet shAuditLocation;
            XSSFSheet shUserGroup;
            XSSFSheet shPriority;
            XSSFSheet shAuditType;
            XSSFSheet shActionStatus;

            string filename = Guid.NewGuid() + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".xlsx";

            string sWebRootFolder = _webHostEnvironment.ContentRootPath;

            string configTemplate = Configs.AppConfig.UploadPath.TemplateAction;
            string pathTemplate = sWebRootFolder + configTemplate;

            if (!Directory.Exists(pathTemplate))
            {
                Directory.CreateDirectory(pathTemplate);
            }

            string URL = string.Format("{0}://{1}/{2}", Request.Scheme, Request.Host, filename);
            FileInfo file = new FileInfo(Path.Combine(pathTemplate, filename));
            var memory = new MemoryStream();
            using (var fs = new FileStream(Path.Combine(pathTemplate, filename), FileMode.Create, FileAccess.Write))
            {
                wb = new XSSFWorkbook();

                #region STYLING HEADER
                IFont boldFont = wb.CreateFont();
                boldFont.Boldweight = (short)FontBoldWeight.Bold;
                ICellStyle HeaderStyle = wb.CreateCellStyle();
                HeaderStyle.SetFont(boldFont);

                HeaderStyle.BorderBottom = BorderStyle.Thin;
                HeaderStyle.BorderTop = BorderStyle.Thin;
                HeaderStyle.BorderLeft = BorderStyle.Thin;
                HeaderStyle.BorderRight = BorderStyle.Thin;

                HeaderStyle.FillForegroundColor = NPOI.HSSF.Util.HSSFColor.LightOrange.Index;
                HeaderStyle.FillPattern = FillPattern.SolidForeground;
                #endregion

                #region STYLING BODY
                IFont NormalFont = wb.CreateFont();
                ICellStyle BodyStyle = wb.CreateCellStyle();
                BodyStyle.SetFont(NormalFont);

                BodyStyle.BorderBottom = BorderStyle.Thin;
                BodyStyle.BorderTop = BorderStyle.Thin;
                BodyStyle.BorderLeft = BorderStyle.Thin;
                BodyStyle.BorderRight = BorderStyle.Thin;
                #endregion

                #region CREATE SHEET TEMPLATE
                sh = (XSSFSheet)wb.CreateSheet("Sheet1");

                int i = 0;

                if (sh.GetRow(i) == null)
                    sh.CreateRow(i);

                if (sh.GetRow(i).GetCell(0) == null)
                {
                    sh.GetRow(i).CreateCell(0).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(0).SetCellValue("Title");
                }

                if (sh.GetRow(i).GetCell(1) == null)
                {
                    sh.GetRow(i).CreateCell(1).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(1).SetCellValue("Description");
                }

                if (sh.GetRow(i).GetCell(2) == null)
                {
                    sh.GetRow(i).CreateCell(2).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(2).SetCellValue("Question Id");
                }

                if (sh.GetRow(i).GetCell(3) == null)
                {
                    sh.GetRow(i).CreateCell(3).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(3).SetCellValue("Question Code");
                }

                if (sh.GetRow(i).GetCell(4) == null)
                {
                    sh.GetRow(i).CreateCell(4).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(4).SetCellValue("Question");
                }

                if (sh.GetRow(i).GetCell(5) == null)
                {
                    sh.GetRow(i).CreateCell(5).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(5).SetCellValue("Audit Location Id");
                }

                //if (sh.GetRow(i).GetCell(6) == null)
                //{
                //    sh.GetRow(i).CreateCell(6).CellStyle = HeaderStyle;
                //    sh.GetRow(i).GetCell(6).SetCellValue("Location Name");
                //}

                //if (sh.GetRow(i).GetCell(7) == null)
                //{
                //    sh.GetRow(i).CreateCell(7).CellStyle = HeaderStyle;
                //    sh.GetRow(i).GetCell(7).SetCellValue("Region");
                //}

                if (sh.GetRow(i).GetCell(6) == null)
                {
                    sh.GetRow(i).CreateCell(6).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(6).SetCellValue("Assign Group");
                }

                //if (sh.GetRow(i).GetCell(9) == null)
                //{
                //    sh.GetRow(i).CreateCell(9).CellStyle = HeaderStyle;
                //    sh.GetRow(i).GetCell(9).SetCellValue("Group Name");
                //}

                //if (sh.GetRow(i).GetCell(10) == null)
                //{
                //    sh.GetRow(i).CreateCell(10).CellStyle = HeaderStyle;
                //    sh.GetRow(i).GetCell(10).SetCellValue("Group Leader");
                //}


                if (sh.GetRow(i).GetCell(7) == null)
                {
                    sh.GetRow(i).CreateCell(7).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(7).SetCellValue("Assign User");
                }

                if (sh.GetRow(i).GetCell(8) == null)
                {
                    sh.GetRow(i).CreateCell(8).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(8).SetCellValue("Creator");
                }

                if (sh.GetRow(i).GetCell(9) == null)
                {
                    sh.GetRow(i).CreateCell(9).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(9).SetCellValue("Priority Id");
                }

                //if (sh.GetRow(i).GetCell(14) == null)
                //{
                //    sh.GetRow(i).CreateCell(14).CellStyle = HeaderStyle;
                //    sh.GetRow(i).GetCell(14).SetCellValue("Priority");
                //}

                if (sh.GetRow(i).GetCell(10) == null)
                {
                    sh.GetRow(i).CreateCell(10).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(10).SetCellValue("Target Closing");
                }

                if (sh.GetRow(i).GetCell(11) == null)
                {
                    sh.GetRow(i).CreateCell(11).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(11).SetCellValue("Action Status Id");
                }

                //if (sh.GetRow(i).GetCell(17) == null)
                //{
                //    sh.GetRow(i).CreateCell(17).CellStyle = HeaderStyle;
                //    sh.GetRow(i).GetCell(17).SetCellValue("Action Status");
                //}

                if (sh.GetRow(i).GetCell(12) == null)
                {
                    sh.GetRow(i).CreateCell(12).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(12).SetCellValue("Audit Type");
                }
                #endregion

                #region CREATE SHEET MASTER AUDIT LOCATION
                shAuditLocation = (XSSFSheet)wb.CreateSheet("Audit Location");

                i = 0;

                #region HEADER
                if (shAuditLocation.GetRow(i) == null)
                    shAuditLocation.CreateRow(i);

                if (shAuditLocation.GetRow(i).GetCell(0) == null)
                {
                    shAuditLocation.GetRow(i).CreateCell(0).CellStyle = HeaderStyle;
                    shAuditLocation.GetRow(i).GetCell(0).SetCellValue("Audit Location ID");
                }

                if (shAuditLocation.GetRow(i).GetCell(1) == null)
                {
                    shAuditLocation.GetRow(i).CreateCell(1).CellStyle = HeaderStyle;
                    shAuditLocation.GetRow(i).GetCell(1).SetCellValue("Location Name");
                }

                if (shAuditLocation.GetRow(i).GetCell(2) == null)
                {
                    shAuditLocation.GetRow(i).CreateCell(2).CellStyle = HeaderStyle;
                    shAuditLocation.GetRow(i).GetCell(2).SetCellValue("Region");
                }
                #endregion

                #region BODY
                List<fn_Get_MAuditLocation> ListAuditLocation = _unitOfWork.MAuditLocationRepository.Get_MAuditLocation(null, null, null);

                i += 1;

                foreach (fn_Get_MAuditLocation AuditLocation in ListAuditLocation.OrderBy(O => O.AuditLocationId))
                {
                    if (shAuditLocation.GetRow(i) == null)
                        shAuditLocation.CreateRow(i);

                    if (shAuditLocation.GetRow(i).GetCell(0) == null)
                    {
                        shAuditLocation.GetRow(i).CreateCell(0).CellStyle = BodyStyle;
                        shAuditLocation.GetRow(i).GetCell(0).SetCellValue(AuditLocation.ID);
                    }

                    if (shAuditLocation.GetRow(i).GetCell(1) == null)
                    {
                        shAuditLocation.GetRow(i).CreateCell(1).CellStyle = BodyStyle;
                        shAuditLocation.GetRow(i).GetCell(1).SetCellValue(AuditLocation.Name);
                    }

                    if (shAuditLocation.GetRow(i).GetCell(2) == null)
                    {
                        shAuditLocation.GetRow(i).CreateCell(2).CellStyle = BodyStyle;
                        shAuditLocation.GetRow(i).GetCell(2).SetCellValue(AuditLocation.RegionName);
                    }

                    i += 1;
                }
                #endregion

                #endregion

                #region CREATE SHEET MASTER USER GROUP
                shUserGroup = (XSSFSheet)wb.CreateSheet("User Group");

                i = 0;

                #region HEADER
                if (shUserGroup.GetRow(i) == null)
                    shUserGroup.CreateRow(i);

                if (shUserGroup.GetRow(i).GetCell(0) == null)
                {
                    shUserGroup.GetRow(i).CreateCell(0).CellStyle = HeaderStyle;
                    shUserGroup.GetRow(i).GetCell(0).SetCellValue("User Group ID");
                }

                if (shUserGroup.GetRow(i).GetCell(1) == null)
                {
                    shUserGroup.GetRow(i).CreateCell(1).CellStyle = HeaderStyle;
                    shUserGroup.GetRow(i).GetCell(1).SetCellValue("Group Name");
                }

                if (shUserGroup.GetRow(i).GetCell(2) == null)
                {
                    shUserGroup.GetRow(i).CreateCell(2).CellStyle = HeaderStyle;
                    shUserGroup.GetRow(i).GetCell(2).SetCellValue("Group Leader");
                }

                if (shUserGroup.GetRow(i).GetCell(3) == null)
                {
                    shUserGroup.GetRow(i).CreateCell(3).CellStyle = HeaderStyle;
                    shUserGroup.GetRow(i).GetCell(3).SetCellValue("User Type");
                }
                #endregion

                #region BODY
                i += 1;
                List<fn_Get_MUserGroup> ListUserGroup = _unitOfWork.MUserGroupRepository.Get_MUserGroup(null, null);

                foreach (fn_Get_MUserGroup item in ListUserGroup)
                {
                    if (shUserGroup.GetRow(i) == null)
                        shUserGroup.CreateRow(i);

                    if (shUserGroup.GetRow(i).GetCell(0) == null)
                    {
                        shUserGroup.GetRow(i).CreateCell(0).CellStyle = BodyStyle;
                        shUserGroup.GetRow(i).GetCell(0).SetCellValue(item.ID);
                    }

                    if (shUserGroup.GetRow(i).GetCell(1) == null)
                    {
                        shUserGroup.GetRow(i).CreateCell(1).CellStyle = BodyStyle;
                        shUserGroup.GetRow(i).GetCell(1).SetCellValue(item.Name);
                    }

                    if (shUserGroup.GetRow(i).GetCell(2) == null)
                    {
                        shUserGroup.GetRow(i).CreateCell(2).CellStyle = BodyStyle;
                        shUserGroup.GetRow(i).GetCell(2).SetCellValue(item.UserId);
                    }

                    if (shUserGroup.GetRow(i).GetCell(3) == null)
                    {
                        shUserGroup.GetRow(i).CreateCell(3).CellStyle = BodyStyle;
                        shUserGroup.GetRow(i).GetCell(3).SetCellValue(item.UserType);
                    }

                    i += 1;
                }


                #endregion

                #endregion

                #region CREATE SHEET MASTER PRIORITY
                shPriority = (XSSFSheet)wb.CreateSheet("Priority");

                i = 0;

                #region HEADER
                if (shPriority.GetRow(i) == null)
                    shPriority.CreateRow(i);

                if (shPriority.GetRow(i).GetCell(0) == null)
                {
                    shPriority.GetRow(i).CreateCell(0).CellStyle = HeaderStyle;
                    shPriority.GetRow(i).GetCell(0).SetCellValue("Priority ID");
                }

                if (shPriority.GetRow(i).GetCell(1) == null)
                {
                    shPriority.GetRow(i).CreateCell(1).CellStyle = HeaderStyle;
                    shPriority.GetRow(i).GetCell(1).SetCellValue("Name");
                }

                #endregion

                #region BODY
                i += 1;
                List<MPriority> ListPriority = _unitOfWork.MPriorityRepository.GetAllPriority();

                foreach (MPriority item in ListPriority)
                {
                    if (shPriority.GetRow(i) == null)
                        shPriority.CreateRow(i);

                    if (shPriority.GetRow(i).GetCell(0) == null)
                    {
                        shPriority.GetRow(i).CreateCell(0).CellStyle = BodyStyle;
                        shPriority.GetRow(i).GetCell(0).SetCellValue(item.PriorityId);
                    }

                    if (shPriority.GetRow(i).GetCell(1) == null)
                    {
                        shPriority.GetRow(i).CreateCell(1).CellStyle = BodyStyle;
                        shPriority.GetRow(i).GetCell(1).SetCellValue(item.Name);
                    }


                    i += 1;
                }


                #endregion

                #endregion



                #region CREATE SHEET MASTER AUDIT TYPE
                shAuditType = (XSSFSheet)wb.CreateSheet("Audit Type");

                i = 0;

                #region HEADER
                if (shAuditType.GetRow(i) == null)
                    shAuditType.CreateRow(i);

                if (shAuditType.GetRow(i).GetCell(0) == null)
                {
                    shAuditType.GetRow(i).CreateCell(0).CellStyle = HeaderStyle;
                    shAuditType.GetRow(i).GetCell(0).SetCellValue("Audit Type ID");
                }

                if (shAuditType.GetRow(i).GetCell(1) == null)
                {
                    shAuditType.GetRow(i).CreateCell(1).CellStyle = HeaderStyle;
                    shAuditType.GetRow(i).GetCell(1).SetCellValue("Name");
                }

                #endregion

                #region BODY
                i += 1;
                List<MAuditType> ListAuditType = _unitOfWork.MAuditTypeRepository.GetAll().ToList();

                foreach (MAuditType item in ListAuditType)
                {
                    if (shAuditType.GetRow(i) == null)
                        shAuditType.CreateRow(i);

                    if (shAuditType.GetRow(i).GetCell(0) == null)
                    {
                        shAuditType.GetRow(i).CreateCell(0).CellStyle = BodyStyle;
                        shAuditType.GetRow(i).GetCell(0).SetCellValue(item.ID);
                    }

                    if (shAuditType.GetRow(i).GetCell(1) == null)
                    {
                        shAuditType.GetRow(i).CreateCell(1).CellStyle = BodyStyle;
                        shAuditType.GetRow(i).GetCell(1).SetCellValue(item.Name);
                    }


                    i += 1;
                }


                #endregion

                #endregion


                #region CREATE SHEET MASTER ACTION STATUS
                shActionStatus = (XSSFSheet)wb.CreateSheet("Action Status");

                i = 0;

                #region HEADER
                if (shActionStatus.GetRow(i) == null)
                    shActionStatus.CreateRow(i);

                if (shActionStatus.GetRow(i).GetCell(0) == null)
                {
                    shActionStatus.GetRow(i).CreateCell(0).CellStyle = HeaderStyle;
                    shActionStatus.GetRow(i).GetCell(0).SetCellValue("Action Status ID");
                }

                if (shActionStatus.GetRow(i).GetCell(1) == null)
                {
                    shActionStatus.GetRow(i).CreateCell(1).CellStyle = HeaderStyle;
                    shActionStatus.GetRow(i).GetCell(1).SetCellValue("Name");
                }

                #endregion

                #region BODY
                i += 1;
                List<MActionStatus> ListActionStatus = _unitOfWork.MActionStatusRepository.GetAll().ToList();

                foreach (MActionStatus item in ListActionStatus)
                {
                    if (shActionStatus.GetRow(i) == null)
                        shActionStatus.CreateRow(i);

                    if (shActionStatus.GetRow(i).GetCell(0) == null)
                    {
                        shActionStatus.GetRow(i).CreateCell(0).CellStyle = BodyStyle;
                        shActionStatus.GetRow(i).GetCell(0).SetCellValue(item.StatusId);
                    }

                    if (shActionStatus.GetRow(i).GetCell(1) == null)
                    {
                        shActionStatus.GetRow(i).CreateCell(1).CellStyle = BodyStyle;
                        shActionStatus.GetRow(i).GetCell(1).SetCellValue(item.Name);
                    }


                    i += 1;
                }


                #endregion

                #endregion


                wb.Write(fs);
            }

            using (var stream = new FileStream(Path.Combine(pathTemplate, filename), FileMode.Open))
            {
                await stream.CopyToAsync(memory);
            }
            memory.Position = 0;
            return File(memory, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", filename);
        }

        [AllowAnonymous]
        [HttpPost]
        [Route("Import")]
        public ActionResult Import([FromForm] TrActionViewModel.ImportAction param)
        {
            try
            {
                string baseURL = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}";
                StatusViewModel statusUpload = new StatusViewModel();
                string sessionId = Constants.GETID();
                IFormFile file = param.File;
                string webRootPath = _webHostEnvironment.ContentRootPath;
                string configTemplate = Configs.AppConfig.UploadPath.ImportAction;
                string pathTemplate = webRootPath + configTemplate;
                StringBuilder sb = new StringBuilder();
                if (!Directory.Exists(pathTemplate))
                {
                    Directory.CreateDirectory(pathTemplate);
                }

                string fileName = "Import_" + Constants.GETID() + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".xlsx";

                _unitOfWork.TrActionImportSessionRepository.Add(new TrActionImportSession(sessionId, Constants.GETDATE(), fileName, false, false, Constants.DEFAULT_USER, Constants.GETDATE(), null, null));
                _unitOfWork.Complete();

                if (file.Length > 0)
                {
                    string sFileExtension = Path.GetExtension(file.FileName).ToLower();
                    ISheet sheet;
                    string fullPath = Path.Combine(pathTemplate, fileName);
                    using (var stream = new FileStream(fullPath, FileMode.Create))
                    {
                        file.CopyTo(stream);
                        stream.Position = 0;
                        if (sFileExtension == ".xls")
                        {
                            HSSFWorkbook hssfwb = new HSSFWorkbook(stream); //This will read the Excel 97-2000 formats  
                            sheet = hssfwb.GetSheetAt(0); //get first sheet from workbook  
                        }
                        else
                        {
                            XSSFWorkbook hssfwb = new XSSFWorkbook(stream); //This will read 2007 Excel format  
                            sheet = hssfwb.GetSheetAt(0); //get first sheet from workbook   
                        }
                        IRow headerRow = sheet.GetRow(0); //Get Header Row
                        int cellCount = headerRow.LastCellNum;

                        List<TrActionImport> trActions = new List<TrActionImport>();
                        for (int i = (sheet.FirstRowNum + 1); i <= sheet.LastRowNum; i++) //Read Excel File
                        {
                            IRow row = sheet.GetRow(i);
                            if (row == null) continue;
                            if (row.Cells.All(d => d.CellType == CellType.Blank)) continue;

                            var action = new TrActionImport
                            {
                                ActionImportId = Constants.GETID(),
                                SessionId = sessionId,
                                Title = row.GetCell(0, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? "" : row.GetCell(0, MissingCellPolicy.RETURN_NULL_AND_BLANK).ToString(),
                                Descriptions = row.GetCell(1, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? "" : row.GetCell(1, MissingCellPolicy.RETURN_NULL_AND_BLANK).ToString(),
                                QuestionId = row.GetCell(2, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? null : row.GetCell(2, MissingCellPolicy.RETURN_NULL_AND_BLANK).ToString(),
                                Code = row.GetCell(3, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? null : row.GetCell(3, MissingCellPolicy.RETURN_NULL_AND_BLANK).ToString(),
                                Question = row.GetCell(4, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? null : row.GetCell(4, MissingCellPolicy.RETURN_NULL_AND_BLANK).ToString(),
                                AuditLocationId = row.GetCell(5, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? "" : row.GetCell(5, MissingCellPolicy.RETURN_NULL_AND_BLANK).ToString(),
                                AssignGroup = row.GetCell(6, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? null : row.GetCell(6, MissingCellPolicy.RETURN_NULL_AND_BLANK).ToString(),
                                AssignUser = row.GetCell(7, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? null : row.GetCell(7, MissingCellPolicy.RETURN_NULL_AND_BLANK).ToString(),
                                Creator = _userId, //row.GetCell(8, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? null : row.GetCell(8, MissingCellPolicy.RETURN_NULL_AND_BLANK).ToString(),
                                PriorityId = row.GetCell(9, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? 0 : Convert.ToInt32(row.GetCell(9).ToString()),
                                TargetClosing = row.GetCell(10, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? DateTime.Now : Convert.ToDateTime(row.GetCell(10).ToString()),
                                StatusId = row.GetCell(11, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? 0 : Convert.ToInt32(row.GetCell(11).ToString()),
                                AuditTypeId = row.GetCell(12, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? null : row.GetCell(12).ToString(),
                                IsSuccess = null,
                                ErrorMessage = null,
                                IsDeleted = false,
                                UserCreated = _userId, // row.GetCell(8, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? "" : row.GetCell(8, MissingCellPolicy.RETURN_NULL_AND_BLANK).ToString(),
                                DateCreated = Constants.GETDATE(),
                                UserModified = null,
                                DateModified = null
                            };

                            trActions.Add(action);
                        }

                        _unitOfWork.TrActionImportRepository.AddLists(trActions);
                        _unitOfWork.Complete();

                        statusUpload = _unitOfWork.TrActionImportRepository.ActionImportValidate(sessionId, Constants.DEFAULT_USER);
                    }
                }

                if (statusUpload.IsSuccess == false)
                {
                    statusUpload.Messages = "Please check this file to check error data";
                }
                return Ok(new StatusModel(statusUpload.IsSuccess, statusUpload.Messages, baseURL + "/" + "Action/DownloadError/" + sessionId));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }

        }

        [HttpPost]
        public IActionResult Post([FromBody] TrActionViewModel.CreateAction item)
        {
            try
            {
                var action = new TrAction
                {
                    ActionId = Constants.GETID(),
                    Title = item.Title,
                    Descriptions = item.Descriptions,
                    IssueId = item.IssueId,
                    AuditLocationId = item.AuditLocationId,
                    AssignGroup = item.AssignGroup,
                    AssignUser = item.AssignUser,
                    Creator = item.Creator,
                    PriorityId = item.PriorityId,
                    TargetClosing = item.TargetClosing,
                    StatusId = item.StatusId,
                    InspectionId = item.InspectionId,
                    QuestionId = item.QuestionId,
                    Code = item.Code,
                    Question = item.Question,
                    DateCreated = Constants.GETDATE(),
                    UserCreated = _userId
                };

                Validate(action, Constants.CRUD.CREATE);

                _unitOfWork.TrActionRepository.Add(action);
                _unitOfWork.Complete();


                // Create Log
                var user = _unitOfWork.MUserSyncRepository.GetAll().Where(x => x.UserId.Equals(_userId ?? "")).FirstOrDefault();
                string TextLog = "telah membuat action ini";
                CreateLog(action, Convert.ToInt32(Constants.LOG_TYPE.STATUS), TextLog, user==null? "" : user.DisplayName);

                var dataAction = _unitOfWork.TrActionRepository.SelectAll(action.ActionId.Trim(), null, null, null, null, null, null, null, null, null, null, null, null).ToList();

                var responseData = _mapper.Map<List<fn_Get_Action>, List<TrActionViewModel.ReadAction>>(dataAction);

                return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.CREATE, responseData));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
            
        }

        [HttpPut]
        public IActionResult Put([FromBody] TrActionViewModel.UpdateAction item)
        {
            try
            {
                TrAction data = _unitOfWork.TrActionRepository.Get(item.ActionId.Trim());

                if (data != null)
                {
                    data.Title = item.Title;
                    data.Descriptions = item.Descriptions;
                    data.IssueId = item.IssueId;
                    data.AuditLocationId = item.AuditLocationId;
                    data.AssignGroup = item.AssignGroup;
                    data.AssignUser = item.AssignUser;
                    data.Creator = item.Creator;
                    data.PriorityId = item.PriorityId;
                    data.TargetClosing = item.TargetClosing;
                    data.StatusId = item.StatusId;

                    Validate(data, Constants.CRUD.UPDATE);

                    //data.AssignUser = data.AssignUser == null ? null : _unitOfWork.MUserSyncRepository.GetAll().FirstOrDefault(x => x.IsDeleted == false && x.UserId.Equals(data.AssignUser)).UserSyncId;
                    //data.Creator = data.Creator == null ? null : _unitOfWork.MUserSyncRepository.GetAll().FirstOrDefault(x => x.IsDeleted == false && x.UserId.Equals(data.Creator)).UserSyncId;

                    _unitOfWork.TrActionRepository.Update(data, _userId ?? "", Constants.GETDATE());
                    _unitOfWork.Complete();

                    var dataAction = _unitOfWork.TrActionRepository.SelectAll(data.ActionId.Trim(), null, null, null, null, null, null, null, null, null, null, null, null).ToList();
                    var responseData = _mapper.Map<List<fn_Get_Action>, List<TrActionViewModel.ReadAction>>(dataAction);

                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.UPDATE, responseData));
                    //return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.UPDATE, dataAction));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new StatusModel(ex));
            }
           
        }

        [HttpPut]
        [Route("Status")]
        public IActionResult PutStatus([FromBody] TrActionViewModel.UpdateStatusAction item)
        {
            try
            {
                TrAction data = _unitOfWork.TrActionRepository.Get(item.ActionId.Trim());

                if (data != null)
                {
                    var statusOld = _unitOfWork.MIssueStatusRepository.SelectOne(data.StatusId);
                    var statusNew = _unitOfWork.MIssueStatusRepository.SelectOne(item.StatusId);

                    if (statusOld == null || statusNew == null)
                    {
                        throw new Exception("Status tidak valid");
                    }

                    data.StatusId = item.StatusId;

                    // Hanya update status tidak perlu cek data.
                    //Validate(data, Constants.CRUD.UPDATE);

                    _unitOfWork.TrActionRepository.Update(data, _userId ?? "", Constants.GETDATE());
                    _unitOfWork.Complete();

                    #region CEK ISSUE
                    if (data.StatusId == Constants.ACTION_STATUS.CLOSE && !string.IsNullOrEmpty(data.IssueId))
                    {
                        var listAction = _unitOfWork.TrActionRepository.GetAll()
                            .Where(w => w.IsDeleted == false && w.IssueId == data.IssueId && w.StatusId != Constants.ACTION_STATUS.CLOSE);

                        if (listAction.Count() == 0) // Kalau semua action terkait issue tersebut sudah close, maka issue jg di close
                        {
                            var issue = _unitOfWork.TrIssueRepository.Get(data.IssueId);

                            issue.StatusId = Constants.ACTION_STATUS.CLOSE;

                            _unitOfWork.TrIssueRepository.Update(issue, _userId ?? "", Constants.GETDATE());
                            _unitOfWork.Complete();
                        }
                    }                    
                    #endregion

                    var TextLog = "memperbaharui status dari '" + statusOld.Name + "' menjadi '" + statusNew.Name + "'";

                    // Create Log
                    var user = _unitOfWork.MUserSyncRepository.GetAll().Where(x => x.UserId.Equals(_userId ?? "")).FirstOrDefault();
                    CreateLog(data, Convert.ToInt32(Constants.LOG_TYPE.STATUS), TextLog, user == null ? "" : user.DisplayName);

                    var dataAction = _unitOfWork.TrActionRepository.SelectAll(data.ActionId.Trim(), null, null, null, null, null, null, null, null, null, null, null, null).ToList();
                    var responseData = _mapper.Map<List<fn_Get_Action>, List<TrActionViewModel.ReadAction>>(dataAction);

                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.UPDATE, responseData));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new StatusModel(ex));
            }

        }

        [HttpDelete("{id}")]
        public IActionResult Delete(string id)
        {
            try
            {
                TrAction data = _unitOfWork.TrActionRepository.Get(id.Trim());
                if (data != null)
                {
                    _unitOfWork.TrActionRepository.Delete(data, _userId, Constants.GETDATE());
                    _unitOfWork.Complete();

                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.DELETE, null));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }



        [ApiExplorerSettings(IgnoreApi = true)]
        public void Validate(TrAction model, string func)
        {
            if (model.AuditTypeId != null)
            {
                if (!_unitOfWork.MAuditTypeRepository.GetAll().Any(i => i.IsDeleted == false && i.AuditTypeId == model.AuditTypeId))
                {
                    throw new Exception("Tipe audit tidak valid");
                }
            }

            if (model.IssueId != null)
            {
                if (!_unitOfWork.TrIssueRepository.GetAll().Any(i => i.IsDeleted == false && i.IssueId == model.IssueId))
                {
                    throw new Exception("Issue tidak valid");
                }
            }

            if (model.AuditLocationId != null)
            {
                if (!_unitOfWork.MAuditLocationRepository.GetAll().Any(i => i.IsDeleted == false && i.AuditLocationId == model.AuditLocationId))
                {
                    throw new Exception("Lokasi audit tidak valid");
                }
            }
            if (model.AssignGroup != null)
            {
                if (!_unitOfWork.MUserGroupRepository.GetAll().Any(i => i.IsDeleted == false && i.UserGroupId == model.AssignGroup))
                {
                    throw new Exception("User group tidak valid");
                }
            }
            if (model.AssignUser != null)
            {
                if (!_unitOfWork.MUserSyncRepository.GetAll().Any(i => i.IsDeleted == false && i.UserId == model.AssignUser))
                {
                    throw new Exception("Assignee tidak valid");
                }
            }
            if (model.Creator != null)
            {
                if (!_unitOfWork.MUserSyncRepository.GetAll().Any(i => i.IsDeleted == false && i.UserId == model.Creator))
                {
                    throw new Exception("Creator tidak valid");
                }
            }
            if (model.PriorityId > 0)
            {
                if (!_unitOfWork.MPriorityRepository.GetAll().Any(i => i.IsDeleted == false && i.PriorityId == model.PriorityId))
                {
                    throw new Exception("Priority tidak valid");
                }
            }
            else
            {
                throw new Exception("Priority tidak valid");
            }
            if (model.StatusId > 0)
            {
                if (!_unitOfWork.MIssueStatusRepository.GetAll().Any(i => i.IsDeleted == false && i.StatusId == model.StatusId))
                {
                    throw new Exception("Status tidak valid");
                }
            }
            else
            {
                throw new Exception("Status tidak valid");
            }

            if (func == Constants.CRUD.CREATE)
            {
                if (model.TargetClosing != null)
                {
                    if (model.TargetClosing.Date < DateTime.Now.Date)
                    {
                        throw new Exception("Target closing tidak boleh lebih kecil dari tanggal saat ini");
                    }
                }
                else
                {
                    throw new Exception("Target closing tidak valid");
                }
            }
                
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        public void CreateLog(TrAction action, int logType, string textLog, string userName)
        {
            var actionLog = new TrActionLog
            {
                LogId = Constants.GETID(),
                ActionId = action.ActionId,
                UserId = _userId,
                Username = userName,
                DatetimeLog = Constants.GETDATE(),
                TextLog = userName + " " + textLog,
                LogTypeId = logType,
                IsDeleted = false,
                UserCreated = _userId,
                DateCreated = Constants.GETDATE()
            };

            _unitOfWork.TrActionLogRepository.Add(actionLog);
            _unitOfWork.Complete();
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        public string ConvertSortParameter(string param)
        {
            string sortField = param;
            if (param.ToLower().Equals("duedate"))
            {
                sortField = "TargetClosing";
            }
            else if (param.ToLower().Equals("lastupdated"))
            {
                sortField = "LastUpdate";
            }
            else if (param.ToLower().Equals("datecreated"))
            {
                sortField = "DateCreated";
            }
            else if (param.ToLower().Equals("priority"))
            {
                sortField = "PriorityName";
            }
            

            return sortField;
        }
    }
}
