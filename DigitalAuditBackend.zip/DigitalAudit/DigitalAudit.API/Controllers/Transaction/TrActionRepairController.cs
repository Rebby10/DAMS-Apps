﻿using AutoMapper;
using DigitalAudit.Helper;
using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using DigitalAudit.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace DigitalAudit.API.Controllers.Transaction
{
    [Authorize]
    [ApiController]
    [Route("Action/Repair")]
    public class TrActionRepairController : ControllerBase
    {
        private readonly ILogger<TrActionRepairController> _logger;
        private readonly IUnitOfWork _unitOfWork;
        private string _userId;
        private readonly IMapper _mapper;
        private IHostingEnvironment _hostingEnvironment;

        public TrActionRepairController(IUnitOfWork unitOfWork, ILogger<TrActionRepairController> logger, 
            IHostingEnvironment hostingEnvironment, IMapper mapper, IHttpContextAccessor httpContextAccessor)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
            _mapper = mapper;
            _hostingEnvironment = hostingEnvironment;
            _userId = httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
        }

        [HttpGet("{id}")]
        public IActionResult Get(string id)
        {
            try
            {
                var dataActionRepair = _unitOfWork.TrActionRepairRepository.SelectAll(id, null, null, null, null, null, null, null).FirstOrDefault();

                if (dataActionRepair != null)
                {
                    var responseData = _mapper.Map<TrActionRepair, TrActionRepairViewModel.ReadActionRepair>(dataActionRepair);                   

                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.READ, responseData));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return Ok(new StatusModel(ex));
            }
        }


        [HttpPost]
        public async Task<IActionResult> PostAsync([FromForm] TrActionRepairViewModel.CreateActionRepair item)
        {
            try
            {
                string fileName = "";

                if (item.Filename != null)
                {
                    string webRootPath = _hostingEnvironment.ContentRootPath;
                    string configTemplate = Configs.AppConfig.UploadPath.ImportFileLogAction;
                    string path = webRootPath + configTemplate + "\\" + item.ActionId;

                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }

                    fileName = item.Filename.FileName;
                    string fullPath = Path.Combine(path, fileName);

                    if (System.IO.File.Exists(fullPath))
                    {
                        string extension = Path.GetExtension(fileName).ToLower();
                        fileName = Path.GetFileNameWithoutExtension(fileName) + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + extension;
                        fullPath = Path.Combine(path, fileName);
                    }

                    using (var stream = new FileStream(fullPath, FileMode.Create))
                    {
                        await item.Filename.CopyToAsync(stream);                       
                    }
                }          

                var actionRepair = new TrActionRepair
                {
                    ActionRepairId = Constants.GETID(),
                    ActionId = item.ActionId,
                    RootCause = item.RootCause,
                    RootCauseCategoryId = item.RootCauseCategoryId,
                    ActionRepair = item.ActionRepair,
                    ActionRepairCategoryId = item.ActionRepairCategoryId,
                    RepairDate = item.RepairDate,
                    Filename = fileName,
                    DateCreated = Constants.GETDATE(),
                    UserCreated = _userId
                };

                Validate(actionRepair);

                _unitOfWork.TrActionRepairRepository.Add(actionRepair);
                _unitOfWork.Complete();

                var dataActionRepair = _unitOfWork.TrActionRepairRepository.SelectAll(actionRepair.ActionRepairId.Trim(), null, null, null, null, null, null, null).FirstOrDefault();

                var responseData = _mapper.Map<TrActionRepair, TrActionRepairViewModel.ReadActionRepair>(dataActionRepair);
                                
                CreateLog(responseData, _userId);

                return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.CREATE, responseData));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, item);
                return BadRequest(new StatusModel(ex));
            }
        }        

        [ApiExplorerSettings(IgnoreApi = true)]
        public void CreateLog(TrActionRepairViewModel.ReadActionRepair model, string userId)
        {
            var filePath = "Files/TemplateHTML/ActionRepair.html";
            string webRootPath = _hostingEnvironment.ContentRootPath;
            var templateFilePath = Path.Combine(webRootPath, filePath);

            var stringTemplate = System.IO.File.ReadAllText(templateFilePath);

            Dictionary<string, string> replacements = new Dictionary<string, string>(){
                {"{analisa_penyebab}", model.RootCause },
                {"{kategori_analisa_penyebab}", model.RootCauseCategory.Name},
                {"{tindakan_perbaikan}", model.ActionRepair},
                {"{kategori_tindakan_perbaikan}", model.ActionRepairCategory.Name},
                {"{tanggal_perbaikan}", model.RepairDate.ToString("dd MMM yyyy hh:mm tt")}
            };

            foreach (var key in replacements.Keys)
            {
                stringTemplate = stringTemplate.Replace(key, replacements[key]);
            }

            var user = _unitOfWork.MUserSyncRepository.SelectAll().FirstOrDefault(x => x.UserId == userId);

            var actionLog = new TrActionLog
            {
                LogId = Constants.GETID(),
                ActionId = model.Action.ActionId,
                UserId = userId,
                Username = user.DisplayName,
                DatetimeLog = Constants.GETDATE(),
                TextLog = stringTemplate,
                LogTypeId = Convert.ToInt32(Constants.LOG_TYPE.TEXT),
                IsDeleted = false,
                UserCreated = userId,
                DateCreated = Constants.GETDATE()
            };

            _unitOfWork.TrActionLogRepository.Add(actionLog);
            _unitOfWork.Complete();

            if (!string.IsNullOrEmpty(model.Filename))
            {
                var actionLogFile = new TrActionLog
                {
                    LogId = Constants.GETID(),
                    ActionId = model.Action.ActionId,
                    UserId = userId,
                    Username = user.DisplayName,
                    DatetimeLog = Constants.GETDATE(),
                    Filename = model.Filename,
                    LogTypeId = Convert.ToInt32(Constants.LOG_TYPE.FILE),
                    IsDeleted = false,
                    UserCreated = userId,
                    DateCreated = Constants.GETDATE()
                };

                _unitOfWork.TrActionLogRepository.Add(actionLogFile);
                _unitOfWork.Complete();
            }
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        public void Validate(TrActionRepair model)
        {
            if (model.ActionId != null)
            {
                if (!_unitOfWork.TrActionRepository.GetAll().Any(i => i.IsDeleted == false && i.ActionId == model.ActionId))
                {
                    throw new Exception("Action Id tidak valid");
                }
            }

            if (model.RootCauseCategoryId != null)
            {
                if (!_unitOfWork.MRootCauseCategoryRepository.GetAll().Any(i => i.IsDeleted == false && i.RootCauseCategoryId == model.RootCauseCategoryId))
                {
                    throw new Exception("Kategori analisa penyebab tidak valid");
                }
            }

            if (model.ActionRepairCategoryId != null)
            {
                if (!_unitOfWork.MActionRepairCategoryRepository.GetAll().Any(i => i.IsDeleted == false && i.ActionRepairCategoryId == model.ActionRepairCategoryId))
                {
                    throw new Exception("Kategori tindakan perbaikan tidak valid");
                }
            }
        }
    }
}