﻿using DigitalAudit.Helper;
using DigitalAudit.Model;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using DigitalAudit.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace DigitalAudit.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("Schedule")]
    public class TrAuditScheduleController : ControllerBase
    {
        private readonly ILogger<TrAuditScheduleController> _logger;
        private readonly IUnitOfWork _unitOfWork;
        private string _userId;
        private IHostingEnvironment _hostingEnvironment;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public TrAuditScheduleController(IUnitOfWork unitOfWork, ILogger<TrAuditScheduleController> logger, 
            IHostingEnvironment hostingEnvironment, IWebHostEnvironment webHostEnvironment, IHttpContextAccessor httpContextAccessor)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
            _hostingEnvironment = hostingEnvironment;
            _webHostEnvironment = webHostEnvironment;
            _userId = httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier) == null ? "" : httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
        }

        // GET: api/Schedule
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var items = _unitOfWork.TrAuditScheduleRepository.SelectAll();
                int totalData = items.Count();

                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, items.Count(), items.Count()));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpGet]
        [Route("query")]
        public IActionResult Get(
            [FromQuery] TrAuditScheduleViewModel.QueryAuditSchedule param)
        {
            try
            {
                IEnumerable<TrAuditScheduleViewModel.ReadAuditSchedule> items = _unitOfWork.TrAuditScheduleRepository.SelectAll();

                if (!string.IsNullOrEmpty(param.id))
                    items = items.Where(i => i.ScheduleId == param.id.Trim());

                if (!string.IsNullOrEmpty(param.template_id))
                    items = items.Where(i => i.Template.TemplateId == param.template_id.Trim());


                if (!string.IsNullOrEmpty(param.audit_location_id))
                    items = items.Where(i => i.AuditLocation.AuditLocationId == param.audit_location_id.Trim());

                if (param.status_id != null)
                    items = items.Where(i => i.Status.StatusId == param.status_id.Value);

                if (!string.IsNullOrEmpty(param.location_name))
                    items = items.Where(i => i.AuditLocation.Name.ToLower().Contains(param.location_name.Trim().ToLower()));

                if (!string.IsNullOrEmpty(param.title))
                    items = items.Where(i => i.Template.Title.ToLower().Contains(param.title.Trim().ToLower()));

                #region  check user role
                var userRole = _unitOfWork.MUserRoleRepository.GetAll().FirstOrDefault(f => f.UserId == _userId);

                if (userRole != null)
                {
                    if (userRole.RoleId == Constants.ROLE.ADMIN_PUSAT)
                    {
                        _userId = null; // admin pusat bisa lihat semua data, tidak di filter berdasarkan userId
                    }
                    else if (userRole.RoleId == Constants.ROLE.ADMIN_REGION)
                    {
                        //if (param.RegionId == null) // Jika param region gk diisi, ngikutin region user role
                        //{
                        //    param.RegionId = userRole.RegionId;
                        //    _userId = null;
                        //}

                        _userId = null;
                    }
                    else if (userRole.RoleId == Constants.ROLE.ADMIN_LOKASI)
                    {
                        //if (param.AuditLocationId == null) //Jika param lokasi audit tidak diisi, ngikutin lokasi user role
                        //{
                        //    param.AuditLocationId = userRole.AuditLocationId;
                        //    _userId = null;
                        //}

                        _userId = null;
                    }
                }

                #endregion

                if (!string.IsNullOrEmpty(_userId))
                    items = items.Where(i =>
                        //((i.Auditee.Users == null) ? false : i.Auditee.Users.UserId == param.user_id.Trim())
                        //||
                        //((i.Auditee.Groups == null) ? false : i.Auditee.Groups.UserId == param.user_id.Trim())
                        //||
                        //((i.Auditor.Users == null) ? false : i.Auditor.Users.UserId == param.user_id.Trim())
                        //||
                        //((i.Auditor.Groups == null) ? false : i.Auditor.Groups.UserId == param.user_id.Trim())


                        (i.Auditee.Users != null && i.Auditee.Users.UserId == _userId)
                        ||
                        (i.Auditee.Groups != null && i.Auditee.Groups.UserId == _userId)
                        ||
                        (i.Auditor.Users != null && i.Auditor.Users.UserId == _userId)
                        ||
                        (i.Auditor.Groups != null && i.Auditor.Groups.UserId == _userId)
                        
                        );

                int totalData = items.Count();

                if (!string.IsNullOrEmpty(param.sort_by))
                {
                    var orderByExpression = Helpers.GetOrderByExpression<TrAuditScheduleViewModel.ReadAuditSchedule>(param.sort_by);
                    items = Helpers.OrderByDir<TrAuditScheduleViewModel.ReadAuditSchedule>(items, param.order_by, orderByExpression).AsEnumerable();
                }

                if (param.page_size != null && param.page_number != null)
                {
                    items = Helpers.Page<TrAuditScheduleViewModel.ReadAuditSchedule>(items, param.page_size.Value, param.page_number.Value);
                }

                if (items.Count() > 0)
                {
                    return Ok(new StatusDataModel(true, Constants.DEFAULT_REMARKS.READ, items, totalData, items.Count() ));
                }
                else
                {
                    return NotFound(new StatusDataModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null, 0, 0 ));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, param);
                return BadRequest(new StatusModel(ex));
            }
        }

        [HttpGet("{id}")]
        public IActionResult Get(string id)
        {
            try
            {
                var faq = _unitOfWork.TrAuditScheduleRepository.SelectOne(id.Trim());

                if (faq != null)
                {
                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.READ, faq));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, id);
                return BadRequest(new StatusModel(ex));
            }
        }


        [HttpPost]
        public IActionResult Post([FromBody] TrAuditScheduleViewModel.CreateAuditSchedule item)
        {
            try
            {
                Helpers.Validate(item);
                string scheduleId = Constants.GETID();
                TrAuditSchedule data = new TrAuditSchedule(
                    scheduleId, item.AuditLocationId, item.StartDate, item.EndDate, item.TemplateId, Constants.SCHEDULE_STATUS.CONFIRMED, false, _userId, Constants.GETDATE(), null, null);

                Validate(data, Constants.CRUD.CREATE);
                if (item.Auditor.UserGroupId != null && item.Auditor.UserId != null)
                {
                    throw new Exception("Auditor tidak valid, silahkan pilih salah satu");
                }
                else if (item.Auditee.UserGroupId != null && item.Auditee.UserId != null)
                {
                    throw new Exception("Auditee tidak valid, silahkan pilih salah satu");
                }

                int countDoublePIC = _unitOfWork.TrAuditScheduleRepository.ValidatePICDouble_TrAuditSchedulePIC(item.Auditee.UserId, item.Auditee.UserGroupId, item.Auditor.UserId, item.Auditor.UserGroupId).Count();

                if(countDoublePIC > 0)
                {
                    throw new Exception("PIC antara auditor dan auditee tidak boleh double");
                }

                _unitOfWork.TrAuditScheduleRepository.Add(data);

                List<TrAuditSchedulePIC> dataPIC = new List<TrAuditSchedulePIC>();
                //auditor
                dataPIC.Add(new TrAuditSchedulePIC(Constants.GETID(), scheduleId, item.Auditor.UserId, item.Auditor.UserGroupId, Constants.USER_TYPE.AUDITOR, Constants.SCHEDULE_STATUS.CONFIRMED, false, _userId, Constants.GETDATE(), null, null));
                
                //auditee
                dataPIC.Add(new TrAuditSchedulePIC(Constants.GETID(), scheduleId, item.Auditee.UserId, item.Auditee.UserGroupId, Constants.USER_TYPE.AUDITEE, Constants.SCHEDULE_STATUS.CONFIRMED, false, _userId, Constants.GETDATE(), null, null));

                _unitOfWork.TrAuditSchedulePICRepository.AddLists(dataPIC);

                _unitOfWork.Complete();

                data = _unitOfWork.TrAuditScheduleRepository.Get(data.ScheduleId.Trim());

                //Insert ke inspection
                string inspectionId = Constants.GETID();
                TrInspection inspection = new TrInspection(inspectionId, scheduleId, data.AuditLocationId, data.StartDate, data.EndDate, data.TemplateId, Constants.INSPECTION_STATUS.SCHEDULED, false, data.UserCreated, Constants.GETDATE(), null, null, null, null, null, null, null);
                _unitOfWork.TrInspectionRepository.Add(inspection);

                //insert ke inspection PIC
                List<TrInspectionPIC> dataInspectionPIC = new List<TrInspectionPIC>();
                foreach(TrAuditSchedulePIC i in dataPIC)
                {
                    TrInspectionPIC inspectionPIC = new TrInspectionPIC(Constants.GETID(), inspectionId, i.UserId, i.UserGroupId, i.UserTypeId, false, data.UserCreated, Constants.GETDATE(), null, null);
                    dataInspectionPIC.Add(inspectionPIC);
                }

                _unitOfWork.TrInspectionPICRepository.AddLists(dataInspectionPIC);

                _unitOfWork.Complete();


                TrAuditScheduleViewModel.ReadAuditSchedule read = _unitOfWork.TrAuditScheduleRepository.SelectOne(data.ScheduleId.Trim());

                return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.CREATE, read));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, item);
                return Ok(new StatusModel(ex));
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(string id)
        {
            try
            {
                var item = _unitOfWork.TrAuditScheduleRepository.Get(id.Trim());
                if (item != null)
                {
                    _unitOfWork.TrAuditScheduleRepository.Delete(item, _userId, Constants.GETDATE());
                    _unitOfWork.Complete();

                    return Ok(new StatusModel(true, Constants.DEFAULT_REMARKS.DELETE, null));
                }
                else
                {
                    return NotFound(new StatusModel(false, Constants.DEFAULT_REMARKS.DATA_NOT_FOUND, null));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE, id);
                return Ok(new StatusModel(ex));
            }
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        public void Validate(TrAuditSchedule model, string func)
        {

            if (func == Constants.CRUD.CREATE || func == Constants.CRUD.UPDATE)
            {
                if (!_unitOfWork.MAuditLocationRepository.GetAll().Any(i => i.IsDeleted == false && i.AuditLocationId == model.AuditLocationId))
                {
                    throw new Exception("Lokasi tidak valid");
                }
                else if (!_unitOfWork.MTemplateRepository.GetAll().Any(i => i.IsDeleted == false && i.TemplateId == model.TemplateId))
                {
                    throw new Exception("Template tidak valid");
                }
            }
        }

        [HttpGet]
        [Route("Template")]
        public async Task<ActionResult> GenerateTemplateAsync()
        {
            XSSFWorkbook wb;
            XSSFSheet sh;
            XSSFSheet shAuditLocation;
            XSSFSheet shUserGroup;
            XSSFSheet shTemplate;

            string filename = Guid.NewGuid() + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".xlsx";

            string sWebRootFolder = _hostingEnvironment.ContentRootPath;

            string configTemplate = Configs.AppConfig.UploadPath.TemplateSchedule;
            string pathTemplate = sWebRootFolder + configTemplate;

            if (!Directory.Exists(pathTemplate))
            {
                Directory.CreateDirectory(pathTemplate);
            }

            string URL = string.Format("{0}://{1}/{2}", Request.Scheme, Request.Host, filename);
            FileInfo file = new FileInfo(Path.Combine(pathTemplate, filename));
            var memory = new MemoryStream();
            using (var fs = new FileStream(Path.Combine(pathTemplate, filename), FileMode.Create, FileAccess.Write))
            {
                wb = new XSSFWorkbook();

                #region STYLING HEADER
                IFont boldFont = wb.CreateFont();
                boldFont.Boldweight = (short)FontBoldWeight.Bold;
                ICellStyle HeaderStyle = wb.CreateCellStyle();
                HeaderStyle.SetFont(boldFont);

                HeaderStyle.BorderBottom = BorderStyle.Thin;
                HeaderStyle.BorderTop = BorderStyle.Thin;
                HeaderStyle.BorderLeft = BorderStyle.Thin;
                HeaderStyle.BorderRight = BorderStyle.Thin;

                HeaderStyle.FillForegroundColor = NPOI.HSSF.Util.HSSFColor.LightOrange.Index;
                HeaderStyle.FillPattern = FillPattern.SolidForeground;
                #endregion

                #region STYLING BODY
                IFont NormalFont = wb.CreateFont();
                ICellStyle BodyStyle = wb.CreateCellStyle();
                BodyStyle.SetFont(NormalFont);

                BodyStyle.BorderBottom = BorderStyle.Thin;
                BodyStyle.BorderTop = BorderStyle.Thin;
                BodyStyle.BorderLeft = BorderStyle.Thin;
                BodyStyle.BorderRight = BorderStyle.Thin;
                #endregion

                #region CREATE SHEET TEMPLATE
                sh = (XSSFSheet)wb.CreateSheet("Sheet1");

                int i = 0;

                if (sh.GetRow(i) == null)
                    sh.CreateRow(i);

                if (sh.GetRow(i).GetCell(0) == null)
                {
                    sh.GetRow(i).CreateCell(0).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(0).SetCellValue("Audit Location Id");
                }

                if (sh.GetRow(i).GetCell(1) == null)
                {
                    sh.GetRow(i).CreateCell(1).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(1).SetCellValue("Template Id");
                }

                if (sh.GetRow(i).GetCell(2) == null)
                {
                    sh.GetRow(i).CreateCell(2).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(2).SetCellValue("Start Date");
                }

                if (sh.GetRow(i).GetCell(3) == null)
                {
                    sh.GetRow(i).CreateCell(3).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(3).SetCellValue("End Date");
                }

                if (sh.GetRow(i).GetCell(4) == null)
                {
                    sh.GetRow(i).CreateCell(4).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(4).SetCellValue("Auditor Group");
                }

                if (sh.GetRow(i).GetCell(5) == null)
                {
                    sh.GetRow(i).CreateCell(5).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(5).SetCellValue("Auditor User");
                }

                if (sh.GetRow(i).GetCell(6) == null)
                {
                    sh.GetRow(i).CreateCell(6).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(6).SetCellValue("Auditee Group");
                }


                if (sh.GetRow(i).GetCell(7) == null)
                {
                    sh.GetRow(i).CreateCell(7).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(7).SetCellValue("Auditee User");
                }

                if (sh.GetRow(i).GetCell(8) == null)
                {
                    sh.GetRow(i).CreateCell(8).CellStyle = HeaderStyle;
                    sh.GetRow(i).GetCell(8).SetCellValue("Creator");
                }

                #endregion

                #region CREATE SHEET MASTER AUDIT LOCATION
                shAuditLocation = (XSSFSheet)wb.CreateSheet("Audit Location");

                i = 0;

                #region HEADER
                if (shAuditLocation.GetRow(i) == null)
                    shAuditLocation.CreateRow(i);

                if (shAuditLocation.GetRow(i).GetCell(0) == null)
                {
                    shAuditLocation.GetRow(i).CreateCell(0).CellStyle = HeaderStyle;
                    shAuditLocation.GetRow(i).GetCell(0).SetCellValue("Audit Location ID");
                }

                if (shAuditLocation.GetRow(i).GetCell(1) == null)
                {
                    shAuditLocation.GetRow(i).CreateCell(1).CellStyle = HeaderStyle;
                    shAuditLocation.GetRow(i).GetCell(1).SetCellValue("Location Name");
                }

                if (shAuditLocation.GetRow(i).GetCell(2) == null)
                {
                    shAuditLocation.GetRow(i).CreateCell(2).CellStyle = HeaderStyle;
                    shAuditLocation.GetRow(i).GetCell(2).SetCellValue("Region");
                }
                #endregion

                #region BODY
                List<fn_Get_MAuditLocation> ListAuditLocation = _unitOfWork.MAuditLocationRepository.Get_MAuditLocation(null, null, null);

                i += 1;

                foreach (fn_Get_MAuditLocation AuditLocation in ListAuditLocation.OrderBy(O => O.AuditLocationId))
                {
                    if (shAuditLocation.GetRow(i) == null)
                        shAuditLocation.CreateRow(i);

                    if (shAuditLocation.GetRow(i).GetCell(0) == null)
                    {
                        shAuditLocation.GetRow(i).CreateCell(0).CellStyle = BodyStyle;
                        shAuditLocation.GetRow(i).GetCell(0).SetCellValue(AuditLocation.ID);
                    }

                    if (shAuditLocation.GetRow(i).GetCell(1) == null)
                    {
                        shAuditLocation.GetRow(i).CreateCell(1).CellStyle = BodyStyle;
                        shAuditLocation.GetRow(i).GetCell(1).SetCellValue(AuditLocation.Name);
                    }

                    if (shAuditLocation.GetRow(i).GetCell(2) == null)
                    {
                        shAuditLocation.GetRow(i).CreateCell(2).CellStyle = BodyStyle;
                        shAuditLocation.GetRow(i).GetCell(2).SetCellValue(AuditLocation.RegionName);
                    }

                    i += 1;
                }
                #endregion

                #endregion

                #region CREATE SHEET MASTER USER GROUP
                shUserGroup = (XSSFSheet)wb.CreateSheet("User Group");

                i = 0;

                #region HEADER
                if (shUserGroup.GetRow(i) == null)
                    shUserGroup.CreateRow(i);

                if (shUserGroup.GetRow(i).GetCell(0) == null)
                {
                    shUserGroup.GetRow(i).CreateCell(0).CellStyle = HeaderStyle;
                    shUserGroup.GetRow(i).GetCell(0).SetCellValue("User Group ID");
                }

                if (shUserGroup.GetRow(i).GetCell(1) == null)
                {
                    shUserGroup.GetRow(i).CreateCell(1).CellStyle = HeaderStyle;
                    shUserGroup.GetRow(i).GetCell(1).SetCellValue("Group Name");
                }

                if (shUserGroup.GetRow(i).GetCell(2) == null)
                {
                    shUserGroup.GetRow(i).CreateCell(2).CellStyle = HeaderStyle;
                    shUserGroup.GetRow(i).GetCell(2).SetCellValue("Group Leader");
                }

                if (shUserGroup.GetRow(i).GetCell(3) == null)
                {
                    shUserGroup.GetRow(i).CreateCell(3).CellStyle = HeaderStyle;
                    shUserGroup.GetRow(i).GetCell(3).SetCellValue("User Type");
                }
                #endregion

                #region BODY
                i += 1;
                List<fn_Get_MUserGroup> ListUserGroup = _unitOfWork.MUserGroupRepository.Get_MUserGroup(null, null);

                foreach (fn_Get_MUserGroup item in ListUserGroup)
                {
                    if (shUserGroup.GetRow(i) == null)
                        shUserGroup.CreateRow(i);

                    if (shUserGroup.GetRow(i).GetCell(0) == null)
                    {
                        shUserGroup.GetRow(i).CreateCell(0).CellStyle = BodyStyle;
                        shUserGroup.GetRow(i).GetCell(0).SetCellValue(item.ID);
                    }

                    if (shUserGroup.GetRow(i).GetCell(1) == null)
                    {
                        shUserGroup.GetRow(i).CreateCell(1).CellStyle = BodyStyle;
                        shUserGroup.GetRow(i).GetCell(1).SetCellValue(item.Name);
                    }

                    if (shUserGroup.GetRow(i).GetCell(2) == null)
                    {
                        shUserGroup.GetRow(i).CreateCell(2).CellStyle = BodyStyle;
                        shUserGroup.GetRow(i).GetCell(2).SetCellValue(item.UserId);
                    }

                    if (shUserGroup.GetRow(i).GetCell(3) == null)
                    {
                        shUserGroup.GetRow(i).CreateCell(3).CellStyle = BodyStyle;
                        shUserGroup.GetRow(i).GetCell(3).SetCellValue(item.UserType);
                    }

                    i += 1;
                }


                #endregion

                #endregion

                #region CREATE SHEET MASTER TEMPLATE
                shTemplate = (XSSFSheet)wb.CreateSheet("Template");

                i = 0;

                #region HEADER
                if (shTemplate.GetRow(i) == null)
                    shTemplate.CreateRow(i);

                if (shTemplate.GetRow(i).GetCell(0) == null)
                {
                    shTemplate.GetRow(i).CreateCell(0).CellStyle = HeaderStyle;
                    shTemplate.GetRow(i).GetCell(0).SetCellValue("Template ID");
                }

                if (shTemplate.GetRow(i).GetCell(1) == null)
                {
                    shTemplate.GetRow(i).CreateCell(1).CellStyle = HeaderStyle;
                    shTemplate.GetRow(i).GetCell(1).SetCellValue("Name");
                }

                #endregion

                #region BODY
                i += 1;
                List<MTemplate> ListTemplate = _unitOfWork.MTemplateRepository.GetAll().Where(w => w.IsDeleted == false).ToList();

                foreach (MTemplate item in ListTemplate)
                {
                    if (shTemplate.GetRow(i) == null)
                        shTemplate.CreateRow(i);

                    if (shTemplate.GetRow(i).GetCell(0) == null)
                    {
                        shTemplate.GetRow(i).CreateCell(0).CellStyle = BodyStyle;
                        shTemplate.GetRow(i).GetCell(0).SetCellValue(item.ID);
                    }

                    if (shTemplate.GetRow(i).GetCell(1) == null)
                    {
                        shTemplate.GetRow(i).CreateCell(1).CellStyle = BodyStyle;
                        shTemplate.GetRow(i).GetCell(1).SetCellValue(item.Title);
                    }


                    i += 1;
                }


                #endregion

                #endregion

                wb.Write(fs);
            }

            using (var stream = new FileStream(Path.Combine(pathTemplate, filename), FileMode.Open))
            {
                await stream.CopyToAsync(memory);
            }
            memory.Position = 0;
            return File(memory, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", filename);
        }

        [AllowAnonymous]
        [HttpPost]
        [Route("Import")]
        public ActionResult Import([FromForm] TrAuditScheduleViewModel.ImportSchedule param)
        {
            try
            {
                string baseURL = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}";
                StatusViewModel statusUpload = new StatusViewModel();
                string sessionId = Constants.GETID();
                IFormFile file = param.File;
                string webRootPath = _hostingEnvironment.ContentRootPath;
                string configTemplate = Configs.AppConfig.UploadPath.ImportSchedule;
                string pathTemplate = webRootPath + configTemplate;
                StringBuilder sb = new StringBuilder();
                if (!Directory.Exists(pathTemplate))
                {
                    Directory.CreateDirectory(pathTemplate);
                }

                string fileName = "Import_" + Constants.GETID() + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".xlsx";

                _unitOfWork.TrAuditScheduleImportSessionRepository.Add(new TrAuditScheduleImportSession(sessionId, Constants.GETDATE(), fileName, false, false, Constants.DEFAULT_USER, Constants.GETDATE(), null, null));
                _unitOfWork.Complete();

                if (file.Length > 0)
                {
                    string sFileExtension = Path.GetExtension(file.FileName).ToLower();
                    ISheet sheet;
                    string fullPath = Path.Combine(pathTemplate, fileName);
                    using (var stream = new FileStream(fullPath, FileMode.Create))
                    {
                        file.CopyTo(stream);
                        stream.Position = 0;
                        if (sFileExtension == ".xls")
                        {
                            HSSFWorkbook hssfwb = new HSSFWorkbook(stream); //This will read the Excel 97-2000 formats  
                            sheet = hssfwb.GetSheetAt(0); //get first sheet from workbook  
                        }
                        else if (sFileExtension == ".xlsx")
                        {
                            XSSFWorkbook hssfwb = new XSSFWorkbook(stream); //This will read 2007 Excel format  
                            sheet = hssfwb.GetSheetAt(0); //get first sheet from workbook   
                        }
                        else
                        {
                            throw new Exception("Hanya boleh upload .xls atau .xlsx");
                        }

                        IRow headerRow = sheet.GetRow(0); //Get Header Row
                        int cellCount = headerRow.LastCellNum;

                        int countIsColumnNotValid = 0;
                        List<TrAuditScheduleImport> trAuditSchedules = new List<TrAuditScheduleImport>();
                        for (int i = (sheet.FirstRowNum + 1); i <= sheet.LastRowNum; i++) //Read Excel File
                        {
                            IRow row = sheet.GetRow(i);
                            if (row == null) continue;
                            if (row.Cells.All(d => d.CellType == CellType.Blank)) continue;

                            //if(row.Cells.Count() < 20)
                            //{
                            //    countIsColumnNotValid = countIsColumnNotValid + 1;
                            //}

                        }

                        if (countIsColumnNotValid == 0)
                        {
                            for (int i = (sheet.FirstRowNum + 1); i <= sheet.LastRowNum; i++) //Read Excel File
                            {
                                IRow row = sheet.GetRow(i);
                                if (row == null) continue;
                                if (row.Cells.All(d => d.CellType == CellType.Blank)) continue;

                                var schedule = new TrAuditScheduleImport
                                {
                                    ScheduleImportId = Constants.GETID(),
                                    SessionId = sessionId,
                                    AuditLocationId = row.GetCell(0, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? "" : row.GetCell(0, MissingCellPolicy.RETURN_NULL_AND_BLANK).ToString(),
                                    TemplateId = row.GetCell(1, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? "" : row.GetCell(1, MissingCellPolicy.RETURN_NULL_AND_BLANK).ToString(),
                                    StartDate = row.GetCell(2, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? Constants.GETDATE() : Convert.ToDateTime(row.GetCell(2, MissingCellPolicy.RETURN_NULL_AND_BLANK).ToString()),
                                    EndDate = row.GetCell(3, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? Constants.GETDATE() : Convert.ToDateTime(row.GetCell(3, MissingCellPolicy.RETURN_NULL_AND_BLANK).ToString()),
                                    AuditorGroup = row.GetCell(4, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? null : row.GetCell(4, MissingCellPolicy.RETURN_NULL_AND_BLANK).ToString(),
                                    AuditorUser = row.GetCell(5, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? null : row.GetCell(5, MissingCellPolicy.RETURN_NULL_AND_BLANK).ToString(),
                                    AuditeeGroup = row.GetCell(6, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? null : row.GetCell(6, MissingCellPolicy.RETURN_NULL_AND_BLANK).ToString(),
                                    AuditeeUser = row.GetCell(7, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? null : row.GetCell(7, MissingCellPolicy.RETURN_NULL_AND_BLANK).ToString(),
                                    Creator = row.GetCell(8, MissingCellPolicy.RETURN_NULL_AND_BLANK) == null ? null : row.GetCell(8, MissingCellPolicy.RETURN_NULL_AND_BLANK).ToString(),
                                    IsSuccess = null,
                                    ErrorMessage = null,
                                    IsDeleted = false,
                                    UserCreated = _userId == null ? _userId : row.GetCell(8, MissingCellPolicy.RETURN_NULL_AND_BLANK).ToString(),
                                    DateCreated = Constants.GETDATE(),
                                    UserModified = null,
                                    DateModified = null
                                };

                                trAuditSchedules.Add(schedule);
                            }

                        }
                        else
                        {
                            throw new Exception("Template file excel tidak valid");
                        }

                        _unitOfWork.TrAuditScheduleImportRepository.AddLists(trAuditSchedules);
                        _unitOfWork.Complete();

                        statusUpload = _unitOfWork.TrAuditScheduleImportRepository.ScheduleImportValidate(sessionId, Constants.DEFAULT_USER);
                    }
                }

                if (statusUpload.IsSuccess == false)
                {
                    statusUpload.Messages = "Please check this file to check error data";
                }

                return Ok(new StatusModel(statusUpload.IsSuccess, statusUpload.Messages, baseURL + "/" + "Schedule/DownloadError/" + sessionId));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, Constants.DEFAULT_REMARKS.ERROR_MESSAGE);
                return BadRequest(new StatusModel(ex));
            }

        }

        [Route("DownloadError/{id}")]
        [HttpGet]
        public async Task<IActionResult> DownloadError(string id)
        {
            string sFileName = Guid.NewGuid().ToString() + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".xlsx";

            string sWebRootFolder = _webHostEnvironment.ContentRootPath;

            string configPath = Configs.AppConfig.UploadPath.DownloadErrorSchedule;
            string path = sWebRootFolder + configPath;

            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }

            var memory = new MemoryStream();
            using (var fs = new FileStream(Path.Combine(path, sFileName), FileMode.Create, FileAccess.Write))
            {
                IWorkbook workbook;
                workbook = new XSSFWorkbook();
                ISheet excelSheet = workbook.CreateSheet("Action");
                IRow row = excelSheet.CreateRow(0);

                string[] header = { "Audit Location", "Region", "Lat Long", "Template Title", "Start Date"
                        , "End Date", "Auditor Group Name", "Auditor Group Leader", "Auditor User", "Auditee Group Name", "Auditee Group Leader"
                        , "Auditee User", "Creator", "Error Message"  };

                int idx_header = 0;
                foreach (string i in header.ToList())
                {
                    row.CreateCell(idx_header).SetCellValue(i);
                    idx_header = idx_header + 1;
                }

                var items = _unitOfWork.TrAuditScheduleImportRepository.GetScheduleImport(id);

                int idx_data = 0;
                foreach (var d in items)
                {
                    idx_data = idx_data + 1;
                    row = excelSheet.CreateRow(idx_data);
                    row.CreateCell(0).SetCellValue(d.LocationName);
                    row.CreateCell(1).SetCellValue(d.Region);
                    row.CreateCell(2).SetCellValue(d.LatLong);
                    row.CreateCell(3).SetCellValue(d.Title);
                    row.CreateCell(4).SetCellValue(d.StartDate.ToString("g"));
                    row.CreateCell(5).SetCellValue(d.EndDate.ToString("g"));
                    row.CreateCell(6).SetCellValue(d.AuditorGroupName);
                    row.CreateCell(7).SetCellValue(d.AuditorGroupLeader);
                    row.CreateCell(8).SetCellValue(d.AuditorUser);
                    row.CreateCell(9).SetCellValue(d.AuditeeGroupName);
                    row.CreateCell(10).SetCellValue(d.AuditeeGroupLeader);
                    row.CreateCell(11).SetCellValue(d.AuditeeUser);
                    row.CreateCell(12).SetCellValue(d.Creator);
                    row.CreateCell(13).SetCellValue(d.ErrorMessage);
                }

                workbook.Write(fs);
            }
            using (var stream = new FileStream(Path.Combine(path, sFileName), FileMode.Open))
            {
                await stream.CopyToAsync(memory);
            }
            memory.Position = 0;
            return File(memory, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", sFileName);
        }
    }
}
