﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DigitalAudit.Attributes
{
    public class CustomParseDateAttribute : ValidationAttribute
    {
        private DateTime _MinDate;

        public CustomParseDateAttribute()
        {
            _MinDate = DateTime.Today;
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            DateTime temp;
            if (DateTime.TryParse(value.ToString(), out temp))
            {
                return ValidationResult.Success;
            }
            else
            {
                return new ValidationResult("Format tidak valid. Tanggal harus (yyyy-MM-dd)");
            }
        }
    }
}
