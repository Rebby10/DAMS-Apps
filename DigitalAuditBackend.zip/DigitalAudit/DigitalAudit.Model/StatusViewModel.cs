﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalAudit.Model
{
    public class StatusViewModel
    {
        public bool IsSuccess { get; set; }
        public string Messages { get; set; }
    }
}
