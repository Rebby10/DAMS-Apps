﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class MFAQViewModel
    {
        public class QueryFAQ : PagingViewModel
        {
            public string id { get; set; }
            public string question { get; set; }
        }

        public class ReadFAQ
        {
            public string FaqId { get; set; }

            [Display(Name = "Pertanyaan")]
            public string Question { get; set; }

            [Display(Name = "Jawaban")]
            public string Answer { get; set; }
        }

        public class CreateFAQ
        {
            [Required]
            [StringLength(1000)]
            [Display(Name = "Pertanyaan")]
            public string Question { get; set; }

            [Required]
            [StringLength(1000)]
            [Display(Name = "Jawaban")]
            public string Answer { get; set; }
        }

        public class UpdateFAQ
        {
            public string FaqId { get; set; }

            [Required]
            [StringLength(1000)]
            [Display(Name = "Pertanyaan")]
            public string Question { get; set; }

            [Required]
            [StringLength(1000)]
            [Display(Name = "Jawaban")]
            public string Answer { get; set; }
        }

        public class DestroyFAQ
        {
            public string FaqId { get; set; }
        }
    }
}
