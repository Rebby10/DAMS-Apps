﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class TemplateCategory
    {
        public string CategoryId { get; set; }
        public string Name { get; set; }

        public TemplateCategory()
        {
        }

        public TemplateCategory(string categoryId, string name)
        {
            CategoryId = categoryId;
            Name = name;
        }
    }

    public class TemplatePermissionType
    {
        public string TemplatePermissionTypeId { get; set; }
        public string Name { get; set; }

        public TemplatePermissionType()
        {
        }

        public TemplatePermissionType(string templatePermissionTypeId, string name)
        {
            TemplatePermissionTypeId = templatePermissionTypeId;
            Name = name;
        }
    }

    public class TemplateUser
    {
        public string UserId { get; set; }
        public string DisplayName { get; set; }

        public TemplateUser()
        {
        }

        public TemplateUser(string userId, string displayName)
        {
            UserId = userId;
            DisplayName = displayName;
        }
    }

    public class TemplateGroup
    {
        public string GroupId { get; set; }
        public string Name { get; set; }

        public TemplateGroup()
        {
        }

        public TemplateGroup(string groupId, string name)
        {
            GroupId = groupId;
            Name = name;
        }
    }

    public class TemplatePermission
    {
        public TemplateUser TemplateUser { get; set; }
        public TemplateGroup TemplateGroup { get; set; }

        public TemplatePermission(TemplateUser templateUser, TemplateGroup templateGroup)
        {
            TemplateUser = templateUser;
            TemplateGroup = templateGroup;
        }

        public TemplatePermission()
        {
        }
    }

    public class TemplateResponseType
    {
        public string TypeId { get; set; }
        public string Name { get; set; }

        public TemplateResponseType()
        {
        }

        public TemplateResponseType(string typeId, string name)
        {
            TypeId = typeId;
            Name = name;
        }
    }

    public class TemplateResponseList
    {
        public string ListId { get; set; }
        public string Name { get; set; }
        public string Score { get; set; }
        public int SeqNo { get; set; }
        public bool IsFailedResponse { get; set; }

        public TemplateResponseList()
        {
        }

        public TemplateResponseList(string listId, string name, string score, int seqNo, bool isFailedResponse)
        {
            ListId = listId;
            Name = name;
            Score = score;
            SeqNo = seqNo;
            IsFailedResponse = isFailedResponse;
        }
    }

    public class TemplateResponse
    {
        public string ResponseId { get; set; }
        public TemplateResponseType TemplateResponseType { get; set; }
        public string Name { get; set; }
        public List<TemplateResponseList> TemplateResponseList { get; set; }

        public TemplateResponse(string responseId, TemplateResponseType templateResponseType, string name, List<TemplateResponseList> templateResponseList)
        {
            ResponseId = responseId;
            TemplateResponseType = templateResponseType;
            Name = name;
            TemplateResponseList = templateResponseList;
        }

        public TemplateResponse()
        {
        }
    }

    //public class TemplateQuestion
    //{
    //    public string QuestionId { get; set; }
    //    public string PageId { get; set; }
    //    public string SectionId { get; set; }
    //    public int SeqNo { get; set; }
    //    public string Code { get; set; }
    //    public string Question { get; set; }
    //    public bool IsMandatory { get; set; }
    //    public TemplateResponse TemplateResponse { get; set; }

    //    public TemplateQuestion(string questionId, string pageId, string sectionId, int seqNo, string code, string question, bool isMandatory, TemplateResponse templateResponse)
    //    {
    //        QuestionId = questionId;
    //        PageId = pageId;
    //        SectionId = sectionId;
    //        SeqNo = seqNo;
    //        Code = code;
    //        Question = question;
    //        IsMandatory = isMandatory;
    //        TemplateResponse = templateResponse;
    //    }

    //    public TemplateQuestion()
    //    {
    //    }
    //}

    public class TemplateSection
    {
        public string PageId { get; set; }
        public string SectionId { get; set; }
        public string Name { get; set; }
        //public List<TemplateQuestion> TemplateQuestion { get; set; }
    }

    public class TemplatePage
    {
        public string PageId { get; set; }
        public string Title { get; set; }
        public string Descriptions { get; set; }
        public int SeqNo { get; set; }
        public List<MTemplateQuestionViewModel.ReadTemplateQuestion> TemplateQuestion { get; set; }
        public List<TemplateSection> TemplateSection { get; set; }

        public TemplatePage()
        {
        }

        public TemplatePage(string pageId, string title, string descriptions, int seqNo, List<MTemplateQuestionViewModel.ReadTemplateQuestion> templateQuestion, List<TemplateSection> templateSection)
        {
            PageId = pageId;
            Title = title;
            Descriptions = descriptions;
            SeqNo = seqNo;
            TemplateQuestion = templateQuestion;
            TemplateSection = templateSection;
        }
    }

    public class MTemplateMainTesViewModel
    {
        public List<MTemplatePageViewModel.ReadTemplatePageDetail> TemplatePage { get; set; }
    }

    public class MTemplateMainViewModel
    {
        public string TemplateId { get; set; }
        public string Code { get; set; }
        public string Title { get; set; }
        public string Descriptions { get; set; }
        public MTemplateCategoryViewModel.ReadTemplateCategory TemplateCategory { get; set; }
        public MTemplatePermissionTypeViewModel.ReadMTemplatePermissionType TemplatePermissionType { get; set; }
        public List<MTemplateViewModel.Permission> TemplatePermission { get; set; }
        public List<MTemplatePageViewModel.ReadTemplatePageDetail> TemplatePage { get; set; }

        public MTemplateMainViewModel()
        {
        }

        public MTemplateMainViewModel(string templateId, string code, string title, string descriptions, MTemplateCategoryViewModel.ReadTemplateCategory templateCategory, MTemplatePermissionTypeViewModel.ReadMTemplatePermissionType templatePermissionType, List<MTemplateViewModel.Permission> templatePermission, List<MTemplatePageViewModel.ReadTemplatePageDetail> templatePage)
        {
            TemplateId = templateId;
            Code = code;
            Title = title;
            Descriptions = descriptions;
            TemplateCategory = templateCategory;
            TemplatePermissionType = templatePermissionType;
            TemplatePermission = templatePermission;
            TemplatePage = templatePage;
        }
    }


}
