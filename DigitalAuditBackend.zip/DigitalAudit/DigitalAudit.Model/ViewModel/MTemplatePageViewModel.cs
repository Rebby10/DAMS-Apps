﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class MTemplatePageViewModel
    {
        public class QueryTemplatePage : PagingViewModel
        {
            public string id { get; set; }
            public string template_id { get; set; }
            public string title { get; set; }
            public string descriptions { get; set; }
            public int? SeqNo { get; set; }
        }

        public class ReadTemplatePage
        {
            public string PageId { get; set; }
            public string TemplateId { get; set; }
            public string Title { get; set; }
            public string Descriptions { get; set; }
            public int SeqNo { get; set; }

        }

        public class ReadTemplatePageDetail
        {
            public string PageId { get; set; }
            public string TemplateId { get; set; }
            public string Title { get; set; }
            public string Descriptions { get; set; }
            public int SeqNo { get; set; }
            public double Score { get; set; }
            public List<MTemplateQuestionViewModel.ReadTemplateQuestion> Question { get; set; }
            public List<MTemplateSectionViewModel.ReadTemplateSectionDetail> Section { get; set; }

        }

        public class CreateTemplatePage
        {
            //[Required]
            //public string PageId { get; set; }

            [Required]
            public string TemplateId { get; set; }

            [Required]
            [StringLength(100)]
            public string Title { get; set; }

            [Required]
            [StringLength(200)]
            public string Descriptions { get; set; }

            [Required]
            public int SeqNo { get; set; }
        }

        public class UpdateTemplatePage
        {
            [Required]
            public string PageId { get; set; }

            [Required]
            public string TemplateId { get; set; }

            [Required]
            [StringLength(100)]
            public string Title { get; set; }

            [Required]
            [StringLength(200)]
            public string Descriptions { get; set; }

            [Required]
            public int SeqNo { get; set; }
        }

        public class DestroyTemplatePage
        {
            [Required]
            public string PageId { get; set; }
        }
    }
}
