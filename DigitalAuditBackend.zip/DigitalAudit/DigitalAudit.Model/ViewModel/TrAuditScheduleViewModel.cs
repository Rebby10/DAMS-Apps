﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class TrAuditScheduleViewModel
    {
        public class QueryAuditSchedule : PagingViewModel
        {
            public string id { get; set; }
            public string template_id { get; set; }
            public string title { get; set; }
            public int? status_id { get; set; }
            public string status { get; set; }
            public string audit_location_id { get; set; }
            public string location_name { get; set; }
            public string region_id { get; set; }
            public string region_name { get; set; }
            public string user_id { get; set; }
        }

        public class ReadTemplate
        {
            public ReadTemplate(string templateId, string title)
            {
                TemplateId = templateId;
                Title = title;
            }

            public string TemplateId { get; set; }
            public string Title { get; set; }
        }

        public class ReadAuditSchedule
        {
            public string ScheduleId { get; set; }

            [Display(Name = "Audit Location")]
            public MAuditLocationViewModel.ReadAuditLocation AuditLocation { get; set; }

            [Display(Name = "Start Date")]
            public DateTime StartDate { get; set; }

            [Display(Name = "End Date")]
            public DateTime EndDate { get; set; }

            [Display(Name = "Template")]
            public ReadTemplate Template { get; set; }

            [Display(Name = "Status")]
            public MScheduleStatusViewModel.ReadScheduleStatus Status { get; set; }

            public TrAuditSchedulePICViewModel.ReadAuditSchedulePIC Auditor { get; set; }
            public TrAuditSchedulePICViewModel.ReadAuditSchedulePIC Auditee { get; set; }
        }

        public class CreateAuditSchedule
        {
            [Required]
            [StringLength(50)]
            [Display(Name = "Audit Location Id")]
            public string AuditLocationId { get; set; }

            [Required]
            [Display(Name = "Tanggal Awal")]
            public DateTime StartDate { get; set; }

            [Required]
            [Display(Name = "Tanggal Akhir")]
            public DateTime EndDate { get; set; }

            [Required]
            [StringLength(50)]
            [Display(Name = "Template Id")]
            public string TemplateId { get; set; }

            [Required]
            public TrAuditSchedulePICViewModel.CreateAuditSchedulePIC Auditor { get; set; }

            [Required]
            public TrAuditSchedulePICViewModel.CreateAuditSchedulePIC Auditee { get; set; }
        }

        public class DestroyAuditSchedule
        {
            [Required]
            [StringLength(50)]
            public string ScheduleId { get; set; }
        }

        public class ImportSchedule
        {
            [Required]
            public IFormFile File { get; set; }
        }
    }
}
