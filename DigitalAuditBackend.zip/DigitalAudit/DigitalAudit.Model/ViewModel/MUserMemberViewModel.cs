﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class MUserMemberViewModel
    {
        public class QueryUserMember : PagingViewModel
        {
            public string id { get; set; }
            public string user_group_id { get; set; }
        }

        public class ReadUserMember
        {
            public string UserMemberId { get; set; }

            [Display(Name = "User Group")]
            public MUserGroupViewModel.ReadUserGroup UserGroup { get; set; }

            [Display(Name = "User Id")]
            public string UserId { get; set; }

            [Display(Name = "Username")]
            public string Username { get; set; }

            [Display(Name = "Official Name")]
            public string OfficialName { get; set; }
        }

        public class CreateUserMember
        {
            [Required]
            [StringLength(50)]
            [Display(Name = "User Group Id")]
            public string UserGroupId { get; set; }

            [Required]
            [StringLength(50)]
            [Display(Name = "User Id")]
            public string UserId { get; set; }

            [Required]
            [StringLength(100)]
            [Display(Name = "Username")]
            public string Username { get; set; }
        }

        public class UpdateUserMember
        {
            public string UserMemberId { get; set; }

            [Required]
            [StringLength(50)]
            [Display(Name = "User Group Id")]
            public string UserGroupId { get; set; }

            [Required]
            [StringLength(50)]
            [Display(Name = "User Id")]
            public string UserId { get; set; }

            [Required]
            [StringLength(100)]
            [Display(Name = "Username")]
            public string Username { get; set; }
        }

        public class DestroyUserMember
        {
            [Required]
            public string UserMemberId { get; set; }
        }
    }
}
