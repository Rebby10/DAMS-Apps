﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace DigitalAudit.Model.ViewModel.Idaman
{
    public class ApplicationIdamanViewModel
    {
        [JsonProperty(PropertyName = "id")]
        public string ApplicationId { get; set; }

        [JsonProperty(PropertyName = "clientId")]
        public string ClientId { get; set; }

        [JsonProperty(PropertyName = "type")]
        public string ApplicationType { get; set; }

        [JsonProperty(PropertyName = "name")]
        public string ApplicationName { get; set; }

        [JsonProperty(PropertyName = "description")]
        public string ApplicationDescription { get; set; }
    }
}
