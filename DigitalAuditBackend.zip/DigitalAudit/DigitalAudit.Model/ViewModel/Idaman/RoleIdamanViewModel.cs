﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace DigitalAudit.Model.ViewModel.Idaman
{
    public class RoleIdamanViewModel
    {
        [JsonProperty(PropertyName = "id")]
        public string Id { get; set; }

        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }

        [JsonProperty(PropertyName = "position")]
        public PositionIdamanViewModel Position { get; set; }

        [JsonProperty(PropertyName = "application")]
        public ApplicationIdamanViewModel Application { get; set; }
    }
}
