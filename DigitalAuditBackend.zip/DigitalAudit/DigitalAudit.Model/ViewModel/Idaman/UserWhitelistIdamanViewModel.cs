﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalAudit.Model.ViewModel.Idaman
{
    public class UserWhitelistIdamanViewModel
    {
        public string id { get; set; }
        public UserWhitelistIdamanViewModel.UserModel user { get; set; }
        public List<UserWhitelistIdamanViewModel.RoleModel> role { get; set; }
        public bool? isDeleted { get; set; }

        public class UserModel
        {
            public string id { get; set; }
            public string displayName { get; set; }
            public string email { get; set; }
        }

        public class RoleModel
        {
            public string id { get; set;  }
            public string roleName { get; set;  }
            public UserWhitelistIdamanViewModel.RoleApplicationModel application { get; set; }

        }

        public class RoleApplicationModel
        {
            public string id { get; set; }
            public string applicationName { get; set; }
        }
    }


}
