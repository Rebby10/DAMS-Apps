﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace DigitalAudit.Model.ViewModel.Idaman
{
    public class PositionIdamanViewModel
    {
        [JsonProperty(PropertyName = "Id")]
        public string PositionId { get; set; }

        [JsonProperty(PropertyName = "name")]
        public string PositionName { get; set; }

        [JsonProperty(PropertyName = "Organization")]
        public OrganizationIdamanViewModel Organization { get; set; }

        [JsonProperty(PropertyName = "KBO")]
        public string KBO { get; set; }

        [JsonProperty(PropertyName = "lastModified")]
        public string LastModified { get; set; }

        [JsonProperty(PropertyName = "isPublished")]
        public bool? IsPublished { get; set; }
    }
}
