﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace DigitalAudit.Model.ViewModel.Idaman
{
    public class RoleIdamanAllViewModel
    {
        [JsonProperty(PropertyName = "type")]
        public string Type { get; set; }

        [JsonProperty(PropertyName = "roles")]
        public List<RoleIdamanViewModel> Roles { get; set; }
    }
}
