﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalAudit.Model.ViewModel.Idaman
{
    public class OrganizationIdamanViewModel
    {
        [JsonProperty(PropertyName = "id")]
        public string OrganizationId { get; set; }

        [JsonProperty(PropertyName = "name")]
        public string OrganizationName { get; set; }

        [JsonProperty(PropertyName = "companyCode")]
        public string CompanyCode { get; set; }
    }
}
