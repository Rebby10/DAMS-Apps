﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class MUserWhitelistViewModel
    {
        public class QueryUserWhitelist : PagingViewModel
        {
            public string id { get; set; }
            public string user_id { get; set; }
            public string official_name { get; set; }
            public string email { get; set; }
        }

        public class ReadUserWhitelist
        {
            public string UserWhitelistId { get; set; }

            [Display(Name = "User")]
            public MUserSyncAllViewModel.ReadUserLite User { get; set; }
        }

        public class CreateUserWhitelist
        {
            [Required]
            [StringLength(50)]
            [Display(Name = "UserId")]
            public string UserId { get; set; }
        }

        public class UpdateUserWhitelist
        {
            [Required]
            public string UserWhitelistId { get; set; }

            [Required]
            [StringLength(50)]
            [Display(Name = "UserId")]
            public string UserId { get; set; }
        }

        public class DestroyUserWhitelist
        {
            [Required]
            public string UserWhitelistId { get; set; }
        }
    }
}
