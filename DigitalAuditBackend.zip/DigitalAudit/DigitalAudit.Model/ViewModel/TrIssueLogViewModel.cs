﻿using DigitalAudit.Model.Database;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class TrIssueLogViewModel
    {
        public class QueryIssueLog
        {
            [Required]
            public string IssueId { get; set; }
            public DateTime LastDate { get; set; }
        }

        public class ReadIssueLog
        {
            [Required]
            public string Id { get; set; }
            public string IssueId { get; set; }
            public UserIdamanViewModel.UserRead User { get; set; }
            public string Text { get; set; }
            public DateTime Datetime { get; set; }
            public string Filename { get; set; }
            public string Link { get; set; }
            public MLogTypeViewModel.ReadLogType Type { get; set; }
        }

        public class CreateIssueLog
        {
            [Required]
            public string IssueId { get; set; }
            public string text { get; set; }
            public IFormFile File { get; set; }
            public string UserCreated { get; set; }
        }
    }
}
