﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class HomeViewModel
    {
        public class QuerySearchOverview : PagingViewModel
        {
            public string user_id { get; set; }
            public string role_id { get; set; }
            public string search { get; set; }
        }
    }
}
