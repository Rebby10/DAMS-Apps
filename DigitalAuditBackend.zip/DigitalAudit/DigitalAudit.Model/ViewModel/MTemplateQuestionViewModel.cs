﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class MTemplateQuestionViewModel
    {
        public class QueryTemplateQuestion : PagingViewModel
        {
            public int? id { get; set; }
            public string page_id { get; set; }
            public string code { get; set; }
            public string question { get; set; }
            public string section_id { get; set; }
            public int? seq_no { get; set; }
        }

        public class ReadTemplateQuestion
        {
            public int? QuestionId { get; set; }
            public string PageId { get; set; }
            public int SeqNo { get; set; }
            public string Code { get; set; }
            public string Question { get; set; }

            public bool IsMandatory { get; set; }

            public string SectionId { get; set; }

            public MResponseViewModel.ReadResponse Response { get; set; }
            public TrInspectionResultViewModel.ReadInspectionResult Answer { get; set; }

            public ReadTemplateQuestion()
            {
            }

            public ReadTemplateQuestion(int? questionId, string pageId, int seqNo, string code, string question, 
                bool isMandatory, string sectionId, MResponseViewModel.ReadResponse response, TrInspectionResultViewModel.ReadInspectionResult answer)
            {
                QuestionId = questionId;
                PageId = pageId;
                SeqNo = seqNo;
                Code = code;
                Question = question;
                IsMandatory = isMandatory;
                SectionId = sectionId;
                Response = response;
                Answer = answer;
            }
        }

        public class CreateTemplateQuestion
        {
            //[Required]
            //public int QuestionId { get; set; }

            [Required]
            public string PageId { get; set; }

            [Required]
            public int SeqNo { get; set; }

            [Required]
            [StringLength(50)]
            public string Code { get; set; }

            [Required]
            [StringLength(500)]
            public string Question { get; set; }

            [Required]
            public bool IsMandatory { get; set; }

            public string SectionId { get; set; }

            public int ResponseId { get; set; }
        }

        public class UpdateTemplateQuestion
        {
            [Required]
            public int QuestionId { get; set; }

            [Required]
            public string PageId { get; set; }

            [Required]
            public int SeqNo { get; set; }


            [Required]
            [StringLength(50)]
            public string Code { get; set; }

            [Required]
            [StringLength(500)]
            public string Question { get; set; }

            [Required]
            public bool IsMandatory { get; set; }

            public string SectionId { get; set; }

            public int ResponseId { get; set; }
        }

        public class DestroyTemplateQuestion
        {
            [Required]
            public int QuestionId { get; set; }
        }
    }
}
