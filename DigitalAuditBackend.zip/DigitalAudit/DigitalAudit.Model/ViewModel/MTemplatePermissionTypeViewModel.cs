﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class MTemplatePermissionTypeViewModel
    {
        public class QueryMTemplatePermissionType : PagingViewModel
        {
            public int? id { get; set; }
            public string name { get; set; }
        }

        public class ReadMTemplatePermissionType
        {
            public int TemplatePermissionTypeId { get; set; }

            [Display(Name = "Nama Permission Type")]
            public string Name { get; set; }

            public ReadMTemplatePermissionType() { }
            public ReadMTemplatePermissionType(int templatePermissionTypeId, string name)
            {
                TemplatePermissionTypeId = templatePermissionTypeId;
                Name = name;
            }
        }

        public class CreateMTemplatePermissionType
        {
            [Required]
            [StringLength(100)]
            [Display(Name = "Nama Template Permission")]
            public string Name { get; set; }
        }

        public class UpdateMTemplatePermissionType
        {
            [Required]
            public string TemplatePermissionTypeId { get; set; }

            [Required]
            [StringLength(100)]
            [Display(Name = "Nama Template Permission")]
            public string Name { get; set; }
        }

        public class DestroyMTemplatePermissionType
        {
            [Required]
            public string TemplatePermissionTypeId { get; set; }
        }
    }
}
