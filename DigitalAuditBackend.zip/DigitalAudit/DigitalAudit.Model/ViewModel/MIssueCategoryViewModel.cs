﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class MIssueCategoryViewModel
    {
        public class ReadIssueCategory
        {
            public int IssueCategoryId { get; set; }
            public string Name { get; set; }
        }
    }
}
