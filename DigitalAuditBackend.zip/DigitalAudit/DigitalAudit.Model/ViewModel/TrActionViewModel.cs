﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;


namespace DigitalAudit.Model.ViewModel
{
    public class TrActionViewModel
    {
        public class QueryAction : PagingViewModel
        {
            public string ActionId { get; set; }
            public string Title { get; set; }
            public string QuestionId { get; set; }
            public string AuditLocationId { get; set; }
            public string RegionId { get; set; }
            public int? PriorityId { get; set; }
            public string Priority { get; set; }
            public int? StatusId { get; set; }
            public string InspectionId { get; set; }
            public string UserCreated { get; set; }
            public string AssignUser { get; set; }
            public DateTime? StartDate { get; set; }
            public DateTime? EndDate { get; set; }
            public string AuditTypeId { get; set; }
            public bool? IsConnectedToIssue { get; set; }
            public string IssueId { get; set; }

        }

        public class ReadAction
        {
            public string ActionId { get; set; }
            [Required]
            public string Title { get; set; }
            [Required]
            public string Descriptions { get; set; }
            public string QuestionId { get; set; }
            public string Code { get; set; }
            public string Question { get; set; }
            public virtual MAuditTypeViewModel.ReadAuditType AuditType { get; set; }
            public virtual TrIssueViewModel.ReadIssueLite Issue { get; set; }
            public virtual MAuditLocationViewModel.ReadAuditLocation AuditLocation { get; set; }
            public virtual MUserGroupViewModel.ReadUserGroup AssignGroup { get; set; }
            public virtual MUserSyncViewModel.ReadUserLite AssignUser { get; set; }
            public virtual MUserSyncViewModel.ReadUserLite Creator { get; set; }
            public virtual MPriorityViewModel.ReadPriority Priority { get; set; }
            public DateTime TargetClosing { get; set; }
            public virtual MIssueStatusViewModel.ReadIssueStatus Status { get; set; }
            public string InspectionId { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime? DateModified { get; set; }
        }

        public class ReadActionRepair
        {
            public string ActionId { get; set; }
            public string Title { get; set; }
        }

        public class CreateAction
        {
            [Required]
            public string Title { get; set; }
            [Required]
            public string Descriptions { get; set; }

            public string QuestionId { get; set; }
            public string Code { get; set; }
            public string Question { get; set; }

            [Required]
            public string AuditLocationId { get; set; }
            public string AssignGroup { get; set; }
            public string AssignUser { get; set; }
            public string IssueId { get; set; }
            [Required]
            public string Creator { get; set; }
            [Required]
            public int PriorityId { get; set; }
            [Required]
            public DateTime TargetClosing { get; set; }
            [Required]
            public int StatusId { get; set; }
            public string InspectionId { get; set; }
            public string UserCreated { get; set; }
        }

        public class UpdateAction
        {
            [Required]
            public string ActionId { get; set; }
            [Required]
            public string Title { get; set; }
            [Required]
            public string Descriptions { get; set; }
            [Required]
            public string AuditLocationId { get; set; }
            public string AssignGroup { get; set; }
            public string AssignUser { get; set; }
            public string IssueId { get; set; }
            [Required]
            public string Creator { get; set; }
            [Required]
            public int PriorityId { get; set; }
            [Required]
            public DateTime TargetClosing { get; set; }
            [Required]
            public int StatusId { get; set; }

            public string UserCreated { get; set; }
        }

        public class UpdateStatusAction
        {
            [Required]
            public string ActionId { get; set; }
            [Required]
            public int StatusId { get; set; }
            public string UserCreated { get; set; }
        }

        public class MultipleDeleteAction
        {
            [Required]
            public List<string> ActionId { get; set; }
        }

        public class ImportAction
        {
            [Required]
            public IFormFile File { get; set; }
        }
    }
}
