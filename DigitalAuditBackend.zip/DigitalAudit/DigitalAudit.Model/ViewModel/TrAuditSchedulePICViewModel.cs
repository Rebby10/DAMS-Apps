﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class TrAuditSchedulePICViewModel
    {
        public class QueryAuditSchedulePIC : PagingViewModel
        {
        }

        public class ReadAuditSchedulePIC
        {
            public ReadAuditSchedulePIC()
            {
            }

            public ReadAuditSchedulePIC(string picId, string scheduleId, MUserSyncViewModel.ReadUserSync users, MUserGroupViewModel.ReadUserGroupMember groups, MUserTypeViewModel.ReadUserType userType, MScheduleStatusViewModel.ReadScheduleStatus status)
            {
                PicId = picId;
                ScheduleId = scheduleId;
                Users = users;
                Groups = groups;
                UserType = userType;
                Status = status;
            }

            public string PicId { get; set; }

            public string ScheduleId { get; set; }

            [Display(Name = "Users")]
            public MUserSyncViewModel.ReadUserSync Users { get; set; }

            [Display(Name = "Groups")]
            public MUserGroupViewModel.ReadUserGroupMember Groups { get; set; }

            [Display(Name = "User Type")]
            public MUserTypeViewModel.ReadUserType UserType { get; set; }

            [Display(Name = "Status")]
            public MScheduleStatusViewModel.ReadScheduleStatus Status { get; set; }
        }

        public class CreateAuditSchedulePIC
        {
            public CreateAuditSchedulePIC()
            {
            }

            public CreateAuditSchedulePIC(string userId, string userGroupId)
            {
                UserId = userId;
                UserGroupId = userGroupId;
            }

            [StringLength(50)]
            [Display(Name = "User Id")]
            public string UserId { get; set; }

            [StringLength(50)]
            [Display(Name = "User Group Id")]
            public string UserGroupId { get; set; }
        }

        public class UpdateAuditSchedulePIC
        {
            [Required]
            [StringLength(50)]
            public string ScheduleId { get; set; }

            [Required]
            [StringLength(50)]
            [Display(Name = "Audit Location Id")]
            public string AuditLocationId { get; set; }

            [Required]
            [Display(Name = "Tanggal Awal")]
            public DateTime StartDate { get; set; }

            [Required]
            [Display(Name = "Tanggal Akhir")]
            public DateTime EndDate { get; set; }

            [Required]
            [StringLength(50)]
            [Display(Name = "Audit Type Id")]
            public string AuditTypeId { get; set; }

            [Required]
            [StringLength(50)]
            [Display(Name = "Status Id")]
            public string StatusId { get; set; }
        }

        public class DestroyAuditSchedulePIC
        {
            [Required]
            [StringLength(50)]
            public string ScheduleId { get; set; }
        }
    }
}
