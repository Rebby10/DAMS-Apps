﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class MPriorityViewModel
    {
        public class ReadPriority
        {
            public int PriorityId { get; set; }
            public string Name { get; set; }
        }
    }
}
