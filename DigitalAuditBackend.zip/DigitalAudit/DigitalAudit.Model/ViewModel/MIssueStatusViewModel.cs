﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class MIssueStatusViewModel
    {
        public class ReadIssueStatus
        {
            public int StatusId { get; set; }
            public string Name { get; set; }
        }
    }
}
