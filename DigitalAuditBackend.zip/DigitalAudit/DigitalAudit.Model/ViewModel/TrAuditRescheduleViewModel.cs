﻿using DigitalAudit.Attributes;
using DigitalAudit.Model.Database;
using DigitalAudit.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class TrAuditRescheduleViewModel
    {
        public class QueryTrAuditReschedule : PagingViewModel
        {
            public string user_id { get; set; }
            public int? status_id { get; set; }
        }

        public class ReadTrAuditReschedule
        {
            public string RescheduleId { get; set; }

            [Display(Name = "Pertanyaan")]
            public string Question { get; set; }

            [Display(Name = "Jawaban")]
            public string Answer { get; set; }
        }

        public class RescheduleApproval
        {
            [Required]
            [StringLength(50)]
            public string RescheduleId { get; set; }
            [Required]
            [StringLength(50)]
            public string ScheduleId { get; set; }
            [Required]
            public bool IsApproved { get; set; }
        }

        public class CreateTrAuditReschedule
        {
            [Required]
            [StringLength(50)]
            [Display(Name = "Schedule ID")]
            public string ScheduleId { get; set; }

            [Required]
            [StringLength(100)]
            [Display(Name = "User ID")]
            public string UserId { get; set; }

            [Required]
            //[CustomParseDate]
            [DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}", ApplyFormatInEditMode = true)]
            [CustomDate(ErrorMessage = "Back date tidak diperbolehkan")]
            public DateTime StartDate { get; set; }
            [Required]
            [DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}", ApplyFormatInEditMode = true)]
            [CustomDate(ErrorMessage = "Back date tidak diperbolehkan")]
            //[CustomParseDate]
            [CustomDateGreaterThan(otherPropertyName = "StartDate", ErrorMessage = "End date must be equals or greater than start date")]
            public DateTime EndDate { get; set; }

            [Required]
            [StringLength(400)]
            [MinLength(10, ErrorMessage = "Minimal 10 karakter")]
            public string Descriptions { get; set; }
        }

        public class UpdateTrAuditReschedule
        {
            public string RescheduleId { get; set; }

            [Required]
            [StringLength(1000)]
            [Display(Name = "Pertanyaan")]
            public string Question { get; set; }

            [Required]
            [StringLength(1000)]
            [Display(Name = "Jawaban")]
            public string Answer { get; set; }
        }

        public class DestroyTrAuditReschedule
        {
            public string RescheduleId { get; set; }
        }
    }
}
