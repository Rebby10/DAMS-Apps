﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class TrInspectionPICViewModel
    {
        public class CreateInspectionPIC
        {
            [StringLength(50)]
            [Display(Name = "User Id")]
            public string UserId { get; set; }

            [StringLength(50)]
            [Display(Name = "User Group Id")]
            public string UserGroupId { get; set; }
        }

        public class ReadInspectionPIC
        {
            public ReadInspectionPIC()
            {
            }

            public ReadInspectionPIC(string picId, string inspectionId, MUserSyncViewModel.ReadUserSync users, MUserGroupViewModel.ReadUserGroupMember groups, MUserTypeViewModel.ReadUserType userType)
            {
                PicId = picId;
                InspectionId = inspectionId;
                Users = users;
                Groups = groups;
                UserType = userType;
            }

            public string PicId { get; set; }

            public string InspectionId { get; set; }

            [Display(Name = "Users")]
            public MUserSyncViewModel.ReadUserSync Users { get; set; }

            [Display(Name = "Groups")]
            public MUserGroupViewModel.ReadUserGroupMember Groups { get; set; }

            [Display(Name = "User Type")]
            public MUserTypeViewModel.ReadUserType UserType { get; set; }

        }
    }
}
