﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class ReportInspectionViewModel
    {
        public class ReportOverview
        {
            public string InspectionId { get; set; }
            public string Title { get; set; }
            public string Descriptions { get; set; }
            public DateTime? CompletedDate { get; set; }
            public DateTime? ApprovedDate { get; set; }
            public double Score { get; set; }
            public string PreparedBy { get; set; }
            public string LocationName { get; set; }
            public string LatLong { get; set; }
            public string Address { get; set; }
            public string StatusInspection { get; set; }
        }

        public class ReportSummary
        {
            public string InspectionId { get; set; }
            public Recomendation PreviousRecomendation { get; set; }
            public Recomendation CurrentRecomendation { get; set; }
            public double Score { get; set; }
            public List<Image> Images { get; set; }

            public ReportSummary()
            {
            }

            public ReportSummary(string inspectionId, Recomendation previousRecomendation, Recomendation currentRecomendation, double score, List<Image> image)
            {
                InspectionId = inspectionId;
                PreviousRecomendation = previousRecomendation;
                CurrentRecomendation = currentRecomendation;
                Score = score;
                Images = image;
            }
        }

        public class ReportAll
        {
            public ReportOverview Overview { get; set; }
            public ReportSummary Summary { get; set; }
            public MTemplateMainViewModel TitlePage { get; set; }
            public List<MTemplatePageViewModel.ReadTemplatePageDetail> ChecklistResult { get; set; }
            public List<TrIssueViewModel.ReadIssue> FailedItems { get; set; }
            public List<TrInspectionInfoViewModel.ReadInspectionInfo> AdditionalInformation { get; set; }

            public ReportAll(ReportOverview overview, ReportSummary summary, MTemplateMainViewModel titlePage, List<MTemplatePageViewModel.ReadTemplatePageDetail> checklistResult, List<TrIssueViewModel.ReadIssue> failedItems, List<TrInspectionInfoViewModel.ReadInspectionInfo> additionalInformation)
            {
                Overview = overview;
                Summary = summary;
                TitlePage = titlePage;
                ChecklistResult = checklistResult;
                FailedItems = failedItems;
                AdditionalInformation = additionalInformation;
            }
        }

        public class Issue
        {
            public string Status { get; set; }
            public int Total { get; set; }

            public Issue()
            {
            }

            public Issue(string status, int total)
            {
                Status = status;
                Total = total;
            }
        }

        public class Action
        {
            public string Status { get; set; }
            public int Total { get; set; }

            public Action(string status, int total)
            {
                Status = status;
                Total = total;
            }

            public Action()
            {
            }
        }

        public class Recomendation
        {
            public List<Issue> Issue { get; set; }
            public List<Action> Action { get; set; }

            public Recomendation(List<Issue> issue, List<Action> action)
            {
                Issue = issue;
                Action = action;
            }

            public Recomendation()
            {
            }
        }

        public class Image
        {
            public string link { get; set; }
        }

        public class Score
        {
            public double ScoreInspection { get; set; }
        }
    }
}
