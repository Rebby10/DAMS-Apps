﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class MRootCauseCategoryViewModel
    {
        public class QueryRootCauseCategory : PagingViewModel
        {
            public string Id { get; set; }
            public string Name { get; set; }
        }

        public class ReadRootCauseCategory
        {
            public string Id { get; set; }
            public string Name { get; set; }
        }
    }
}
