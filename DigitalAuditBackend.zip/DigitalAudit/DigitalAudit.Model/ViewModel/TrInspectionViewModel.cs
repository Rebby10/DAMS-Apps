﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class TrInspectionViewModel
    {
        public class QueryInspection : PagingViewModel
        {
            public int UserTypeId { get; set; }
            public int? StatusId { get; set; }
            public string RegionId { get; set; }
            public string AuditLocationId { get; set; }
            public string UserCreated { get; set; }
            public string Text { get; set; }
        }

        public class CreateInspection
        {
            [Required]
            public string AuditLocationId { get; set; }
            [Required]
            public string TemplateId { get; set; }
            [Required]
            public TrInspectionPICViewModel.CreateInspectionPIC Auditor { get; set; }
            [Required]
            public TrInspectionPICViewModel.CreateInspectionPIC Auditee { get; set; }
            public string UserCreated { get; set; }
        }

        public class ReadInspection
        {
            public string InspectionId { get; set; }
            public string ScheduleId { get; set; }

            [Display(Name = "Audit Location")]
            public MAuditLocationViewModel.ReadAuditLocation AuditLocation { get; set; }

            [Display(Name = "Start Date")]
            public DateTime StartDate { get; set; }

            [Display(Name = "End Date")]
            public DateTime EndDate { get; set; }

            [Display(Name = "Template")]
            public ReadTemplate Template { get; set; }

            [Display(Name = "Status")]
            public MInspectionStatusViewModel.ReadInspectiontatus Status { get; set; }

            public TrInspectionPICViewModel.ReadInspectionPIC Auditor { get; set; }
            public TrInspectionPICViewModel.ReadInspectionPIC Auditee { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime? DateModified { get; set; }
        }

        public class ReadTemplate
        {
            public ReadTemplate(string templateId, string title)
            {
                TemplateId = templateId;
                Title = title;
            }

            public string TemplateId { get; set; }
            public string Title { get; set; }
        }

        public class StartInspection : MTemplateMainViewModel
        {
            public ReadInspection Inspection { get; set; }

        }
    }
}
