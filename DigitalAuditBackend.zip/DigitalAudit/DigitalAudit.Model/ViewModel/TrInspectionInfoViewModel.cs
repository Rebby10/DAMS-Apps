﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class TrInspectionInfoViewModel
    {     

        public class CreateInspectionInfo
        {
            [Required]
            public string InspectionId { get; set; }
            [Required]
            public string Title { get; set; }
            [Required]
            public string Notes { get; set; }
            public string UserCreated { get; set; }
        }

        public class UpdateInspectionInfo : CreateInspectionInfo
        {
            [Required]
            public string InfoId { get; set; }
        }

        public class ReadInspectionInfo
        {
            public string InfoId { get; set; }
            public string InspectionId { get; set; }
            public string Title { get; set; }
            public string Notes { get; set; }
        }
    }
}
