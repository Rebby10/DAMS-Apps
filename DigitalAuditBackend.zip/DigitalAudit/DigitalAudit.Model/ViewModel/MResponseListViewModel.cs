﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class MResponseListViewModel
    {
        public class QueryResponseList : PagingViewModel
        {
            public int id { get; set; }
            public string name { get; set; }
            public int response_id { get; set; }
        }

        public class ReadResponseList
        {
            public int ListId { get; set; }
            public int ResponseId { get; set; }
            public string Name { get; set; }
            public double? Score { get; set; }
            public bool IsFailedResponse { get; set; }
            public int SeqNo { get; set; }

        }

        public class CreateResponseList
        {
            [Required]
            public int ResponseId { get; set; }
            [Required]
            public string Name { get; set; }
            public double? Score { get; set; }
            [Required]
            public bool IsFailedResponse { get; set; }
            [Required]
            public int SeqNo { get; set; }
        }

        public class UpdateResponseList : CreateResponseList
        {
            [Required]
            public int ListId { get; set; }
        }

        public class DestroyResponseList
        {
            [Required]
            public int ListId { get; set; }
        }
    }
}
