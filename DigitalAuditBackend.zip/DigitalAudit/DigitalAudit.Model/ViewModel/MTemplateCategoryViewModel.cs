﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class MTemplateCategoryViewModel
    {
        public class QueryTemplateCategory : PagingViewModel
        {
            public int? id { get; set; }
            public string name { get; set; }
        }

        public class ReadTemplateCategory
        {
            public int CategoryId { get; set; }

            [Display(Name = "Nama Category")]
            public string Name { get; set; }

            public ReadTemplateCategory() { }
            public ReadTemplateCategory(int categoryId, string name)
            {
                CategoryId = categoryId;
                Name = name;
            }
        }

        public class CreateTemplateCategory
        {
            [Required]
            [StringLength(100)]
            [Display(Name = "Nama Category")]
            public string Name { get; set; }
        }

        public class UpdateTemplateCategory
        {
            [Required]
            public int CategoryId { get; set; }

            [Required]
            [StringLength(100)]
            [Display(Name = "Nama Template Category")]
            public string Name { get; set; }
        }

        public class DestroyTemplateCategory
        {
            [Required]
            public int CategoryId { get; set; }
        }
    }
}
