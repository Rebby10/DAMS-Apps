﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class MActionStatusViewModel
    {
        public class ReadActionStatus
        {
            public int StatusId { get; set; }
            public string Name { get; set; }
        }
    }
}
