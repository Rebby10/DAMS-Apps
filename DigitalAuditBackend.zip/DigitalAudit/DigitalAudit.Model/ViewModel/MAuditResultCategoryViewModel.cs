﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class MAuditResultCategoryViewModel
    {
        public class QueryResultCategory : PagingViewModel
        {
            public string id { get; set; }
            public string name { get; set; }
        }

        public class ReadAuditResultCategory
        {
            public string AuditResultCategoryId { get; set; }

            [Display(Name = "Kategori Hasil Audit")]
            public string Name { get; set; }
        }

        public class CreateAuditResultCategory
        {
            [Required]
            [StringLength(100)]
            [Display(Name = "Kategori Hasil Audit")]
            public string Name { get; set; }
        }

        public class UpdateAuditResultCategory
        {
            [Required]
            public string AuditResultCategoryId { get; set; }

            [Required]
            [StringLength(100)]
            [Display(Name = "Kategori Hasil Audit")]
            public string Name { get; set; }
        }

        public class DestroyAuditResultCategory
        {
            [Required]
            public string AuditResultCategoryId { get; set; }
        }
    }
}
