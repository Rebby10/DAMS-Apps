﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class MTemplateSectionViewModel
    {
        public class QueryTemplateSection : PagingViewModel
        {
            public string id { get; set; }
            public string page_id { get; set; }
            public string name { get; set; }
            public int? seq_no { get; set; }
        }

        public class ReadTemplateSection
        {
            public string SectionId { get; set; }
            public string PageId { get; set; }
            public string Name { get; set; }
            public int SeqNo { get; set; }

        }

        public class ReadTemplateSectionDetail
        {
            public string SectionId { get; set; }
            public string PageId { get; set; }
            public string Name { get; set; }
            public int SeqNo { get; set; }
            public List<MTemplateQuestionViewModel.ReadTemplateQuestion> Question { get; set; }
        }

        public class CreateTemplateSection
        {
            //[Required]
            //public string SectionId { get; set; }

            [Required]
            public string PageId { get; set; }

            [Required]
            [StringLength(50)]
            public string Name { get; set; }

            [Required]
            public int SeqNo { get; set; }
        }

        public class UpdateTemplateSection
        {
            [Required]
            public string SectionId { get; set; }

            [Required]
            public string PageId { get; set; }

            [Required]
            [StringLength(50)]
            public string Name { get; set; }

            [Required]
            public int SeqNo { get; set; }
        }

        public class DestroyTemplateSection
        {
            [Required]
            public string SectionId { get; set; }
        }
    }
}
