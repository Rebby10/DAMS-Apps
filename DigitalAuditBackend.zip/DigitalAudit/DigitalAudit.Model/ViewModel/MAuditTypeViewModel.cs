﻿using DigitalAudit.Model.Util;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class MAuditTypeViewModel
    {
        public class QueryAuditType : PagingViewModel
        {
            public string id { get; set; }
            public string name { get; set; }
        }

        public class ReadAuditType
        {
            private string _auditTypeId;
            private string _name;

            public ReadAuditType()
            {
            }

            public ReadAuditType(string auditTypeId, string name)
            {
                AuditTypeId = auditTypeId;
                Name = name;
            }

            public string AuditTypeId { get => GeneralParser.parseNullString(_auditTypeId); set => _auditTypeId = value; }

            [Display(Name = "Tipe Audit")]
            public string Name { get => GeneralParser.parseNullString(_name); set => _name = value; }

            //public string AuditTypeId { get; set; }

            //[Display(Name = "Tipe Audit")]
            //public string Name { get; set; }

            //public ReadAuditType(string auditTypeId, string name)
            //{
            //    AuditTypeId = auditTypeId;
            //    Name = name;
            //}

            //public ReadAuditType()
            //{
            //}
        }

        public class CreateAuditType
        {
            [Required]
            [StringLength(100)]
            [Display(Name = "Tipe Audit")]
            public string Name { get; set; }
        }

        public class UpdateAuditType
        {
            [Required]
            public string AuditTypeId { get; set; }

            [Required]
            [StringLength(100)]
            [Display(Name = "Tipe Audit")]
            public string Name { get; set; }
        }

        public class DestroyAuditType
        {
            [Required]
            public string AuditTypeId { get; set; }
        }
    }
}
