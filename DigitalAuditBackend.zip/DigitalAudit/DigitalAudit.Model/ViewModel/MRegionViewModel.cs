﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class MRegionViewModel
    {
        public class QueryRegion : PagingViewModel
        {
            public string id { get; set; }
            public string name { get; set; }
        }

        public class ReadRegion
        {
            public string RegionId { get; set; }

            [Display(Name = "Nama Region")]
            public string Name { get; set; }

            public ReadRegion() { }
            public ReadRegion(string regionId, string name) 
            {
                RegionId = regionId;
                Name = name;
            }
        }

        public class CreateRegion
        {
            [Required]
            [StringLength(100)]
            [Display(Name = "Nama Region")]
            public string Name { get; set; }
        }

        public class UpdateRegion
        {
            [Required]
            public string RegionId { get; set; }

            [Required]
            [StringLength(100)]
            [Display(Name = "Nama Region")]
            public string Name { get; set; }
        }

        public class DestroyRegion
        {
            [Required]
            public string RegionId { get; set; }
        }
    }
}
