﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class TrActionRepairViewModel
    {
        public class QueryActionRepair : PagingViewModel
        {
            public string ActionId { get; set; }
            public string RootCause { get; set; }
            public string RootCauseCategoryId { get; set; }
            public string ActionRepair { get; set; }
            public string ActionRepairCategoryId { get; set; }
            public DateTime RepairDate { get; set; }
        }

        public class ReadActionRepair
        {
            public string ActionRepairId { get; set; }
            public virtual TrActionViewModel.ReadActionRepair Action { get; set; }
            public string RootCause { get; set; }
            public virtual MRootCauseCategoryViewModel.ReadRootCauseCategory RootCauseCategory { get; set; }
            public string ActionRepair { get; set; }
            public virtual MActionRepairCategoryViewModel.ReadActionRepairCategory ActionRepairCategory { get; set; }
            public DateTime RepairDate { get; set; }
            public string Filename { get; set; }
            //public string LinkFile { get; set; }
        }

        public class CreateActionRepair
        {
            [Required]
            public string ActionId { get; set; }
            [Required]
            public string RootCause { get; set; }
            [Required]
            public string RootCauseCategoryId { get; set; }
            [Required]
            public string ActionRepair { get; set; }
            [Required]
            public string ActionRepairCategoryId { get; set; }
            [Required]
            public DateTime RepairDate { get; set; }
            public IFormFile Filename { get; set; }
        }

        public class UpdateAction
        {
            [Required]
            public string ActionRepairId { get; set; }
            [Required]
            public string ActionId { get; set; }
            [Required]
            public string RootCause { get; set; }
            [Required]
            public string RootCauseCategoryId { get; set; }
            [Required]
            public string ActionRepair { get; set; }
            [Required]
            public string ActionRepairCategoryId { get; set; }
            [Required]
            public DateTime RepairDate { get; set; }
            public string Filename { get; set; }
        }

    }
}
