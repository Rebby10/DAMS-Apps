﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class MasterViewModel
    {
        public List<MIssueStatusViewModel.ReadIssueStatus> IssueStatus { get; set; } 
        public List<MIssueCategoryViewModel.ReadIssueCategory> IssueCategory { get; set; } 
        public List<MPriorityViewModel.ReadPriority> Priority { get; set; } 
        public List<MRootCauseCategoryViewModel.ReadRootCauseCategory> RootCauseCategory { get; set; } 
        public List<MActionRepairCategoryViewModel.ReadActionRepairCategory> ActionRepairCategory { get; set; } 
        public List<MInspectionStatusViewModel.ReadInspectiontatus> InspectionStatus { get; set; } 
    }
}
