﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class MUserSyncViewModel
    {
        public class QueryUserSync : PagingViewModel
        {
            public string id { get; set; }
            public string name { get; set; }
        }

        public class ReadUserSync
        {
            public ReadUserSync() { }

            public ReadUserSync(string userSyncId, string userId, string organizationId, string positionId, string companyCode, string city, string companyName, string country, string department, string displayName, string employeeId, string firstName, string lastName, string jobTitle, string email, string mobilePhone, string officeLocation, string username)
            {
                UserSyncId = userSyncId;
                UserId = userId;
                OrganizationId = organizationId;
                PositionId = positionId;
                CompanyCode = companyCode;
                City = city;
                CompanyName = companyName;
                Country = country;
                Department = department;
                DisplayName = displayName;
                EmployeeId = employeeId;
                FirstName = firstName;
                LastName = lastName;
                JobTitle = jobTitle;
                Email = email;
                MobilePhone = mobilePhone;
                OfficeLocation = officeLocation;
                Username = username;
            }

            public string UserSyncId { get; set; }
            public string UserId { get; set; }
            public string OrganizationId { get; set; }
            public string PositionId { get; set; }
            public string CompanyCode { get; set; }
            public string City { get; set; }
            public string CompanyName { get; set; }
            public string Country { get; set; }
            public string Department { get; set; }
            public string DisplayName { get; set; }
            public string EmployeeId { get; set; }
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public string JobTitle { get; set; }
            public string Email { get; set; }
            public string MobilePhone { get; set; }
            public string OfficeLocation { get; set; }
            public string Username { get; set; }
        }

        public class ReadUserLite
        {
            public ReadUserLite()
            {
            }

            public ReadUserLite(string userId, string displayName, string email)
            {
                UserId = userId;
                DisplayName = displayName;
                Email = email;
            }

            public string UserId { get; set; }
            public string DisplayName { get; set; }
            public string Email { get; set; }
        }

        public class ReadUserAuditee
        {
            public string Id { get; set; }
            public string DisplayName { get; set; }
            public bool IsGroup { get; set; }
        }
    }
}
