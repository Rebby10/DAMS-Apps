﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;


namespace DigitalAudit.Model.ViewModel
{
    public class TrInspectionSignatureViewModel
    {
        public class CreateInspectionSignature
        {
            [Required]
            public string InspectionId { get; set; }
            [Required]
            public string Title { get; set; }
            [Required]
            public string Name { get; set; }
            public IFormFile Signature { get; set; }
            public string UserCreated { get; set; }
        }

        public class UpdateInspectionSignature : CreateInspectionSignature
        {
            [Required]
            public string SignatureId { get; set; }
        }

        public class ReadInspectionSignature
        {
            public string SignatureId { get; set; }
            public string InspectionId { get; set; }
            public string Title { get; set; }
            public string Name { get; set; }
            public string Signature { get; set; }
        }
    }
}
