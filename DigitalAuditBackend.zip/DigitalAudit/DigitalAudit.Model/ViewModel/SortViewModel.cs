﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class SortViewModel
    {
        public string sort_by { get; set; }
        public string order_by { get; set; }
    }
}
