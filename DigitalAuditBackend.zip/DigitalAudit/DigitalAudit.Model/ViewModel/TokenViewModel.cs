﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class TokenViewModel
    {
        public class GetToken
        {
            public string Token { get; set; }
            public DateTime? Expired { get; set; }
        }

        public class Token
        {
            public string TokenUser { get; set; }
            public string TokenPassword { get; set; }
        }
    }
}
