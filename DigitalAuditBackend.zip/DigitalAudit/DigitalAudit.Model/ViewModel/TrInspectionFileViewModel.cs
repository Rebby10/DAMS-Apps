﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class TrInspectionFileViewModel
    {
        public class QueryTrInspectionFile : PagingViewModel
        {
            [Required]
            public string InspectionId { get; set; }
            [Required]
            public int QuestionId { get; set; }
            [Required]
            public int FileTypeId { get; set; }
        }

        public class CreateInspectionFile
        {
            [Required]
            public string InspectionId { get; set; }
            [Required]
            public int QuestionId { get; set; }
            [Required]
            public IFormFile File { get; set; }
            [Required]
            public int FileTypeId { get; set; }
            [Required]
            public string UserCreated { get; set; }
        }

        public class UpdateInspectionFile : CreateInspectionFile
        {
            [Required]
            public string FileId { get; set; }
        }

        public class ReadInspectionFile
        {
            public string FileId { get; set; }
            public string InspectionId { get; set; }
            public int QuestionId { get; set; }
            public string Filename { get; set; }
            public int FileTypeId { get; set; }
            public string LinkFile { get; set; }
        }
    }
}
