﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class PagingViewModel : SortViewModel
    {
        public int? page_size { get; set; } = 25;
        public int? page_number { get; set; } = 1;
    }
}
