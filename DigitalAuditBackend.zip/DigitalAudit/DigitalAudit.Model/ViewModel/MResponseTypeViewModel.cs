﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class MResponseTypeViewModel
    {
        public class QueryMResponseType : PagingViewModel
        {
            public int? id { get; set; }
            public string name { get; set; }
        }

        public class ReadMResponseType
        {
            public int TypeId { get; set; }
            public string Name { get; set; }

            public ReadMResponseType()
            {
            }

            public ReadMResponseType(int typeId, string name)
            {
                TypeId = typeId;
                Name = name;
            }


        }

        public class ReadMResponseDetail //: ReadMResponseType
        {
            public int TypeId { get; set; }
            public string Name { get; set; }
            public List<MResponseViewModel.ReadResponseHeader> Responses { get; set; }
        }

        public class CreateMResponseType
        {

            [Required]
            [Display(Name = "Type Id")]
            public int TypeId { get; set; }

            [Required]
            [StringLength(100)]
            [Display(Name = "Nama")]
            public string Name { get; set; }

        }

        public class UpdateMResponseType
        {
            [Required]
            public int TypeId { get; set; }

            [Required]
            [StringLength(100)]
            [Display(Name = "Nama")]
            public string Name { get; set; }
        }

        public class DestroyMResponseType
        {
            [Required]
            public int TypeId { get; set; }
        }
    }
}
