﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class IdamanUserWhitelistModel
    {

        public IdamanUserWhitelistModel(string userId, string applicationId)
        {
            UserId = userId;
            ApplicationId = applicationId;
        }

        public IdamanUserWhitelistModel()
        {
        }

        public string UserId { get; set; }
        public string ApplicationId { get; set; }
    }
}
