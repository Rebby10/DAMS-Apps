﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class MKboAuditLocationViewModel
    {
        public class QueryKboAuditLocation : PagingViewModel
        {
            public string kbo { get; set; }
            public string AuditLocationId { get; set; }
            public string LocationName { get; set; }
            public string RegionId { get; set; }
            public string RegionName { get; set; }
        }

        public class ReadKboAuditLocation
        {
            public string KboAuditLocationId { get; set; }

            [Display(Name = "Kbo")]
            public string Kbo { get; set; }

            [Display(Name = "Audit Location")]
            public MAuditLocationViewModel.ReadAuditLocation AuditLocation { get; set; }
        }

        public class CreateKboAuditLocation
        {
            [Required]
            [StringLength(50)]
            [Display(Name = "Kbo")]
            public string Kbo { get; set; }

            [Required]
            [StringLength(50)]
            [Display(Name = "Audit Location Id")]
            public string AuditLocationId { get; set; }
        }

        public class UpdateKboAuditLocation
        {
            [Required]
            public string KboAuditLocationId { get; set; }

            [Required]
            [StringLength(50)]
            [Display(Name = "Kbo")]
            public string Kbo { get; set; }

            [Required]
            [StringLength(50)]
            [Display(Name = "Audit Location Id")]
            public string AuditLocationId { get; set; }
        }

        public class DestroyKboAuditLocation
        {
            [Required]
            public string KboAuditLocationId { get; set; }
        }
    }
}
