﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class MAuditLocationViewModel
    {
        public class QueryAuditLocation : PagingViewModel
        {
            public string id { get; set; }
            public string name { get; set; }
            public string address { get; set; }
            public string region_id { get; set; }
            public string region_name { get; set; }
        }

        public class ReadAuditLocation
        {
            public string AuditLocationId { get; set; }

            [Display(Name = "Nama Lokasi")]
            public string Name { get; set; }

            [Display(Name = "Alamat")]
            public string Address { get; set; }

            [Display(Name = "Kode Pos")]
            public string ZipCode { get; set; }

            [Display(Name = "Latitude Longitude")]
            public string LatLong { get; set; }

            [Display(Name = "Region")]
            public MRegionViewModel.ReadRegion Region { get; set; }

            public ReadAuditLocation() { }
            public ReadAuditLocation(string auditLocationId, string name, string address, string zipCode, string latLong, string regionId, string regionName)
            {
                AuditLocationId = auditLocationId;
                Name = name;
                Address = address;
                ZipCode = zipCode;
                LatLong = latLong;
                Region = new MRegionViewModel.ReadRegion(regionId, regionName);
            }
        }

        public class CreateAuditLocation
        {
            [Required]
            [StringLength(100)]
            [Display(Name = "Nama Lokasi")]
            public string Name { get; set; }

            [Required]
            [StringLength(300)]
            [Display(Name = "Alamat")]
            public string Address { get; set; }

            [Required]
            [StringLength(100)]
            [Display(Name = "Kode Pos")]
            public string ZipCode { get; set; }

            [Required]
            [StringLength(100)]
            [Display(Name = "Latitude Longitude")]
            public string LatLong { get; set; }

            [Required]
            [StringLength(50)]
            [Display(Name = "Region Id")]
            public string RegionId { get; set; }
        }

        public class UpdateAuditLocation
        {
            [Required]
            public string AuditLocationId { get; set; }

            [Required]
            [StringLength(100)]
            [Display(Name = "Nama Lokasi")]
            public string Name { get; set; }

            [Required]
            [StringLength(300)]
            [Display(Name = "Alamat")]
            public string Address { get; set; }

            [Required]
            [StringLength(100)]
            [Display(Name = "Kode Pos")]
            public string ZipCode { get; set; }

            [Required]
            [StringLength(100)]
            [Display(Name = "Latitude Longitude")]
            public string LatLong { get; set; }

            [Required]
            [StringLength(50)]
            [Display(Name = "Region Id")]
            public string RegionId { get; set; }
        }

        public class DestroyAuditLocation
        {
            [Required]
            public string AuditLocationId { get; set; }
        }
    }
}
