﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class MTemplateViewModel
    {
        public class QueryMTemplate : PagingViewModel
        {
            public string template_id { get; set; }
            public string code { get; set; }
            public string description { get; set; }
            public string title { get; set; }
            public int? category_id { get; set; }
            public int? template_permission_type_id { get; set; }
            public string user_id { get; set; }
            public string user_group_id { get; set; }
            public string official_name { get; set; }
            public bool? is_show_issue { get; set; }
        }

        public class ReadMTemplate
        {
            public ReadMTemplate()
            {
            }

            public ReadMTemplate(string templateId, MTemplatePermissionTypeViewModel.ReadMTemplatePermissionType permissionType, string permissionEntityId, string code, string title, string descriptions, MTemplateCategoryViewModel.ReadTemplateCategory category, List<Permission> permission, bool isShowIssue, DateTime dateCreated, DateTime? dateModified)
            {
                TemplateId = templateId;
                PermissionType = permissionType;
                PermissionEntityId = permissionEntityId;
                Code = code;
                Title = title;
                Descriptions = descriptions;
                Category = category;
                Permission = permission;
                IsShowIssue = isShowIssue;
                DateCreated = dateCreated;
                DateModified = dateModified;
            }

            public string TemplateId { get; set; }
            public MTemplatePermissionTypeViewModel.ReadMTemplatePermissionType PermissionType { get; set; }
            public string PermissionEntityId { get; set; }
            public string Code { get; set; }
            public string Title { get; set; }
            public string Descriptions { get; set; }
            public MTemplateCategoryViewModel.ReadTemplateCategory Category { get; set; }

            [Display(Name = "Permission")]
            public List<MTemplateViewModel.Permission> Permission { get; set; }

            public bool IsShowIssue { get; set; }

            public DateTime DateCreated { get; set; }
            public DateTime? DateModified { get; set; }

        }

        public class Permission
        {
            public string UserId { get; set; }
            public string Username { get; set; }
            public string OfficialName { get; set; }
        }

        public class CreateMTemplate
        {
            [Required]
            [StringLength(50)]
            [Display(Name = "Code")]
            public string Code { get; set; }

            [Required]
            [StringLength(200)]
            [Display(Name = "Title")]
            public string Title { get; set; }

            [Required]
            [StringLength(300)]
            [Display(Name = "Descriptions")]
            public string Descriptions { get; set; }

            [Required]
            [Display(Name = "Category ID")]
            public int CategoryId { get; set; }

            [Required]
            [Display(Name = "Permission Type")]
            public int TemplatePermissionTypeId { get; set; }

            [Display(Name = "Permission Entity Id")]
            public string PermissionEntityId { get; set; }

            [Display(Name = "Is Show Issue")]
            public bool IsShowIssue { get; set; }
        }

        public class UpdateMTemplate
        {
            [Required]
            public string TemplateId { get; set; }

            [Required]
            [StringLength(50)]
            [Display(Name = "Code")]
            public string Code { get; set; }

            [Required]
            [StringLength(200)]
            [Display(Name = "Title")]
            public string Title { get; set; }

            [Required]
            [StringLength(300)]
            [Display(Name = "Descriptions")]
            public string Descriptions { get; set; }

            [Required]
            [Display(Name = "Category ID")]
            public int CategoryId { get; set; }

            [Required]
            [Display(Name = "Permission Type")]
            public int TemplatePermissionTypeId { get; set; }

            [Display(Name = "Permission Entity Id")]
            public string PermissionEntityId { get; set; }

            [Display(Name = "Is Show Issue")]
            public bool IsShowIssue { get; set; }
        }

        public class DestroyMTemplate
        {
            [Required]
            public string TemplateId { get; set; }
        }
    }
}
