﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class MUserTypeViewModel
    {
        public class QueryUserType : PagingViewModel
        {
            public string id { get; set; }
            public string name { get; set; }
        }

        public class ReadUserType
        {
            public string UserTypeId { get; set; }

            [Display(Name = "Tipe User")]
            public string Name { get; set; }

            public ReadUserType()
            {
            }

            public ReadUserType(string userTypeId, string name)
            {
                UserTypeId = userTypeId;
                Name = name;
            }
        }

        public class CreateUserType
        {
            [Required]
            [StringLength(50)]
            [Display(Name = "Tipe User")]
            public string Name { get; set; }
        }

        public class UpdateUserType
        {
            [Required]
            public string UserTypeId { get; set; }

            [Required]
            [StringLength(50)]
            [Display(Name = "Tipe User")]
            public string Name { get; set; }
        }

        public class DestroyUserType
        {
            [Required]
            public string UserTypeId { get; set; }
        }
    }
}
