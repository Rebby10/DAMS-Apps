﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class MInspectionStatusViewModel
    {
        public class ReadInspectiontatus
        {
            public int StatusId { get; set; }
            public string Name { get; set; }

            public ReadInspectiontatus(int statusId, string name)
            {
                StatusId = statusId;
                Name = name;
            }

            public ReadInspectiontatus()
            {
            }
        }
    }
}
