﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class TrInspectionResultViewModel
    {
        public class CreateInspectionResult
        {
            [Required]
            public string InspectionId { get; set; }
            [Required]
            public int QuestionId { get; set; }
            public int? AnswerId { get; set; }
            public string AnswerText { get; set; }
            public string Notes { get; set; }
            public string UserCreated { get; set; }
        }

        public class UpdateInspectionResult : CreateInspectionResult
        {
            [Required]
            public string ResultId { get; set; }
        }

        public class ReadInspectionResult
        {
            public string ResultId { get; set; }
            public int? AnswerId { get; set; }
            public string AnswerText { get; set; }
            public string LinkFile { get; set; }
            public string Notes { get; set; }
        }
    }
}
