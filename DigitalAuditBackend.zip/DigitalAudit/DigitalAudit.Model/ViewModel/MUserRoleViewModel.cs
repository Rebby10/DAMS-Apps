﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class MUserRoleViewModel
    {
        public class QueryUserRole : PagingViewModel
        {
            public string UserRoleId { get; set; }
            public string Username { get; set; }
            public string Email { get; set; }
            public string UserId { get; set; }
        }

        public class ReadUserRole
        {
            public string UserRoleId { get; set; }
            public string UserId { get; set; }
            public string Username { get; set; }
            public string Email { get; set; }
            public string RoleId { get; set; }
            public string RoleName { get; set; }
            public string OtorisasiId { get; set; }
            public string Otorisasi { get; set; }
        }

        public class CreateUserRole
        {
            public string UserId { get; set; }
            public string Username { get; set; }
            public string Email { get; set; }
            public string RoleId { get; set; }
            public string RoleName { get; set; }
            public string OtorisasiId { get; set; }
            public string Otorisasi { get; set; }
            public string UserCreated { get; set; }
        }

        public class UpdateUserRole
        {
            public string UserRoleId { get; set; }
            public string UserId { get; set; }
            public string Username { get; set; }
            public string Email { get; set; }
            public string RoleId { get; set; }
            public string OtorisasiId { get; set; }
        }

        public class DeleteUserRole
        {
            public string UserRoleId { get; set; }
        }
    }
}
