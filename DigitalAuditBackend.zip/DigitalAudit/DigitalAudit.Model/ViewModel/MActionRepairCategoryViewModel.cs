﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class MActionRepairCategoryViewModel
    {
        public class QueryActionRepairCateogry : PagingViewModel
        {
            public string Id { get; set; }
            public string Name { get; set; }
        }

        public class ReadActionRepairCategory
        {
            public string Id { get; set; }
            public string Name { get; set; }
        }
    }
}
