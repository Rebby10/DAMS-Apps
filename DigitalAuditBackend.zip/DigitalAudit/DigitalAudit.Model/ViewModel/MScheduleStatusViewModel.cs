﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class MScheduleStatusViewModel
    {
        public class ReadScheduleStatus
        {
            public int StatusId { get; set; }
            public string Name { get; set; }

            public ReadScheduleStatus(int statusId, string name)
            {
                StatusId = statusId;
                Name = name;
            }

            public ReadScheduleStatus()
            {
            }
        }
    }
}
