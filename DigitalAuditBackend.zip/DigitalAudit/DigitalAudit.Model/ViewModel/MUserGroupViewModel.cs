﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class MUserGroupViewModel
    {
        public class QueryUserGroup : PagingViewModel
        {
            public string id { get; set; }
            public string name { get; set; }
        }

        public class ReadUserGroup
        {
            public string UserGroupId { get; set; }

            [Display(Name = "User Type")]
            public MUserTypeViewModel.ReadUserType UserType { get; set; }

            [Display(Name = "Group Name")]
            public string Name { get; set; }

            [Display(Name = "User Id")]
            public string UserId { get; set; }

            [Display(Name = "Username")]
            public string Username { get; set; }

            [Display(Name = "Official Name")]
            public string OfficialName { get; set; }

            public ReadUserGroup()
            {
            }

            public ReadUserGroup(string userGroupId, MUserTypeViewModel.ReadUserType userType, string name, string userId, string username, string officialname)
            {
                UserGroupId = userGroupId;
                UserType = userType;
                Name = name;
                UserId = userId;
                Username = username;
                OfficialName = officialname;
            }
        }

        public class ReadUserGroupMember
        {
            public string UserGroupId { get; set; }

            [Display(Name = "User Type")]
            public MUserTypeViewModel.ReadUserType UserType { get; set; }

            [Display(Name = "Group Name")]
            public string Name { get; set; }

            [Display(Name = "User Id")]
            public string UserId { get; set; }

            [Display(Name = "Username")]
            public string Username { get; set; }

            [Display(Name = "Official Name")]
            public string OfficialName { get; set; }

            [Display(Name = "User Member")]
            public List<MUserMemberViewModel.ReadUserMember> UserMember { get; set; }
        }

        public class CreateUserGroup
        {
            [Required]
            [StringLength(50)]
            [Display(Name = "User Type Id")]
            public string UserTypeId { get; set; }

            [Required]
            [StringLength(100)]
            [Display(Name = "Group Name")]
            public string Name { get; set; }

            [Required]
            [StringLength(50)]
            [Display(Name = "User Id")]
            public string UserId { get; set; }

            [Required]
            [StringLength(100)]
            [Display(Name = "Username")]
            public string Username { get; set; }
        }

        public class UpdateUserGroup
        {
            public string UserGroupId { get; set; }

            [Required]
            [StringLength(50)]
            [Display(Name = "User Type Id")]
            public string UserTypeId { get; set; }

            [Required]
            [StringLength(100)]
            [Display(Name = "Group Name")]
            public string Name { get; set; }

            [Required]
            [StringLength(50)]
            [Display(Name = "User Id")]
            public string UserId { get; set; }

            [Required]
            [StringLength(100)]
            [Display(Name = "Username")]
            public string Username { get; set; }
        }

        public class DestroyUserGroup
        {
            [Required]
            public string UserGroupId { get; set; }
        }
    }
}
