﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class MResponseViewModel
    {
        public class QueryResponse : PagingViewModel
        {
            public int id { get; set; }
            public string name { get; set; }
            public int? type_id { get; set; }
            public string type_name { get; set; }
        }

        public class ReadResponseHeader
        {
            public int ResponseId { get; set; }
            public string Name { get; set; }
            public List<MResponseListViewModel.ReadResponseList> ResponseList { get; set; }
        }


        public class ReadResponse
        {
            public int ResponseId { get; set; }
            public string Name { get; set; }
            //public string TypeId { get; set; }
            //public string ResponseType { get; set; }

            public MResponseTypeViewModel.ReadMResponseType ResponseType { get; set; }
            public List<MResponseListViewModel.ReadResponseList> ResponseList { get; set; }

        }

        public class CreateResponse
        {
            [Required]
            [StringLength(100)]
            [Display(Name = "Nama Response")]
            public string Name { get; set; }

            [Required]
            [Display(Name = "Type Id")]
            public int TypeId { get; set; }
            public int AnswerTypeId { get; set; }
        }

        public class UpdateResponse
        {
            [Required]
            public int ResponseId { get; set; }

            [Required]
            [StringLength(100)]
            [Display(Name = "Nama Response")]
            public string Name { get; set; }

            [Required]
            [Display(Name = "Type Id")]
            public int TypeId { get; set; }

            public int AnswerTypeId { get; set; }
        }

        public class DestroyResponse
        {
            [Required]
            public int ResponseId { get; set; }
        }
    }
}
