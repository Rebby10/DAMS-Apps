﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalAudit.Model.ViewModel
{
    public class MLogTypeViewModel
    {
        public class ReadLogType
        {
            public int LogTypeId { get; set; }
            public string Name { get; set; }
        }
    }
}
