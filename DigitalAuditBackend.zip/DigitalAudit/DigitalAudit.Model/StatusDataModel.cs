﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalAudit.Model
{
    public class StatusDataModel
    {
        private bool _isSuccess;
        private string _message;
        private object _result;
        private int _totalData;
        private int _totalResult;

        public bool IsSuccess { get => _isSuccess; set => _isSuccess = value; }
        public string Message { get => _message; set => _message = value; }
        public object Result { get => _result; set => _result = value; }
        public int TotalData { get => _totalData; set => _totalData = value; }
        public int TotalResult { get => _totalResult; set => _totalResult = value; }

        public StatusDataModel()
        {
        }

        public StatusDataModel(bool isSuccess, string message, object result, int totalData, int totalResult)
        {
            IsSuccess = isSuccess;
            Message = message;
            Result = result;
            TotalData = totalData;
            TotalResult = totalResult;
        }

        public StatusDataModel(Exception ex)
        {
            IsSuccess = false;
            Message = ex.Message.ToString();
            Result = null;
            TotalData = 0;
            TotalResult = 0;
        }
    }
}
