﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalAudit.Model
{
    public class StatusModel
    {
        private bool _isSuccess;
        private string _message;
        private object _result;

        public StatusModel() { }
        public StatusModel(bool isSuccess, string message, object result)
        {
            _isSuccess = isSuccess;
            _message = message;
            _result = result;
        }

        public StatusModel(Exception ex)
        {
            _isSuccess = false;
            _message = ex.Message.ToString();
            _result = null;
        }

        public bool IsSuccess { get => _isSuccess; set => _isSuccess = value; }
        public string Message { get => _message; set => _message = value; }
        public object Result { get => _result; set => _result = value; }
    }
}
