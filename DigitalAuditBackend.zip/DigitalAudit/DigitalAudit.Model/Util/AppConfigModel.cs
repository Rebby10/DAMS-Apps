﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalAudit.Model.Util
{
    public class AppConfigModel
    {
        public string UrlPath { get; set; }
        public AppConfigUploadPath UploadPath { get; set; }

        public class AppConfigUploadPath
        {
            public string ImportIssue { get; set; }
            public string ImportAction { get; set; }
            public string ImportSchedule { get; set; }
            public string ImportFileLogIssue { get; set; }
            public string ImportFileLogAction { get; set; }
            public string ImportFileInspection { get; set; }
            public string TemplateIssue { get; set; }
            public string TemplateAction { get; set; }
            public string TemplateSchedule { get; set; }
            public string DownloadIssue { get; set; }
            public string DownloadErrorIssue { get; set; }
            public string DownloadErrorAction { get; set; }
            public string DownloadErrorSchedule { get; set; }
        }
    }

}
