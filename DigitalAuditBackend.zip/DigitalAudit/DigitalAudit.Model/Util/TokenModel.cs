﻿using DigitalAudit.Model.ViewModel;
using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalAudit.Model.Util
{
    public class TokenModel
    {
        private string _token;
        private DateTime _expired;
        private object _userToken;
        

        public TokenModel() { }

        public TokenModel(string token, DateTime expired, object userToken)
        {
            Token = token;
            Expired = expired;
            UserToken = userToken;
        }

        public TokenModel(string token, DateTime expired)
        {
            Token = token;
            Expired = expired;
        }

        public string Token { get => _token; set => _token = value; }
        public DateTime Expired { get => _expired; set => _expired = value; }
        public object UserToken { get => _userToken; set => _userToken = value; }
    }
}
