﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalAudit.Model.Util
{
    public static class GeneralParser
    {
        public static string parseNullString(string val)
        {
            if (val == null)
            {
                val = "";
            }
            return val;
        }
    }
}
