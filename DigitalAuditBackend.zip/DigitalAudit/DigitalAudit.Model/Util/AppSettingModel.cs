﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalAudit.Model.Util
{
    public class AppSettingModel
    {
        public class Swagger
        {
            public string RoutePrefix { get; set; }
        }
    }
}
