﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("MUserRole", Schema = "dbo")]
    public class MUserRole
    {
        [Key]
        private string _userRoleId;
        private string _userId;
        private string _username;
        private string _email;
        private string _roleId;
        private string _regionId;
        private string _auditLocationId;
        private bool _isDeleted;
        private string _userCreated;
        private DateTime _dateCreated;
        private string _userModified;
        private DateTime? _dateModified;

        public MUserRole()
        {
        }

        public MUserRole(string userRoleId, string userId, string username, string email, string roleId, string regionId, string auditLocationId, bool isDeleted, string userCreated, DateTime dateCreated, string userModified, DateTime? dateModified)
        {

            UserRoleId = userRoleId;
            UserId = userId;
            Username = username;
            Email = email;
            RoleId = roleId;
            RegionId = regionId;
            AuditLocationId = auditLocationId;
            IsDeleted = isDeleted;
            UserCreated = userCreated;
            DateCreated = dateCreated;
            UserModified = userModified;
            DateModified = dateModified;
        }

        [Key]
        public string UserRoleId { get => _userRoleId; set => _userRoleId = value; }

        [Required]
        [StringLength(100)]
        [Display(Name = "User Id")]
        public string UserId { get => _userId; set => _userId = value; }

        [Required]
        [StringLength(300)]
        [Display(Name = "Nama Pengguna")]
        public string Username { get => _username; set => _username = value; }

        [Required]
        [StringLength(100)]
        [Display(Name = "Email")]
        public string Email { get => _email; set => _email = value; }

        [Required]
        [StringLength(100)]
        [Display(Name = "Role Id")]
        public string RoleId { get => _roleId; set => _roleId = value; }

        
        [StringLength(50)]
        [Display(Name = "Region Id")]
        public string RegionId { get => _regionId; set => _regionId = value; }

        
        [StringLength(50)]
        [Display(Name = "Audit Location Id")]
        public string AuditLocationId { get => _auditLocationId; set => _auditLocationId = value; }

        public bool IsDeleted { get => _isDeleted; set => _isDeleted = value; }
        public string UserCreated { get => _userCreated; set => _userCreated = value; }
        public DateTime DateCreated { get => _dateCreated; set => _dateCreated = value; }
        public string UserModified { get => _userModified; set => _userModified = value; }
        public DateTime? DateModified { get => _dateModified; set => _dateModified = value; }
    }
}
