﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DigitalAudit.Model.Database
{
    [Table("TrInspectionNote", Schema = "dbo")]
    public class TrInspectionNote
    {
        public TrInspectionNote(string noteId, string resultId, string title, string notes, bool isDeleted, string userCreated, DateTime dateCreated, string userModified, DateTime? dateModified)
        {
            NoteId = noteId;
            ResultId = resultId;
            Title = title;
            Notes = notes;
            IsDeleted = isDeleted;
            UserCreated = userCreated;
            DateCreated = dateCreated;
            UserModified = userModified;
            DateModified = dateModified;
        }

        public TrInspectionNote()
        {
        }

        [Key]
        public string NoteId { get; set; }
        public string ResultId { get; set; }
        public string Title { get; set; }
        public string Notes { get; set; }
        public bool IsDeleted { get; set; }
        public string UserCreated { get; set; }
        public DateTime DateCreated { get; set; }
        public string UserModified { get; set; }
        public DateTime? DateModified { get; set; }
    }
}
