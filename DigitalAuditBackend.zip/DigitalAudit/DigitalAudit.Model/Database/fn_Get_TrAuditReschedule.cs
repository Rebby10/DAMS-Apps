﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("fn_Get_TrAuditReschedule", Schema = "dbo")]
    public class fn_Get_TrAuditReschedule
    {
        [Key]
        private string _rescheduleId;
        private string _scheduleId;
        private string _auditLocationId;
        private string _locationName;
        private string _regionId;
        private string _regionName;
        private string _address;
        private string _latLong;
        private string _zipCode;
        private string _templateId;
        private string _title;
        private DateTime _startDate;
        private DateTime _endDate;
        private DateTime _rescheduleStartDate;
        private DateTime _rescheduleEndDate;
        private string _userIdRequester;
        private string _displayNameRequester;
        private string _emailRequester;
        private string _userIdApprover;
        private string _displayNameApprover;
        private string _emailApprover;
        private bool? _isApproved;
        private DateTime? _approvalDate;
        private int? _scheduleStatusId;
        private string _scheduleStatus;

        [Key]
        public string RescheduleId { get => _rescheduleId; set => _rescheduleId = value; }
        public string ScheduleId { get => _scheduleId; set => _scheduleId = value; }
        public string AuditLocationId { get => _auditLocationId; set => _auditLocationId = value; }
        public string LocationName { get => _locationName; set => _locationName = value; }
        public string RegionId { get => _regionId; set => _regionId = value; }
        public string RegionName { get => _regionName; set => _regionName = value; }
        public string Address { get => _address; set => _address = value; }
        public string LatLong { get => _latLong; set => _latLong = value; }
        public string ZipCode { get => _zipCode; set => _zipCode = value; }
        public string TemplateId { get => _templateId; set => _templateId = value; }
        public string Title { get => _title; set => _title = value; }
        public DateTime StartDate { get => _startDate; set => _startDate = value; }
        public DateTime EndDate { get => _endDate; set => _endDate = value; }
        public DateTime RescheduleStartDate { get => _rescheduleStartDate; set => _rescheduleStartDate = value; }
        public DateTime RescheduleEndDate { get => _rescheduleEndDate; set => _rescheduleEndDate = value; }
        public string UserIdRequester { get => _userIdRequester; set => _userIdRequester = value; }
        public string DisplayNameRequester { get => _displayNameRequester; set => _displayNameRequester = value; }
        public string EmailRequester { get => _emailRequester; set => _emailRequester = value; }
        public string UserIdApprover { get => _userIdApprover; set => _userIdApprover = value; }
        public string DisplayNameApprover { get => _displayNameApprover; set => _displayNameApprover = value; }
        public string EmailApprover { get => _emailApprover; set => _emailApprover = value; }
        public bool? IsApproved { get => _isApproved; set => _isApproved = value; }
        public DateTime? ApprovalDate { get => _approvalDate; set => _approvalDate = value; }
        public int? ScheduleStatusId { get => _scheduleStatusId; set => _scheduleStatusId = value; }
        public string ScheduleStatus { get => _scheduleStatus; set => _scheduleStatus = value; }

        public fn_Get_TrAuditReschedule(string rescheduleId, string scheduleId, string auditLocationId, string locationName, string regionId, string regionName, string address, string latLong, string zipCode, string auditTypeId, string title, DateTime startDate, DateTime endDate, DateTime rescheduleStartDate, DateTime rescheduleEndDate, string userIdRequester, string displayNameRequester, string emailRequester, string userIdApprover, string displayNameApprover, string emailApprover, bool? isApproved, DateTime? approvalDate, int? scheduleStatusId, string scheduleStatus)
        {
            RescheduleId = rescheduleId;
            ScheduleId = scheduleId;
            AuditLocationId = auditLocationId;
            LocationName = locationName;
            RegionId = regionId;
            RegionName = regionName;
            Address = address;
            LatLong = latLong;
            ZipCode = zipCode;
            TemplateId = auditTypeId;
            Title = title;
            StartDate = startDate;
            EndDate = endDate;
            RescheduleStartDate = rescheduleStartDate;
            RescheduleEndDate = rescheduleEndDate;
            UserIdRequester = userIdRequester;
            DisplayNameRequester = displayNameRequester;
            EmailRequester = emailRequester;
            UserIdApprover = userIdApprover;
            DisplayNameApprover = displayNameApprover;
            EmailApprover = emailApprover;
            IsApproved = isApproved;
            ApprovalDate = approvalDate;
            ScheduleStatusId = scheduleStatusId;
            ScheduleStatus = scheduleStatus;
        }

        public fn_Get_TrAuditReschedule()
        {
        }


    }
}
