﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("MTemplatePermissionType", Schema = "dbo")]
    public class MTemplatePermissionType
    {
        [Key]
        private int _templatePermissionTypeId;
        private string _permissionType;
        private bool _isDeleted;
        private string _userCreated;
        private DateTime _dateCreated;
        private string _userModified;
        private DateTime? _dateModified;

        public MTemplatePermissionType()
        {
        }

        public MTemplatePermissionType(int templatePermissionTypeId, string permissionType, bool isDeleted, string userCreated, DateTime dateCreated, string userModified, DateTime? dateModified)
        {
            _templatePermissionTypeId = templatePermissionTypeId;
            _permissionType = permissionType;
            _isDeleted = isDeleted;
            _userCreated = userCreated;
            _dateCreated = dateCreated;
            _userModified = userModified;
            _dateModified = dateModified;
        }

        [Key]
        public int TemplatePermissionTypeId { get => _templatePermissionTypeId; set => _templatePermissionTypeId = value; }
        public string PermissionType { get => _permissionType; set => _permissionType = value; }
        public bool IsDeleted { get => _isDeleted; set => _isDeleted = value; }
        public string UserCreated { get => _userCreated; set => _userCreated = value; }
        public DateTime DateCreated { get => _dateCreated; set => _dateCreated = value; }
        public string UserModified { get => _userModified; set => _userModified = value; }
        public DateTime? DateModified { get => _dateModified; set => _dateModified = value; }
    }


}
