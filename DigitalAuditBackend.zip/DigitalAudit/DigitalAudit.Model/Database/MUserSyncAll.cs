﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("MUserSyncAll", Schema = "dbo")]
    public class MUserSyncAll
    {
        private string _userSyncAllId;
        [Key]
        private string _userId;
        private string _organizationId;
        private string _positionId;
        private string _companyCode;
        private string _kbo;
        private string _isActive;
        private string _birthday;
        private string _city;
        private string _companyName;
        private string _country;
        private string _department;
        private string _displayName;
        private string _employeeId;
        private string _lastName;
        private string _hireDate;
        private string _jobTitle;
        private string _email;
        private string _mobilePhone;
        private string _website;
        private string _aboutMe;
        private string _officeLocation;
        private string _postalCode;
        private string _username;
        private string _firstName;
        private string _address;
        private string _userType;
        private string _photo;
        private string _extensionAttributes;
        private string _idp;
        private string _directoryId;
        private string _createdBy;
        private string _created;
        private string _updated;
        private string _employeeNumber;
        private string _employeeType;
        private string _manager;
        private string _roomNumber;
        private string _state;
        private string _division;
        private string _cultureInfo;
        private string _language;
        private string _dateFormat;
        private string _timeFormat;
        private string _isCheif;
        private bool _isDeleted;
        private DateTime _dateCreated;
        private string _userCreated;
        private DateTime? _dateModified;
        private string _userModified;

        public MUserSyncAll()
        {
        }

        public MUserSyncAll(string userSyncAllId, string userId, string organizationId, string positionId, string companyCode, string kbo, string isActive, string birthday, string city, string companyName, string country, string department, string displayName, string employeeId, string lastName, string hireDate, string jobTitle, string email, string mobilePhone, string website, string aboutMe, string officeLocation, string postalCode, string username, string firstName, string address, string userType, string photo, string extensionAttributes, string idp, string directoryId, string createdBy, string created, string updated, string employeeNumber, string employeeType, string manager, string roomNumber, string state, string division, string cultureInfo, string language, string dateFormat, string timeFormat, string isCheif, bool isDeleted, DateTime dateCreated, string userCreated, DateTime? dateModified, string userModified)
        {
            UserSyncAllId = userSyncAllId;
            UserId = userId;
            OrganizationId = organizationId;
            PositionId = positionId;
            CompanyCode = companyCode;
            Kbo = kbo;
            IsActive = isActive;
            Birthday = birthday;
            City = city;
            CompanyName = companyName;
            Country = country;
            Department = department;
            DisplayName = displayName;
            EmployeeId = employeeId;
            LastName = lastName;
            HireDate = hireDate;
            JobTitle = jobTitle;
            Email = email;
            MobilePhone = mobilePhone;
            Website = website;
            AboutMe = aboutMe;
            OfficeLocation = officeLocation;
            PostalCode = postalCode;
            Username = username;
            FirstName = firstName;
            Address = address;
            UserType = userType;
            Photo = photo;
            ExtensionAttributes = extensionAttributes;
            Idp = idp;
            DirectoryId = directoryId;
            CreatedBy = createdBy;
            Created = created;
            Updated = updated;
            EmployeeNumber = employeeNumber;
            EmployeeType = employeeType;
            Manager = manager;
            RoomNumber = roomNumber;
            State = state;
            Division = division;
            CultureInfo = cultureInfo;
            Language = language;
            DateFormat = dateFormat;
            TimeFormat = timeFormat;
            IsCheif = isCheif;
            IsDeleted = isDeleted;
            DateCreated = dateCreated;
            UserCreated = userCreated;
            DateModified = dateModified;
            UserModified = userModified;
        }

        public string UserSyncAllId { get => _userSyncAllId; set => _userSyncAllId = value; }

        [Key]
        public string UserId { get => _userId; set => _userId = value; }
        public string OrganizationId { get => _organizationId; set => _organizationId = value; }
        public string PositionId { get => _positionId; set => _positionId = value; }
        public string CompanyCode { get => _companyCode; set => _companyCode = value; }
        public string Kbo { get => _kbo; set => _kbo = value; }
        public string IsActive { get => _isActive; set => _isActive = value; }
        public string Birthday { get => _birthday; set => _birthday = value; }
        public string City { get => _city; set => _city = value; }
        public string CompanyName { get => _companyName; set => _companyName = value; }
        public string Country { get => _country; set => _country = value; }
        public string Department { get => _department; set => _department = value; }
        public string DisplayName { get => _displayName; set => _displayName = value; }
        public string EmployeeId { get => _employeeId; set => _employeeId = value; }
        public string LastName { get => _lastName; set => _lastName = value; }
        public string HireDate { get => _hireDate; set => _hireDate = value; }
        public string JobTitle { get => _jobTitle; set => _jobTitle = value; }
        public string Email { get => _email; set => _email = value; }
        public string MobilePhone { get => _mobilePhone; set => _mobilePhone = value; }
        public string Website { get => _website; set => _website = value; }
        public string AboutMe { get => _aboutMe; set => _aboutMe = value; }
        public string OfficeLocation { get => _officeLocation; set => _officeLocation = value; }
        public string PostalCode { get => _postalCode; set => _postalCode = value; }
        public string Username { get => _username; set => _username = value; }
        public string FirstName { get => _firstName; set => _firstName = value; }
        public string Address { get => _address; set => _address = value; }
        public string UserType { get => _userType; set => _userType = value; }
        public string Photo { get => _photo; set => _photo = value; }
        public string ExtensionAttributes { get => _extensionAttributes; set => _extensionAttributes = value; }
        public string Idp { get => _idp; set => _idp = value; }
        public string DirectoryId { get => _directoryId; set => _directoryId = value; }
        public string CreatedBy { get => _createdBy; set => _createdBy = value; }
        public string Created { get => _created; set => _created = value; }
        public string Updated { get => _updated; set => _updated = value; }
        public string EmployeeNumber { get => _employeeNumber; set => _employeeNumber = value; }
        public string EmployeeType { get => _employeeType; set => _employeeType = value; }
        public string Manager { get => _manager; set => _manager = value; }
        public string RoomNumber { get => _roomNumber; set => _roomNumber = value; }
        public string State { get => _state; set => _state = value; }
        public string Division { get => _division; set => _division = value; }
        public string CultureInfo { get => _cultureInfo; set => _cultureInfo = value; }
        public string Language { get => _language; set => _language = value; }
        public string DateFormat { get => _dateFormat; set => _dateFormat = value; }
        public string TimeFormat { get => _timeFormat; set => _timeFormat = value; }
        public string IsCheif { get => _isCheif; set => _isCheif = value; }
        public bool IsDeleted { get => _isDeleted; set => _isDeleted = value; }
        public DateTime DateCreated { get => _dateCreated; set => _dateCreated = value; }
        public string UserCreated { get => _userCreated; set => _userCreated = value; }
        public DateTime? DateModified { get => _dateModified; set => _dateModified = value; }
        public string UserModified { get => _userModified; set => _userModified = value; }
    }
}
