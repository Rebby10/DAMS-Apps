﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("MTokenUser", Schema = "dbo")]
    public class MTokenUser
    {
        [Key]
        private string _tokenUserID;
        private string _tokenUser;
        private string _tokenPassword;
        private bool _isDeleted;
        private string _userCreated;
        private DateTime _dateCreated;
        private string _userModified;
        private DateTime? _dateModified;

        public MTokenUser()
        {
        }

        public MTokenUser(string tokenUserID, string tokenUser, string tokenPassword, bool isDeleted, string userCreated, DateTime dateCreated, string userModified, DateTime? dateModified)
        {
            TokenUserID = tokenUserID;
            TokenUser = tokenUser;
            TokenPassword = tokenPassword;
            IsDeleted = isDeleted;
            UserCreated = userCreated;
            DateCreated = dateCreated;
            UserModified = userModified;
            DateModified = dateModified;
        }

        [Key]
        public string TokenUserID { get => _tokenUserID; set => _tokenUserID = value; }

        [Required]
        [StringLength(100)]
        public string TokenUser { get => _tokenUser; set => _tokenUser = value; }

        [Required]
        [StringLength(100)]
        public string TokenPassword { get => _tokenPassword; set => _tokenPassword = value; }
        public bool IsDeleted { get => _isDeleted; set => _isDeleted = value; }
        public string UserCreated { get => _userCreated; set => _userCreated = value; }
        public DateTime DateCreated { get => _dateCreated; set => _dateCreated = value; }
        public string UserModified { get => _userModified; set => _userModified = value; }
        public DateTime? DateModified { get => _dateModified; set => _dateModified = value; }
    }
}
