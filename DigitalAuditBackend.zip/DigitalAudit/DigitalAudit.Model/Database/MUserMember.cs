﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("MUserMember", Schema = "dbo")]
    public class MUserMember
    {
        [Key]
        private string _userMemberId;
        private string _userGroupId;
        private string _userId;
        private string _username;   
        private bool _isDeleted;
        private string _userCreated;
        private DateTime _dateCreated;
        private string _userModified;
        private DateTime? _dateModified;

        public MUserMember()
        {
        }

        public MUserMember(string userMemberId, string userGroupId, string userId, string username, bool isDeleted, string userCreated, DateTime dateCreated, string userModified, DateTime? dateModified)
        {
            UserMemberId = userMemberId;
            UserGroupId = userGroupId;
            UserId = userId;
            Username = username;
            IsDeleted = isDeleted;
            UserCreated = userCreated;
            DateCreated = dateCreated;
            UserModified = userModified;
            DateModified = dateModified;
        }

        [Key]
        public string UserMemberId { get => _userMemberId; set => _userMemberId = value; }

        [Required]
        [StringLength(50)]
        [Display(Name = "User Group Id")]
        public string UserGroupId { get => _userGroupId; set => _userGroupId = value; }

        [Required]
        [StringLength(50)]
        [Display(Name = "User Id")]
        public string UserId { get => _userId; set => _userId = value; }

        [Required]
        [StringLength(100)]
        [Display(Name = "Username")]
        public string Username { get => _username; set => _username = value; }
        public bool IsDeleted { get => _isDeleted; set => _isDeleted = value; }
        public string UserCreated { get => _userCreated; set => _userCreated = value; }
        public DateTime DateCreated { get => _dateCreated; set => _dateCreated = value; }
        public string UserModified { get => _userModified; set => _userModified = value; }
        public DateTime? DateModified { get => _dateModified; set => _dateModified = value; }
    }
}
