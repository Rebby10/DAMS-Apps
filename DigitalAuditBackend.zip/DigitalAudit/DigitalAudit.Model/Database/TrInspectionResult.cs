﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace DigitalAudit.Model.Database
{
    [Table("TrInspectionResult", Schema = "dbo")]
    public class TrInspectionResult
    {
        public TrInspectionResult(string resultId, string inspectionId, int questionId, int answerId, string answerText, string linkFile, string notes, bool isDeleted, string userCreated, DateTime dateCreated, string userModified, DateTime? dateModified)
        {
            ResultId = resultId;
            InspectionId = inspectionId;
            QuestionId = questionId;
            AnswerId = answerId;
            AnswerText = answerText;
            LinkFile = linkFile;
            Notes = notes;
            IsDeleted = isDeleted;
            UserCreated = userCreated;
            DateCreated = dateCreated;
            UserModified = userModified;
            DateModified = dateModified;
        }

        public TrInspectionResult()
        {
        }

        [Key]
        public string ResultId { get; set; }
        public string InspectionId { get; set; }
        public int QuestionId { get; set; }
        public int? AnswerId { get; set; }
        public string AnswerText { get; set; }
        public string LinkFile { get; set; }
        public string Notes { get; set; }
        public bool IsDeleted { get; set; }
        public string UserCreated { get; set; }
        public DateTime DateCreated { get; set; }
        public string UserModified { get; set; }
        public DateTime? DateModified { get; set; }
    }
}
