﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("fn_Get_MUserGroup", Schema = "dbo")]
    public class fn_Get_MUserGroup
    {
        [Key]
        private string _userGroupId;
        private int _id;
        private string _userTypeId;
        private string _userType;
        private string _name;
        private string _userId;
        private string _username;
        private string _officialName;


        public fn_Get_MUserGroup()
        {
        }

        public fn_Get_MUserGroup(string userGroupId, int id, string userTypeId, string userType, string name, string userId, string username, string officialName)
        {
            UserGroupId = userGroupId;
            ID = id;
            UserTypeId = userTypeId;
            UserType = userType;
            Name = name;
            UserId = userId;
            Username = username;
            OfficialName = officialName;
        }

        [Key]
        public string UserGroupId { get => _userGroupId; set => _userGroupId = value; }
        public int ID { get => _id; set => _id = value; }
        public string UserTypeId { get => _userTypeId; set => _userTypeId = value; }
        public string UserType { get => _userType; set => _userType = value; }
        public string Name { get => _name; set => _name = value; }
        public string UserId { get => _userId; set => _userId = value; }
        public string Username { get => _username; set => _username = value; }
        public string OfficialName { get => _officialName; set => _officialName = value; }
    }
}
