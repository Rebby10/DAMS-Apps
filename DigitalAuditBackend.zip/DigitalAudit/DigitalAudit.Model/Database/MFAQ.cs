﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("MFAQ", Schema = "dbo")]
    public class MFAQ
    {
        [Key]
        private string _faqId;
        private string _question;
        private string _answer;
        private bool _isDeleted;
        private string _userCreated;
        private DateTime _dateCreated;
        private string _userModified;
        private DateTime? _dateModified;

        public MFAQ()
        {
        }

        public MFAQ(string faqId, string question, string answer, bool isDeleted, string userCreated, DateTime dateCreated, string userModified, DateTime? dateModified)
        {
            FaqId = faqId;
            Question = question;
            Answer = answer;
            IsDeleted = isDeleted;
            UserCreated = userCreated;
            DateCreated = dateCreated;
            UserModified = userModified;
            DateModified = dateModified;
        }

        [Key]
        public string FaqId { get => _faqId; set => _faqId = value; }

        [Required]
        [StringLength(1000)]
        [Display(Name = "Pertanyaan")]
        public string Question { get => _question; set => _question = value; }

        [Required]
        [StringLength(1000)]
        [Display(Name = "Jawaban")]
        public string Answer { get => _answer; set => _answer = value; }
        public bool IsDeleted { get => _isDeleted; set => _isDeleted = value; }
        public string UserCreated { get => _userCreated; set => _userCreated = value; }
        public DateTime DateCreated { get => _dateCreated; set => _dateCreated = value; }
        public string UserModified { get => _userModified; set => _userModified = value; }
        public DateTime? DateModified { get => _dateModified; set => _dateModified = value; }
    }
}
