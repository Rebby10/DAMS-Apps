﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace DigitalAudit.Model.Database
{
    [Table("TrInspectionFile", Schema = "dbo")]
    public class TrInspectionFile
    {
        
        public TrInspectionFile()
        {
        }

        public TrInspectionFile(string fileId, string inspectionId, int questionId, string filename, int fileTypeId, string linkFile, bool isDeleted, string userCreated, DateTime dateCreated, string userModified, DateTime? dateModified)
        {
            FileId = fileId;
            InspectionId = inspectionId;
            QuestionId = questionId;
            Filename = filename;
            FileTypeId = fileTypeId;
            LinkFile = linkFile;
            IsDeleted = isDeleted;
            UserCreated = userCreated;
            DateCreated = dateCreated;
            UserModified = userModified;
            DateModified = dateModified;
        }

        [Key]
        public string FileId { get; set; }
        public string InspectionId { get; set; }
        public int QuestionId { get; set; }
        public string Filename { get; set; }
        public int FileTypeId { get; set; }
        public string LinkFile { get; set; }
        public bool IsDeleted { get; set; }
        public string UserCreated { get; set; }
        public DateTime DateCreated { get; set; }
        public string UserModified { get; set; }
        public DateTime? DateModified { get; set; }
    }
}
