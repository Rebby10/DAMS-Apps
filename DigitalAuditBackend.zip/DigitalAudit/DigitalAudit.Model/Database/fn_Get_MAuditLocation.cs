﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("fn_Get_MAuditLocation", Schema = "dbo")]
    public class fn_Get_MAuditLocation
    {
        [Key]
        private string _auditLocationId;
        private int _id;
        private string _name;
        private string _address;
        private string _zipCode;
        private string _latLong;
        private string _regionId;
        private string _regionName;


        public fn_Get_MAuditLocation()
        {
        }

        public fn_Get_MAuditLocation(string auditLocationId, int id, string name, string address, string zipCode, string latLong, string regionId, string regionName)
        {
            AuditLocationId = auditLocationId;
            ID = id; 
            Name = name;
            Address = address;
            ZipCode = zipCode;
            LatLong = latLong;
            RegionId = regionId;
            RegionName = regionName;
        }

        [Key]
        public string AuditLocationId { get => _auditLocationId; set => _auditLocationId = value; }
        public int ID { get => _id; set => _id = value; }
        public string Name { get => _name; set => _name = value; }
        public string Address { get => _address; set => _address = value; }
        public string ZipCode { get => _zipCode; set => _zipCode = value; }
        public string LatLong { get => _latLong; set => _latLong = value; }
        public string RegionId { get => _regionId; set => _regionId = value; }
        public string RegionName { get => _regionName; set => _regionName = value; }
    }
}
