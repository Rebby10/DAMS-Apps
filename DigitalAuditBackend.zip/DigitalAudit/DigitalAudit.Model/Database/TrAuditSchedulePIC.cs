﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("TrAuditSchedulePIC", Schema = "dbo")]
    public class TrAuditSchedulePIC
    {
        [Key]
        private string _picId;
        private string _scheduleId;
        private string _userId;
        private string _userGroupId;
        private string _userTypeId;
        private int _statusId;
        private bool _isDeleted;
        private string _userCreated;
        private DateTime _dateCreated;
        private string _userModified;
        private DateTime? _dateModified;

        public TrAuditSchedulePIC()
        {
        }

        public TrAuditSchedulePIC(string picId, string scheduleId, string userId, string userGroupId, string userTypeId, int statusId, bool isDeleted, string userCreated, DateTime dateCreated, string userModified, DateTime? dateModified)
        {
            PicId = picId;
            ScheduleId = scheduleId;
            UserId = userId;
            UserGroupId = userGroupId;
            UserTypeId = userTypeId;
            StatusId = statusId;
            IsDeleted = isDeleted;
            UserCreated = userCreated;
            DateCreated = dateCreated;
            UserModified = userModified;
            DateModified = dateModified;
        }

        [Key]
        public string PicId { get => _picId; set => _picId = value; }
        public string ScheduleId { get => _scheduleId; set => _scheduleId = value; }
        public string UserId { get => _userId; set => _userId = value; }
        public string UserGroupId { get => _userGroupId; set => _userGroupId = value; }
        public string UserTypeId { get => _userTypeId; set => _userTypeId = value; }
        public int StatusId { get => _statusId; set => _statusId = value; }
        public bool IsDeleted { get => _isDeleted; set => _isDeleted = value; }
        public string UserCreated { get => _userCreated; set => _userCreated = value; }
        public DateTime DateCreated { get => _dateCreated; set => _dateCreated = value; }
        public string UserModified { get => _userModified; set => _userModified = value; }
        public DateTime? DateModified { get => _dateModified; set => _dateModified = value; }
    }
}
