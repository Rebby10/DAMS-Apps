﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("TrAuditSchedule", Schema = "dbo")]
    public class TrAuditSchedule
    {
        [Key]
        private string _scheduleId;
        private string _auditLocationId;
        private DateTime _startDate;
        private DateTime _endDate;
        private string _templateId;
        private int _statusId;
        private bool _isDeleted;
        private string _userCreated;
        private DateTime _dateCreated;
        private string _userModified;
        private DateTime? _dateModified;

        [Key]
        public string ScheduleId { get => _scheduleId; set => _scheduleId = value; }
        public string AuditLocationId { get => _auditLocationId; set => _auditLocationId = value; }
        public DateTime StartDate { get => _startDate; set => _startDate = value; }
        public DateTime EndDate { get => _endDate; set => _endDate = value; }
        public string TemplateId { get => _templateId; set => _templateId = value; }
        public int StatusId { get => _statusId; set => _statusId = value; }
        public bool IsDeleted { get => _isDeleted; set => _isDeleted = value; }
        public string UserCreated { get => _userCreated; set => _userCreated = value; }
        public DateTime DateCreated { get => _dateCreated; set => _dateCreated = value; }
        public string UserModified { get => _userModified; set => _userModified = value; }
        public DateTime? DateModified { get => _dateModified; set => _dateModified = value; }

        public TrAuditSchedule(string scheduleId, string auditLocationId, DateTime startDate, DateTime endDate, string auditTypeId, int statusId, bool isDeleted, string userCreated, DateTime dateCreated, string userModified, DateTime? dateModified)
        {
            ScheduleId = scheduleId;
            AuditLocationId = auditLocationId;
            StartDate = startDate;
            EndDate = endDate;
            TemplateId = auditTypeId;
            StatusId = statusId;
            IsDeleted = isDeleted;
            UserCreated = userCreated;
            DateCreated = dateCreated;
            UserModified = userModified;
            DateModified = dateModified;
        }

        public TrAuditSchedule()
        {
        }


    }
}
