﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("fn_Get_MTemplate", Schema = "dbo")]
    public class fn_Get_MTemplate
    {
        [Key]
        private string _templateId;
        private int _id;
        private int _templatePermissionTypeId;
        private string _permissionType;
        private string _permissionEntityId;
        private string _code;
        private string _title;
        private string _descriptions;
        private int _categoryId;
        private string _templateCategory;
        private bool _isShowIssue;
        private DateTime _dateCreated;
        private DateTime? _dateModified;


        public fn_Get_MTemplate()
        {
        }

        public fn_Get_MTemplate(string templateId, int id, int templatePermissionTypeId, string permissionType, string permissionEntityId, string code, string title, string descriptions, int categoryId, string templateCategory, bool isShowIssue, DateTime dateCreated, DateTime? dateModified)
        {
            TemplateId = templateId;
            Id = id;
            TemplatePermissionTypeId = templatePermissionTypeId;
            PermissionType = permissionType;
            PermissionEntityId = permissionEntityId;
            Code = code;
            Title = title;
            Descriptions = descriptions;
            CategoryId = categoryId;
            TemplateCategory = templateCategory;
            IsShowIssue = isShowIssue;
            DateCreated = dateCreated;
            DateModified = dateModified;
        }

        [Key]
        public string TemplateId { get => _templateId; set => _templateId = value; }
        public int Id { get => _id; set => _id = value; }
        public int TemplatePermissionTypeId { get => _templatePermissionTypeId; set => _templatePermissionTypeId = value; }
        public string PermissionType { get => _permissionType; set => _permissionType = value; }
        public string PermissionEntityId { get => _permissionEntityId; set => _permissionEntityId = value; }
        public string Code { get => _code; set => _code = value; }
        public string Title { get => _title; set => _title = value; }
        public string Descriptions { get => _descriptions; set => _descriptions = value; }
        public int CategoryId { get => _categoryId; set => _categoryId = value; }
        public string TemplateCategory { get => _templateCategory; set => _templateCategory = value; }
        public bool IsShowIssue { get => _isShowIssue; set => _isShowIssue = value; }
        public DateTime DateCreated { get => _dateCreated; set => _dateCreated = value; }
        public DateTime? DateModified { get => _dateModified; set => _dateModified = value; }
    }
}
