﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("MUserSyncWhitelist", Schema = "dbo")]
    public class MUserSyncWhitelist
    {
        [Key]
        private string _userSyncWhitelistId;
        private string _userId;
        private string _applicationId;
        private DateTime _dateCreated;

        public MUserSyncWhitelist()
        {
        }

        public MUserSyncWhitelist(string userSyncWhitelistId, string userId, string applicationId, DateTime dateCreated)
        {
            UserSyncWhitelistId = userSyncWhitelistId;
            UserId = userId;
            ApplicationId = applicationId;
            DateCreated = dateCreated;
        }

        [Key]
        public string UserSyncWhitelistId { get => _userSyncWhitelistId; set => _userSyncWhitelistId = value; }
        public string UserId { get => _userId; set => _userId = value; }
        public string ApplicationId { get => _applicationId; set => _applicationId = value; }
        public DateTime DateCreated { get => _dateCreated; set => _dateCreated = value; }
    }
}
