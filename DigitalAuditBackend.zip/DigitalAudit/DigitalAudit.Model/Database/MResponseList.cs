﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("MResponseList", Schema = "dbo")]
    public class MResponseList
    {
        [Key]
        private int _listId;
        private int _responseId;
        private string _name;
        private double? _score;
        private bool _isFailedResponse;
        private int _seqNo;
        private bool _isDeleted;
        private string _userCreated;
        private DateTime _dateCreated;
        private string _userModified;
        private DateTime? _dateModified;

        public MResponseList()
        {
        }

        public MResponseList(int listId, int responseId, string name, double? score, bool isFailedResponse, int seqNo, bool isDeleted, string userCreated, DateTime dateCreated, string userModified, DateTime? dateModified)
        {
            ListId = listId;
            ResponseId = responseId;
            Name = name;
            Score = score;
            IsFailedResponse = isFailedResponse;
            IsDeleted = isDeleted;
            UserCreated = userCreated;
            DateCreated = dateCreated;
            UserModified = userModified;
            DateModified = dateModified;
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ListId { get => _listId; set => _listId = value; }
        public int ResponseId { get => _responseId; set => _responseId = value; }
        public string Name { get => _name; set => _name = value; }
        public double? Score { get => _score; set => _score = value; }
        public bool IsFailedResponse { get => _isFailedResponse; set => _isFailedResponse = value; }
        public int SeqNo { get => _seqNo; set => _seqNo = value; }
        public bool IsDeleted { get => _isDeleted; set => _isDeleted = value; }
        public string UserCreated { get => _userCreated; set => _userCreated = value; }
        public DateTime DateCreated { get => _dateCreated; set => _dateCreated = value; }
        public string UserModified { get => _userModified; set => _userModified = value; }
        public DateTime? DateModified { get => _dateModified; set => _dateModified = value; }
    }
}
