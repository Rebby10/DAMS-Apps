﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DigitalAudit.Model.Database
{
    [Table("TrAction", Schema = "dbo")]
    public class TrAction
    {
        public TrAction(string actionId, string inspectionId, string title, string descriptions, string questionId, string code, string question, string auditTypeId, string issueId, string auditLocationId, string assignGroup, string assignUser, string creator, int priorityId, DateTime targetClosing, int statusId, bool isDeleted, string userCreated, DateTime dateCreated, string userModified, DateTime? dateModified)
        {
            ActionId = actionId;
            InspectionId = inspectionId;
            Title = title;
            Descriptions = descriptions;
            QuestionId = questionId;
            Code = code;
            Question = question;
            AuditTypeId = auditTypeId;
            IssueId = issueId;
            AuditLocationId = auditLocationId;
            AssignGroup = assignGroup;
            AssignUser = assignUser;
            Creator = creator;
            PriorityId = priorityId;
            TargetClosing = targetClosing;
            StatusId = statusId;
            IsDeleted = isDeleted;
            UserCreated = userCreated;
            DateCreated = dateCreated;
            UserModified = userModified;
            DateModified = dateModified;
        }

        public TrAction()
        {
        }

        [Key]
        public string ActionId { get; set; }
        public string InspectionId { get; set; }
        [Required]
        public string Title { get; set; }
        [Required]
        public string Descriptions { get; set; }
        public string QuestionId { get; set; }
        public string Code { get; set; }
        public string Question { get; set; }
        public string AuditTypeId { get; set; }
        [ForeignKey("AuditTypeId")]
        public virtual MAuditType AuditType { get; set; }
        public string IssueId { get; set; }
        [ForeignKey("IssueId")]
        public virtual TrIssue Issue { get; set; }
        [Required]
        public string AuditLocationId { get; set; }
        [ForeignKey("AuditLocationId")]
        public virtual MAuditLocation AuditLocation { get; set; }        
        public string AssignGroup { get; set; }
        [ForeignKey("AssignGroup")]
        public virtual MUserGroup UserGroup { get; set; }
        public string AssignUser { get; set; }
        [ForeignKey("AssignUser")]
        public virtual MUserSync Assignee { get; set; }
        [Required]
        public string Creator { get; set; }
        [ForeignKey("Creator")]
        public virtual MUserSync UserCreator { get; set; }
        [Required]
        public int PriorityId { get; set; }
        [ForeignKey("PriorityId")]
        public virtual MPriority Priority { get; set; }
        [Required]
        public DateTime TargetClosing { get; set; }
        [Required]
        public int StatusId { get; set; }
        [ForeignKey("StatusId")]
        public virtual MIssueStatus Status { get; set; }
        public bool IsDeleted { get; set; }
        public string UserCreated { get; set; }
        public DateTime DateCreated { get; set; }
        public string UserModified { get; set; }
        public DateTime? DateModified { get; set; }
    }
}
