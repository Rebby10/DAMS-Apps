﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DigitalAudit.Model.Database
{
    [Table("TrInspectionPIC", Schema = "dbo")]
    public class TrInspectionPIC
    {
        public TrInspectionPIC(string picId, string inspectionId, string userId, string userGroupId, string userTypeId, bool isDeleted, string userCreated, DateTime dateCreated, string userModified, DateTime? dateModified)
        {
            PicId = picId;
            InspectionId = inspectionId;
            UserId = userId;
            UserGroupId = userGroupId;
            UserTypeId = userTypeId;
            IsDeleted = isDeleted;
            UserCreated = userCreated;
            DateCreated = dateCreated;
            UserModified = userModified;
            DateModified = dateModified;
        }

        public TrInspectionPIC()
        {
        }

        [Key]
        public string PicId { get; set; }
        public string InspectionId { get; set; }
        public string UserId { get; set; }
        public string UserGroupId { get; set; }
        public string UserTypeId { get; set; }
        public bool IsDeleted { get; set; }
        public string UserCreated { get; set; }
        public DateTime DateCreated { get; set; }
        public string UserModified { get; set; }
        public DateTime? DateModified { get; set; }
    }
}
