﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;


namespace DigitalAudit.Model.Database
{
    [Table("fn_Get_MUserWhitelist", Schema = "dbo")]
    public class fn_Get_MUserWhitelist
    {
        [Key]
        private string _userWhitelistId;
        private string _userId;
        private string _email;
        private string _displayName;

        public fn_Get_MUserWhitelist()
        {
        }

        public fn_Get_MUserWhitelist(string userWhitelistId, string userId, string email, string displayName)
        {
            UserWhitelistId = userWhitelistId;
            UserId = userId;
            Email = email;
            DisplayName = displayName;
        }

        [Key]
        public string UserWhitelistId { get => _userWhitelistId; set => _userWhitelistId = value; }
        public string UserId { get => _userId; set => _userId = value; }
        public string Email { get => _email; set => _email = value; }
        public string DisplayName { get => _displayName; set => _displayName = value; }
    }
}
