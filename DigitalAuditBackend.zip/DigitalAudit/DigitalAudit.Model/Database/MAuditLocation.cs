﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("MAuditLocation", Schema = "dbo")]
    public class MAuditLocation
    {
        [Key]
        private string _auditLocationId;
        private int _ID;
        private string _name;
        private string _address;
        private string _zipCode;
        private string _latLong;
        private string _regionId;
        private bool _isDeleted;
        private string _userCreated;
        private DateTime _dateCreated;
        private string _userModified;
        private DateTime? _dateModified;

        public MAuditLocation()
        {
        }

        public MAuditLocation(string auditLocationId, int id, string name, string address, string zipCode, string latLong, string regionId, bool isDeleted, string userCreated, DateTime dateCreated, string userModified, DateTime? dateModified)
        {
            AuditLocationId = auditLocationId;
            Name = name;
            ID = id;
            Address = address;
            ZipCode = zipCode;
            LatLong = latLong;
            RegionId = regionId;
            IsDeleted = isDeleted;
            UserCreated = userCreated;
            DateCreated = dateCreated;
            UserModified = userModified;
            DateModified = dateModified;
        }

        [Key]
        public string AuditLocationId { get => _auditLocationId; set => _auditLocationId = value; }
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ID { get => _ID; set => _ID = value; }

        [Required]
        [StringLength(100)]
        [Display(Name = "Nama Lokasi")]
        public string Name { get => _name; set => _name = value; }

        [Required]
        [StringLength(300)]
        [Display(Name = "Alamat")]
        public string Address { get => _address; set => _address = value; }

        [Required]
        [StringLength(100)]
        [Display(Name = "Kode Pos")]
        public string ZipCode { get => _zipCode; set => _zipCode = value; }

        [Required]
        [StringLength(100)]
        [Display(Name = "Latitude Longitude")]
        public string LatLong { get => _latLong; set => _latLong = value; }

        [Required]
        [StringLength(50)]
        [Display(Name = "Region Id")]
        public string RegionId { get => _regionId; set => _regionId = value; }
        [ForeignKey("RegionId")]
        public virtual MRegion Region { get; set; }

        public bool IsDeleted { get => _isDeleted; set => _isDeleted = value; }
        public string UserCreated { get => _userCreated; set => _userCreated = value; }
        public DateTime DateCreated { get => _dateCreated; set => _dateCreated = value; }
        public string UserModified { get => _userModified; set => _userModified = value; }
        public DateTime? DateModified { get => _dateModified; set => _dateModified = value; }
    }
}
