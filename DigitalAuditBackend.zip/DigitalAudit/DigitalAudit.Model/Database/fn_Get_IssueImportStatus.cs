﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;


namespace DigitalAudit.Model.Database
{
    [Table("fn_Get_IssueImportStatus", Schema = "dbo")]
    public class fn_Get_IssueImportStatus
    {
        [Key]
        public string SessionId { get; set; }
        public int? TotalData { get; set; }
        public int? TotalSuccess { get; set; }
        public int? TotalError { get; set; }
        public bool? IsSuccess { get; set; }
    }
}
