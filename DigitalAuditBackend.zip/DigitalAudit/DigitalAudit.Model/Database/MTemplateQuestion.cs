﻿

using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DigitalAudit.Model.Database
{
    [Table("MTemplateQuestion", Schema = "dbo")]
    public class MTemplateQuestion
    {
        
        public MTemplateQuestion(int questionId, string pageId, int seqNo, string code, string question, bool isMandatory, string sectionId, 
            int responseId, bool isDeleted, string userCreated, DateTime dateCreated, string userModified, DateTime? dateModified)
        {
            QuestionId = questionId;
            PageId = pageId;
            SeqNo = seqNo;
            Code = code;
            Question = question;
            IsMandatory = isMandatory;
            SectionId = sectionId;
            ResponseId = responseId;
            IsDeleted = isDeleted;
            UserCreated = userCreated;
            DateCreated = dateCreated;
            UserModified = userModified;
            DateModified = dateModified;
        }

        public MTemplateQuestion()
        {
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int QuestionId { get; set; }
        public string PageId { get; set; }
        public int SeqNo { get; set; }
        public string Code { get; set; }
        public string Question { get; set; }
        public bool IsMandatory { get; set; }
        public string SectionId { get; set; }
        public int ResponseId { get; set; }
        public bool IsDeleted { get; set; }
        public string UserCreated { get; set; }
        public DateTime DateCreated { get; set; }
        public string UserModified { get; set; }
        public DateTime? DateModified { get; set; }
    }
}
