﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DigitalAudit.Model.Database
{
    [Table("TrAuditScheduleImport", Schema = "dbo")]
    public class TrAuditScheduleImport
    {
        public TrAuditScheduleImport()
        {
        }

        public TrAuditScheduleImport(string scheduleImportId, string sessionId, string auditLocationId, string templateId, DateTime startDate, DateTime endDate, string creator, string auditorGroup, string auditorUser, string auditeeGroup, string auditeeUser, bool? isSuccess, string errorMessage, bool isDeleted, string userCreated, DateTime dateCreated, string userModified, DateTime? dateModified)
        {
            ScheduleImportId = scheduleImportId;
            SessionId = sessionId;
            AuditLocationId = auditLocationId;
            TemplateId = templateId;
            StartDate = startDate;
            EndDate = endDate;
            Creator = creator;
            AuditorGroup = auditorGroup;
            AuditorUser = auditorUser;
            AuditeeGroup = auditeeGroup;
            AuditeeUser = auditeeUser;
            IsSuccess = isSuccess;
            ErrorMessage = errorMessage;
            IsDeleted = isDeleted;
            UserCreated = userCreated;
            DateCreated = dateCreated;
            UserModified = userModified;
            DateModified = dateModified;
        }

        [Key]
        public string ScheduleImportId { get; set; }
        public string SessionId { get; set; }
        [Required]
        public string AuditLocationId { get; set; }
        [Required]
        public string TemplateId { get; set; }
        [Required]
        public DateTime StartDate { get; set; }
        [Required]
        public DateTime EndDate { get; set; }
        [Required]
        public string Creator { get; set; }
        public string AuditorGroup { get; set; }
        public string AuditorUser { get; set; }
        public string AuditeeGroup { get; set; }
        public string AuditeeUser { get; set; }
        public bool? IsSuccess { get; set; }
        public string ErrorMessage { get; set; }
        public bool IsDeleted { get; set; }
        public string UserCreated { get; set; }
        public DateTime DateCreated { get; set; }
        public string UserModified { get; set; }
        public DateTime? DateModified { get; set; }
    }
}
