﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("MKboAuditLocation", Schema = "dbo")]
    public class MKboAuditLocation
    {
        [Key]
        private string _kboAuditLocationId;
        private string _kbo;
        private string _auditLocationId;
        private bool _isDeleted;
        private string _userCreated;
        private DateTime _dateCreated;
        private string _userModified;
        private DateTime? _dateModified;

        public MKboAuditLocation()
        {
        }

        public MKboAuditLocation(string kboAuditLocationId, string kbo, string auditLocationId, bool isDeleted, string userCreated, DateTime dateCreated, string userModified, DateTime? dateModified)
        {
            KboAuditLocationId = kboAuditLocationId;
            Kbo = kbo;
            AuditLocationId = auditLocationId;
            IsDeleted = isDeleted;
            UserCreated = userCreated;
            DateCreated = dateCreated;
            UserModified = userModified;
            DateModified = dateModified;
        }

        [Key]
        public string KboAuditLocationId { get => _kboAuditLocationId; set => _kboAuditLocationId = value; }
        public string Kbo { get => _kbo; set => _kbo = value; }
        public string AuditLocationId { get => _auditLocationId; set => _auditLocationId = value; }
        public bool IsDeleted { get => _isDeleted; set => _isDeleted = value; }
        public string UserCreated { get => _userCreated; set => _userCreated = value; }
        public DateTime DateCreated { get => _dateCreated; set => _dateCreated = value; }
        public string UserModified { get => _userModified; set => _userModified = value; }
        public DateTime? DateModified { get => _dateModified; set => _dateModified = value; }
    }
}
