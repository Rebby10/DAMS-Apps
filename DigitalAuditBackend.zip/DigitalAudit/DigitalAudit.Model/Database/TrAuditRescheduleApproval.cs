﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("TrAuditRescheduleApproval", Schema = "dbo")]
    public class TrAuditRescheduleApproval
    {
        [Key]
        private string _approvalId;
        private string _rescheduleId;
        private string _picId;
        private bool? _isApproved;
        private DateTime? _approvalDate;
        private bool _isDeleted;
        private string _userCreated;
        private DateTime _dateCreated;
        private string _userModified;
        private DateTime? _dateModified;


        public TrAuditRescheduleApproval(string approvalId, string rescheduleId, string picId, bool? isApproved, DateTime? approvalDate, bool isDeleted, string userCreated, DateTime dateCreated, string userModified, DateTime? dateModified)
        {
            ApprovalId = approvalId;
            RescheduleId = rescheduleId;
            PicId = picId;
            IsApproved = isApproved;
            ApprovalDate = approvalDate;
            IsDeleted = isDeleted;
            UserCreated = userCreated;
            DateCreated = dateCreated;
            UserModified = userModified;
            DateModified = dateModified;
        }

        public TrAuditRescheduleApproval()
        {
        }

        [Key]
        public string ApprovalId { get => _approvalId; set => _approvalId = value; }
        public string RescheduleId { get => _rescheduleId; set => _rescheduleId = value; }
        public string PicId { get => _picId; set => _picId = value; }
        public bool? IsApproved { get => _isApproved; set => _isApproved = value; }
        public DateTime? ApprovalDate { get => _approvalDate; set => _approvalDate = value; }
        public bool IsDeleted { get => _isDeleted; set => _isDeleted = value; }
        public string UserCreated { get => _userCreated; set => _userCreated = value; }
        public DateTime DateCreated { get => _dateCreated; set => _dateCreated = value; }
        public string UserModified { get => _userModified; set => _userModified = value; }
        public DateTime? DateModified { get => _dateModified; set => _dateModified = value; }
    }
}
