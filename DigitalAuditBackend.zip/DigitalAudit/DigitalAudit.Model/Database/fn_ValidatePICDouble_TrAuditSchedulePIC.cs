﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("fn_ValidatePICDouble_TrAuditSchedulePIC", Schema = "dbo")]
    public class fn_ValidatePICDouble_TrAuditSchedulePIC
    {
        [Key]
        private string _userId;
        private string _totalData;


        [Key]
        public string UserId { get => _userId; set => _userId = value; }
        public string TotalData { get => _totalData; set => _totalData = value; }

        public fn_ValidatePICDouble_TrAuditSchedulePIC(string userId, string totalData)
        {
            UserId = userId;
            TotalData = totalData;
        }

        public fn_ValidatePICDouble_TrAuditSchedulePIC()
        {
        }
    }

}
