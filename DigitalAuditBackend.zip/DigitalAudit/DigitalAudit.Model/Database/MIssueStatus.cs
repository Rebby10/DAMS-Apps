﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;


namespace DigitalAudit.Model.Database
{
    [Table("MIssueStatus", Schema = "dbo")]
    public class MIssueStatus
    {
        public MIssueStatus(int statusId, string name, bool isDeleted, string userCreated, DateTime dateCreated, string userModified, DateTime dateModified)
        {
            StatusId = statusId;
            Name = name;
            IsDeleted = isDeleted;
            UserCreated = userCreated;
            DateCreated = dateCreated;
            UserModified = userModified;
            DateModified = dateModified;
        }

        public MIssueStatus()
        {
        }

        [Key]
        public int StatusId { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public bool IsDeleted { get; set; }
        [Required]
        public string UserCreated { get; set; }
        [Required]
        public DateTime DateCreated { get; set; }
        public string UserModified { get; set; }
        public DateTime? DateModified { get; set; }


    }
}
