﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("MConfig", Schema = "dbo")]
    public class MConfig
    {
        [Key]
        private int _configId;
        private int _configTypeId;
        private string _configKey;
        private string _configValue;
        private bool _isDeleted;
        private string _userCreated;
        private DateTime _dateCreated;
        private string _userModified;
        private DateTime? _dateModified;

        public MConfig()
        {
        }

        public MConfig(int configId, int configTypeId, string configKey, string configValue, bool isDeleted, string userCreated, DateTime dateCreated, string userModified, DateTime? dateModified)
        {
            ConfigId = configId;
            ConfigTypeId = configTypeId;
            ConfigKey = configKey;
            ConfigValue = configValue;
            IsDeleted = isDeleted;
            UserCreated = userCreated;
            DateCreated = dateCreated;
            UserModified = userModified;
            DateModified = dateModified;
        }

        [Key]
        public int ConfigId { get => _configId; set => _configId = value; }
        public int ConfigTypeId { get => _configTypeId; set => _configTypeId = value; }
        public string ConfigKey { get => _configKey; set => _configKey = value; }
        public string ConfigValue { get => _configValue; set => _configValue = value; }
        public bool IsDeleted { get => _isDeleted; set => _isDeleted = value; }
        public string UserCreated { get => _userCreated; set => _userCreated = value; }
        public DateTime DateCreated { get => _dateCreated; set => _dateCreated = value; }
        public string UserModified { get => _userModified; set => _userModified = value; }
        public DateTime? DateModified { get => _dateModified; set => _dateModified = value; }
    }
}
