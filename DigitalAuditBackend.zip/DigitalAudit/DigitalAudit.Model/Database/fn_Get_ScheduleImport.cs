﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("fn_Get_ScheduleImport", Schema = "dbo")]
    public class fn_Get_ScheduleImport
    {
        public fn_Get_ScheduleImport(string scheduleImportId, string sessionId, string auditLocationId, string locationName, string regionId, string region, string latLong, string templateId, string title, DateTime startDate, DateTime endDate, string auditorGroup, string auditorGroupName, string auditorGroupLeader, string auditorUser, string auditeeGroup, string auditeeGroupName, string auditeeGroupLeader, string auditeeUser, string creator, string errorMessage, string userCreated, DateTime dateCreated, string userModified, DateTime? dateModified)
        {
            ScheduleImportId = scheduleImportId;
            SessionId = sessionId;
            AuditLocationId = auditLocationId;
            LocationName = locationName;
            RegionId = regionId;
            Region = region;
            LatLong = latLong;
            TemplateId = templateId;
            Title = title;
            StartDate = startDate;
            EndDate = endDate;
            AuditorGroup = auditorGroup;
            AuditorGroupName = auditorGroupName;
            AuditorGroupLeader = auditorGroupLeader;
            AuditorUser = auditorUser;
            AuditeeGroup = auditeeGroup;
            AuditeeGroupName = auditeeGroupName;
            AuditeeGroupLeader = auditeeGroupLeader;
            AuditeeUser = auditeeUser;
            Creator = creator;
            ErrorMessage = errorMessage;
            UserCreated = userCreated;
            DateCreated = dateCreated;
            UserModified = userModified;
            DateModified = dateModified;
        }

        public fn_Get_ScheduleImport()
        {
        }

        [Key]
        public string ScheduleImportId { get; set; }
        public string SessionId { get; set; }
        public string AuditLocationId { get; set; }
        public string LocationName { get; set; }
        public string RegionId { get; set; }
        public string Region { get; set; }
        public string LatLong { get; set; }
        public string TemplateId { get; set; }
        public string Title { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string AuditorGroup { get; set; }
        public string AuditorGroupName { get; set; }
        public string AuditorGroupLeader { get; set; }
        public string AuditorUser { get; set; }
        public string AuditeeGroup { get; set; }
        public string AuditeeGroupName { get; set; }
        public string AuditeeGroupLeader { get; set; }
        public string AuditeeUser { get; set; }
        public string Creator { get; set; }
        public string ErrorMessage { get; set; }
        public string UserCreated { get; set; }
        public DateTime DateCreated { get; set; }
        public string UserModified { get; set; }
        public DateTime? DateModified { get; set; }
    }
}
