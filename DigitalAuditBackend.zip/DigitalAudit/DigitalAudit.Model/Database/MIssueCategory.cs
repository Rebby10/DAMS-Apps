﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{

    [Table("MIssueCategory", Schema = "dbo")]
    public class MIssueCategory
    {
        public MIssueCategory(int issueCategoryId, string name, bool isDeleted, string userCreated, DateTime dateCreated, string userModified, DateTime dateModified)
        {
            IssueCategoryId = issueCategoryId;
            Name = name;
            IsDeleted = isDeleted;
            UserCreated = userCreated;
            DateCreated = dateCreated;
            UserModified = userModified;
            DateModified = dateModified;
        }

        public MIssueCategory()
        {
        }

        [Key]
        public int IssueCategoryId { get; set; }
        [Required]
        public string Name { get; set; }
        public bool IsDeleted { get; set; }
        public string UserCreated { get; set; }
        public DateTime DateCreated { get; set; }
        public string UserModified { get; set; }
        public DateTime? DateModified { get; set; }
    }
}
