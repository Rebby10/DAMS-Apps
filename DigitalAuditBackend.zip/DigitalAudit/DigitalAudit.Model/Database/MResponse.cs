﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("MResponse", Schema = "dbo")]
    public class MResponse
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        private int _responseId;
        private string _name;
        private int _typeId;
        private int? _answerTypeId;
        private bool _isDeleted;
        private string _userCreated;
        private DateTime _dateCreated;
        private string _userModified;
        private DateTime? _dateModified;


        public MResponse()
        {
        }

        public MResponse(int responseId, string name, int typeId, int? answerTypeId, bool isDeleted, string userCreated, DateTime dateCreated, string userModified, DateTime? dateModified)
        {
            ResponseId = responseId;
            Name = name;
            TypeId = typeId;
            AnswerTypeId = answerTypeId;
            IsDeleted = isDeleted;
            UserCreated = userCreated;
            DateCreated = dateCreated;
            UserModified = userModified;
            DateModified = dateModified;
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ResponseId { get => _responseId; set => _responseId = value; }
        public string Name { get => _name; set => _name = value; }
        public int TypeId { get => _typeId; set => _typeId = value; }
        public int? AnswerTypeId { get => _answerTypeId; set => _answerTypeId = value; }
        public bool IsDeleted { get => _isDeleted; set => _isDeleted = value; }
        public string UserCreated { get => _userCreated; set => _userCreated = value; }
        public DateTime DateCreated { get => _dateCreated; set => _dateCreated = value; }
        public string UserModified { get => _userModified; set => _userModified = value; }
        public DateTime? DateModified { get => _dateModified; set => _dateModified = value; }
    }
}
