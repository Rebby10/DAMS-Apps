﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DigitalAudit.Model.Database
{
    [Table("TrInspection", Schema = "dbo")]
    public class TrInspection
    {
        

        public TrInspection()
        {
        }

        public TrInspection(string inspectionId, string scheduleId, string locationId, DateTime startDate, DateTime endDate, string templateId, int statusId, bool isDeleted, string userCreated, DateTime dateCreated, string userModified, DateTime? dateModified, string completedBy, DateTime? completedDate, string approvedBy, DateTime? approvedDate, DateTime? conductedDate)
        {
            InspectionId = inspectionId;
            ScheduleId = scheduleId;
            LocationId = locationId;
            StartDate = startDate;
            EndDate = endDate;
            TemplateId = templateId;
            StatusId = statusId;
            IsDeleted = isDeleted;
            UserCreated = userCreated;
            DateCreated = dateCreated;
            UserModified = userModified;
            DateModified = dateModified;
            CompletedBy = completedBy;
            CompletedDate = completedDate;
            ApprovedBy = approvedBy;
            ApprovedDate = approvedDate;
            ConductedDate = conductedDate;
        }

        [Key]
        public string InspectionId { get; set; }
        public string ScheduleId { get; set; }
        public string LocationId { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string TemplateId { get; set; }
        public int StatusId { get; set; }
        public bool IsDeleted { get; set; }
        public string UserCreated { get; set; }
        public DateTime DateCreated { get; set; }
        public string UserModified { get; set; }
        public DateTime? DateModified { get; set; }
        public string CompletedBy { get; set; }
        public DateTime? CompletedDate { get; set; }
        public string ApprovedBy { get; set; }
        public DateTime? ApprovedDate { get; set; }
        public DateTime? ConductedDate { get; set; }


    }
}
