﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;


namespace DigitalAudit.Model.Database
{
    [Table("TrActionImport", Schema = "dbo")]
    public class TrActionImport
    {
        public TrActionImport(string actionImportId, string sessionId, string title, string descriptions, string questionId, string code, string question, string auditLocationId, string assignGroup, string assignUser, string creator, int priorityId, DateTime targetClosing, int statusId, string auditTypeId, bool? isSuccess, string errorMessage, bool isDeleted, string userCreated, DateTime dateCreated, string userModified, DateTime? dateModified)
        {
            ActionImportId = actionImportId;
            SessionId = sessionId;
            Title = title;
            Descriptions = descriptions;
            QuestionId = questionId;
            Code = code;
            Question = question;
            AuditLocationId = auditLocationId;
            AssignGroup = assignGroup;
            AssignUser = assignUser;
            Creator = creator;
            PriorityId = priorityId;
            TargetClosing = targetClosing;
            StatusId = statusId;
            AuditTypeId = auditTypeId;
            IsSuccess = isSuccess;
            ErrorMessage = errorMessage;
            IsDeleted = isDeleted;
            UserCreated = userCreated;
            DateCreated = dateCreated;
            UserModified = userModified;
            DateModified = dateModified;
        }

        public TrActionImport()
        {
        }

        [Key]
        public string ActionImportId { get; set; }
        public string SessionId { get; set; }

        [Required]
        public string Title { get; set; }

        [Required]
        public string Descriptions { get; set; }
        public string QuestionId { get; set; }
        public string Code { get; set; }
        public string Question { get; set; }

        [Required]
        public string AuditLocationId { get; set; }
        public string AssignGroup { get; set; }
        public string AssignUser { get; set; }

        [Required]
        public string Creator { get; set; }

        [Required]
        public int PriorityId { get; set; }

        [Required]
        public DateTime TargetClosing { get; set; }
        [Required]
        public string AuditTypeId { get; set; }

        [Required]
        public int StatusId { get; set; }
        public bool? IsSuccess { get; set; }
        public string ErrorMessage { get; set; }
        public bool IsDeleted { get; set; }
        public string UserCreated { get; set; }
        public DateTime DateCreated { get; set; }
        public string UserModified { get; set; }
        public DateTime? DateModified { get; set; }
    }
}
