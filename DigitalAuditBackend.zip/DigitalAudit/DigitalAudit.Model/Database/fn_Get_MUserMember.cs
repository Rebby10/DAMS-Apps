﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("fn_Get_MUserMember", Schema = "dbo")]
    public class fn_Get_MUserMember
    {
        [Key]
        private string _userMemberId;
        private string _userGroupId;
        private string _userTypeId;
        private string _userType;
        private string _groupName;
        private string _userIdGroup;
        private string _usernameGroup;
        private string _officialNameGroup;
        private string _userIdMember;
        private string _usernameMember;
        private string _officialNameMember;


        public fn_Get_MUserMember()
        {
        }

        public fn_Get_MUserMember(string userMemberId, string userGroupId, string userTypeId, string userType, string groupName, string userIdGroup, string usernameGroup, string officialNameGroup, string userIdMember, string usernameMember, string officialNameMember)
        {
            UserMemberId = userMemberId;
            UserGroupId = userGroupId;
            UserTypeId = userTypeId;
            UserType = userType;
            GroupName = groupName;
            UserIdGroup = userIdGroup;
            UsernameGroup = usernameGroup;
            OfficialNameGroup = officialNameGroup;
            UserIdMember = userIdMember;
            UsernameMember = usernameMember;
            OfficialNameMember = officialNameMember;
        }


        [Key]
        public string UserMemberId { get => _userMemberId; set => _userMemberId = value; }
        public string UserGroupId { get => _userGroupId; set => _userGroupId = value; }
        public string UserTypeId { get => _userTypeId; set => _userTypeId = value; }
        public string UserType { get => _userType; set => _userType = value; }
        public string GroupName { get => _groupName; set => _groupName = value; }
        public string UserIdGroup { get => _userIdGroup; set => _userIdGroup = value; }
        public string UsernameGroup { get => _usernameGroup; set => _usernameGroup = value; }
        public string OfficialNameGroup { get => _officialNameGroup; set => _officialNameGroup = value; }
        public string UserIdMember { get => _userIdMember; set => _userIdMember = value; }
        public string UsernameMember { get => _usernameMember; set => _usernameMember = value; }
        public string OfficialNameMember { get => _officialNameMember; set => _officialNameMember = value; }
    }
}
