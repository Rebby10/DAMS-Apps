﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;


namespace DigitalAudit.Model.Database
{
    [Table("TrActionLog", Schema = "dbo")]
    public class TrActionLog
    {
        public TrActionLog(string logId, string actionId, string userId, string userName, string textLog, DateTime datetimeLog, string linkFile, int logTypeId, bool isDeleted, string userCreated, DateTime dateCreated, string userModified, DateTime? dateModified)
        {
            LogId = logId;
            ActionId = actionId;
            UserId = userId;
            Username = userName;
            TextLog = textLog;
            DatetimeLog = datetimeLog;
            LinkFile = linkFile;
            LogTypeId = logTypeId;
            IsDeleted = isDeleted;
            UserCreated = userCreated;
            DateCreated = dateCreated;
            UserModified = userModified;
            DateModified = dateModified;
        }

        public TrActionLog()
        {
        }

        [Key]
        public string LogId { get; set; }
        public string ActionId { get; set; }
        public string UserId { get; set; }
        public string Username { get; set; }
        public string TextLog { get; set; }
        public DateTime DatetimeLog { get; set; }
        public string Filename { get; set; }
        public string LinkFile { get; set; }
        public int LogTypeId { get; set; }
        [ForeignKey("LogTypeId")]
        public virtual MLogType LogType { get; set; }
        public bool IsDeleted { get; set; }
        public string UserCreated { get; set; }
        public DateTime DateCreated { get; set; }
        public string UserModified { get; set; }
        public DateTime? DateModified { get; set; }
    }
}
