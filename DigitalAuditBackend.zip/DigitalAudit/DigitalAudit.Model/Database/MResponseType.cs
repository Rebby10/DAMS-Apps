﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("MResponseType", Schema = "dbo")]
    public class MResponseType
    {
        [Key]
        private int _typeId;
        private string _name;
        private bool _isDeleted;
        private string _userCreated;
        private DateTime _dateCreated;
        private string _userModified;
        private DateTime? _dateModified;

        public MResponseType()
        {
        }

        public MResponseType(int typeId, string name, bool isDeleted, string userCreated, DateTime dateCreated, string userModified, DateTime? dateModified)
        {
            _typeId = typeId;
            _name = name;
            _isDeleted = isDeleted;
            _userCreated = userCreated;
            _dateCreated = dateCreated;
            _userModified = userModified;
            _dateModified = dateModified;
        }

        [Key]
        public int TypeId { get => _typeId; set => _typeId = value; }
        public string Name { get => _name; set => _name = value; }
        public bool IsDeleted { get => _isDeleted; set => _isDeleted = value; }
        public string UserCreated { get => _userCreated; set => _userCreated = value; }
        public DateTime DateCreated { get => _dateCreated; set => _dateCreated = value; }
        public string UserModified { get => _userModified; set => _userModified = value; }
        public DateTime? DateModified { get => _dateModified; set => _dateModified = value; }
    }


}
