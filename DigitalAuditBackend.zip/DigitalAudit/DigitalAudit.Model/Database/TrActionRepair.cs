﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DigitalAudit.Model.Database
{
    [Table("TrActionRepair", Schema = "dbo")]
    public class TrActionRepair
    {
        [Key]
        public string ActionRepairId { get; set; }
        public string ActionId { get; set; }
        [ForeignKey("ActionId")]
        public virtual TrAction Action { get; set; }
        public string RootCause { get; set; }
        public string RootCauseCategoryId { get; set; }
        [ForeignKey("RootCauseCategoryId")]
        public virtual MRootCauseCategory RootCauseCategory { get; set; }
        public string ActionRepair { get; set; }
        public string ActionRepairCategoryId { get; set; }
        [ForeignKey("ActionRepairCategoryId")]
        public virtual MActionRepairCategory ActionRepairCategory { get; set; }
        public DateTime RepairDate { get; set; }
        public string Filename { get; set; }
        public string LinkFile { get; set; }
        public bool IsDeleted { get; set; }
        public string UserCreated { get; set; }
        public DateTime DateCreated { get; set; }
        public string UserModified { get; set; }
        public DateTime? DateModified { get; set; }

        public TrActionRepair()
        {
        }

        public TrActionRepair(string actionRepairId, string actionId, string rootCause, string rootCauseCategoryId, string actionRepair, string actionRepairCategoryId, DateTime repairDate, string filename, string linkFile, bool isDeleted, string userCreated, DateTime dateCreated, string userModified, DateTime? dateModified)
        {
            ActionRepairId = actionRepairId;
            ActionId = actionId;
            RootCause = rootCause;
            RootCauseCategoryId = rootCauseCategoryId;
            ActionRepair = actionRepair;
            ActionRepairCategoryId = actionRepairCategoryId;
            RepairDate = repairDate;
            Filename = filename;
            LinkFile = linkFile;
            IsDeleted = isDeleted;
            UserCreated = userCreated;
            DateCreated = dateCreated;
            UserModified = userModified;
            DateModified = dateModified;
        }
    }
}
