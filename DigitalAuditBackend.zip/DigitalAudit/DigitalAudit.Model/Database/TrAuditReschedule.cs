﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("TrAuditReschedule", Schema = "dbo")]
    public class TrAuditReschedule
    {
        [Key]
        private string _rescheduleId;
        private string _scheduleId;
        private string _picId;
        private DateTime _startDate;
        private DateTime _endDate;
        private string _descriptions;
        private string _PicIdApprover;
        private bool? _isApproved;
        private DateTime? _approvalDate;
        private bool _isDeleted;
        private string _userCreated;
        private DateTime _dateCreated;
        private string _userModified;
        private DateTime? _dateModified;

        public TrAuditReschedule()
        {
        }

        public TrAuditReschedule(string rescheduleId, string scheduleId, string picId, DateTime startDate, DateTime endDate, string descriptions, string picIdApprover, bool? isApproved, DateTime? approvalDate, bool isDeleted, string userCreated, DateTime dateCreated, string userModified, DateTime? dateModified)
        {
            RescheduleId = rescheduleId;
            ScheduleId = scheduleId;
            PicId = picId;
            StartDate = startDate;
            EndDate = endDate;
            Descriptions = descriptions;
            PicIdApprover = picIdApprover;
            IsApproved = isApproved;
            ApprovalDate = approvalDate;
            IsDeleted = isDeleted;
            UserCreated = userCreated;
            DateCreated = dateCreated;
            UserModified = userModified;
            DateModified = dateModified;
        }

        [Key]
        public string RescheduleId { get => _rescheduleId; set => _rescheduleId = value; }
        public string ScheduleId { get => _rescheduleId; set => _rescheduleId = value; }
        public string PicId { get => _picId; set => _picId = value; }
        public DateTime StartDate { get => _startDate; set => _startDate = value; }
        public DateTime EndDate { get => _endDate; set => _endDate = value; }
        public string Descriptions { get => _descriptions; set => _descriptions = value; }
        public string PicIdApprover { get => _PicIdApprover; set => _PicIdApprover = value; }
        public bool? IsApproved { get => _isApproved; set => _isApproved = value; }
        public DateTime? ApprovalDate { get => _approvalDate; set => _approvalDate = value; }
        public bool IsDeleted { get => _isDeleted; set => _isDeleted = value; }
        public string UserCreated { get => _userCreated; set => _userCreated = value; }
        public DateTime DateCreated { get => _dateCreated; set => _dateCreated = value; }
        public string UserModified { get => _userModified; set => _userModified = value; }
        public DateTime? DateModified { get => _dateModified; set => _dateModified = value; }
    }
}
