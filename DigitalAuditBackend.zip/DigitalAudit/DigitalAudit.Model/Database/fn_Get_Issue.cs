﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("fn_Get_Issue", Schema = "dbo")]
    public class fn_Get_Issue
    {
        public fn_Get_Issue(
            string issueId, string title, string descriptions, string questionId, string code, string question, string auditTypeId, string auditType, 
            string auditLocationId, string locationName, string regionId, string region, string latLong, string assignGroup, string userGroupName, string groupLeader, 
            string assignUser, string creator, int priorityId, string priority, DateTime targetClosing, int issueCategoryId, string issueCategory, 
            int statusId, string issueStatus, string userCreated, DateTime dateCreated, string userModified, DateTime? dateModified, int lastUpdate, int? recurringFinding, int totalAction, string inspectionId)
        {
            IssueId = issueId;
            Title = title;
            Descriptions = descriptions;
            QuestionId = questionId;
            Code = code;
            Question = question;
            AuditTypeId = auditTypeId;
            AuditType = auditType;
            AuditLocationId = auditLocationId;
            LocationName = locationName;
            RegionId = regionId;
            Region = region;
            LatLong = latLong;
            AssignGroup = assignGroup;
            UserGroupName = userGroupName;
            GroupLeader = groupLeader;
            AssignUser = assignUser;
            Creator = creator;
            PriorityId = priorityId;
            Priority = priority;
            TargetClosing = targetClosing;
            IssueCategoryId = issueCategoryId;
            IssueCategory = issueCategory;
            StatusId = statusId;
            IssueStatus = issueStatus;
            UserCreated = userCreated;
            DateCreated = dateCreated;
            UserModified = userModified;
            DateModified = dateModified;
            LastUpdate = lastUpdate;
            RecurringFinding = recurringFinding;
            TotalAction = totalAction;
            InspectionId = inspectionId;
        }

        public fn_Get_Issue()
        {
        }

        [Key]
        public string IssueId { get; set; }
        public string Title { get; set; }
        public string Descriptions { get; set; }
        public string QuestionId { get; set; }
        public string Code { get; set; }
        public string Question { get; set; }
        public string AuditTypeId { get; set; }
        public string AuditType { get; set; }
        public string AuditLocationId { get; set; }
        public string AuditLocationAddress { get; set; }
        public string AuditLocationZipCode { get; set; }
        public string LocationName { get; set; }
        public string RegionId { get; set; }
        public string Region { get; set; }
        public string LatLong { get; set; }
        public string AssignGroup { get; set; }
        public string UserGroupName { get; set; }
        public string UserGroupTypeId { get; set; }
        public string UserGroupTypeName { get; set; }
        public string GroupLeader { get; set; }
        public string GroupLeaderName { get; set; }
        public string AssignUser { get; set; }
        public string AssignUserName { get; set; }
        public string AssignUserEmail { get; set; }
        public string Creator { get; set; }
        public string CreatorName { get; set; }
        public string CreatorEmail { get; set; }
        public int PriorityId { get; set; }
        public string Priority { get; set; }
        public DateTime TargetClosing { get; set; }
        public int IssueCategoryId { get; set; }
        public string IssueCategory { get; set; }
        public int StatusId { get; set; }
        public string IssueStatus { get; set; }
        public int? RecurringFinding { get; set; }
        public string UserCreated { get; set; }
        public DateTime DateCreated { get; set; }
        public string UserModified { get; set; }
        public DateTime? DateModified { get; set; }
        public int? LastUpdate { get; set; }
        public int TotalAction { get; set; }
        public string InspectionId { get; set; }
    }
}
