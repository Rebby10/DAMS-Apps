﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("TrIssue", Schema = "dbo")]
    public class TrIssue
    {
        public TrIssue(string issueId, string title, string descriptions, string questionId, string code, string question, string auditLocationId, string auditTypeId, string assignGroup, string assignUser, string creator, int priorityId, DateTime targetClosing, int issueCategoryId, int statusId, string inspectionId, bool isDeleted, string userCreated, DateTime dateCreated, string userModified, DateTime? dateModified)
        {
            IssueId = issueId;
            Title = title;
            Descriptions = descriptions;
            QuestionId = questionId;
            Code = code;
            Question = question;
            AuditLocationId = auditLocationId;
            AuditTypeId = auditTypeId;
            AssignGroup = assignGroup;
            AssignUser = assignUser;
            Creator = creator;
            PriorityId = priorityId;
            TargetClosing = targetClosing;
            IssueCategoryId = issueCategoryId;
            StatusId = statusId;
            InspectionId = inspectionId;
            IsDeleted = isDeleted;
            UserCreated = userCreated;
            DateCreated = dateCreated;
            UserModified = userModified;
            DateModified = dateModified;
        }

        public TrIssue()
        {
        }

        [Key]
        public string IssueId { get; set; }

        [Display(Name = "Judul Issue")]
        [Required]
        public string Title { get; set; }

        [Required]
        public string Descriptions { get; set; }
        public string QuestionId { get; set; }
        public string Code { get; set; }
        public string Question { get; set; }

        //[Required]
        public string AuditTypeId { get; set; }

        [Required]
        public string AuditLocationId { get; set; }
        public string AssignGroup { get; set; }
        public string AssignUser { get; set; }

        [Required]
        public string Creator { get; set; }

        [Required]
        public int PriorityId { get; set; }

        [Required]
        public DateTime TargetClosing { get; set; }

        [Required]
        public int IssueCategoryId { get; set; }

        [Required]
        public int StatusId { get; set; }
        public string InspectionId { get; set; }
        public bool IsDeleted { get; set; }
        public string UserCreated { get; set; }
        public DateTime DateCreated { get; set; }
        public string UserModified { get; set; }
        public DateTime? DateModified { get; set; }
    }
}
