﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("fn_Get_Inspection", Schema = "dbo")]
    public class fn_Get_Inspection
    {
        

        public fn_Get_Inspection()
        {
        }

        public fn_Get_Inspection(string inspectionId, string scheduleId, string locationId, string locationName, string address, string zipCode, string latLong, string regionId, string regionName, string templateId, string templateTitle, string descriptions, int statusId, string statusInspection, DateTime startDate, DateTime endDate, DateTime dateCreated, DateTime? dateModified, string completedBy, DateTime? completedDate, string approvedBy, DateTime? approvedDate, DateTime? conductedDate)
        {
            InspectionId = inspectionId;
            ScheduleId = scheduleId;
            LocationId = locationId;
            LocationName = locationName;
            Address = address;
            ZipCode = zipCode;
            LatLong = latLong;
            RegionId = regionId;
            RegionName = regionName;
            TemplateId = templateId;
            TemplateTitle = templateTitle;
            Descriptions = descriptions;
            StatusId = statusId;
            StatusInspection = statusInspection;
            StartDate = startDate;
            EndDate = endDate;
            DateCreated = dateCreated;
            DateModified = dateModified;
            CompletedBy = completedBy;
            CompletedDate = completedDate;
            ApprovedBy = approvedBy;
            ApprovedDate = approvedDate;
            ConductedDate = conductedDate;
        }

        public string InspectionId { get; set; }
        public string ScheduleId { get; set; }
        public string LocationId { get; set; }
        public string LocationName { get; set; }
        public string Address { get; set; }
        public string ZipCode { get; set; }
        public string LatLong { get; set; }
        public string RegionId { get; set; }
        public string RegionName { get; set; }
        public string TemplateId { get; set; }
        public string TemplateTitle { get; set; }
        public string Descriptions { get; set; }
        public int StatusId { get; set; }
        public string StatusInspection { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public DateTime DateCreated { get; set; }
        public DateTime? DateModified { get; set; }
        public string CompletedBy { get; set; }
        public DateTime? CompletedDate { get; set; }
        public string ApprovedBy { get; set; }
        public DateTime? ApprovedDate { get; set; }
        public DateTime? ConductedDate { get; set; }
    }
}
