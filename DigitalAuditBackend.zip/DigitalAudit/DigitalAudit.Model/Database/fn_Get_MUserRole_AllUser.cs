﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("fn_Get_MUserRole_AllUser", Schema = "dbo")]
    public class fn_Get_MUserRole_AllUser
    {
        public fn_Get_MUserRole_AllUser(string userRoleId, string userId, string username, string email, string displayName, string roleId, string roleName, string otorisasiId, string otorisasi)
        {
            UserRoleId = userRoleId;
            UserId = userId;
            Username = username;
            Email = email;
            DisplayName = displayName;
            RoleId = roleId;
            RoleName = roleName;
            OtorisasiId = otorisasiId;
            Otorisasi = otorisasi;
        }

        public fn_Get_MUserRole_AllUser()
        {
        }

        public string UserRoleId { get; set; }
        public string UserId { get; set; }
        public string Username { get; set; }
        public string Email { get; set; }
        public string DisplayName { get; set; }
        public string RoleId { get; set; }
        public string RoleName { get; set; }
        public string OtorisasiId { get; set; }
        public string Otorisasi { get; set; }

    }
}
