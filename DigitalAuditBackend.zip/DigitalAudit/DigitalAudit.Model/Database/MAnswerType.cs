﻿using System;
using System.ComponentModel.DataAnnotations;

namespace DigitalAudit.Model.Database
{
    public class MAnswerType
    {
        public MAnswerType(int answerTypeId, string name, bool isDeleted, string userCreated, DateTime dateCreated, string userModified, DateTime? dateModified)
        {
            AnswerTypeId = answerTypeId;
            Name = name;
            IsDeleted = isDeleted;
            UserCreated = userCreated;
            DateCreated = dateCreated;
            UserModified = userModified;
            DateModified = dateModified;
        }

        public MAnswerType()
        {
        }

        [Key]
        public int AnswerTypeId { get; set; }
        public string Name { get; set; }
        public bool IsDeleted { get; set; }
        public string UserCreated { get; set; }
        public DateTime DateCreated { get; set; }
        public string UserModified { get; set; }
        public DateTime? DateModified { get; set; }
    }
}
