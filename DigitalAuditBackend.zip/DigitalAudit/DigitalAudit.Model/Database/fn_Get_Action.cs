﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("fn_Get_Action", Schema = "dbo")]
    public class fn_Get_Action
    {
       


        public fn_Get_Action()
        {
        }

        public fn_Get_Action(string actionId, string title, string descriptions, string questionId, string code, string question, string auditTypeId, string auditTypeName, string issueId, string issueTitle, string auditLocationId, string auditLocationName, string auditLocationAddress, string auditLocationLatLong, string auditLocationRegionId, string auditLocationZipCode, string regionName, string assignGroup, string assignGroupName, string assignGroupUserId, string assignGroupTypeId, string assignGroupTypeName, string assignGroupUserName, string assignUser, string assignUserDisplayName, string assignUserEmail, string creator, string creatorDisplayName, string creatorEmail, int priorityId, string priorityName, DateTime targetClosing, int statusId, string statusName, string inspectionId, DateTime dateCreated, DateTime? dateModified)
        {
            ActionId = actionId;
            Title = title;
            Descriptions = descriptions;
            QuestionId = questionId;
            Code = code;
            Question = question;
            AuditTypeId = auditTypeId;
            AuditTypeName = auditTypeName;
            IssueId = issueId;
            IssueTitle = issueTitle;
            AuditLocationId = auditLocationId;
            AuditLocationName = auditLocationName;
            AuditLocationAddress = auditLocationAddress;
            AuditLocationLatLong = auditLocationLatLong;
            AuditLocationRegionId = auditLocationRegionId;
            AuditLocationZipCode = auditLocationZipCode;
            RegionName = regionName;
            AssignGroup = assignGroup;
            AssignGroupName = assignGroupName;
            AssignGroupUserId = assignGroupUserId;
            AssignGroupTypeId = assignGroupTypeId;
            AssignGroupTypeName = assignGroupTypeName;
            AssignGroupUserName = assignGroupUserName;
            AssignUser = assignUser;
            AssignUserDisplayName = assignUserDisplayName;
            AssignUserEmail = assignUserEmail;
            Creator = creator;
            CreatorDisplayName = creatorDisplayName;
            CreatorEmail = creatorEmail;
            PriorityId = priorityId;
            PriorityName = priorityName;
            TargetClosing = targetClosing;
            StatusId = statusId;
            StatusName = statusName;
            InspectionId = inspectionId;
            DateCreated = dateCreated;
            DateModified = dateModified;
        }

        [Key]
        public string ActionId { get; set; }
        public string Title { get; set; }
        public string Descriptions { get; set; }
        public string QuestionId { get; set; }
        public string Code { get; set; }
        public string Question { get; set; }
        public string AuditTypeId { get; set; }
        public string AuditTypeName { get; set; }
        public string IssueId { get; set; }
        public string IssueTitle { get; set; }
        public string AuditLocationId { get; set; }
        public string AuditLocationName { get; set; }
        public string AuditLocationAddress { get; set; }
        public string AuditLocationLatLong { get; set; }
        public string AuditLocationRegionId { get; set; }
        public string AuditLocationZipCode { get; set; }
        public string RegionName { get; set; }
        public string AssignGroup { get; set; }
        public string AssignGroupName { get; set; }
        public string AssignGroupUserId { get; set; }
        public string AssignGroupTypeId { get; set; }
        public string AssignGroupTypeName { get; set; }
        public string AssignGroupUserName { get; set; }
        public string AssignUser { get; set; }
        public string AssignUserDisplayName { get; set; }
        public string AssignUserEmail { get; set; }
        public string Creator { get; set; }
        public string CreatorDisplayName { get; set; }
        public string CreatorEmail { get; set; }
        public int PriorityId { get; set; }
        public string PriorityName { get; set; }
        public DateTime TargetClosing { get; set; }
        public int StatusId { get; set; }
        public string StatusName { get; set; }
        public string InspectionId { get; set; }
        public DateTime DateCreated { get; set; }
        public DateTime? DateModified { get; set; }
    }
}
