﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("fn_Get_TrAuditSchedule", Schema = "dbo")]
    public class fn_Get_TrAuditSchedule
    {
        [Key]
        private string _scheduleId;
        private string _auditLocationId;
        private string _locationName;
        private string _address;
        private string _zipCode;
        private string _latLong;
        private string _regionId;
        private string _regionName;
        private DateTime _startDate;
        private DateTime _endDate;
        private string _templateId;
        private string _title;
        private int _statusId;
        private string _status;

        [Key]
        public string ScheduleId { get => _scheduleId; set => _scheduleId = value; }
        public string AuditLocationId { get => _auditLocationId; set => _auditLocationId = value; }
        public string LocationName { get => _locationName; set => _locationName = value; }
        public string Address { get => _address; set => _address = value; }
        public string ZipCode { get => _zipCode; set => _zipCode = value; }
        public string LatLong { get => _latLong; set => _latLong = value; }
        public string RegionId { get => _regionId; set => _regionId = value; }
        public string RegionName { get => _regionName; set => _regionName = value; }
        public DateTime StartDate { get => _startDate; set => _startDate = value; }
        public DateTime EndDate { get => _endDate; set => _endDate = value; }
        public string TemplateId { get => _templateId; set => _templateId = value; }
        public string Title { get => _title; set => _title = value; }
        public int StatusId { get => _statusId; set => _statusId = value; }
        public string Status { get => _status; set => _status = value; }

        public fn_Get_TrAuditSchedule(string scheduleId, string auditLocationId, string locationName, string address, string zipCode, string latLong, string regionId, string regionName, DateTime startDate, DateTime endDate, string templateId, string title, int statusId, string status)
        {
            ScheduleId = scheduleId;
            AuditLocationId = auditLocationId;
            LocationName = locationName;
            Address = address;
            ZipCode = zipCode;
            LatLong = latLong;
            RegionId = regionId;
            RegionName = regionName;
            StartDate = startDate;
            EndDate = endDate;
            TemplateId = templateId;
            Title = title;
            StatusId = statusId;
            Status = status;
        }

        public fn_Get_TrAuditSchedule()
        {
        }


    }
}
