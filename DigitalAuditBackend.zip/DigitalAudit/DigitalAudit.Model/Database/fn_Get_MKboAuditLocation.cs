﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("fn_Get_MKboAuditLocation", Schema = "dbo")]
    public class fn_Get_MKboAuditLocation
    {
        [Key]
        private string _kboAuditLocationId;
        private string _kbo;
        private string _auditLocationId;
        private string _locationName;
        private string _address;
        private string _zipCode;
        private string _latLong;
        private string _regionId;
        private string _regionName;


        public fn_Get_MKboAuditLocation()
        {
        }

        public fn_Get_MKboAuditLocation(string kboAuditLocationId, string kbo, string auditLocationId, string locationName, string address, string zipCode, string latLong, string regionId, string regionName)
        {
            KboAuditLocationId = kboAuditLocationId;
            Kbo = kbo;
            AuditLocationId = auditLocationId;
            LocationName = locationName;
            Address = address;
            ZipCode = zipCode;
            LatLong = latLong;
            RegionId = regionId;
            RegionName = regionName;
        }

        [Key]
        public string KboAuditLocationId { get => _kboAuditLocationId; set => _kboAuditLocationId = value; }
        public string Kbo { get => _kbo; set => _kbo = value; }
        public string AuditLocationId { get => _auditLocationId; set => _auditLocationId = value; }
        public string LocationName { get => _locationName; set => _locationName = value; }
        public string Address { get => _address; set => _address = value; }
        public string ZipCode { get => _zipCode; set => _zipCode = value; }
        public string LatLong { get => _latLong; set => _latLong = value; }
        public string RegionId { get => _regionId; set => _regionId = value; }
        public string RegionName { get => _regionName; set => _regionName = value; }
    }
}
