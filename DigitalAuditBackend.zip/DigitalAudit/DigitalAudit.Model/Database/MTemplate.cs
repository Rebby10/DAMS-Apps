﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("MTemplate", Schema = "dbo")]
    public class MTemplate
    {
        [Key]
        private string _templateId;
        private int _id;
        private int _templatePermissionTypeId;
        private string _permissionEntityId;
        private string _code;
        private string _title;
        private string _descriptions;
        private int _categoryId;
        private bool _isShowIssue;
        private bool _isDeleted;
        private string _userCreated;
        private DateTime _dateCreated;
        private string _userModified;
        private DateTime? _dateModified;


        public MTemplate()
        {
        }

        public MTemplate(string templateId, int id, int templatePermissionTypeId, string permissionEntityId, string code, string title, string descriptions, int categoryId, bool isDeleted, bool isShowIssue, string userCreated, DateTime dateCreated, string userModified, DateTime? dateModified)
        {
            TemplateId = templateId;
            ID = id;
            TemplatePermissionTypeId = templatePermissionTypeId;
            PermissionEntityId = permissionEntityId;
            Code = code;
            Title = title;
            Descriptions = descriptions;
            CategoryId = categoryId;
            IsShowIssue = isShowIssue;
            IsDeleted = isDeleted;
            UserCreated = userCreated;
            DateCreated = dateCreated;
            UserModified = userModified;
            DateModified = dateModified;
        }

        [Key]
        public string TemplateId { get => _templateId; set => _templateId = value; }
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ID { get => _id; set => _id = value; }
        public int TemplatePermissionTypeId { get => _templatePermissionTypeId; set => _templatePermissionTypeId = value; }
        public string PermissionEntityId { get => _permissionEntityId; set => _permissionEntityId = value; }
        public string Code { get => _code; set => _code = value; }
        public string Title { get => _title; set => _title = value; }
        public string Descriptions { get => _descriptions; set => _descriptions = value; }
        public int CategoryId { get => _categoryId; set => _categoryId = value; }
        public bool IsShowIssue { get => _isShowIssue; set => _isShowIssue = value; }
        public bool IsDeleted { get => _isDeleted; set => _isDeleted = value; }
        public string UserCreated { get => _userCreated; set => _userCreated = value; }
        public DateTime DateCreated { get => _dateCreated; set => _dateCreated = value; }
        public string UserModified { get => _userModified; set => _userModified = value; }
        public DateTime? DateModified { get => _dateModified; set => _dateModified = value; }
    }
}
