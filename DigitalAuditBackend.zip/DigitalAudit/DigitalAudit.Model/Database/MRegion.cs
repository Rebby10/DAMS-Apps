﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("MRegion", Schema = "dbo")]
    public class MRegion
    {
        [Key]
        private string _regionId;
        private string _name;
        private bool _isDeleted;
        private string _userCreated;
        private DateTime _dateCreated;
        private string _userModified;
        private DateTime? _dateModified;

        public MRegion()
        {
        }

        public MRegion(string regionId, string name, bool isDeleted, string userCreated, DateTime dateCreated, string userModified, DateTime? dateModified)
        {
            RegionId = regionId;
            Name = name;
            IsDeleted = isDeleted;
            UserCreated = userCreated;
            DateCreated = dateCreated;
            UserModified = userModified;
            DateModified = dateModified;
        }

        [Key]
        public string RegionId { get => _regionId; set => _regionId = value; }

        [Required]
        [StringLength(100)]
        [Display(Name = "Nama Region")]
        public string Name { get => _name; set => _name = value; }
        public bool IsDeleted { get => _isDeleted; set => _isDeleted = value; }
        public string UserCreated { get => _userCreated; set => _userCreated = value; }
        public DateTime DateCreated { get => _dateCreated; set => _dateCreated = value; }
        public string UserModified { get => _userModified; set => _userModified = value; }
        public DateTime? DateModified { get => _dateModified; set => _dateModified = value; }
    }
}
