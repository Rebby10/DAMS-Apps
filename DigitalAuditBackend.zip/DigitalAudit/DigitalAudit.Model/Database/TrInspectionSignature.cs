﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DigitalAudit.Model.Database
{
    [Table("TrInspectionSignature", Schema = "dbo")]
    public class TrInspectionSignature
    {
        public TrInspectionSignature(string signatureId, string inspectionId, string title, string name, string signature, bool isDeleted, string userCreated, DateTime dateCreated, string userModified, DateTime? dateModified)
        {
            SignatureId = signatureId;
            InspectionId = inspectionId;
            Title = title;
            Name = name;
            Signature = signature;
            IsDeleted = isDeleted;
            UserCreated = userCreated;
            DateCreated = dateCreated;
            UserModified = userModified;
            DateModified = dateModified;
        }

        public TrInspectionSignature()
        {
        }

        [Key]
        public string SignatureId { get; set; }
        public string InspectionId { get; set; }
        public string Title { get; set; }
        public string Name { get; set; }
        public string Signature { get; set; }
        public bool IsDeleted { get; set; }
        public string UserCreated { get; set; }
        public DateTime DateCreated { get; set; }
        public string UserModified { get; set; }
        public DateTime? DateModified { get; set; }
    }
}
