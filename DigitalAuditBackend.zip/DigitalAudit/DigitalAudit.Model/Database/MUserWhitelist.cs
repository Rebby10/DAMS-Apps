﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("MUserWhitelist", Schema = "dbo")]
    public class MUserWhitelist
    {
        [Key]
        private string _userWhitelistId;
        private string _userId;
        private bool _isDeleted;
        private string _userCreated;
        private DateTime _dateCreated;
        private string _userModified;
        private DateTime? _dateModified;

        public MUserWhitelist()
        {
        }

        public MUserWhitelist(string userWhitelistId, string userId, bool isDeleted, string userCreated, DateTime dateCreated, string userModified, DateTime? dateModified)
        {
            UserWhitelistId = userWhitelistId;
            UserId = userId;
            IsDeleted = isDeleted;
            UserCreated = userCreated;
            DateCreated = dateCreated;
            UserModified = userModified;
            DateModified = dateModified;
        }

        [Key]
        public string UserWhitelistId { get => _userWhitelistId; set => _userWhitelistId = value; }
        public string UserId { get => _userId; set => _userId = value; }
        public bool IsDeleted { get => _isDeleted; set => _isDeleted = value; }
        public string UserCreated { get => _userCreated; set => _userCreated = value; }
        public DateTime DateCreated { get => _dateCreated; set => _dateCreated = value; }
        public string UserModified { get => _userModified; set => _userModified = value; }
        public DateTime? DateModified { get => _dateModified; set => _dateModified = value; }
    }
}
