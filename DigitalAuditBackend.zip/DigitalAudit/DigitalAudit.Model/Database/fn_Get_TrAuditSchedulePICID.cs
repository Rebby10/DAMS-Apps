﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("fn_Get_TrAuditSchedulePICID", Schema = "dbo")]
    public class fn_Get_TrAuditSchedulePICID
    {
        [Key]
        private string _picId;
        private string _scheduleId;
        private string _userId;
        private string _userGroupId;
        private string _userTypeId;
        private int _statusId;
        private string _teamType;

        public fn_Get_TrAuditSchedulePICID()
        {
        }

        public fn_Get_TrAuditSchedulePICID(string picId, string scheduleId, string userId, string userGroupId, string userTypeId, int statusId, string teamType)
        {
            PicId = picId;
            ScheduleId = scheduleId;
            UserId = userId;
            UserGroupId = userGroupId;
            UserTypeId = userTypeId;
            StatusId = statusId;
            TeamType = teamType;
        }

        [Key]
        public string PicId { get => _picId; set => _picId = value; }
        public string ScheduleId { get => _scheduleId; set => _scheduleId = value; }
        public string UserId { get => _userId; set => _userId = value; }
        public string UserGroupId { get => _userGroupId; set => _userGroupId = value; }
        public string UserTypeId { get => _userTypeId; set => _userTypeId = value; }
        public int StatusId { get => _statusId; set => _statusId = value; }
        public string TeamType { get => _teamType; set => _teamType = value; }
    }

}
