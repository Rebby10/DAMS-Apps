﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DigitalAudit.Model.Database
{
    [Table("fn_Get_MTemplatePermission", Schema = "dbo")]
    public class fn_Get_MTemplatePermission
    {
        [Key]
        private int _rowNum;
        private string _templateId;
        private int _id;
        private int _templatePermissionTypeId;
        private string _permissionType;
        private string _permissionEntityId;
        private string _code;
        private string _title;
        private string _descriptions;
        private int? _categoryId;
        private string _templateCategory;
        private bool _isShowIssue;
        private string _userId;
        private string _username;
        private string _officialName;



        public fn_Get_MTemplatePermission()
        {
        }

        public fn_Get_MTemplatePermission(int rowNum, string templateId, int id, int templatePermissionTypeId, string permissionType, string permissionEntityId, string code, string title, string descriptions, int? categoryId, string templateCategory, bool isShowIssue, string userId, string username, string officialName)
        {
            RowNum = rowNum;
            TemplateId = templateId;
            Id = id;
            TemplatePermissionTypeId = templatePermissionTypeId;
            PermissionType = permissionType;
            PermissionEntityId = permissionEntityId;
            Code = code;
            Title = title;
            Descriptions = descriptions;
            CategoryId = categoryId;
            TemplateCategory = templateCategory;
            IsShowIssue = isShowIssue;
            UserId = userId;
            Username = username;
            OfficialName = officialName;
        }

        [Key]
        public int RowNum { get => _rowNum; set => _rowNum = value; }
        public string TemplateId { get => _templateId; set => _templateId = value; }
        public int Id { get => _id; set => _id = value; }
        public int TemplatePermissionTypeId { get => _templatePermissionTypeId; set => _templatePermissionTypeId = value; }
        public string PermissionType { get => _permissionType; set => _permissionType = value; }
        public string PermissionEntityId { get => _permissionEntityId; set => _permissionEntityId = value; }
        public string Code { get => _code; set => _code = value; }
        public string Title { get => _title; set => _title = value; }
        public string Descriptions { get => _descriptions; set => _descriptions = value; }
        public int? CategoryId { get => _categoryId; set => _categoryId = value; }
        public string TemplateCategory { get => _templateCategory; set => _templateCategory = value; }
        public bool IsShowIssue { get => _isShowIssue; set => _isShowIssue = value; }
        public string UserId { get => _userId; set => _userId = value; }
        public string Username { get => _username; set => _username = value; }
        public string OfficialName { get => _officialName; set => _officialName = value; }
    }
}
