﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;


namespace DigitalAudit.Model.Database
{
    [Table("fn_Get_MUserRole", Schema = "dbo")]
    public class fn_Get_MUserRole
    {
        [Key]
        private string _userRoleId;
        private string _userId;
        private string _username;
        private string _email;
        private string _displayName;
        private string _roleId;
        private string _roleName;
        private string _otorisasiId;
        private string _otorisasi;

        public fn_Get_MUserRole(string userRoleId, string userId, string username, string email, string displayName, string roleId, string roleName, string otorisasiId, string otorisasi)
        {
            UserRoleId = userRoleId;
            UserId = userId;
            Username = username;
            Email = email;
            DisplayName = displayName;
            RoleId = roleId;
            RoleName = roleName;
            OtorisasiId = otorisasiId;
            Otorisasi = otorisasi;
        }

        public string UserRoleId { get => _userRoleId; set => _userRoleId = value; }
        public string UserId { get => _userId; set => _userId = value; }
        public string Username { get => _username; set => _username = value; }
        public string Email { get => _email; set => _email = value; }
        public string DisplayName { get => _displayName; set => _displayName = value; }
        public string RoleId { get => _roleId; set => _roleId = value; }
        public string RoleName { get => _roleName; set => _roleName = value; }
        public string OtorisasiId { get => _otorisasiId; set => _otorisasiId = value; }
        public string Otorisasi { get => _otorisasi; set => _otorisasi = value; }      

    }
}
