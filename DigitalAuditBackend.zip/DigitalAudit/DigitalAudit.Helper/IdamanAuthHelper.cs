﻿using DigitalAudit.Model.ViewModel;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;

namespace DigitalAudit.Helper
{
    public static class IdamanAuthHelper
    {
        public static HttpClient ClientIdamanBearear(AppSettingsViewModel appSettingsViewModel)
        {
            var client = new HttpClient
            {
                BaseAddress = new Uri(appSettingsViewModel.IdamanUrlApi)
            };

            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", GetTokenIdaman(client, appSettingsViewModel));

            return client;
        }

        public static string GetTokenIdaman(HttpClient client, AppSettingsViewModel appSettingsViewModel)
        {
            string token = string.Empty;

            if (client != null)
            {
                client = new HttpClient
                {
                    BaseAddress = new Uri(appSettingsViewModel.IdamanUrlLogin)
                };
                
                var multiContent = new MultipartFormDataContent
            {
                { new StringContent(appSettingsViewModel.IdamanClientId), "client_id" },
                { new StringContent(appSettingsViewModel.IdamanClientSecret), "client_secret" },
                { new StringContent(appSettingsViewModel.IdamanScopes), "scope" },
                { new StringContent("client_credentials"), "grant_type" }
            };

                var response = client.PostAsync("connect/token", multiContent).GetAwaiter().GetResult();
                var contents = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                var tokens = JsonConvert.DeserializeObject<IDictionary<string, object>>(contents);
                token = tokens["access_token"] as string;
                
            }

            return token;
        }
    }
}
