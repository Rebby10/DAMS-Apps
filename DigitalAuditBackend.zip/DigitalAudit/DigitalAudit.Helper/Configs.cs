﻿using DigitalAudit.Model.Util;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalAudit.Helper
{
    public class Configs
    {
        /// <summary>
        /// Environment Setting Ada Disini. Semua akan terpengaruh.
        /// </summary>


        /// <summary>
        /// General Configuration
        /// </summary>
        public static string ConnectionString = Constants.ConnectionString;
        public static string SecretKey = Constants.SecretKey;
        public static string SwaggerRoutePrefix = Constants.SwaggerRoutePrefix;
        public static string SwaggerEndPoint = Constants.SwaggerEndPoint;
        public static AppConfigModel AppConfig = Constants.AppConfig;
    }
}
