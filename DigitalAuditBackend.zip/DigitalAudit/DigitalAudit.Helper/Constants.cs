﻿using DigitalAudit.Model.Util;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace DigitalAudit.Helper
{
    public class Constants
    {
        //public static string ConnectionString = "Server=svr-auditdb.database.windows.net; Database=auditdb;User Id=admaudit; Password=ABC123abc123;";
        public static string ConnectionString = "Server=ptmcntsqlaiadev.database.windows.net; Database=auditdb;User Id=admaudit; Password=Lf3c947V6_?B;";

        public static string SecretKey = "zBMdmWVQaEZ.LwIke8jzF8w";
        public static string TokenPassword = "JTwVLQN38w3XjN3ZU8$%@";

        public static string SwaggerRoutePrefix = "";

        //public static string SwaggerEndPoint = "/swagger/v1/swagger.json"; //kalau ga pakai virtual app
        public static string SwaggerEndPoint = "./v1/swagger.json"; //kalau pakai virtual app

        public static AppConfigModel AppConfig = APPCONFIG();
        public static string DigitalAuditApplicationId = "c81a3fdb-6960-48f2-a0a0-623fa8c11437";

        //public static double TokenTimeoutMinutes = 360; //6 jam


        public static class CRUD
        {
            public static string CREATE = "C";
            public static string READ = "R";
            public static string UPDATE = "U";
            public static string DESTROY = "D";
        }

        public static class Encryption
        {
            public static string IV = "UdBLKY,wovu{CcQY4zTHueY";
            public static string KEY = "MQpgZ]tvq!N&l4ZxqzwMuFgDMN8wEcYYwTb";
        }

        public static string SentryKey = "https://5512a5c6d32045d6a659d5c00816cb41@o512462.ingest.sentry.io/5645360";

        public static string DEFAULT_USER = "systemapi";

        public static string GETID()
        {
            return Guid.NewGuid().ToString();
        }

        public static DateTime GETDATE()
        {
            return DateTime.Now;
        }

        public static class DEFAULT_REMARKS
        {
            public static string CREATE = "Data berhasil ditambahkan";
            public static string UPDATE = "Data berhasil diupdate";
            public static string DELETE = "Data berhasil dihapus";
            public static string READ = "Data berhasil ditampilkan";
            public static string DATA_NOT_FOUND = "Data tidak ditemukan";
            public static string ERROR_MESSAGE = "Pesan error";
        }

        public static class ROLE_GROUP
        {
            public static string ADMIN_PUSAT = "1";
            public static string AUDITEE = "2";
            public static string AUDITOR = "3";
        }

        public static class ROLE
        {
            public static string ADMIN_PUSAT = "1";
            public static string ADMIN_REGION = "2";
            public static string ADMIN_LOKASI = "3";
            public static string USER = "4";
        }

        public static class LOG_TYPE
        {
            public static string TEXT = "1";
            public static string STATUS = "2";
            public static string FILE = "3";
        }


        public static class USER_TYPE
        {
            public static string AUDITOR = "1";
            public static string AUDITEE = "2";
            public static string ADMIN_PUSAT = "3";
        }

        public static class SCHEDULE_STATUS 
        {
            public static int UNCONFIRMED = 1;
            public static int CONFIRMED = 2;
            public static int RESCHEDULE = 3;
        }

        public static class TEMPLATE_PERMISSION_TYPE
        {
            public static int ALL_USER = 1;
            public static int GROUP = 2;
            public static int USER = 3;
        }

        public static class ACTION_STATUS
        {
            public static int OPEN = 1;
            public static int ON_PROGRESS = 2;
            public static int CLOSE = 3;
        }

        public static class INSPECTION_STATUS
        {
            public static int SCHEDULED = 1;
            public static int ON_PROGRESS = 2;
            public static int PENDING_APPROVAL = 3;
            public static int COMPLETED = 4;
            public static int RESCHEDULE = 5;
        }

        public static class FILE_TYPE
        {
            public static int IMAGE = 1;
            public static int AUDIO = 2;
        }

        private static AppConfigModel APPCONFIG()
        {
            var jsonString = System.IO.File.ReadAllText("AppConfig.json");
            AppConfigModel items = JsonConvert.DeserializeObject<AppConfigModel>(jsonString);
            return items;
        }
    }
}
