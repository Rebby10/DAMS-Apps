package com.pertamina.digitalaudit.util

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import com.pertamina.digitalaudit.R
import org.apache.commons.io.FileUtils
import org.apache.commons.io.IOUtils
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream


class DownloadFile {
    companion object {
        fun viewFile(context: Context, file: File) {
            val uriFile = FileProvider
                .getUriForFile(context, context.getString(R.string.authority_file_provider), file)

            val intent = Intent(Intent.ACTION_VIEW)
            val fileName = file.name.orEmpty()
            if (fileName.contains(".doc") || fileName.contains(".docx")) { // Word document
                intent.setDataAndType(uriFile, "application/msword")
            } else if (fileName.contains(".pdf")) { // PDF filex
                intent.setDataAndType(uriFile, "application/pdf")
            } else if (fileName.contains(".xls") || fileName.contains(".xlsx")) { // Excel file
                intent.setDataAndType(uriFile, "application/vnd.ms-excel")
            } else if (fileName.contains(".wav") || fileName.contains(".mp3")) { // WAV audio file
                intent.setDataAndType(uriFile, "audio/x-wav")
            } else if (fileName.contains(".jpg") || fileName.contains(".jpeg") || fileName.contains(
                    ".png"
                )
            ) { // JPG file
                intent.setDataAndType(uriFile, "image/jpeg")
            } else if (fileName.contains(".3gp") || fileName.contains(".mpg") || fileName.contains(".mpeg") || fileName.contains(
                    ".mpe"
                ) || fileName.contains(".mp4") || fileName.contains(".avi")
            ) { // Video files
                intent.setDataAndType(uriFile, "video/*")
            } else {
                intent.setDataAndType(uriFile, "*/*")
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            context.startActivity(Intent.createChooser(intent, "Open File"))
        }

        fun showDialogInfoCLose(context: Context, message: String) {
            val builder: AlertDialog.Builder = AlertDialog.Builder(context)
            builder.setCancelable(false)
                .setMessage(message)
                .setPositiveButton(
                    R.string.close_label
                ) { dialog, _ -> dialog.dismiss() }
            val alert = builder.create()
            alert.show()
        }

        @JvmStatic
        fun copyFile(inputStream: InputStream?, destination: File?) {
            if (inputStream == null || destination == null) return

            var outputStream: FileOutputStream? = null

            try {
                outputStream = FileUtils.openOutputStream(destination)
                IOUtils.copy(inputStream, outputStream)
            } catch (e: Exception) {
                e.printStackTrace()
            }

            try {
                outputStream?.close()
            } catch (e: Exception) {
                e.printStackTrace()
            }

            try {
                inputStream.close()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}