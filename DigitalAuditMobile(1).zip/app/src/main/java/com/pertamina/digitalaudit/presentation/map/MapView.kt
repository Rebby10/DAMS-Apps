package com.pertamina.digitalaudit.presentation.map

import android.view.View
import com.pertamina.framework.base.BaseView

/**
 * Created by M Hafidh Abdul Aziz on 12/03/21.
 */

interface MapView : BaseView {
    fun onClickClearSearch(view: View)
}
