package com.pertamina.digitalaudit.model.body

import com.google.gson.annotations.SerializedName

data class SubmitInspectionInfoReqBody(
    @SerializedName("InspectionId")
    var inspectionId: String,
    @SerializedName("Title")
    var title: String,
    @SerializedName("Notes")
    var notes: String,
    @SerializedName("UserCreated")
    var userCreated: String
)