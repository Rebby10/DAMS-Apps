package com.pertamina.digitalaudit.presentation.sheet

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.presentation.startinspection.adapter.ImagePreviewByLinkAdapter
import kotlinx.android.synthetic.main.sheet_add_photo.*

class ImagesReportSheet : BottomSheetDialogFragment() {

    private var imagePreviewAdapter: ImagePreviewByLinkAdapter? = null
    private var imagesUri = mutableListOf<String>()
    private var bottomSheetBehavior: BottomSheetBehavior<*>? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.sheet_images_report, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
    }

    private fun setupRecyclerView() {
        val intent = arguments?.getStringArrayList("EXISTING_IMAGE")?.toMutableList()
        val isFromReport = arguments?.getBoolean("FROM_REPORT", false) ?: false
        intent?.let {
            imagesUri.addAll(it)
        }
        imagePreviewAdapter = ImagePreviewByLinkAdapter()
        imagePreviewAdapter?.setOnImageClickListener(object :
            ImagePreviewByLinkAdapter.ImageClickListener {
            override fun onClickImage(position: Int, image: String) {
                Glide.with(requireContext()).load(image)
                    .into(ivPreview)
            }
        })
        val horizontalManager =
            LinearLayoutManager(requireContext(), RecyclerView.HORIZONTAL, false)
        rvPhotos.apply {
            layoutManager = horizontalManager
            setHasFixedSize(true)
            adapter = imagePreviewAdapter
        }
        imagePreviewAdapter?.setData(imagesUri)
        if (imagesUri.isNotEmpty()) {
            Glide.with(requireContext()).load(imagesUri[0])
                .into(ivPreview)
        }
    }

    override fun onStart() {
        super.onStart()
        val dialog = dialog

        if (dialog != null) {
            val bottomSheet: View? = dialog.findViewById(R.id.container)
            bottomSheet?.layoutParams?.height = ViewGroup.LayoutParams.MATCH_PARENT
            view?.post {
                val parent = view?.parent as View
                val params = parent.layoutParams as CoordinatorLayout.LayoutParams
                val behavior = params.behavior
                bottomSheetBehavior = behavior as BottomSheetBehavior<*>?

                bottomSheet?.layoutParams?.height = ViewGroup.LayoutParams.MATCH_PARENT
                bottomSheetBehavior?.setPeekHeight(requireView().measuredHeight)
            }
        }
    }
}