package com.pertamina.digitalaudit.presentation.search.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.model.*
import com.pertamina.framework.base.BaseRecyclerViewAdapter
import com.pertamina.framework.base.BaseViewHolder
import kotlinx.android.synthetic.main.item_list_search.view.*

class ListSearchItemAdapter : BaseRecyclerViewAdapter<BaseItem>() {

    private var listener: SearchItemClickListener? = null

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BaseViewHolder<BaseItem> {
        val view = LayoutInflater.from(parent.context).inflate(viewType, parent, false)
        return ListViewHolder(parent.context, view, listener)
    }

    override fun onBindViewHolder(
        holder: BaseViewHolder<BaseItem>,
        position: Int
    ) {
        holder.bindData(getItem(position))
    }

    override fun getItemViewType(position: Int): Int {
        return R.layout.item_list_search
    }

    class ListViewHolder(context: Context, val view: View, listener: SearchItemClickListener?) :
        BaseViewHolder<BaseItem>(context, view) {

        private lateinit var data: BaseItem
        private var holderListener: SearchItemClickListener? = listener

        private var tvNameSearch = view.tvNameSearch

        override fun bindData(data: BaseItem) {
            when (data) {
                is LocationModel.Location -> {
                    tvNameSearch.text = data.name
                    itemView.setOnClickListener {
                        holderListener?.onClickLocation(
                            data.auditLocationId.orEmpty(),
                            data.name.orEmpty()
                        )
                    }
                }
                is TemplateModel.Template -> {
                    tvNameSearch.text = data.title
                    itemView.setOnClickListener {
                        holderListener?.onClickTemplate(
                            data.templateId.orEmpty(),
                            data.title.orEmpty()
                        )
                    }
                }
                is IssueModel.Issue -> {
                    tvNameSearch.text = data.title
                    itemView.setOnClickListener {
                        holderListener?.onClickIssue(data.issueId.orEmpty(), data.title.orEmpty())
                    }
                }
                is UserAssignModel.UserAssign -> {
                    tvNameSearch.text = data.displayName
                    itemView.setOnClickListener {
                        holderListener?.onClickUser(data)
                    }
                }
                is RegionModel.Region -> {
                    tvNameSearch.text = data.name
                    itemView.setOnClickListener {
                        holderListener?.onClickRegion(data.regionId.orEmpty(), data.name.orEmpty())
                    }
                }
            }
        }
    }

    fun setSearchItemClickListener(listener: SearchItemClickListener) {
        this.listener = listener
    }

    interface SearchItemClickListener {
        fun onClickIssue(issueId: String, issueTitle: String)
        fun onClickTemplate(templateId: String, templateTitle: String)
        fun onClickLocation(locationId: String, locationName: String)
        fun onClickRegion(regionId: String, regionName: String)
        fun onClickUser(user: UserAssignModel.UserAssign)
    }
}