package com.pertamina.digitalaudit.eventbus

class StartInspectionActivityEvent {
}
