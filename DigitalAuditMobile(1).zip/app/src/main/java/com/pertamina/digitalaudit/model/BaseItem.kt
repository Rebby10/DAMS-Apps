package com.pertamina.digitalaudit.model

open class BaseItem