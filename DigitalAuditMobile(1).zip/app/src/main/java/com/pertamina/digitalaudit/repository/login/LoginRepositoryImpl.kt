package com.pertamina.digitalaudit.repository.login

import android.util.Log
import com.pertamina.digitalaudit.model.TokenModel
import com.pertamina.digitalaudit.model.TokenRequestModel
import com.pertamina.digitalaudit.model.UserModel
import com.pertamina.digitalaudit.model.UserProfileModel
import com.pertamina.framework.ResponseHandler
import com.pertamina.framework.base.Resource

class LoginRepositoryImpl(
    private val service: LoginService,
    private val profileSSOService: UserProfileSSOService,
    private val responseHandler: ResponseHandler
) : LoginRepository {

    override suspend fun login(
        tokenUser: String,
        tokenPassword: String
    ): Resource<TokenModel.Token> {
        try {
            val request = service.login(TokenRequestModel(tokenUser, tokenPassword))
            request.data.let {
                return responseHandler.setSuccess(it!!)
            }
        } catch (e: Exception) {
            return responseHandler.setException(Exception(e))
        }
    }

    override suspend fun getUserData(email: String): Resource<UserModel.User> {
        try {
            val request = service.getUserData(email)
            request.data.let {
                return responseHandler.setSuccess(it!!)
            }
        } catch (e: Exception) {
            return responseHandler.setException(Exception(e))
        }
    }

    override suspend fun getUserDataFromSSO(): Resource<UserProfileModel> {
        try {
            val request = profileSSOService.getUserProfileDataFromSSO()
            request.let {
                return responseHandler.setSuccess(it)
            }
        } catch (e: Exception) {
            Log.d("getuserdata", "error:${e.localizedMessage}")
            return responseHandler.setException(Exception(e))
        }
    }

}
