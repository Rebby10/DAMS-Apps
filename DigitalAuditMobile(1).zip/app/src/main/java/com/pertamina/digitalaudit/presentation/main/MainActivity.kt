package com.pertamina.digitalaudit.presentation.main

import android.animation.ObjectAnimator
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.navigation.NavController
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.databinding.ActivityMainBinding
import com.pertamina.digitalaudit.eventbus.StartActionActivityEvent
import com.pertamina.digitalaudit.eventbus.StartInspectionActivityEvent
import com.pertamina.digitalaudit.eventbus.StartIssueActivityEvent
import com.pertamina.digitalaudit.eventbus.StartScheduleActivityEvent
import com.pertamina.framework.ViewDataBindingOwner
import com.pertamina.framework.base.BaseActivity
import com.pertamina.framework.extensions.setupWithNavController
import kotlinx.android.synthetic.main.activity_main.*
import org.greenrobot.eventbus.EventBus
import org.koin.androidx.viewmodel.ext.android.viewModel


class MainActivity : BaseActivity<MainViewModel>(),
    MainView, ViewDataBindingOwner<ActivityMainBinding> {

    override val layoutResourceId: Int = R.layout.activity_main
    override val viewModel: MainViewModel by viewModel()
    override var binding: ActivityMainBinding? = null

    private var currentNavController: LiveData<NavController>? = null
    private var isStateOpen: Boolean = false
    private var lastBackPressedTime: Long = 0

    companion object {
        private const val BACK_PRESSED_PERIOD: Long = 1000
        const val EXTRA_FROM_ADD_ACTION_BY_ISSUE = "EXTRA_FROM_ADD_ACTION_BY_ISSUE"
        const val EXTRA_FROM_COMPLETE_INSPECTION = "EXTRA_FROM_COMPLETE_INSPECTION"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (savedInstanceState == null) {
            setupBottomNavigationBar()
        }
        getExtraData()
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        setupBottomNavigationBar()
    }

    private fun setupBottomNavigationBar() {
        val navGraphIds = listOf(
            R.navigation.nav_graph_home,
            R.navigation.nav_graph_inspection,
            R.navigation.nav_graph_issues,
            R.navigation.nav_graph_action,
            R.navigation.nav_graph_account
        )

        val controller = bottomNav.setupWithNavController(
            navGraphIds = navGraphIds,
            fragmentManager = supportFragmentManager,
            containerId = R.id.navHostFragment,
            intent = intent
        )
        currentNavController = controller
    }

    private fun getExtraData() {
        val fromAddActionByIssue =
            intent?.getBooleanExtra(EXTRA_FROM_ADD_ACTION_BY_ISSUE, false) ?: false
        val fromCompleteInspection =
            intent?.getBooleanExtra(EXTRA_FROM_COMPLETE_INSPECTION, false) ?: false
        if (fromAddActionByIssue) setActiveTab(isAction = true)
        if (fromCompleteInspection) setActiveTab(isInspection = true)
    }

    private fun openFabMenu() {
        ObjectAnimator.ofFloat(fabAdd, "rotation", 0f, 45f).setDuration(300).start()
        groupFab.visibility = View.VISIBLE
        isStateOpen = !isStateOpen
    }

    fun closeFabMenu() {
        if (isStateOpen) {
            ObjectAnimator.ofFloat(fabAdd, "rotation", 45f, 0f).setDuration(300).start()
            groupFab.visibility = View.GONE
            isStateOpen = !isStateOpen
        }
    }

    fun manageFloatingButtonAdd(isShow: Boolean) {
        fabAdd.visibility = if (isShow) View.VISIBLE else View.GONE
    }

    override fun onClickAdd(view: View) {
        when (getSelectedItem(bottomNav)) {
            R.id.nav_graph_home -> {
                if (isStateOpen) {
                    closeFabMenu()
                } else {
                    openFabMenu()
                }
            }
            R.id.nav_graph_inspection -> onClickAddInspection(view)
            R.id.nav_graph_issues -> onClickAddIssue(view)
            R.id.nav_graph_action -> onClickAddAction(view)
        }
    }

    override fun onClickAddSchedule(view: View) {
        setActiveTab(isHome = true)
        EventBus.getDefault().postSticky(StartScheduleActivityEvent())
        closeFabMenu()
    }

    override fun onClickAddIssue(view: View) {
        setActiveTab(isIssue = true)
        EventBus.getDefault().postSticky(StartIssueActivityEvent())
        closeFabMenu()
    }

    override fun onClickAddInspection(view: View) {
        setActiveTab(isInspection = true)
        EventBus.getDefault().postSticky(StartInspectionActivityEvent())
        closeFabMenu()
    }

    override fun onClickAddAction(view: View) {
        setActiveTab(isAction = true)
        EventBus.getDefault().postSticky(StartActionActivityEvent())
        closeFabMenu()
    }

    private fun getSelectedItem(bottomNavigationView: BottomNavigationView): Int {
        val menu = bottomNavigationView.menu
        for (i in 0 until menu.size()) {
            val menuItem = menu.getItem(i)
            if (menuItem.isChecked) {
                return menuItem.itemId
            }
        }
        return 0
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        event?.let {
            if (it.keyCode == KeyEvent.KEYCODE_BACK && it.action == KeyEvent.ACTION_DOWN) {
                if (it.downTime - lastBackPressedTime < BACK_PRESSED_PERIOD) {
                    finishAffinity()
                } else {
                    Toast.makeText(
                        this,
                        getString(R.string.back_pressed_info),
                        Toast.LENGTH_SHORT
                    )
                        .show()
                    lastBackPressedTime = it.eventTime
                }
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    fun setActiveTab(
        isHome: Boolean = false,
        isInspection: Boolean = false,
        isIssue: Boolean = false,
        isAction: Boolean = false
    ) {
        when {
            isHome -> {
                bottomNav.selectedItemId = R.id.nav_graph_home
            }
            isInspection -> {
                bottomNav.selectedItemId = R.id.nav_graph_inspection
            }
            isIssue -> {
                bottomNav.selectedItemId = R.id.nav_graph_issues
            }
            isAction -> {
                bottomNav.selectedItemId = R.id.nav_graph_action
            }
        }
    }
}
