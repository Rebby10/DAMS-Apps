package com.pertamina.digitalaudit.presentation.startinspection.startpage.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.model.ActionModel
import com.pertamina.digitalaudit.presentation.issues.helper.IssuesStatusViewHelper
import com.pertamina.framework.base.BaseRecyclerViewAdapter
import com.pertamina.framework.base.BaseViewHolder
import com.pertamina.framework.util.DateHelper
import kotlinx.android.synthetic.main.item_report_failed_items_child.view.*

class InspectionIssueChildAdapter : BaseRecyclerViewAdapter<ActionModel.Action>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BaseViewHolder<ActionModel.Action> {
        val view = LayoutInflater.from(parent.context).inflate(viewType, parent, false)
        return ListViewHolder(parent.context, view)
    }

    override fun onBindViewHolder(
        holder: BaseViewHolder<ActionModel.Action>,
        position: Int
    ) {
        holder.bindData(getItem(position))
    }

    override fun getItemViewType(position: Int): Int {
        return R.layout.item_report_failed_items_child
    }

    class ListViewHolder(context: Context, val view: View) :
        BaseViewHolder<ActionModel.Action>(context, view) {

        private var tvTitleReportAction = view.tvTitleReportAction
        private var tvReportActionLocation = view.tvReportActionLocation
        private var tvReportedBy = view.tvReportedBy
        private var tvReportActionPriorityType = view.tvReportActionPriorityType
        private var tvReportActionStatus = view.tvReportActionStatus
        private var tvReportActionTargetClosing = view.tvReportActionTargetClosing

        @SuppressLint("SetTextI18n")
        override fun bindData(data: ActionModel.Action) {
            tvTitleReportAction.text = data.title
            tvReportActionLocation.text = data.auditLocation?.name
            tvReportedBy.text = "Reported by ${data.creator?.displayName}"
            tvReportActionTargetClosing.text = DateHelper.changeFormat(
                data.targetClosing.orEmpty(),
                DateHelper.yyyy_MM_dd_T_HHmmss,
                DateHelper.dd_MMMM_yyyy
            )

            tvReportActionPriorityType.apply {
                data.priority?.name?.let { priority ->
                    text = priority
                    setTextColor(
                        ContextCompat.getColor(context,
                            IssuesStatusViewHelper.getPriorityTextColor(priority)
                        ))
                }
            }

            tvReportActionStatus.apply {
                data.status?.let { status ->
                    text = status.name
                    setBackgroundResource(IssuesStatusViewHelper.getStatusBackgroundColor(status.name.orEmpty()))
                    setTextColor(
                        ContextCompat.getColor(
                            context,
                            IssuesStatusViewHelper.getStatusTextColor(status.name.orEmpty())
                        )
                    )
                }
            }
        }
    }
}