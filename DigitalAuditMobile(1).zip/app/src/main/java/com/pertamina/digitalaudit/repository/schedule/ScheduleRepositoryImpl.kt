package com.pertamina.digitalaudit.repository.schedule

import com.pertamina.digitalaudit.model.ScheduleDetailModel
import com.pertamina.digitalaudit.model.ScheduleModel
import com.pertamina.digitalaudit.model.UserAssignModel
import com.pertamina.digitalaudit.model.body.CreateScheduleReqBody
import com.pertamina.digitalaudit.model.body.RescheduleApprovalReqBody
import com.pertamina.digitalaudit.model.body.RescheduleReqBody
import com.pertamina.digitalaudit.model.body.UpdateScheduleReqBody
import com.pertamina.framework.ResponseHandler
import com.pertamina.framework.base.Resource

class ScheduleRepositoryImpl(
    private val service: ScheduleService,
    private val responseHandler: ResponseHandler
) : ScheduleRepository {

    override suspend fun getScheduleList(): Resource<List<ScheduleModel.Schedule>> {
        try {
            val request = service.getScheduleList()
            request.data.let {
                return responseHandler.setSuccess(it!!)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun createNewSchedule(reqBody: CreateScheduleReqBody): Resource<ScheduleModel.Schedule> {
        try {
            val request = service.createNewSchedule(reqBody)
            request.let {
                return responseHandler.setSuccess(it)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun getScheduleDetail(scheduleId: String): Resource<ScheduleDetailModel> {
        try {
            val request = service.getScheduleDetail(scheduleId)
            request.let {
                return responseHandler.setSuccess(it)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun deleteSchedule(scheduleId: String): Resource<ScheduleModel> {
        try {
            val request = service.deleteSchedule(scheduleId)
            request.let {
                return responseHandler.setSuccess(it)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun updateSchedule(reqBody: UpdateScheduleReqBody): Resource<ScheduleModel.Schedule> {
        try {
            val request = service.updateSchedule(reqBody)
            request.let {
                return responseHandler.setSuccess(it)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun getAuditeeByName(name: String?): Resource<List<UserAssignModel.UserAssign>> {
        try {
            val request = service.getAuditeeByName(name)
            request.data.let {
                return responseHandler.setSuccess(it!!)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun confirmReschedule(reqBody: RescheduleApprovalReqBody): Resource<ScheduleModel.Schedule> {
        try {
            val request = service.confirmReschedule(reqBody)
            request.let {
                return responseHandler.setSuccess(it)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun reschedule(reqBody: RescheduleReqBody): Resource<ScheduleModel.Schedule> {
        try {
            val request = service.reschedule(reqBody)
            request.let {
                return responseHandler.setSuccess(it)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }
}
