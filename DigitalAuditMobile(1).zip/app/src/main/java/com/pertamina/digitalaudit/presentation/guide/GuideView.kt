package com.pertamina.digitalaudit.presentation.guide

import com.pertamina.framework.base.BaseView

interface GuideView : BaseView
