package com.pertamina.digitalaudit.presentation.actiondetail

import androidx.lifecycle.MutableLiveData
import com.pertamina.digitalaudit.model.*
import com.pertamina.digitalaudit.model.body.UpdateActionStatusReqBody
import com.pertamina.digitalaudit.preference.PreferenceProvider
import com.pertamina.digitalaudit.repository.actions.ActionsRepository
import com.pertamina.framework.NonNullMutableLiveData
import com.pertamina.framework.base.BaseViewModel
import com.pertamina.framework.base.Resource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ActionDetailViewModel(
    private val actionsRepository: ActionsRepository,
    val preference: PreferenceProvider
) : BaseViewModel() {

    val showProgressBar = MutableLiveData(false)

    var bTextDetailActionInspectionTitle = MutableLiveData("")
    var bTextDetailActionInspectionDescription = MutableLiveData("")
    var bTextDetailActionRelatedIssueTitle = MutableLiveData("")

    var bTextDetailActionTitle = MutableLiveData("")
    var bTextDetailActionDescription = MutableLiveData("")
    var bTextDetailActionLocation = MutableLiveData("")
    var bTextDetailActionCreatedAt = MutableLiveData("")
    var bTextDetailActionCreatedBy = MutableLiveData("")
    var bTextDetailActionAssignTo = MutableLiveData("")
    var bTextDetailActionPriority = MutableLiveData("")
    var bTextDetailActionTargetClosing = MutableLiveData("")
    var bTextDetailActionStatus = MutableLiveData("")

    var detailActionStatusId = NonNullMutableLiveData(0)
    var prevDetailActionStatusId = NonNullMutableLiveData(0)
    var isDetailActionStateAuto = MutableLiveData(false)
    var isDetailActionStateSelfAssign = MutableLiveData(false)

    val actionDetailResponse = MutableLiveData<Resource<ActionDetailModel>>()
    val statusListResponse = MutableLiveData<Resource<List<IssueStatusModel.IssueStatus>>>()
    val updateActionResponse = MutableLiveData<Resource<ActionModel>>()

    var actionId: String = ""
    var user = UserModel.User()

    init {
        getUserData()
    }

    private fun getUserData() {
        launch {
            withContext(Dispatchers.IO) {
                user = preference.getAuthPreferences()
            }
        }
    }

    fun getActionDetail() {
        showProgressBar.value = true
        launch {
            val request = actionsRepository.getActionDetail(actionId)
            actionDetailResponse.value = request
            showProgressBar.value = false
        }
    }

    fun getStatusList() {
        showProgressBar.value = true
        launch {
            val request = actionsRepository.getIssueStatus()
            statusListResponse.value = request
            showProgressBar.value = false
        }
    }

    fun getSelectedStatusItemPosition(): Int {
        val prevSelectedStatus = detailActionStatusId.value
        prevSelectedStatus.let {
            statusListResponse.value?.data?.let { list ->
                val data = list.toMutableList()
                return list.indexOf(data.find { it.statusId == prevSelectedStatus })
            }
        }
        return 0
    }

    fun updateStatusAction() {
        showProgressBar.value = true
        launch {
            val request = actionsRepository.updateActionStatus(
                UpdateActionStatusReqBody(
                    actionId = actionId,
                    statusId = detailActionStatusId.value
                )
            )
            updateActionResponse.value = request
            showProgressBar.value = false
        }
    }

    fun setActionSelfAssign(assignUseId: String){
        isDetailActionStateSelfAssign.value = user.userId == assignUseId
    }
}
