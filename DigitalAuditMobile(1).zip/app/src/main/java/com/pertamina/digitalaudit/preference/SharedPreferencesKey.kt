package com.pertamina.digitalaudit.preference

/**
 * @author asadurrahman.qayyim
 * @date 03/02/2021
 */

enum class SharedPreferencesKey {
    USER_ID,
    USER_NAME,
    SUB,
    DISPLAY_NAME,
    USER_EMAIL,
    USER_PHOTO_URL,
    USER_JOB_TITLE,
    USER_COMPANY_NAME,
    USER_OFFICE_LOCATION,
    USER_DEPARTMENT,
    FIREBASE_TOKEN_ID,
    ACCESS_TOKEN,
    ID_TOKEN
}
