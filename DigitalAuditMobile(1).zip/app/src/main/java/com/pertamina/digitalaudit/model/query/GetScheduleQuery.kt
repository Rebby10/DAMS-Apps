package com.pertamina.digitalaudit.model.query

import com.google.gson.annotations.SerializedName
import java.io.Serializable

class GetScheduleQuery : Serializable {
    @SerializedName("id")
    var id: String? = null

    @SerializedName("template_id")
    var templateId: String? = null

    @SerializedName("title")
    var title: String? = null

    @SerializedName("status_id")
    var statusId: Int? = null

    @SerializedName("status")
    var status: Int? = null

    @SerializedName("audit_location_id")
    var auditLocationId: String? = null

    @SerializedName("location_name")
    var locationName: String? = null

    @SerializedName("region_id")
    var regionId: String? = null

    @SerializedName("region_name")
    var regionName: String? = null

    @SerializedName("user_id")
    var userId: String? = null

    @SerializedName("page_size")
    var pageSize: Int? = null

    @SerializedName("page_number")
    var pageNumber: Int? = null

    @SerializedName("sort_by")
    var sortBy: String? = null

    @SerializedName("order_by")
    var orderBy: String? = null
}
