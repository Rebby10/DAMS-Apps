package com.pertamina.digitalaudit.presentation.chat

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.databinding.ActivityChatBinding
import com.pertamina.digitalaudit.presentation.actiondetail.ActionDetailActivity
import com.pertamina.digitalaudit.presentation.chat.adapter.ChatAdapter
import com.pertamina.digitalaudit.presentation.chat.adapter.RecommendationAdapter
import com.pertamina.digitalaudit.presentation.guide.GuideActivity
import com.pertamina.digitalaudit.presentation.issuedetails.IssueDetailActivity
import com.pertamina.digitalaudit.presentation.sheet.SelectUploadSourceSheet
import com.pertamina.digitalaudit.util.*
import com.pertamina.digitalaudit.util.camera.CameraActivity
import com.pertamina.framework.NetworkState
import com.pertamina.framework.ViewDataBindingOwner
import com.pertamina.framework.base.BaseActivity
import com.pertamina.framework.util.FileUtils
import com.pertamina.framework.util.FileUtils.Companion.createDigitalAuditFolder
import com.pertamina.imageeditor.ImageEditorActivity
import kotlinx.android.synthetic.main.activity_chat.*
import kotlinx.android.synthetic.main.layout_empty_state.*
import kotlinx.android.synthetic.main.progressbar_dialog_layout.view.*
import kotlinx.android.synthetic.main.toolbar_layout.*
import okhttp3.ResponseBody
import org.koin.androidx.viewmodel.ext.android.viewModel
import pub.devrel.easypermissions.AfterPermissionGranted
import pub.devrel.easypermissions.EasyPermissions
import java.io.*
import java.util.*

/**
 * Created by M Hafidh Abdul Aziz on 20/03/21.
 */

class ChatActivity : BaseActivity<ChatViewModel>(), ChatView,
    ViewDataBindingOwner<ActivityChatBinding> {

    override val layoutResourceId: Int = R.layout.activity_chat
    override val viewModel: ChatViewModel by viewModel()
    override var binding: ActivityChatBinding? = null

    private var logChatAdapter: ChatAdapter? = null
    private var recommendationAdapter: RecommendationAdapter? = null
    private var fileUpload: File? = null
    private var mAlertDialog: AlertDialog? = null
    private var selectedDownloadFileName: String? = null

    private fun openImageEditorActivity(uri: Uri) {
        val intent = Intent(this, ImageEditorActivity::class.java)
        intent.putExtra("imageUri", uri.toString())
        imageEditorLauncher.launch(intent)
    }

    private var imageEditorLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val intent = result.data?.getStringExtra("imagePath")
                intent?.let {
                    viewModel.sendLogChatFile(File(it))
                }
            }
        }

    private var galleryLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                result.data?.let {
                    val imageUri: Uri? = it.data
                    imageUri?.let { uri ->
                        openImageEditorActivity(uri)
                    } ?: run { showErrorUploadFile() }
                } ?: run { showErrorUploadFile() }
            }
        }

    private var cameraLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                result.data?.let {
                    val uri = Uri.parse(it.getStringExtra(CameraActivity.EXTRA_CAPTURED_URI))
                    uri?.let { data ->
                        openImageEditorActivity(data)
                    } ?: run { showErrorUploadFile() }
                } ?: run { showErrorUploadFile() }
            }
        }

    private var fileManagerLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                result.data?.let { intent ->
                    val fileUri = intent.data
                    fileUri?.let {
                        fileUpload =
                            updateFileLocation(FileUtils.getDocumentFileNameByUri(this, fileUri))
                        copyUriStream(fileUri)
                        fileUpload?.let { file ->
                            viewModel.sendLogChatFile(file)
                        }
                    } ?: run {
                        showErrorUploadFile()
                    }
                } ?: run {
                    showErrorUploadFile()
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setupToolbar()
        setupRv()
        getExtraData()
        observeLogChat()
        observeSendLogChat()
        observeDownloadFile()
    }

    private fun setupToolbar() {
        val defaultTitle = when {
            intent?.getBooleanExtra(EXTRA_IS_FROM_ISSUE, false) == true -> {
                getString(R.string.issues_detail_issue)
            }
            intent?.getBooleanExtra(EXTRA_IS_FROM_ACTION, false) == true -> {
                getString(R.string.actions_detail_action)
            }
            else -> {
                ""
            }
        }
        tvTitleToolbar.text =
            intent?.getStringExtra(EXTRA_TITLE) ?: defaultTitle
        btnBackToolbar.apply {
            visibility = View.VISIBLE
            setImageResource(R.drawable.ic_close)
            setOnClickListener {
                onBackPressed()
            }
        }
    }

    private fun setupRv() {
        logChatAdapter = ChatAdapter()
        logChatAdapter?.setDownloadListener(object : ChatAdapter.DownloadListener {
            override fun onClickDownloadFile(fileName: String?, fileUrl: String?) {
                if (fileName != null && fileUrl != null) {
                    selectedDownloadFileName = fileName
                    checkPermissionBeforeDownload(fileUrl)
                } else {
                    Toast.makeText(
                        this@ChatActivity,
                        getString(R.string.file_not_found),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        })
        val manager = LinearLayoutManager(this)
        rvLogChat.apply {
            layoutManager = manager
            setHasFixedSize(true)
            adapter = logChatAdapter
        }
        recommendationAdapter = RecommendationAdapter()
        recommendationAdapter?.setRecommendationClickListener(object :
            RecommendationAdapter.RecommendationClickListener {
            override fun onClicRecommendation(recommendation: String) {
                viewModel.sendLogChat(recommendation)
            }
        })
        val horizontalManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
        rvRecommendation.apply {
            layoutManager = horizontalManager
            setHasFixedSize(true)
            adapter = recommendationAdapter
        }
        val recommendations = resources.getStringArray(R.array.recommendation_menu)
        recommendationAdapter?.setData(recommendations.toList())
    }

    private fun getExtraData() {
        viewModel.issueId = intent?.getStringExtra(EXTRA_ISSUE_ID).orEmpty()
        viewModel.actionId = intent?.getStringExtra(EXTRA_ACTION_ID).orEmpty()
        viewModel.fromIssue = intent?.getBooleanExtra(EXTRA_IS_FROM_ISSUE, false) ?: false
        viewModel.fromAction = intent?.getBooleanExtra(EXTRA_IS_FROM_ACTION, false) ?: false
        viewModel.showRecommendation.value = viewModel.fromAction
    }

    private fun getLogChat() {
        viewModel.getLogChat()
    }

    private fun observeLogChat() {
        observeData(viewModel.logListResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { data ->
                            viewModel.showEmptyState.value = false
                            logChatAdapter?.setData(data)
                            rvLogChat.smoothScrollToPosition(data.size - 1)
                        }
                    }
                    NetworkState.ERROR -> {
                        tvEmptyMessage.text = it.message
                        when (it.code) {
                            404 -> {
                                tvEmptyMessage.text = it.message
                                viewModel.showEmptyState.value = true
                                logChatAdapter?.removeAllData()
                            }
                            else -> {
                                SnackBar.snackBarShowError(
                                    this,
                                    parentLayout,
                                    it.message ?: getString(R.string.general_server_error_message)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    private fun observeSendLogChat() {
        observeData(viewModel.sendLogChatResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        viewModel.bTextChat.value = ""
                        getLogChat()
                    }
                    NetworkState.ERROR -> {
                        viewModel.bTextChat.value = ""
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message ?: getString(R.string.general_server_error_message)
                        )
                    }
                }
            }
        }
    }

    private fun observeDownloadFile() {
        observeData(viewModel.downloadFileResponse) { result ->
            result?.let {
                hideDownloadDialog()
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { body ->
                            showMessageDialogDownloadComplete(body)
                        } ?: run {
                            Toast.makeText(
                                this@ChatActivity,
                                getString(R.string.file_not_found),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message ?: getString(R.string.general_server_error_message)
                        )
                    }
                }
            }
        }
    }

    override fun onClickAddAttachment(view: View) {
        requestPermissionWriteExternalStorage()
    }

    override fun onClickSendChat(view: View) {
        viewModel.sendLogChat(viewModel.bTextChat.value)
    }

    override fun onClickGuide(view: View) {
        GuideActivity.startThisActivity(this)
    }

    override fun onClickDetail(view: View) {
        if (viewModel.fromIssue) {
            IssueDetailActivity.startThisActivity(
                this,
                viewModel.issueId, intent?.getBooleanExtra(EXTRA_IS_ASSIGN_TO_ME, false) ?: false
            )
        } else if (viewModel.fromAction) {
            ActionDetailActivity.startThisActivity(
                this,
                viewModel.actionId
            )
        }
    }

    @AfterPermissionGranted(CommonConstant.RC_WRITE_EXTERNAL_STORAGE_PERM)
    private fun requestPermissionWriteExternalStorage() {
        val perms = arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (EasyPermissions.hasPermissions(this, *perms)) {
            showFilePickerDialog()
        } else {
            EasyPermissions.requestPermissions(
                this,
                getString(R.string.permission_to_access_file),
                CommonConstant.RC_WRITE_EXTERNAL_STORAGE_PERM,
                *perms
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this)
    }

    private fun showFilePickerDialog() {
        val dialog = SelectUploadSourceSheet()
        dialog.listener = object :
            SelectUploadSourceSheet.SelectUploadSourceBottomSheetFragmentListener {
            override fun onSelectCamera() {
                goToCamera()
            }

            override fun onSelectGallery() {
                goToGallery()
            }

            override fun onSelectFile() {
                goToFileManager()
            }
        }
        dialog.show(supportFragmentManager, "select_upload_source")
    }

    private fun goToCamera() {
        val intent = Intent(this, CameraActivity::class.java)
        cameraLauncher.launch(intent)
    }

    private fun goToGallery() {
        val photoPickerIntent = Intent(Intent.ACTION_GET_CONTENT)
        photoPickerIntent.type = "image/*"
        galleryLauncher.launch(photoPickerIntent)
    }

    private fun goToFileManager() {
        var chooseFile = Intent(Intent.ACTION_OPEN_DOCUMENT)
        chooseFile.addCategory(Intent.CATEGORY_OPENABLE)
        chooseFile.type = "*/*"
        val mimeTypes = arrayOf(
            "application/pdf",
            "application/msword",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "application/vnd.ms-excel",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        )
        chooseFile.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes)
        chooseFile = Intent.createChooser(chooseFile, "Choose a file")

        fileManagerLauncher.launch(chooseFile)
        fileUpload = createDigitalAuditFolder(this)
    }

    private fun updateFileLocation(fileName: String): File {
        val folder: File? = getExternalFilesDir("/DigitalAuditFilesTemp/")
        return File(folder?.absolutePath, fileName)
    }

    private fun copyUriStream(uri: Uri) {
        try {
            val inputStream = contentResolver.openInputStream(uri)
            fileUpload?.let {
                val fileOutputStream = FileOutputStream(it)
                if (inputStream != null) {
                    FileUtils.copyStream(inputStream, fileOutputStream)
                    fileOutputStream.close()
                    inputStream.close()
                }
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun showErrorUploadFile() {
        Toast.makeText(
            this,
            getString(R.string.error_upload_file),
            Toast.LENGTH_SHORT
        ).show()
    }

    fun checkPermissionBeforeDownload(fileUrl: String) {
        if (CommonFunction.isConnectingToInternet(this)) {
            val writeExternalStorage =
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            val readExternalStorage =
                Manifest.permission.READ_EXTERNAL_STORAGE
            val hasWritePermission: Int =
                ContextCompat.checkSelfPermission(this, writeExternalStorage)
            val hasReadPermission: Int =
                ContextCompat.checkSelfPermission(this, readExternalStorage)
            val permissions: MutableList<String> =
                ArrayList()
            if (hasReadPermission != PackageManager.PERMISSION_GRANTED &&
                hasWritePermission != PackageManager.PERMISSION_GRANTED
            ) {
                permissions.add(writeExternalStorage)
                permissions.add(readExternalStorage)
            }
            when {
                permissions.isNotEmpty() -> {
                    val params =
                        permissions.toTypedArray()
                    requestPermissions(params, 100)
                }
                File(
                    getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),
                    selectedDownloadFileName.orEmpty()
                ).exists() -> {
                    DownloadFile.viewFile(
                        this,
                        File(
                            getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),
                            selectedDownloadFileName.orEmpty()
                        )
                    )
                }
                else -> {
                    startDownloadFile(fileUrl)
                }
            }
        } else {
            DownloadFile.showDialogInfoCLose(
                this,
                getString(R.string.error_download_file)
            )
        }
    }

    private fun startDownloadFile(fileUrl: String) {
        getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)?.let {
            val fileDownload = File(it, selectedDownloadFileName.orEmpty())
            if (!fileDownload.exists() && fileDownload.length() <= 0) {
                showStartDownloadDialog()
            }
            viewModel.startDownloadFile(fileUrl)
        }
    }

    private fun showMessageDialogDownloadComplete(body: ResponseBody?) {
        try {
            val fileDownload = File(
                getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),
                selectedDownloadFileName.orEmpty()
            )
            DownloadFile.copyFile(body?.byteStream(), fileDownload)
            val alertDialog = AlertDialog.Builder(this)
                .setMessage(getString(R.string.download_complete))
                .setPositiveButton(getString(R.string.view_label)) { dialog, _ ->
                    dialog.dismiss()
                    DownloadFile.viewFile(this, fileDownload)
                }
                .setNegativeButton(getString(R.string.close_label)) { dialog, _ ->
                    dialog.dismiss()
                }
            alertDialog.show()
        } catch (e: IOException) {
            Log.d("TAG", "file not download:")
        }
    }

    private fun showStartDownloadDialog() {
        val mDialogView =
            LayoutInflater.from(this).inflate(R.layout.progressbar_dialog_layout, null)
        mDialogView.tvMessage.text = getString(R.string.downloading_file_label)
        val mBuilder = AlertDialog.Builder(this)
            .setView(mDialogView)
        mAlertDialog = mBuilder.show()
    }

    private fun hideDownloadDialog() {
        if (mAlertDialog != null) {
            mAlertDialog?.dismiss()
        }
    }

    override fun onResume() {
        super.onResume()
        getLogChat()
    }

    companion object {
        private const val EXTRA_ISSUE_ID = "EXTRA_ISSUE_ID"
        private const val EXTRA_TITLE = "EXTRA_TITLE"
        private const val EXTRA_IS_ASSIGN_TO_ME = "EXTRA_IS_ASSIGN_TO_ME"
        private const val EXTRA_IS_FROM_ISSUE = "EXTRA_IS_FROM_ISSUE"

        private const val EXTRA_ACTION_ID = "EXTRA_ACTION_ID"
        private const val EXTRA_IS_FROM_ACTION = "EXTRA_IS_FROM_ACTION"

        fun startThisActivityFromIssue(
            context: Context,
            issueId: String,
            issueTitle: String,
            isAssignToMe: Boolean
        ) {
            val intent = Intent(context, ChatActivity::class.java)
            intent.putExtra(EXTRA_ISSUE_ID, issueId)
            intent.putExtra(EXTRA_TITLE, issueTitle)
            intent.putExtra(EXTRA_IS_ASSIGN_TO_ME, isAssignToMe)
            intent.putExtra(EXTRA_IS_FROM_ISSUE, true)
            context.startActivity(intent)
        }

        fun startThisActivityFromAction(
            context: Context,
            actionId: String,
            actionTitle: String
        ) {
            val intent = Intent(context, ChatActivity::class.java)
            intent.putExtra(EXTRA_ACTION_ID, actionId)
            intent.putExtra(EXTRA_TITLE, actionTitle)
            intent.putExtra(EXTRA_IS_FROM_ACTION, true)
            context.startActivity(intent)
        }
    }
}
