package com.pertamina.digitalaudit.presentation.startinspection.additionalinfo.adapter

import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.bumptech.glide.Glide
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.model.body.SubmitInspectionSignatureReqBody
import com.pertamina.framework.base.BaseRecyclerViewAdapter
import com.pertamina.framework.base.BaseViewHolder
import kotlinx.android.synthetic.main.item_inspection_additional_info_signature.view.*

class AdditionalInfoSignatureAdapter : BaseRecyclerViewAdapter<SubmitInspectionSignatureReqBody>() {

    private var listener: ItemListener? = null

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BaseViewHolder<SubmitInspectionSignatureReqBody> {
        val view = LayoutInflater.from(parent.context).inflate(viewType, parent, false)
        return ListViewHolder(parent.context, view, listener)
    }

    override fun onBindViewHolder(
        holder: BaseViewHolder<SubmitInspectionSignatureReqBody>,
        position: Int
    ) {
        holder.bindData(getItem(position))
    }

    override fun getItemViewType(position: Int): Int {
        return R.layout.item_inspection_additional_info_signature
    }

    class ListViewHolder(context: Context, val view: View, listener: ItemListener?) :
        BaseViewHolder<SubmitInspectionSignatureReqBody>(context, view) {

        private var holderListener: ItemListener? = listener
        private var etTitleSignature = view.etTitleSignature
        private var clActionDelete = view.clActionDelete
        private var etSignature = view.etSignature
        private var ivAddAndEditSignature = view.ivAddAndEditSignature
        private var ivSignature = view.ivSignature

        override fun bindData(data: SubmitInspectionSignatureReqBody) {
            etTitleSignature.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    holderListener?.onTitleSignatureChange(
                        adapterPosition,
                        s.toString()
                    )
                }

                override fun beforeTextChanged(
                    s: CharSequence?,
                    start: Int,
                    count: Int,
                    after: Int
                ) {
                }

                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                }
            })
            clActionDelete.setOnClickListener {
                holderListener?.onDeleteItem(adapterPosition)
            }
            etSignature.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    holderListener?.onNameSignatureChange(
                        adapterPosition,
                        s.toString()
                    )
                }

                override fun beforeTextChanged(
                    s: CharSequence?,
                    start: Int,
                    count: Int,
                    after: Int
                ) {
                }

                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                }
            })
            ivAddAndEditSignature.setOnClickListener {
                //todo scratch signature
            }
            if (data.signature.isNotEmpty()) {
                ivSignature.visibility = View.VISIBLE
                Glide.with(context).load(data.signature)
                    .into(ivSignature)
            }
        }
    }

    fun setItemListener(listener: ItemListener) {
        this.listener = listener
    }

    interface ItemListener {
        fun onDeleteItem(position: Int)
        fun onTitleSignatureChange(position: Int, titleNote: String)
        fun onNameSignatureChange(position: Int, note: String)
    }
}