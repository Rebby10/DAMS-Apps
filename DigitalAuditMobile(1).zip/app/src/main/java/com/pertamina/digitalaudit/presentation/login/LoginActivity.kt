package com.pertamina.digitalaudit.presentation.login

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.pertamina.digitalaudit.BuildConfig
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.databinding.ActivityLoginBinding
import com.pertamina.digitalaudit.preference.SharedPreferencesKey
import com.pertamina.digitalaudit.presentation.login.authmanager.AuthStateManager
import com.pertamina.digitalaudit.presentation.main.MainActivity
import com.pertamina.digitalaudit.util.SnackBar
import com.pertamina.digitalaudit.util.ViewUtils
import com.pertamina.framework.NetworkState
import com.pertamina.framework.ViewDataBindingOwner
import com.pertamina.framework.base.BaseActivity
import kotlinx.android.synthetic.main.activity_login.*
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import net.openid.appauth.AuthorizationException
import net.openid.appauth.AuthorizationRequest
import net.openid.appauth.AuthorizationResponse
import net.openid.appauth.AuthorizationService
import net.openid.appauth.AuthorizationServiceConfiguration
import net.openid.appauth.ResponseTypeValues
import org.koin.androidx.viewmodel.ext.android.viewModel

/**
 * Created by M Hafidh Abdul Aziz on 21/03/21.
 */

class LoginActivity : BaseActivity<LoginViewModel>(), LoginView,
    ViewDataBindingOwner<ActivityLoginBinding> {

    companion object {
        private const val RC_AUTH = 100
    }

    override val layoutResourceId: Int = R.layout.activity_login
    override val viewModel: LoginViewModel by viewModel()
    override var binding: ActivityLoginBinding? = null

    private var mAuthService: AuthorizationService? = null
    private var mStateManager: AuthStateManager? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupAuthManager()
        observeUserData()
        observeUserProfileFromSSO()
        viewModel.showProgressBar.value = true
        GlobalScope.launch {
            delay(1000)
            checkUserLogin(null)
            viewModel.showProgressBar.postValue(false)
        }
    }

    private fun setupAuthManager() {
        mStateManager = AuthStateManager.getInstance(this)
        mAuthService = AuthorizationService(this)
    }

    private fun observeUserData() {
        observeData(viewModel.userDataResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> goToMainActivity()
                    else -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message ?: getString(R.string.general_server_error_message)
                        )
                    }
                }
            }
        }
    }

    private fun observeUserProfileFromSSO() {
        observeData(viewModel.userProfileDataResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> viewModel.getUserData()
                    else -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message ?: getString(R.string.general_server_error_message)
                        )
                    }
                }
            }
        }
    }

    private fun goToMainActivity() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish()
    }

    override fun onClickLogin(view: View) {
        ViewUtils.hideKeyboard(this, view)
        checkUserLogin(view)
    }

    private fun checkUserLogin(view: View?) {
        val issuer = BuildConfig.IDAMAN_ISSUER
        val clientId = BuildConfig.IDAMAN_CLIENT_ID
        val redirectUri = Uri.parse(BuildConfig.IDAMAN_REDIRECT_URI)
        if (mStateManager?.current?.isAuthorized!!) {
            goToMainActivity()
        } else if (view != null) {
            val serviceConfig = AuthorizationServiceConfiguration(
                Uri.parse("${issuer}connect/authorize"), // authorization endpoint
                Uri.parse("${issuer}connect/token") // token endpoint
            )
            val builder = AuthorizationRequest.Builder(
                serviceConfig,
                clientId,
                ResponseTypeValues.CODE,
                redirectUri
            )
            builder.setScopes("openid", "profile", "email")

            val authRequest = builder.build()

            val authService = AuthorizationService(this)
            val authIntent = authService.getAuthorizationRequestIntent(authRequest)
            startActivityForResult(authIntent, RC_AUTH)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == RC_AUTH) {
            val resp = AuthorizationResponse.fromIntent(data!!)
            val ex = AuthorizationException.fromIntent(data)

            if (resp != null) {
                mAuthService = AuthorizationService(this)
                mStateManager?.updateAfterAuthorization(resp, ex)

                mAuthService?.performTokenRequest(
                    resp.createTokenExchangeRequest()
                ) { response, exception ->
                    if (response != null) {
                        mStateManager?.updateAfterTokenResponse(response, exception)
                        response.accessToken?.let {
                            viewModel.preference.setStringToPreference(
                                SharedPreferencesKey.ACCESS_TOKEN,
                                it
                            )
                        }
                        viewModel.preference.setStringToPreference(
                            SharedPreferencesKey.ID_TOKEN,
                            response.idToken.toString()
                        )
                        viewModel.getUserDataFromSSO()
                    } else {
                        Toast.makeText(this, "authorization failed", Toast.LENGTH_LONG).show()
                    }
                }
            } else {
                Toast.makeText(this, "authorization failed", Toast.LENGTH_LONG).show()
            }
        }
    }
}
