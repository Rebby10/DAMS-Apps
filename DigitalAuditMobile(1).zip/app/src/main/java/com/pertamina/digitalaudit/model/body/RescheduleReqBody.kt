package com.pertamina.digitalaudit.model.body

import com.google.gson.annotations.SerializedName

class RescheduleReqBody(
    @SerializedName("ScheduleId")
    var scheduleId: String,
    @SerializedName("UserId")
    var userId: String,
    @SerializedName("StartDate")
    var startDate: String,
    @SerializedName("EndDate")
    var endDate: String,
    @SerializedName("Descriptions")
    var descriptions: String
)