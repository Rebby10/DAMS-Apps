package com.pertamina.digitalaudit.presentation.actionofissue

import com.pertamina.framework.base.BaseView

interface ActionOfIssueView : BaseView {
}