package com.pertamina.digitalaudit.presentation.home.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.model.ScheduleModel
import com.pertamina.digitalaudit.presentation.issues.helper.IssuesStatusViewHelper
import com.pertamina.framework.base.BaseRecyclerViewAdapter
import com.pertamina.framework.base.BaseViewHolder
import com.pertamina.framework.util.DateHelper
import kotlinx.android.synthetic.main.item_home_schedule.view.*

/**
 * Created by M Hafidh Abdul Aziz on 08/03/21.
 */

class ScheduleAdapter : BaseRecyclerViewAdapter<ScheduleModel.Schedule>() {

    private var listener: ScheduleClickListener? = null

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BaseViewHolder<ScheduleModel.Schedule> {
        val view = LayoutInflater.from(parent.context).inflate(viewType, parent, false)
        return ListViewHolder(parent.context, view, listener)
    }

    override fun onBindViewHolder(holder: BaseViewHolder<ScheduleModel.Schedule>, position: Int) {
        holder.bindData(getItem(position))
    }

    override fun getItemViewType(position: Int): Int {
        return R.layout.item_home_schedule
    }

    class ListViewHolder(context: Context, val view: View, listener: ScheduleClickListener?) :
        BaseViewHolder<ScheduleModel.Schedule>(context, view) {

        private lateinit var data: ScheduleModel.Schedule
        private var holderListener: ScheduleClickListener? = listener

        private var tvTitleSchedule = view.tvTitleSchedule
        private var tvScheduleAuditLocation = view.tvScheduleAuditLocation
        private var tvLocationAndAuditorNameSchedule = view.tvLocationAndAuditorNameSchedule
        private var tvStatusSchedule = view.tvStatusSchedule
        private var tvScheduleRangeTime = view.tvScheduleRangeTime

        @SuppressLint("SetTextI18n")
        override fun bindData(data: ScheduleModel.Schedule) {
            this.data = data
            tvTitleSchedule.text = data.template?.title
            tvScheduleAuditLocation.text = data.auditLocation?.name
            tvLocationAndAuditorNameSchedule.text = data.auditor?.users?.name
            tvStatusSchedule.apply {
                data.status?.let { status ->
                    text = status.name
                    setBackgroundResource(IssuesStatusViewHelper.getStatusBackgroundColor(status.name.orEmpty()))
                    setTextColor(
                        ContextCompat.getColor(
                            context,
                            IssuesStatusViewHelper.getStatusTextColor(status.name.orEmpty())
                        )
                    )
                }
            }
            var startDate = ""
            var endDate = ""
            data.startDate?.let {
                startDate = DateHelper.changeFormat(
                    it,
                    DateHelper.yyyy_MM_dd_T_HHmmss,
                    DateHelper.dd_MMM
                )
            }
            data.endDate?.let {
                endDate = DateHelper.changeFormat(
                    data.endDate.orEmpty(),
                    DateHelper.yyyy_MM_dd_T_HHmmss,
                    DateHelper.dd_MMM_yyyy
                )
            }
            tvScheduleRangeTime.text = "$startDate - $endDate"
            itemView.setOnClickListener {
                holderListener?.onClickSchedule(
                    data.scheduleId.orEmpty(),
                    data.status?.name.orEmpty()
                )
            }
        }
    }

    fun setScheduleClickListener(listener: ScheduleClickListener) {
        this.listener = listener
    }

    interface ScheduleClickListener {
        fun onClickSchedule(scheduleId: String, scheduleStatus: String)
    }
}
