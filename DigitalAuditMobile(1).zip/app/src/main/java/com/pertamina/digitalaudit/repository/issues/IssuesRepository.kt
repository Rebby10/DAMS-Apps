package com.pertamina.digitalaudit.repository.issues

import com.pertamina.digitalaudit.model.*
import com.pertamina.digitalaudit.model.body.CreateIssueReqBody
import com.pertamina.digitalaudit.model.body.IssueLogReqBody
import com.pertamina.digitalaudit.model.body.SortAndFilterReqBody
import com.pertamina.digitalaudit.model.body.UpdateIssueReqBody
import com.pertamina.framework.base.BaseResponse
import com.pertamina.framework.base.Resource
import okhttp3.ResponseBody
import java.io.File

interface IssuesRepository {

    @Throws(Exception::class)
    suspend fun createNewIssue(reqBody: CreateIssueReqBody): Resource<IssueModel>

    @Throws(Exception::class)
    suspend fun getIssueDetail(issueId: String): Resource<IssueDetailModel>

    @Throws(Exception::class)
    suspend fun applyFilter(reqBody: SortAndFilterReqBody): Resource<List<IssueModel.Issue>>

    @Throws(Exception::class)
    suspend fun getIssueCategory(): Resource<List<IssueCategoryModel.IssueCategory>>

    @Throws(Exception::class)
    suspend fun getIssueStatus(): Resource<List<IssueStatusModel.IssueStatus>>

    @Throws(Exception::class)
    suspend fun deleteIssue(issueId: String): Resource<IssueModel>

    @Throws(Exception::class)
    suspend fun updateIssue(reqBody: UpdateIssueReqBody): Resource<IssueModel>

    @Throws(Exception::class)
    suspend fun getIssueLog(issueId: String): Resource<List<LogModel.Log>>

    @Throws(Exception::class)
    suspend fun sendLogChat(logReqBody: IssueLogReqBody): Resource<BaseResponse>

    @Throws(Exception::class)
    suspend fun getAuditeeByName(name: String?, pageSize: Int?, pageNumber: Int?): Resource<List<UserAssignModel.UserAssign>>

    @Throws(Exception::class)
    suspend fun sendLogChatFile(
        issueId: String,
        userCreated: String,
        file: File
    ): Resource<BaseResponse>

    @Throws(Exception::class)
    suspend fun downloadFile(fileUrl: String): Resource<ResponseBody>
}
