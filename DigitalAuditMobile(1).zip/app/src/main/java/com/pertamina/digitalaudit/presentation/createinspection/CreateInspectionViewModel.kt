package com.pertamina.digitalaudit.presentation.createinspection

import androidx.lifecycle.MutableLiveData
import com.pertamina.digitalaudit.model.AssignGroupModel
import com.pertamina.digitalaudit.model.InspectionModel
import com.pertamina.digitalaudit.model.UserModel
import com.pertamina.digitalaudit.model.body.CreateInspectionReqBody
import com.pertamina.digitalaudit.preference.PreferenceProvider
import com.pertamina.digitalaudit.repository.inspection.InspectionRepository
import com.pertamina.framework.base.BaseViewModel
import com.pertamina.framework.base.Resource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class CreateInspectionViewModel(
    private val inspectionRepository: InspectionRepository,
    val preference: PreferenceProvider
) : BaseViewModel() {

    val showProgressBar = MutableLiveData(false)

    var bTextCreateInspectionLocation = MutableLiveData("")
    var bTextCreateInspectionAuditTypeTemplate = MutableLiveData("")
    var bTextCreateInspectionAssignAuditeeName = MutableLiveData("")
    var bTextCreateInspectionAssignAuditorName = MutableLiveData("")

    var createInspectionAuditTypeTemplateId = MutableLiveData<String?>(null)
    var createInspectionLocationId = MutableLiveData<String?>(null)
    var createInspectionAssignAuditeeUserId = MutableLiveData<String?>(null)
    var createInspectionAssignAuditeeGroupId = MutableLiveData<String?>(null)
    var createInspectionAssignAuditorUserId = MutableLiveData<String?>(null)
    var createInspectionAssignAuditorGroupId = MutableLiveData<String?>(null)

    val createInspectionResponse = MutableLiveData<Resource<InspectionModel.Inspection>>()
    var user = UserModel.User()

    init {
        getUserData()
    }

    private fun getUserData() {
        launch {
            withContext(Dispatchers.IO) {
                user = preference.getAuthPreferences()
            }
        }
    }

    fun createNewInspection() {
        showProgressBar.value = true
        launch {
            val request = inspectionRepository.createNewInspection(
                CreateInspectionReqBody(
                    createInspectionLocationId.value,
                    createInspectionAuditTypeTemplateId.value,
                    user.userId,
                    AssignGroupModel.AssignGroup().apply {
                        userGroupId = createInspectionAssignAuditorGroupId.value
                        userId = createInspectionAssignAuditorUserId.value
                    },
                    AssignGroupModel.AssignGroup().apply {
                        userGroupId = createInspectionAssignAuditeeGroupId.value
                        userId = createInspectionAssignAuditeeUserId.value
                    })
            )
            createInspectionResponse.value = request
            showProgressBar.value = false
        }
    }
}
