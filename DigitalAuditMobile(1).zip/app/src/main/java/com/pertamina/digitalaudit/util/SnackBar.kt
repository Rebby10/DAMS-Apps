package com.pertamina.digitalaudit.util

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.google.android.material.snackbar.Snackbar
import com.pertamina.digitalaudit.R

/**
 * Created by M Hafidh Abdul Aziz on 02/04/21.
 */

object SnackBar {

    @JvmStatic
    private fun customSnackBar(
        context: Context,
        view: View,
        message: String,
        bgColor: Int
    ): Snackbar {
        val snackBar = Snackbar.make(view, "", Snackbar.LENGTH_LONG)
        val layout = snackBar.view as Snackbar.SnackbarLayout
        val mInflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val snackView = mInflater.inflate(R.layout.snackbar_layout, null)
        val tvSnackBar = snackView.findViewById<TextView>(R.id.tvMessageSnackBar)
        val linearLayout = snackView.findViewById<LinearLayout>(R.id.llSnackBar)
        linearLayout.setBackgroundColor(ContextCompat.getColor(context, bgColor))
        tvSnackBar.text = message
        layout.addView(snackView, 0)
        layout.setPadding(0,0,0,0)

        return snackBar.apply { show() }
    }

    @JvmStatic
    fun snackBarShowError(context: Context, view: View, message: String): Snackbar {
        val color: Int = R.color.scarlet
        return customSnackBar(context, view, message, color)
    }

    @JvmStatic
    fun snackBarShowSuccess(context: Context, view: View, message: String): Snackbar {
        val color: Int = R.color.jungle_green
        return customSnackBar(context, view, message, color)
    }
}
