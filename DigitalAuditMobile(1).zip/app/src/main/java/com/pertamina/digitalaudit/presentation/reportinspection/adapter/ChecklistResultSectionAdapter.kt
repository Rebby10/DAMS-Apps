package com.pertamina.digitalaudit.presentation.reportinspection.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.animation.RotateAnimation
import androidx.recyclerview.widget.LinearLayoutManager
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.model.reportinspection.SectionItem
import com.pertamina.framework.base.BaseRecyclerViewAdapter
import com.pertamina.framework.base.BaseViewHolder
import kotlinx.android.synthetic.main.item_report_check_list_result_section.view.*

class ChecklistResultSectionAdapter : BaseRecyclerViewAdapter<SectionItem>() {

    private var listener: ItemClickListener? = null

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BaseViewHolder<SectionItem> {
        val view = LayoutInflater.from(parent.context).inflate(viewType, parent, false)
        return ListViewHolder(parent.context, view, listener)
    }

    override fun onBindViewHolder(
        holder: BaseViewHolder<SectionItem>,
        position: Int
    ) {
        holder.bindData(getItem(position))
    }

    override fun getItemViewType(position: Int): Int {
        return R.layout.item_report_check_list_result_section
    }

    class ListViewHolder(context: Context, val view: View, listener: ItemClickListener?) :
        BaseViewHolder<SectionItem>(context, view) {

        private var holderListener: ItemClickListener? = listener
        private var tvSectionNumber = view.tvSectionNumber
        private var ivArrowRight = view.ivArrowRight
        private var rvCheckListResultSection = view.rvCheckListResultSection

        override fun bindData(data: SectionItem) {
            tvSectionNumber.text = data.name
            itemView.setOnClickListener {
                rotateSectionArrow(rvCheckListResultSection.visibility == View.GONE)
                rvCheckListResultSection.visibility =
                    if (rvCheckListResultSection.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            }

            val llManager = LinearLayoutManager(context)
            val checklistResultQuestionAdapter = ChecklistResultQuestionAdapter()
            checklistResultQuestionAdapter.setItemClickListener(object :
                ChecklistResultQuestionAdapter.ItemClickListener {
                override fun onClickAttachment(questionId: String) {
                    holderListener?.onClickAttachment(questionId)
                }

                override fun onClickVoiceNote(questionId: String) {
                    holderListener?.onClickVoiceNote(questionId)
                }

                override fun onClickActions(questionId: String) {
                    holderListener?.onClickActions(questionId)
                }
            })
            rvCheckListResultSection.apply {
                layoutManager = llManager
                setHasFixedSize(true)
                adapter = checklistResultQuestionAdapter
            }
            checklistResultQuestionAdapter.setData(data.question ?: mutableListOf())

            rvCheckListResultSection.visibility =
                if (data.question?.isNotEmpty() == true && adapterPosition == 0) View.VISIBLE else View.GONE
            rotateSectionArrow(data.question?.isNotEmpty() == true && adapterPosition == 0)
        }

        private fun rotateSectionArrow(isShow: Boolean) {
            val anim = if (isShow) {
                RotateAnimation(
                    0F,
                    180F,
                    Animation.RELATIVE_TO_SELF,
                    0.5f,
                    Animation.RELATIVE_TO_SELF,
                    0.5f
                )
            } else {
                RotateAnimation(
                    180F,
                    0F,
                    Animation.RELATIVE_TO_SELF,
                    0.5f,
                    Animation.RELATIVE_TO_SELF,
                    0.5f
                )
            }
            anim.fillAfter = true
            ivArrowRight.startAnimation(anim)
        }
    }

    fun setItemClickListener(listener: ItemClickListener) {
        this.listener = listener
    }

    interface ItemClickListener {
        fun onClickAttachment(questionId: String)
        fun onClickVoiceNote(questionId: String)
        fun onClickActions(questionId: String)
    }
}