package com.pertamina.digitalaudit.presentation.inspectionfilter

import androidx.lifecycle.MutableLiveData
import com.pertamina.digitalaudit.model.query.GetInspectionQuery
import com.pertamina.framework.base.BaseViewModel

class InspectionFilterViewModel(
    private val inspectionFilterQuery: GetInspectionQuery
) : BaseViewModel() {

    companion object {
        private const val DEFAULT_USER_TYPE_ID = 1
    }

    val showProgressBar = MutableLiveData(false)
    var bTextFilterUserType = MutableLiveData<String?>(null)
    var bTextFilterLocation = MutableLiveData("Semua")
    var bTextFilterRegion = MutableLiveData("Semua")

    var filterUserTypeId = MutableLiveData(DEFAULT_USER_TYPE_ID)
    var filterRegionId = MutableLiveData<String?>(null)
    var filterLocationId = MutableLiveData<String?>(null)

    fun applyInspectionFilter() {
        inspectionFilterQuery.userTypeId = filterUserTypeId.value ?: DEFAULT_USER_TYPE_ID
        inspectionFilterQuery.regionId = filterRegionId.value
        inspectionFilterQuery.auditLocationId = filterLocationId.value
    }

}
