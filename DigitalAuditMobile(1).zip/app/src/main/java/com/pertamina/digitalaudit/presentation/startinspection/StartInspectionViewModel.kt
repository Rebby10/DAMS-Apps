package com.pertamina.digitalaudit.presentation.startinspection

import androidx.lifecycle.MutableLiveData
import com.pertamina.digitalaudit.model.startinspection.InspectionCompletedItem
import com.pertamina.digitalaudit.model.startinspection.InspectionPage
import com.pertamina.digitalaudit.model.startinspection.StartInspectionResponseModel
import com.pertamina.digitalaudit.preference.PreferenceProvider
import com.pertamina.digitalaudit.repository.inspection.InspectionRepository
import com.pertamina.framework.base.BaseViewModel
import com.pertamina.framework.base.Resource
import kotlinx.coroutines.launch

class StartInspectionViewModel(
    private val inspectionRepository: InspectionRepository,
    val preference: PreferenceProvider
) : BaseViewModel() {
    val showProgressBar = MutableLiveData(false)
    var inspectionLocation: String? = null
    var inspectionDate: String? = null
    var inspectionAuditorName: String? = null
    var inspectionAuditeeName: String? = null
    val saveInProgressClicked = MutableLiveData<Boolean>()

    val startInspectionResponse = MutableLiveData<Resource<StartInspectionResponseModel>>()
    val startInspectionListPageResponse = MutableLiveData<Resource<List<InspectionPage>>>()
    val inspectionCompletedResponse = MutableLiveData<Resource<List<InspectionCompletedItem>>>()

    var inspectionId: String? = null

    fun getStartInspection() {
        showProgressBar.value = true
        launch {
            val request = inspectionRepository.startInspection(inspectionId.orEmpty())
            startInspectionResponse.value = request
            showProgressBar.value = false
        }
    }

    fun getStartInspectionListPage() {
        showProgressBar.value = true
        launch {
            val request = inspectionRepository.startInspectionPageList(inspectionId.orEmpty())
            startInspectionListPageResponse.value = request
            showProgressBar.value = false
        }
    }

    fun markInspectionAsComplete() {
        showProgressBar.value = true
        launch {
            val request =
                inspectionRepository.completeInspection(inspectionId.orEmpty())
            inspectionCompletedResponse.value = request
            showProgressBar.value = false
        }
    }
}
