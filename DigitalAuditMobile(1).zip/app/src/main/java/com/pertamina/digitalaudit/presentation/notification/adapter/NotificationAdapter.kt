package com.pertamina.digitalaudit.presentation.notification.adapter

/**
 * Created by M Hafidh Abdul Aziz on 20/03/21.
 */

class NotificationAdapter {
}