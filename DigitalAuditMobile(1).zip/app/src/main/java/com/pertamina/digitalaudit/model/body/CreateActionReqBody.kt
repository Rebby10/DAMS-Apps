package com.pertamina.digitalaudit.model.body

import com.google.gson.annotations.SerializedName

class CreateActionReqBody(
    @SerializedName("Title")
    var title: String,
    @SerializedName("Descriptions")
    var descriptions: String,
    @SerializedName("AuditLocationId")
    var auditLocationId: String,
    @SerializedName("AssignGroup")
    var assignedGroup: String?,
    @SerializedName("AssignUser")
    var assignedUser: String?,
    @SerializedName("IssueId")
    var issueId: String?,
    @SerializedName("Creator")
    var creator: String,
    @SerializedName("PriorityId")
    var priorityId: Int,
    @SerializedName("TargetClosing")
    var targetClosing: String,
    @SerializedName("StatusId")
    var statusId: Int,
    @SerializedName("InspectionId")
    var inspectionId: String? = null,
    @SerializedName("QuestionId")
    var questionId: String? = null
)
