package com.pertamina.digitalaudit.model.query

import com.google.gson.annotations.SerializedName
import java.io.Serializable

class GetRegionQuery : Serializable {

    @SerializedName("name")
    var name: String? = null

    @SerializedName("page_size")
    var pageSize: Int? = null

    @SerializedName("page_number")
    var pageNumber: Int? = null

    @SerializedName("sort_by")
    var sortBy: String? = null

    @SerializedName("order_by")
    var orderBy: String? = null
}