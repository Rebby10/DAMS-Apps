package com.pertamina.digitalaudit.presentation.home.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.model.Reschedule
import com.pertamina.digitalaudit.presentation.issues.helper.IssuesStatusViewHelper
import com.pertamina.framework.base.BaseRecyclerViewAdapter
import com.pertamina.framework.base.BaseViewHolder
import com.pertamina.framework.util.DateHelper
import kotlinx.android.synthetic.main.item_home_reschedule.view.*

class RescheduleAdapter : BaseRecyclerViewAdapter<Reschedule>() {

    private var listener: RescheduleClickListener? = null

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BaseViewHolder<Reschedule> {
        val view = LayoutInflater.from(parent.context).inflate(viewType, parent, false)
        return ListViewHolder(parent.context, view, listener)
    }

    override fun onBindViewHolder(holder: BaseViewHolder<Reschedule>, position: Int) {
        holder.bindData(getItem(position))
    }

    override fun getItemViewType(position: Int): Int {
        return R.layout.item_home_reschedule
    }

    class ListViewHolder(context: Context, val view: View, listener: RescheduleClickListener?) :
        BaseViewHolder<Reschedule>(context, view) {

        private lateinit var data: Reschedule
        private var holderListener: RescheduleClickListener? = listener

        private var tvTitleReschedule = view.tvTitleReschedule
        private var tvRescheduleAuditLocation = view.tvRescheduleAuditLocation
        private var tvLocationAndAuditorNameReschedule = view.tvLocationAndAuditorNameReschedule
        private var tvStatusReschedule = view.tvStatusReschedule
        private var tvRescheduleRangeTime = view.tvRescheduleRangeTime

        @SuppressLint("SetTextI18n")
        override fun bindData(data: Reschedule) {
            this.data = data
            tvTitleReschedule.text = data.title //todo check template title
            tvRescheduleAuditLocation.text = data.locationName
            tvLocationAndAuditorNameReschedule.text = data.displayNameRequester
            tvStatusReschedule.apply {
                data.scheduleStatus?.let { status ->
                    text = status
                    setBackgroundResource(IssuesStatusViewHelper.getStatusBackgroundColor(status))
                    setTextColor(
                        ContextCompat.getColor(
                            context,
                            IssuesStatusViewHelper.getStatusTextColor(status)
                        )
                    )
                }
            }
            var startDate = ""
            var endDate = ""
            data.startDate?.let {
                startDate = DateHelper.changeFormat(
                    it,
                    DateHelper.yyyy_MM_dd_T_HHmmss,
                    DateHelper.dd_MMM
                )
            }
            data.endDate?.let {
                endDate = DateHelper.changeFormat(
                    data.endDate.orEmpty(),
                    DateHelper.yyyy_MM_dd_T_HHmmss,
                    DateHelper.dd_MMM_yyyy
                )
            }
            tvRescheduleRangeTime.text = "$startDate - $endDate"
            itemView.setOnClickListener {
                holderListener?.onClickReschedule(
                    data.rescheduleId.orEmpty(),
                    data.scheduleId.orEmpty(),
                    data.scheduleStatus.orEmpty(),
                    data.userIdRequester.orEmpty(),
                    data.userIdApprover.orEmpty()
                )
            }
        }
    }

    fun setRescheduleClickListener(listener: RescheduleClickListener) {
        this.listener = listener
    }

    interface RescheduleClickListener {
        fun onClickReschedule(
            rescheduleId: String,
            scheduleId: String,
            scheduleStatus: String,
            userIdRequester: String,
            userIdApprover: String
        )
    }
}