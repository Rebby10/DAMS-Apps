package com.pertamina.digitalaudit.presentation.startinspection.startpage

import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.pertamina.digitalaudit.model.IssueModel
import com.pertamina.digitalaudit.model.body.InspectionResultReqBody
import com.pertamina.digitalaudit.model.body.UploadInspectionFileReqBody
import com.pertamina.digitalaudit.model.startinspection.AnswerInspectionResultResponse
import com.pertamina.digitalaudit.model.startinspection.ImageFileInspection
import com.pertamina.digitalaudit.model.startinspection.InspectionCompletedItem
import com.pertamina.digitalaudit.model.startinspection.InspectionPage
import com.pertamina.digitalaudit.model.startinspection.InspectionPageResponse
import com.pertamina.digitalaudit.model.startinspection.StartInspectionModel
import com.pertamina.digitalaudit.preference.PreferenceProvider
import com.pertamina.digitalaudit.preference.SharedPreferencesKey
import com.pertamina.digitalaudit.repository.inspection.InspectionRepository
import com.pertamina.digitalaudit.util.CommonConstant.AUDIO_FILE_TYPE
import com.pertamina.digitalaudit.util.CommonConstant.IMAGE_FILE_TYPE
import com.pertamina.framework.base.BaseResponse
import com.pertamina.framework.base.BaseViewModel
import com.pertamina.framework.base.Resource
import kotlinx.coroutines.launch
import java.io.File

class StartPageViewModel(
    private val pref: PreferenceProvider,
    private val inspectionRepository: InspectionRepository
) : BaseViewModel() {
    val showProgressBar = MutableLiveData(false)
    val isLastPage = MutableLiveData(false)
    val isIssuePage = MutableLiveData(false)
    val allInspectionImageAudioReqBody = mutableListOf<UploadInspectionFileReqBody>()
    val allVoiceNotesDataSaved = mutableMapOf<Int, List<String>>()
    val allImageDataSaved = mutableMapOf<Int, List<String>>()
    val allNotesDataSaved = mutableMapOf<Int, String>()

    //map of questionId, answerId, answerText
    val allAnswerDataSaved = mutableMapOf<Int, Pair<Int, String>>()
    val listInspectionResultData = mutableListOf<InspectionResultReqBody>()

    var bTextSelectedPage = MutableLiveData("")
    var bTextInfoTotalPage = MutableLiveData("")
    var bTextInspectionCodeAndTitle = MutableLiveData("")
    var bTextInspectionDescription = MutableLiveData("")
    var bTextInspectionLocation = MutableLiveData("")
    var bTextInspectionDate = MutableLiveData("")
    var bTextInspectionAuditor = MutableLiveData("")
    var bTextInspectionAuditee = MutableLiveData("")

    val inspectionByPageResponse = MutableLiveData<Resource<InspectionPageResponse>>()
    val allImageFileResponse = MutableLiveData<Resource<ImageFileInspection>>()
    val allAudioFileResponse = MutableLiveData<Resource<ImageFileInspection>>()
    val startInspectionAnswerResultResponse =
        MutableLiveData<Resource<AnswerInspectionResultResponse>>()
    val issueFromLastInspectionResponse = MutableLiveData<Resource<List<IssueModel.Issue>>>()
    val inspectionCompletedResponse = MutableLiveData<Resource<List<InspectionCompletedItem>>>()
    val uploadInspectionFileResponse = MutableLiveData<Resource<BaseResponse>>()
    var startInspectionData: StartInspectionModel? = null
    var startInspectionListData: List<InspectionPage>? = null
    var inspectionId: String? = null

    fun getPageListWithoutIssueFromLastInspection(): List<InspectionPage>? {
        return startInspectionListData?.let { it.filter { filter -> filter.pageId?.isNotEmpty() == true } }
    }

    fun getAllNotesSavedFromAPI() {
        startInspectionData?.templatePage?.forEach { inspectionPage ->
            inspectionPage?.section?.forEach {
                it.question?.forEach { questionItem ->
                    allNotesDataSaved[questionItem.questionId ?: 0] =
                        questionItem.answer?.notes.orEmpty()
                }
            }
        }
    }

    fun getInspectionBySelectedPage(inspectionId: String, pageId: String) {
        showProgressBar.value = true
        launch {
            val request =
                inspectionRepository.getInspectionByPage(inspectionId, pageId)
            inspectionByPageResponse.value = request
            request.data?.data?.let { saveAllQuestionList(it) }

            showProgressBar.value = false
        }
    }

    fun getIssueFromLastInspectionPage(inspectionId: String) {
        showProgressBar.value = true
        launch {
            val request =
                inspectionRepository.startInspectionIssue(inspectionId)
            issueFromLastInspectionResponse.value = request
            showProgressBar.value = false
        }
    }

    fun getAllAudioFileFromAPI() {
        showProgressBar.value = true
        inspectionId?.let { inspectionId ->
            startInspectionData?.templatePage?.forEach { inspectionPage ->
                inspectionPage?.section?.forEach {
                    it.question?.forEach { questionItem ->
                        questionItem.questionId?.let { questionId ->
                            launch {
                                val request =
                                    inspectionRepository.getAllImageFile(
                                        inspectionId,
                                        questionId,
                                        AUDIO_FILE_TYPE
                                    )
                                allAudioFileResponse.value = request
                                showProgressBar.value = false
                            }
                        }
                    }
                }
            }
        }
    }

    fun getAllImageFileFromAPI() {
        showProgressBar.value = true
        inspectionId?.let { inspectionId ->
            startInspectionData?.templatePage?.forEach { inspectionPage ->
                inspectionPage?.section?.forEach {
                    it.question?.forEach { questionItem ->
                        questionItem.questionId?.let { questionId ->
                            launch {
                                val request =
                                    inspectionRepository.getAllImageFile(
                                        inspectionId,
                                        questionId,
                                        IMAGE_FILE_TYPE
                                    )
                                allImageFileResponse.value = request
                                showProgressBar.value = false
                            }
                        }
                    }
                }
            }
        }
    }

    fun postAnswerInspectionResult() {
        showProgressBar.value = true
        mergeAllAnswerInspectionData()
        listInspectionResultData.forEach { data ->
            Log.d("startpagevm", "post:${data.answerId}")
            data.answerId?.let {
                launch {
                    val request =
                        inspectionRepository.sendInspectionResult(data)
                    startInspectionAnswerResultResponse.value = request
                    showProgressBar.value = false
                }
            }
        }
    }

    fun uploadInspectionFile() {
        allInspectionImageAudioReqBody.forEach {
            launch {
                val request =
                    inspectionRepository.uploadInspectionFile(it)
                uploadInspectionFileResponse.value = request
                showProgressBar.value = false
            }
        }
    }

    fun setUploadFileReqBody(fileType: Int, questionId: Int, files: List<File>) {
        if (allInspectionImageAudioReqBody.firstOrNull { it.questionId == questionId && it.fileTypeId == IMAGE_FILE_TYPE } != null) {
            allInspectionImageAudioReqBody.removeAll {
                it.questionId == questionId && it.fileTypeId == IMAGE_FILE_TYPE
            }
        }

        allInspectionImageAudioReqBody.add(
            UploadInspectionFileReqBody(
                inspectionId.orEmpty(),
                questionId,
                files,
                fileType,
                pref.getStringFromPreference(SharedPreferencesKey.USER_NAME).orEmpty()
            )
        )
    }

    fun markInspectionAsComplete(inspectionId: String) {
        showProgressBar.value = true
        launch {
            val request =
                inspectionRepository.completeInspection(inspectionId)
            inspectionCompletedResponse.value = request
            showProgressBar.value = false
        }
    }

    fun setDataToView(location: String, date: String, auditorName: String, auditeeName: String) {
        bTextInspectionCodeAndTitle.value =
            startInspectionData?.code + "/" + startInspectionData?.title
        bTextInspectionDescription.value = startInspectionData?.descriptions
        bTextInspectionLocation.value = location
        bTextInspectionDate.value = date
        bTextInspectionAuditor.value = auditorName
        bTextInspectionAuditee.value = auditeeName
    }

    private fun mergeAllAnswerInspectionData() {
        allAnswerDataSaved.forEach { map ->
            val exist = listInspectionResultData.firstOrNull { it.questionId == map.key } != null
            if (exist) {
                val iterator: MutableListIterator<InspectionResultReqBody> =
                        listInspectionResultData.listIterator()
                while (iterator.hasNext()) {
                    val next = iterator.next()
                    if (next.questionId == map.key) {
                        next.answerId = map.value.first
                        next.answerText = map.value.second
                        iterator.set(next)
                    }
                }
            }
        }

        allNotesDataSaved.forEach { map ->
            val exist = listInspectionResultData.firstOrNull { it.questionId == map.key } != null

            if (exist) {
                val iterator: MutableListIterator<InspectionResultReqBody> =
                        listInspectionResultData.listIterator()
                while (iterator.hasNext()) {
                    val next = iterator.next()
                    if (next.questionId == map.key) {
                        next.notes = map.value
                        iterator.set(next)
                    }
                }
            }
        }
    }

    fun saveAllQuestionList(inspectionPage: InspectionPage) {
        inspectionPage.section?.forEach { section ->
            section.question?.forEach {
                updateListInspectionResultData(
                        it.questionId ?: 0,
                        it.answer?.answerId,
                        it.answer?.answerText,
                        it.answer?.notes
                )
            }
        }
    }

    private fun updateListInspectionResultData(
            questionId: Int,
            answerId: Int?, answerText: String?, notes: String?
    ) {
        val reqBody =
                InspectionResultReqBody(inspectionId.orEmpty(), questionId, answerId, answerText, notes)

        val exist = listInspectionResultData.firstOrNull { it.questionId == questionId } != null

        if (!exist) listInspectionResultData.add(reqBody)
        else {
            val iterator: MutableListIterator<InspectionResultReqBody> =
                    listInspectionResultData.listIterator()
            while (iterator.hasNext()) {
                val next = iterator.next()
                if (next.questionId == questionId) {
                    reqBody.answerId = answerId ?: next.answerId
                    reqBody.answerText = answerText ?: next.answerText
                    reqBody.notes = if (notes.isNullOrEmpty()) next.notes else notes
                    iterator.set(reqBody)
                }
            }
        }
    }
}
