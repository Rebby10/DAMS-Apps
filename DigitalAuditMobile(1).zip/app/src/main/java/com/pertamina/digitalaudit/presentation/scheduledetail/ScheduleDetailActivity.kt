package com.pertamina.digitalaudit.presentation.scheduledetail

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.databinding.ActivityScheduleDetailBinding
import com.pertamina.digitalaudit.model.ScheduleDetailModel
import com.pertamina.digitalaudit.util.SnackBar
import com.pertamina.framework.NetworkState
import com.pertamina.framework.ViewDataBindingOwner
import com.pertamina.framework.base.BaseActivity
import com.pertamina.framework.customview.DateTimePicker
import com.pertamina.framework.util.DateHelper
import kotlinx.android.synthetic.main.activity_schedule_detail.*
import kotlinx.android.synthetic.main.toolbar_layout.*
import org.koin.androidx.viewmodel.ext.android.viewModel

/**
 * Created by M Hafidh Abdul Aziz on 03/03/21.
 */

class ScheduleDetailActivity : BaseActivity<ScheduleDetailViewModel>(), ScheduleDetailView,
    ViewDataBindingOwner<ActivityScheduleDetailBinding> {

    override val layoutResourceId: Int = R.layout.activity_schedule_detail
    override val viewModel: ScheduleDetailViewModel by viewModel()
    override var binding: ActivityScheduleDetailBinding? = null

    companion object {
        const val EXTRA_SCHEDULE_ID = "EXTRA_SCHEDULE_ID"
        private const val EXTRA_RESCHEDULE_ID = "EXTRA_RESCHEDULE_ID"
        const val EXTRA_SCHEDULE_STATUS = "EXTRA_SCHEDULE_STATUS"
        private const val EXTRA_RESCHEDULE_USER_ID_REQUESTER = "EXTRA_RESCHEDULE_USER_ID_REQUESTER"
        private const val EXTRA_RESCHEDULE_USER_ID_APPROVER = "EXTRA_RESCHEDULE_USER_ID_APPROVER"

        fun startThisActivity(
            context: Context,
            scheduleId: String,
            rescheduleId: String?,
            scheduleStatus: String,
            userIdRequester: String?,
            userIdApprover: String?
        ) {
            val intent = Intent(context, ScheduleDetailActivity::class.java)
            intent.putExtra(EXTRA_SCHEDULE_ID, scheduleId)
            intent.putExtra(EXTRA_RESCHEDULE_ID, rescheduleId)
            intent.putExtra(EXTRA_SCHEDULE_STATUS, scheduleStatus)
            intent.putExtra(EXTRA_RESCHEDULE_USER_ID_REQUESTER, userIdRequester)
            intent.putExtra(EXTRA_RESCHEDULE_USER_ID_APPROVER, userIdApprover)
            context.startActivity(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        getExtraData()
        setupToolbar()
        subscribeScheduleDetail()
        subscribeRescheduleApproval()
        subscribeReschedule()
        etRescheduleStartDate.setEventListener(object : DateTimePicker.OnGetDateListener {
            override fun onGetDate(date: String) {
                tvRescheduleStartDateError?.visibility = View.GONE
                viewModel.bTextRescheduleStartDate.value = date
            }
        })
        etRescheduleEndDate.setEventListener(object : DateTimePicker.OnGetDateListener {
            override fun onGetDate(date: String) {
                tvRescheduleEndDateError?.visibility = View.GONE
                viewModel.bTextRescheduleEndDate.value = date
            }
        })
    }

    private fun getExtraData() {
        viewModel.scheduleId = intent?.getStringExtra(EXTRA_SCHEDULE_ID).orEmpty()
        viewModel.rescheduleId = intent?.getStringExtra(EXTRA_RESCHEDULE_ID).orEmpty()
        viewModel.isCanReschedule.value = viewModel.rescheduleId.isEmpty()

        val requesterId = intent?.getStringExtra(EXTRA_RESCHEDULE_USER_ID_REQUESTER).orEmpty()
        val approverId = intent?.getStringExtra(EXTRA_RESCHEDULE_USER_ID_APPROVER).orEmpty()
        viewModel.isRequester.value =
            requesterId.isNotEmpty() && requesterId == viewModel.user.userId
        viewModel.isApprover.value = approverId.isNotEmpty() && approverId == viewModel.user.userId

        getScheduleDetail()
    }

    private fun setupToolbar() {
        tvTitleToolbar.text = getString(R.string.title_audit_schedule)
        btnBackToolbar.apply {
            visibility = View.VISIBLE
            setImageResource(R.drawable.ic_close)
            setOnClickListener {
                onBackPressed()
            }
        }
    }

    private fun getScheduleDetail() {
        viewModel.getScheduleDetail()
    }

    private fun subscribeScheduleDetail() {
        observeData(viewModel.detailScheduleResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { scheduleDetail ->
                            setDataToView(scheduleDetail.data)
                        }
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message ?: getString(R.string.general_server_error_message)
                        )
                    }
                    else -> {
                        //do nothing just to avoid error warning
                    }
                }
            }
        }
    }

    private fun subscribeRescheduleApproval() {
        observeData(viewModel.rescheduleApprovalResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let {
                            setResult(RESULT_OK)
                            finish()
                        }
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message ?: getString(R.string.general_server_error_message)
                        )
                    }
                    else -> {
                        //do nothing just to avoid error warning
                    }
                }
            }
        }
    }

    private fun subscribeReschedule() {
        observeData(viewModel.rescheduleResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let {
                            setResult(RESULT_OK)
                            finish()
                        }
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message ?: getString(R.string.general_server_error_message)
                        )
                    }
                    else -> {
                        //do nothing just to avoid error warning
                    }
                }
            }
        }
    }

    private fun setDataToView(data: ScheduleDetailModel.ScheduleDetail?) {
        viewModel.bTextScheduleTitle.value = data?.title
        val startDate = DateHelper.changeFormat(
            data?.startDate.orEmpty(),
            DateHelper.yyyy_MM_dd_T_HHmmss,
            DateHelper.dd_MMM_yyyy_hh_mm_a
        )
        val endDate = DateHelper.changeFormat(
            data?.endDate.orEmpty(),
            DateHelper.yyyy_MM_dd_T_HHmmss,
            DateHelper.dd_MMM_yyyy_hh_mm_a
        )
        viewModel.bTextScheduleDate.value = "$startDate - $endDate"
        viewModel.bTextScheduleLocation.value = data?.auditLocation?.name
        viewModel.bTextScheduleTemplate.value = data?.template?.title
        viewModel.bTextScheduleAuditor.value = getAssignedAuditor(data)
        viewModel.bTextScheduleAuditee.value = getAssignedAuditee(data)
    }

    private fun getAssignedAuditor(data: ScheduleDetailModel.ScheduleDetail?): String? {
        data?.auditor?.users?.let {
            return it.name
        }
        data?.auditor?.groups?.let {
            return it.officialName
        }
        return ""
    }

    private fun getAssignedAuditee(data: ScheduleDetailModel.ScheduleDetail?): String? {
        data?.auditee?.users?.let {
            return it.name
        }
        data?.auditee?.groups?.let {
            return it.officialName
        }
        return ""
    }

    override fun onClickReschedule(view: View) {
        var isValid = true
        if (viewModel.bTextRescheduleStartDate.value?.isEmpty() == true) {
            tvRescheduleStartDateError?.visibility = View.VISIBLE
            isValid = false
        }
        if (viewModel.bTextRescheduleEndDate.value?.isEmpty() == true) {
            tvRescheduleEndDateError?.visibility = View.VISIBLE
            isValid = false
        }
        if (viewModel.bTextRescheduleReasonDescription.value?.isEmpty() == true) {
            tvRescheduleReasonDescriptionError?.text = getString(R.string.required_field_error)
            tvRescheduleReasonDescriptionError?.visibility = View.VISIBLE
            isValid = false
        }
        if (viewModel.bTextRescheduleReasonDescription.value?.length ?: 0 < 10) {
            tvRescheduleReasonDescriptionError?.text =
                getString(R.string.required_field_error_min_char)
            tvRescheduleReasonDescriptionError?.visibility = View.VISIBLE
            isValid = false
        }
        if (isValid) {
            rescheduleEvent()
        }
    }

    override fun onClickConfirm(view: View) {
        viewModel.confirmReschedule(true)
    }

    override fun onClickReject(view: View) {
        viewModel.confirmReschedule(false)
    }

    override var bTextWatcherRescheduleReasonDescription: TextWatcher
        get() = object : TextWatcher {

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                tvRescheduleReasonDescriptionError?.visibility = View.GONE
            }

            override fun afterTextChanged(s: Editable?) {}
        }
        set(_) {}

    private fun rescheduleEvent() {
        viewModel.reschedule()
    }
}
