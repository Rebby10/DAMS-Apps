package com.pertamina.digitalaudit.presentation.guide

import androidx.lifecycle.MutableLiveData
import com.pertamina.framework.base.BaseViewModel

class GuideViewModel : BaseViewModel(){
    val showProgressBar = MutableLiveData(false)
}
