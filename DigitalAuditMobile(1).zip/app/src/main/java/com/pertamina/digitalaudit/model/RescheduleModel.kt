package com.pertamina.digitalaudit.model

import com.google.gson.annotations.SerializedName

data class RescheduleModel(

    @field:SerializedName("TotalResult")
    val totalResult: Int? = null,

    @field:SerializedName("TotalData")
    val totalData: Int? = null,

    @field:SerializedName("Result")
    val result: List<Reschedule>? = null
)

data class Reschedule(

    @field:SerializedName("RescheduleEndDate")
    val rescheduleEndDate: String? = null,

    @field:SerializedName("Address")
    val address: String? = null,

    @field:SerializedName("RescheduleId")
    val rescheduleId: String? = null,

    @field:SerializedName("UserIdRequester")
    val userIdRequester: String? = null,

    @field:SerializedName("ScheduleStatusId")
    val scheduleStatusId: Int? = null,

    @field:SerializedName("LocationName")
    val locationName: String? = null,

    @field:SerializedName("IsApproved")
    val isApproved: Boolean? = null,

    @field:SerializedName("StartDate")
    val startDate: String? = null,

    @field:SerializedName("UserIdApprover")
    val userIdApprover: String? = null,

    @field:SerializedName("RegionName")
    val regionName: String? = null,

    @field:SerializedName("EmailRequester")
    val emailRequester: String? = null,

    @field:SerializedName("TemplateId")
    val templateId: String? = null,

    @field:SerializedName("ZipCode")
    val zipCode: String? = null,

    @field:SerializedName("Title")
    val title: String? = null,

    @field:SerializedName("ScheduleId")
    val scheduleId: String? = null,

    @field:SerializedName("EndDate")
    val endDate: String? = null,

    @field:SerializedName("ApprovalDate")
    val approvalDate: String? = null,

    @field:SerializedName("DisplayNameRequester")
    val displayNameRequester: String? = null,

    @field:SerializedName("RescheduleStartDate")
    val rescheduleStartDate: String? = null,

    @field:SerializedName("EmailApprover")
    val emailApprover: String? = null,

    @field:SerializedName("RegionId")
    val regionId: String? = null,

    @field:SerializedName("AuditLocationId")
    val auditLocationId: String? = null,

    @field:SerializedName("LatLong")
    val latLong: String? = null,

    @field:SerializedName("DisplayNameApprover")
    val displayNameApprover: String? = null,

    @field:SerializedName("ScheduleStatus")
    val scheduleStatus: String? = null
)
