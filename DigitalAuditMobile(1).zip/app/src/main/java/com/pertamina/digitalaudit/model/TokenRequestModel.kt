package com.pertamina.digitalaudit.model

import com.google.gson.annotations.SerializedName

class TokenRequestModel(

    @SerializedName("TokenUser")
    var tokenUser: String? = "",

    @SerializedName("TokenPassword")
    var tokenPassword: String? = ""
)

