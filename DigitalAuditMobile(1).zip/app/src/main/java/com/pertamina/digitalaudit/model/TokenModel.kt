package com.pertamina.digitalaudit.model

import com.pertamina.framework.base.BaseResponse
import com.google.gson.annotations.SerializedName

class TokenModel : BaseResponse() {

    @SerializedName("Result")
    var data: Token? = null

    class Token {
        @SerializedName("Token")
        var token : String? = ""
    }
}

