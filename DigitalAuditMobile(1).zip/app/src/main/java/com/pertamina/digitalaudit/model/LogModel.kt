package com.pertamina.digitalaudit.model

import com.google.gson.annotations.SerializedName
import com.pertamina.framework.base.BaseResponse

/**
 * Created by M Hafidh Abdul Aziz on 01/04/21.
 */

class LogModel : BaseResponse() {

    @SerializedName("Result")
    var data: List<Log>? = null

    class Log {
        @SerializedName("Id")
        var id: String? = ""

        @SerializedName("IssueId")
        var issueId: String? = ""

        @SerializedName("ActionId")
        var actionId: String? = ""

        @SerializedName("Text")
        var text: String? = ""

        @SerializedName("Datetime")
        var datetime: String? = ""

        @SerializedName("Filename")
        var filename: String? = ""

        @SerializedName("Link")
        var link: String? = ""

        @SerializedName("Type")
        var type: Type? = null

        @SerializedName("User")
        var user: UserModel.User? = null

        class Type {
            @SerializedName("LogTypeId")
            var logTypeId: Int? = 0

            @SerializedName("Name")
            var name: String? = ""
        }
    }
}
