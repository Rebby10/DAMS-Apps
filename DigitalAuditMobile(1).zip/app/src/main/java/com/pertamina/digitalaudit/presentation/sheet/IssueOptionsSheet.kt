package com.pertamina.digitalaudit.presentation.sheet

import android.content.Context
import android.content.res.TypedArray
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.presentation.issues.IssuesViewModel.Companion.REPORTED_BY_ME
import com.pertamina.framework.customview.BaseBottomSheet

/**
 * @author Asadurrahman Al Qayyim
 * @date 3/26/2021
 */

class IssueOptionsSheet(context: Context, private var position: Int) :
    BaseBottomSheet(context, R.style.AppBottomSheetDialogTheme) {

    private lateinit var bottomSheetMenuItemAdapter: BottomSheetMenuItemAdapter
    private var bottomMenuListener: MenuItemClickListener? = null

    override fun customBottomSheetView() {
        val layout = R.layout.sheet_common_options
        createBottomSheetView(layout)
    }

    override fun bottomSheetView(view: View) {
        window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        val rvData =
            view.findViewById<RecyclerView>(R.id.rvData)

        val mVerticalLayoutManager = LinearLayoutManager(context)
        mVerticalLayoutManager.orientation = LinearLayoutManager.VERTICAL
        rvData.layoutManager = mVerticalLayoutManager

        bottomSheetMenuItemAdapter = BottomSheetMenuItemAdapter(getMenuList(position))
        bottomSheetMenuItemAdapter.setListener(object :
            MenuItemClickListener {
            override fun onBottomSheetItemClicked(menu: String) {
                bottomMenuListener?.onBottomSheetItemClicked(menu)
            }
        })
        rvData.adapter = bottomSheetMenuItemAdapter

    }

    private fun getMenuList(filterMenuPosition: Int): MutableList<BottomSheetMenuModel> {
        val menuList: MutableList<BottomSheetMenuModel> = mutableListOf()
        menuList.clear()
        val iconMenu = getIconMenu(filterMenuPosition)
        val menu = getMenuText(filterMenuPosition)
        for (position in menu.indices) {
            menuList.add(
                BottomSheetMenuModel(
                    iconMenu.getResourceId(position, 0),
                    menu[position]
                )
            )
        }

        return menuList
    }

    inner class BottomSheetMenuItemAdapter(private var list: MutableList<BottomSheetMenuModel>) :
        RecyclerView.Adapter<BottomSheetMenuItemAdapter.BottomSheetMenuViewHolder>() {

        private var listener: MenuItemClickListener? = null

        override fun onCreateViewHolder(
            parent: ViewGroup,
            viewType: Int
        ): BottomSheetMenuViewHolder {
            val inflater = LayoutInflater.from(parent.context)
            val view = inflater.inflate(R.layout.item_bottom_sheet_menu, parent, false)
            return BottomSheetMenuViewHolder(view)
        }

        override fun onBindViewHolder(holder: BottomSheetMenuViewHolder, position: Int) {
            holder.listener = listener
            holder.bindItem(list[position])
        }

        override fun getItemCount(): Int = list.size

        inner class BottomSheetMenuViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

            var listener: MenuItemClickListener? = null
            private val ivIconMenu: ImageView = itemView.findViewById(R.id.ivIconMenu)
            private val tvMenu: TextView = itemView.findViewById(R.id.tvMenu)

            fun bindItem(item: BottomSheetMenuModel) {
                if (item.imageDrawable != 0) {
                    ivIconMenu.apply {
                        setImageResource(item.imageDrawable)
                        visibility = View.VISIBLE
                    }
                } else {
                    ivIconMenu.apply {
                        visibility = View.GONE
                    }
                }
                tvMenu.text = item.title
                if (item.title == context.getString(R.string.menu_delete)) {
                    tvMenu.setTextColor(ContextCompat.getColor(context, R.color.primary_red_700))
                }
                itemView.setOnClickListener {
                    listener?.onBottomSheetItemClicked(item.title)
                }
            }
        }

        fun setListener(listener: MenuItemClickListener?) {
            this.listener = listener
        }
    }

    fun setMenuItemListener(listener: MenuItemClickListener?) {
        this.bottomMenuListener = listener
    }

    interface MenuItemClickListener {
        fun onBottomSheetItemClicked(menu: String)
    }

    data class BottomSheetMenuModel(val imageDrawable: Int, val title: String)


    private fun getIconMenu(filterMenuPosition: Int): TypedArray {
        return if (filterMenuPosition == REPORTED_BY_ME) context.resources.obtainTypedArray(
            R.array.issues_item_menu_icon
        )
        else context.resources.obtainTypedArray(R.array.issues_item_menu_assigned_icon)
    }

    private fun getMenuText(filterMenuPosition: Int): Array<String> {
        return if (filterMenuPosition == REPORTED_BY_ME) context.resources.getStringArray(
            R.array.issues_item_menu
        )
        else context.resources.getStringArray(R.array.issues_item_menu_assigned)
    }

}
