package com.pertamina.digitalaudit.presentation.splashscreen

import com.pertamina.digitalaudit.preference.PreferenceProvider
import com.pertamina.digitalaudit.preference.SharedPreferencesKey
import com.pertamina.framework.base.BaseViewModel

/**
 * Created by Asadurrahman Al Qayyim on 22/03/21.
 */

class SplashScreenViewModel(val preference: PreferenceProvider) : BaseViewModel(){

    fun getTokenFromPreference(): String {
        return preference.getStringFromPreference(SharedPreferencesKey.ACCESS_TOKEN) ?: ""
    }
}