package com.pertamina.digitalaudit.presentation.issues

import androidx.lifecycle.MutableLiveData
import com.pertamina.digitalaudit.model.IssueModel
import com.pertamina.digitalaudit.model.UserModel
import com.pertamina.digitalaudit.model.body.SortAndFilterReqBody
import com.pertamina.digitalaudit.preference.PreferenceProvider
import com.pertamina.digitalaudit.repository.issues.IssuesRepository
import com.pertamina.digitalaudit.util.CommonConstant
import com.pertamina.framework.base.BaseViewModel
import com.pertamina.framework.base.Resource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * @author Asadurrahman Al Qayyim
 * @date 23-Mar-21
 */

class IssuesViewModel(
    private val issuesRepository: IssuesRepository,
    val preference: PreferenceProvider
) : BaseViewModel() {

    companion object {
        const val REPORTED_BY_ME = 0
        const val ASSIGN_TO_ME = 1
    }

    val reportByMeIssueList = MutableLiveData<Resource<List<IssueModel.Issue>>>()
    val assignToMeIssueList = MutableLiveData<Resource<List<IssueModel.Issue>>>()
    val deletedIssueResponse = MutableLiveData<Resource<IssueModel>>()
    var user = UserModel.User()
    val isLoading = MutableLiveData(false)
    val showEmptyState = MutableLiveData(false)
    var filterMenuPosition = REPORTED_BY_ME

    init {
        getUserData()
    }

    private fun getUserData() {
        launch {
            withContext(Dispatchers.IO) {
                user = preference.getAuthPreferences()
            }
            getAllDataAPI()
        }
    }

    fun getAllDataAPI() {
        if (filterMenuPosition == REPORTED_BY_ME) {
            reportByMeIssueList(SortAndFilterReqBody())
        } else {
            assignToMeIssueList(SortAndFilterReqBody())
        }
    }

    fun reportByMeIssueList(reqBody: SortAndFilterReqBody) {
        isLoading.value = true
        reqBody.userCreated = user.userId
        reqBody.sortBy = CommonConstant.SORT_BY_DATE_CREATED
        reqBody.orderBy = CommonConstant.ORDER_BY_DESC
        launch {
            val request = issuesRepository.applyFilter(reqBody)
            reportByMeIssueList.value = request
            isLoading.value = false
        }
    }

    fun assignToMeIssueList(reqBody: SortAndFilterReqBody) {
        isLoading.value = true
        reqBody.assignUser = user.userId
        reqBody.sortBy = CommonConstant.SORT_BY_DATE_CREATED
        reqBody.orderBy = CommonConstant.ORDER_BY_DESC
        launch {
            val request = issuesRepository.applyFilter(reqBody)
            assignToMeIssueList.value = request
            isLoading.value = false
        }
    }

    fun applyFilterIssueReportByMe(reqBody: SortAndFilterReqBody) {
        reqBody.userCreated = user.userId
        reqBody.orderBy = CommonConstant.ORDER_BY_DESC
        launch {
            val request = issuesRepository.applyFilter(reqBody)
            reportByMeIssueList.value = request
            isLoading.value = false
        }
    }

    fun applyFilterIssueAssignToMe(reqBody: SortAndFilterReqBody) {
        reqBody.assignUser = user.userId
        reqBody.orderBy = CommonConstant.ORDER_BY_DESC
        launch {
            val request = issuesRepository.applyFilter(reqBody)
            assignToMeIssueList.value = request
            isLoading.value = false
        }
    }

    fun deleteSelectedIssue(issueId: String) {
        isLoading.value = true
        launch {
            val request = issuesRepository.deleteIssue(issueId)
            deletedIssueResponse.value = request
            isLoading.value = false
        }
    }
}
