package com.pertamina.digitalaudit.model.startinspection

import com.google.gson.annotations.SerializedName

data class InspectionCompletedResponse(

    @field:SerializedName("Result")
    val data: List<InspectionCompletedItem>? = null
)

data class AuditLocation(

    @field:SerializedName("Address")
    val address: String? = null,

    @field:SerializedName("ZipCode")
    val zipCode: String? = null,

    @field:SerializedName("Region")
    val region: Region? = null,

    @field:SerializedName("AuditLocationId")
    val auditLocationId: String? = null,

    @field:SerializedName("LatLong")
    val latLong: String? = null,

    @field:SerializedName("Name")
    val name: String? = null
)

data class Region(

    @field:SerializedName("RegionId")
    val regionId: String? = null,

    @field:SerializedName("Name")
    val name: String? = null
)

data class Users(

    @field:SerializedName("Email")
    val email: String? = null,

    @field:SerializedName("PositionId")
    val positionId: Any? = null,

    @field:SerializedName("FirstName")
    val firstName: String? = null,

    @field:SerializedName("OrganizationId")
    val organizationId: String? = null,

    @field:SerializedName("City")
    val city: Any? = null,

    @field:SerializedName("JobTitle")
    val jobTitle: String? = null,

    @field:SerializedName("MobilePhone")
    val mobilePhone: Any? = null,

    @field:SerializedName("CompanyName")
    val companyName: Any? = null,

    @field:SerializedName("Department")
    val department: Any? = null,

    @field:SerializedName("Username")
    val username: String? = null,

    @field:SerializedName("UserId")
    val userId: String? = null,

    @field:SerializedName("DisplayName")
    val displayName: String? = null,

    @field:SerializedName("Country")
    val country: Any? = null,

    @field:SerializedName("OfficeLocation")
    val officeLocation: Any? = null,

    @field:SerializedName("LastName")
    val lastName: String? = null,

    @field:SerializedName("EmployeeId")
    val employeeId: String? = null,

    @field:SerializedName("UserSyncId")
    val userSyncId: String? = null,

    @field:SerializedName("CompanyCode")
    val companyCode: String? = null
)

data class UserType(

    @field:SerializedName("UserTypeId")
    val userTypeId: String? = null,

    @field:SerializedName("Name")
    val name: String? = null
)

data class Auditor(

    @field:SerializedName("Groups")
    val groups: Any? = null,

    @field:SerializedName("InspectionId")
    val inspectionId: String? = null,

    @field:SerializedName("Users")
    val users: Users? = null,

    @field:SerializedName("PicId")
    val picId: String? = null,

    @field:SerializedName("UserType")
    val userType: UserType? = null
)

data class Auditee(

    @field:SerializedName("Groups")
    val groups: Any? = null,

    @field:SerializedName("InspectionId")
    val inspectionId: String? = null,

    @field:SerializedName("Users")
    val users: Users? = null,

    @field:SerializedName("PicId")
    val picId: String? = null,

    @field:SerializedName("UserType")
    val userType: UserType? = null
)

data class Status(

    @field:SerializedName("StatusId")
    val statusId: Int? = null,

    @field:SerializedName("Name")
    val name: String? = null
)

data class Template(

    @field:SerializedName("Title")
    val title: String? = null,

    @field:SerializedName("TemplateId")
    val templateId: String? = null
)

data class InspectionCompletedItem(

    @field:SerializedName("StartDate")
    val startDate: String? = null,

    @field:SerializedName("Status")
    val status: Status? = null,

    @field:SerializedName("Auditor")
    val auditor: Auditor? = null,

    @field:SerializedName("Auditee")
    val auditee: Auditee? = null,

    @field:SerializedName("AuditLocation")
    val auditLocation: AuditLocation? = null,

    @field:SerializedName("InspectionId")
    val inspectionId: String? = null,

    @field:SerializedName("DateCreated")
    val dateCreated: String? = null,

    @field:SerializedName("ScheduleId")
    val scheduleId: Any? = null,

    @field:SerializedName("EndDate")
    val endDate: String? = null,

    @field:SerializedName("DateModified")
    val dateModified: String? = null,

    @field:SerializedName("Template")
    val template: Template? = null
)
