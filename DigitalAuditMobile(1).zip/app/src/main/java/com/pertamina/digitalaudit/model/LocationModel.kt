package com.pertamina.digitalaudit.model

import com.google.gson.annotations.SerializedName
import com.pertamina.framework.base.BaseResponse

class LocationModel : BaseResponse() {

    @SerializedName("Result")
    var data: List<Location>? = null

    class Location : BaseItem() {
        @SerializedName("AuditLocationId")
        var auditLocationId: String? = ""

        @SerializedName("Name")
        var name: String? = ""

        @SerializedName("Address")
        var address: String? = ""

        @SerializedName("ZipCode")
        var zipCode: String? = ""

        @SerializedName("LatLong")
        var latLong: String? = ""

        @SerializedName("Region")
        var Region: RegionModel.Region? = null

        /**
         * Pay attention here, you have to override the toString method as the
         * ArrayAdapter will reads the toString of the given object for the name
         *
         * @return name
         */
        override fun toString(): String {
            return name.orEmpty()
        }
    }
}