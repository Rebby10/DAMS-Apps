package com.pertamina.digitalaudit.presentation.account

import android.view.View
import com.pertamina.framework.base.BaseView

/**
 * Created by M Hafidh Abdul Aziz on 03/03/21.
 */

interface AccountView : BaseView {
    fun onClickLogout(view: View)
}
