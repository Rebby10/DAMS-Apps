package com.pertamina.digitalaudit.repository.common

import com.pertamina.digitalaudit.model.ActionRepairMasterDataModel
import com.pertamina.digitalaudit.model.AuditTypeModel
import com.pertamina.digitalaudit.model.FAQMasterDataModel
import com.pertamina.digitalaudit.model.HomeOverviewModel
import com.pertamina.digitalaudit.model.InspectionModel
import com.pertamina.digitalaudit.model.IssueModel
import com.pertamina.digitalaudit.model.LocationModel
import com.pertamina.digitalaudit.model.PriorityModel
import com.pertamina.digitalaudit.model.RegionModel
import com.pertamina.digitalaudit.model.Reschedule
import com.pertamina.digitalaudit.model.ScheduleModel
import com.pertamina.digitalaudit.model.TemplateModel
import com.pertamina.digitalaudit.model.query.GetHomeOverviewQuery
import com.pertamina.digitalaudit.model.query.GetInspectionQuery
import com.pertamina.digitalaudit.model.query.GetIssueQuery
import com.pertamina.digitalaudit.model.query.GetLocationQuery
import com.pertamina.digitalaudit.model.query.GetRegionQuery
import com.pertamina.digitalaudit.model.query.GetRescheduleQuery
import com.pertamina.digitalaudit.model.query.GetScheduleQuery
import com.pertamina.digitalaudit.model.query.GetTemplateQuery
import com.pertamina.framework.ResponseHandler
import com.pertamina.framework.base.Resource

class CommonRepositoryImpl(
    private val commonService: CommonService,
    private val responseHandler: ResponseHandler
) : CommonRepository {

    override suspend fun getHomeIssueList(query: GetIssueQuery): Resource<List<IssueModel.Issue>> {
        try {
            val request = commonService.getHomeIssueList(
                query.userCreated,
                query.assignUser,
                query.title,
                query.pageSize,
                query.pageNumber,
                query.sortBy,
                query.orderBy
            )
            request.data.let {
                return responseHandler.setSuccess(it!!)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun getHomeScheduleList(query: GetScheduleQuery): Resource<List<ScheduleModel.Schedule>> {
        try {
            val request =
                commonService.getHomeScheduleList(
                    query.userId,
                    query.title,
                    query.pageSize,
                    query.pageNumber,
                    query.sortBy,
                    query.orderBy
                )
            request.data.let {
                return responseHandler.setSuccess(it!!)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun getHomeRescheduleList(query: GetRescheduleQuery): Resource<List<Reschedule>> {
        try {
            val request =
                commonService.getHomeRescheduleList(
                    query.userId,
                    query.title,
                    query.sortBy,
                    query.orderBy
                )
            request.result.let {
                return responseHandler.setSuccess(it!!)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun getHomeInspectionList(query: GetInspectionQuery): Resource<List<InspectionModel.Inspection>> {
        try {
            val request =
                commonService.getHomeInspectionList(
                    query.userCreated,
                    query.textSearch,
                    query.pageSize,
                    query.pageNumber,
                    query.sortBy,
                    query.orderBy
                )
            request.data.let {
                return responseHandler.setSuccess(it!!)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun getHomeOverview(query: GetHomeOverviewQuery): Resource<HomeOverviewModel> {
        try {
            val request =
                commonService.getHomeOverview(
                    query.userId,
                    query.roleId,
                    query.search,
                    query.pageSize,
                    query.pageNumber,
                    query.sortBy,
                    query.orderBy
                )
            request.let {
                return responseHandler.setSuccess(it)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun getFAQMasterData(): Resource<List<FAQMasterDataModel.FAQ>> {
        try {
            val request = commonService.getFAQMasterData()
            request.data.let {
                return responseHandler.setSuccess(it!!)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun getRegionMasterData(query: GetRegionQuery): Resource<List<RegionModel.Region>> {
        try {
            val request =
                commonService.getRegionMasterData(query.name, query.pageSize, query.pageNumber)
            request.data.let {
                return responseHandler.setSuccess(it!!)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun getActionRepairMasterData(): Resource<ActionRepairMasterDataModel.ActionRepairMasterData> {
        try {
            val request = commonService.getActionRepairMasterData()
            request.data.let {
                return responseHandler.setSuccess(it!!)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun getLocation(query: GetLocationQuery?): Resource<List<LocationModel.Location>> {
        try {
            val request =
                commonService.getLocationList(query?.name, query?.pageSize, query?.pageNumber)
            request.data.let {
                return responseHandler.setSuccess(it!!)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun getTemplate(query: GetTemplateQuery): Resource<List<TemplateModel.Template>> {
        try {
            val request =
                commonService.getTemplateList(query.title, query.pageSize, query.pageNumber)
            request.data.let {
                return responseHandler.setSuccess(it!!)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun getPriority(): Resource<List<PriorityModel.Priority>> {
        try {
            val request = commonService.getPriorityList()
            request.data.let {
                return responseHandler.setSuccess(it!!)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun getAuditType(): Resource<List<AuditTypeModel.AuditType>> {
        try {
            val request = commonService.getAuditTypeList()
            request.data.let {
                return responseHandler.setSuccess(it!!)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }
}
