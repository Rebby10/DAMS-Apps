package com.pertamina.digitalaudit.model.reportinspection

import com.google.gson.annotations.SerializedName

data class ReportChecklistResultResponse(

	@field:SerializedName("TotalResult")
	val totalResult: Int? = null,

	@field:SerializedName("TotalData")
	val totalData: Int? = null,

	@field:SerializedName("Result")
	val data: List<ReportChecklistResult>? = null
)

data class ReportChecklistResult(

	@field:SerializedName("PageId")
	val pageId: String? = null,

	@field:SerializedName("Descriptions")
	val descriptions: String? = null,

	@field:SerializedName("SeqNo")
	val seqNo: Int? = null,

	@field:SerializedName("Title")
	val title: String? = null,

	@field:SerializedName("Question")
	val question: List<QuestionItem>? = null,

	@field:SerializedName("Section")
	val section: List<SectionItem>? = null,

	@field:SerializedName("TemplateId")
	val templateId: String? = null
)
