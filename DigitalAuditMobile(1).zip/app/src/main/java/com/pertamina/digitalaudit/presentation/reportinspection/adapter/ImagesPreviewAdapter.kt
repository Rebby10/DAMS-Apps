package com.pertamina.digitalaudit.presentation.reportinspection.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.bumptech.glide.Glide
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.model.reportinspection.ImageLink
import com.pertamina.framework.base.BaseRecyclerViewAdapter
import com.pertamina.framework.base.BaseViewHolder
import kotlinx.android.synthetic.main.item_add_photo.view.*

class ImagesPreviewAdapter : BaseRecyclerViewAdapter<ImageLink>() {

    private var listener: ItemClickListener? = null

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BaseViewHolder<ImageLink> {
        val view = LayoutInflater.from(parent.context).inflate(viewType, parent, false)
        return ListViewHolder(parent.context, view, listener)
    }

    override fun onBindViewHolder(
        holder: BaseViewHolder<ImageLink>,
        position: Int
    ) {
        holder.bindData(getItem(position))
    }

    override fun getItemViewType(position: Int): Int {
        return R.layout.item_add_photo
    }

    class ListViewHolder(context: Context, val view: View, listener: ItemClickListener?) :
        BaseViewHolder<ImageLink>(context, view) {

        private var holderListener: ItemClickListener? = listener
        private var ivAddedPhoto = view.ivAddedPhoto

        override fun bindData(data: ImageLink) {
            Glide.with(context).load(data.link)
                .into(ivAddedPhoto)
            ivAddedPhoto.setOnClickListener {
                holderListener?.onClickItem(data.link.orEmpty())
            }
        }
    }

    fun setItemClickListener(listener: ItemClickListener) {
        this.listener = listener
    }

    interface ItemClickListener {
        fun onClickItem(url: String)
    }
}