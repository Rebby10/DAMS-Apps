package com.pertamina.digitalaudit.presentation.startinspection.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.bumptech.glide.Glide
import com.pertamina.digitalaudit.R
import com.pertamina.framework.base.BaseRecyclerViewAdapter
import com.pertamina.framework.base.BaseViewHolder
import kotlinx.android.synthetic.main.item_image_preview.view.*

class ImagePreviewByLinkAdapter : BaseRecyclerViewAdapter<String>() {

    private var listener: ImageClickListener? = null

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BaseViewHolder<String> {
        val view = LayoutInflater.from(parent.context).inflate(viewType, parent, false)
        return ListViewHolder(parent.context, view, listener)
    }

    override fun onBindViewHolder(
        holder: BaseViewHolder<String>,
        position: Int
    ) {
        holder.bindData(getItem(position))
    }

    override fun getItemViewType(position: Int): Int {
        return R.layout.item_image_preview
    }

    class ListViewHolder(context: Context, val view: View, listener: ImageClickListener?) :
        BaseViewHolder<String>(context, view) {

        private lateinit var data: String
        private var holderListener: ImageClickListener? = listener
        private var ivAddedPhoto = view.ivImageSelected
        private var ivDelete = view.ivDelete

        override fun bindData(data: String) {
            this.data = data
            Glide.with(context).load(data)
                .centerCrop()
                .into(ivAddedPhoto)
            itemView.setOnClickListener {
                holderListener?.onClickImage(adapterPosition, data)
            }
            ivDelete.visibility = View.GONE
        }
    }

    fun setOnImageClickListener(listener: ImageClickListener) {
        this.listener = listener
    }

    interface ImageClickListener {
        fun onClickImage(position: Int, image: String)
    }
}