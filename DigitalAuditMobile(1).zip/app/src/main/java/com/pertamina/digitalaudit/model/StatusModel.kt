package com.pertamina.digitalaudit.model

import com.google.gson.annotations.SerializedName
import com.pertamina.framework.base.BaseResponse
import java.io.Serializable

class StatusModel : BaseResponse() {

    @SerializedName("Result")
    var data: List<Status>? = null

    class Status: Serializable {
        @SerializedName("StatusId")
        var statusId: Int? = 0

        @SerializedName("Name")
        var name: String? = ""
    }
}