package com.pertamina.digitalaudit.presentation.notification

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.databinding.ActivityNotificationBinding
import com.pertamina.framework.ViewDataBindingOwner
import com.pertamina.framework.base.BaseActivity
import kotlinx.android.synthetic.main.toolbar_layout.*
import org.koin.androidx.viewmodel.ext.android.viewModel

/**
 * Created by M Hafidh Abdul Aziz on 19/03/21.
 */

class NotificationActivity : BaseActivity<NotificationViewModel>(), NotificationView,
    ViewDataBindingOwner<ActivityNotificationBinding> {

    override val layoutResourceId: Int = R.layout.activity_notification
    override val viewModel: NotificationViewModel by viewModel()
    override var binding: ActivityNotificationBinding? = null

    companion object {

        fun startThisActivity(context: Context) {
            val intent = Intent(context, NotificationActivity::class.java)
            context.startActivity(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupToolbar()
    }

    override fun setupToolbar() {
        tvTitleToolbar.text = getString(R.string.title_notification)
        btnBackToolbar.apply {
            visibility = View.VISIBLE
            setImageResource(R.drawable.ic_close)
            setOnClickListener {
                onBackPressed()
            }
        }
    }
}
