package com.pertamina.digitalaudit.presentation.createinspection

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.databinding.ActivityCreateInspectionBinding
import com.pertamina.digitalaudit.model.UserAssignModel
import com.pertamina.digitalaudit.presentation.login.LoginActivity
import com.pertamina.digitalaudit.presentation.search.SearchActivity
import com.pertamina.digitalaudit.util.SnackBar
import com.pertamina.digitalaudit.util.ViewUtils
import com.pertamina.framework.NetworkState
import com.pertamina.framework.ViewDataBindingOwner
import com.pertamina.framework.base.BaseActivity
import kotlinx.android.synthetic.main.activity_create_inspection.*
import kotlinx.android.synthetic.main.toolbar_layout.*
import org.koin.androidx.viewmodel.ext.android.viewModel

class CreateInspectionActivity : BaseActivity<CreateInspectionViewModel>(), CreateInspectionView,
    ViewDataBindingOwner<ActivityCreateInspectionBinding> {

    override val layoutResourceId: Int = R.layout.activity_create_inspection
    override val viewModel: CreateInspectionViewModel by viewModel()
    override var binding: ActivityCreateInspectionBinding? = null

    private var chooseLocationLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val locationId = result.data?.getStringExtra(SearchActivity.EXTRA_LOCATION_ID)
                val locationName = result.data?.getStringExtra(SearchActivity.EXTRA_LOCATION_NAME)
                viewModel.createInspectionLocationId.value = locationId
                viewModel.bTextCreateInspectionLocation.value = locationName
                tvCreateInspectionLocationError?.visibility = View.GONE
            }
        }

    private var chooseTemplateLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val templateId = result.data?.getStringExtra(SearchActivity.EXTRA_TEMPLATE_ID)
                val templateTitle = result.data?.getStringExtra(SearchActivity.EXTRA_TEMPLATE_TITLE)
                viewModel.createInspectionAuditTypeTemplateId.value = templateId
                viewModel.bTextCreateInspectionAuditTypeTemplate.value = templateTitle
                tvCreateInspectionAuditTypeTemplateError?.visibility = View.GONE
            }
        }

    private var chooseAuditeeLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val user: UserAssignModel.UserAssign? =
                    result.data?.getSerializableExtra(SearchActivity.EXTRA_USER_DATA) as UserAssignModel.UserAssign?
                user?.let {
                    viewModel.bTextCreateInspectionAssignAuditeeName.value =
                        it.displayName.orEmpty()
                    tvCreateInspectionAssignAuditorError?.visibility = View.GONE
                    if (it.isGroup == true) {
                        viewModel.createInspectionAssignAuditeeGroupId.value = it.id.orEmpty()
                    } else {
                        viewModel.createInspectionAssignAuditeeUserId.value = it.id.orEmpty()
                    }
                }
            }
        }

    private var chooseAuditorLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val user: UserAssignModel.UserAssign? =
                    result.data?.getSerializableExtra(SearchActivity.EXTRA_USER_DATA) as UserAssignModel.UserAssign?
                user?.let {
                    viewModel.bTextCreateInspectionAssignAuditorName.value =
                        it.displayName.orEmpty()
                    tvCreateInspectionAssignAuditeeError?.visibility = View.GONE
                    if (it.isGroup == true) {
                        viewModel.createInspectionAssignAuditorGroupId.value = it.id.orEmpty()
                    } else {
                        viewModel.createInspectionAssignAuditorUserId.value = it.id.orEmpty()
                    }
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupToolbar()
        observeCreateInspection()
    }

    private fun setupToolbar() {
        tvTitleToolbar.text = getString(R.string.inspection_create_title)
        btnBackToolbar.apply {
            visibility = View.VISIBLE
            setImageResource(R.drawable.ic_close)
            setOnClickListener {
                onBackPressed()
            }
        }
    }

    private fun observeCreateInspection() {
        observeData(viewModel.createInspectionResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        setResult(RESULT_OK)
                        finish()
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message ?: getString(R.string.general_server_error_message)
                        )
                        when (it.code) {
                            401 -> {
                                viewModel.preference.clearPreferences()
                                logout(Intent(this, LoginActivity::class.java))
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onClickCreateInspection(view: View) {
        var isValid = true
        if (viewModel.bTextCreateInspectionAssignAuditeeName.value.isNullOrEmpty()) {
            isValid = false
            tvCreateInspectionAssignAuditeeError?.visibility = View.VISIBLE
        }

        if (viewModel.bTextCreateInspectionAssignAuditorName.value.isNullOrEmpty()) {
            isValid = false
            tvCreateInspectionAssignAuditorError?.visibility = View.VISIBLE
        }

        if (viewModel.bTextCreateInspectionLocation.value.isNullOrEmpty()) {
            isValid = false
            tvCreateInspectionLocationError?.visibility = View.VISIBLE
        }

        if (viewModel.bTextCreateInspectionAuditTypeTemplate.value.isNullOrEmpty()) {
            isValid = false
            tvCreateInspectionAuditTypeTemplateError?.visibility = View.VISIBLE
        }

        if (isValid) {
            ViewUtils.hideKeyboard(this, view)
            viewModel.createNewInspection()
        }
    }

    override fun onClickChooseLocation(view: View) {
        val intent = Intent(this, SearchActivity::class.java)
        intent.putExtra(SearchActivity.EXTRA_TITLE, getString(R.string.choose_location))
        intent.putExtra(SearchActivity.EXTRA_IS_SEARCH_LOCATION, true)
        chooseLocationLauncher.launch(intent)
    }

    override fun onClickChooseAuditTypeTemplate(view: View) {
        val intent = Intent(this, SearchActivity::class.java)
        intent.putExtra(SearchActivity.EXTRA_TITLE, getString(R.string.choose_audit_template))
        intent.putExtra(SearchActivity.EXTRA_IS_SEARCH_TEMPLATE, true)
        chooseTemplateLauncher.launch(intent)
    }

    override fun onClickChooseAuditor(view: View) {
        val intent = Intent(this, SearchActivity::class.java)
        intent.putExtra(SearchActivity.EXTRA_FROM_ISSUE, true)
        intent.putExtra(SearchActivity.EXTRA_TITLE, getString(R.string.choose_auditor))
        intent.putExtra(SearchActivity.EXTRA_IS_SEARCH_USER, true)
        chooseAuditorLauncher.launch(intent)
    }

    override fun onClickChooseAuditee(view: View) {
        val intent = Intent(this, SearchActivity::class.java)
        intent.putExtra(SearchActivity.EXTRA_FROM_ISSUE, true)
        intent.putExtra(SearchActivity.EXTRA_TITLE, getString(R.string.choose_auditee))
        intent.putExtra(SearchActivity.EXTRA_IS_SEARCH_USER, true)
        chooseAuditeeLauncher.launch(intent)
    }
}
