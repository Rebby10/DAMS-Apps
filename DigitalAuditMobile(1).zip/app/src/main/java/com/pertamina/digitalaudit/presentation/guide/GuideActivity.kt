package com.pertamina.digitalaudit.presentation.guide

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.View
import android.webkit.*
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.databinding.ActivityGuideBinding
import com.pertamina.framework.ViewDataBindingOwner
import com.pertamina.framework.base.BaseActivity
import kotlinx.android.synthetic.main.activity_guide.*
import kotlinx.android.synthetic.main.toolbar_layout.*
import org.koin.androidx.viewmodel.ext.android.viewModel

/**
 * Created by M Hafidh Abdul Aziz on 16/03/21.
 */

class GuideActivity : BaseActivity<GuideViewModel>(), GuideView,
    ViewDataBindingOwner<ActivityGuideBinding> {

    override val layoutResourceId: Int = R.layout.activity_guide
    override val viewModel: GuideViewModel by viewModel()
    override var binding: ActivityGuideBinding? = null

    companion object {

        fun startThisActivity(context: Context) {
            val intent = Intent(context, GuideActivity::class.java)
            context.startActivity(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupToolbar()
        initWebViewContainer()
    }

    private fun setupToolbar() {
        tvTitleToolbar.text = getString(R.string.title_guide)
        btnBackToolbar.apply {
            visibility = View.VISIBLE
            setOnClickListener {
                onBackPressed()
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun initWebViewContainer() {
        wvIssueGuide.settings.apply {
            allowFileAccess = false
            javaScriptEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = true
            displayZoomControls = false
        }
        wvIssueGuide.setInitialScale(1)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            wvIssueGuide.settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }

        wvIssueGuide.webViewClient = AuditMobileWebViewClient(this, viewModel)
        wvIssueGuide.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(consoleMessage: ConsoleMessage): Boolean {
                return true
            }

            override fun onJsConfirm(
                view: WebView,
                url: String,
                message: String,
                result: JsResult
            ): Boolean {
                return true
            }
        }
        wvIssueGuide.loadUrl("url guide") //todo url guide
    }

    class AuditMobileWebViewClient(
        activity: GuideActivity,
        viewModel: GuideViewModel
    ) : WebViewClient() {

        private val activity: GuideActivity?
        private val viewModel: GuideViewModel?

        init {
            this.activity = activity
            this.viewModel = viewModel
        }

        override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
            view.loadUrl(url)
            return true
        }

        override fun onPageFinished(view: WebView, url: String) {
            super.onPageFinished(view, url)
            if (activity != null) {
                viewModel?.showProgressBar?.value = false
            }
        }
    }
}
