package com.pertamina.digitalaudit.presentation.actionofissue

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.databinding.ActivityActionOfIssueBinding
import com.pertamina.digitalaudit.presentation.chat.ChatActivity
import com.pertamina.digitalaudit.presentation.home.adapter.ActionsAdapter
import com.pertamina.digitalaudit.util.SnackBar
import com.pertamina.framework.NetworkState
import com.pertamina.framework.ViewDataBindingOwner
import com.pertamina.framework.base.BaseActivity
import kotlinx.android.synthetic.main.activity_action_of_issue.*
import kotlinx.android.synthetic.main.layout_empty_state.*
import kotlinx.android.synthetic.main.toolbar_layout.*
import org.koin.androidx.viewmodel.ext.android.viewModel

class ActionOfIssueActivity : BaseActivity<ActionOfIssueViewModel>(), ActionOfIssueView,
    ViewDataBindingOwner<ActivityActionOfIssueBinding> {

    override val layoutResourceId: Int = R.layout.activity_action_of_issue
    override val viewModel: ActionOfIssueViewModel by viewModel()
    override var binding: ActivityActionOfIssueBinding? = null

    private var actionAdapter: ActionsAdapter? = null

    companion object {

        private const val EXTRA_ISSUE_ID = "EXTRA_ISSUE_ID"

        fun startThisActivity(context: Context, issueId: String) {
            val intent = Intent(context, ActionOfIssueActivity::class.java)
            intent.putExtra(EXTRA_ISSUE_ID, issueId)
            context.startActivity(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupToolbar()
        getExtraData()
        setupRv()
        getActionOfIssue()

        observeActionOfIssue()
    }

    private fun setupToolbar() {
        tvTitleToolbar.text = getString(R.string.actions_of_issues)
        btnBackToolbar.apply {
            visibility = View.VISIBLE
            setOnClickListener {
                onBackPressed()
            }
        }
    }

    private fun getExtraData() {
        viewModel.issueId = intent?.getStringExtra(EXTRA_ISSUE_ID).orEmpty()
    }

    private fun setupRv() {
        actionAdapter = ActionsAdapter()
        actionAdapter?.setActionsClickListener(object : ActionsAdapter.ActionsClickListener {
            override fun onClickActions(actionsId: String, actionTitle: String) {
                ChatActivity.startThisActivityFromAction(
                    this@ActionOfIssueActivity,
                    actionsId, actionTitle
                )
            }
        })
        val manager = LinearLayoutManager(this)
        rvAction.apply {
            layoutManager = manager
            setHasFixedSize(true)
            adapter = actionAdapter
        }
    }

    private fun getActionOfIssue() {
        viewModel.getActionOfIssue()
    }

    private fun observeActionOfIssue() {
        observeData(viewModel.actionOfIssueResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { actions ->
                            if (actions.isNotEmpty()) {
                                viewModel.showEmptyState.value = false
                                actionAdapter?.setData(actions)
                            } else {
                                viewModel.showEmptyState.value = true
                                tvEmptyMessage.text = getString(R.string.actions_empty)
                            }
                        }
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message
                                ?: getString(R.string.general_server_error_message)
                        )
                    }
                }
            }
        }
    }
}