package com.pertamina.digitalaudit.model.body

import com.google.gson.annotations.SerializedName
import java.io.File

data class UploadInspectionFileReqBody(
        @SerializedName("InspectionId")
    var inspectionId: String,
        @SerializedName("QuestionId")
    var questionId: Int,
        @SerializedName("File")
    var files: List<File>,
        @SerializedName("FileTypeId")
    var fileTypeId: Int,
        @SerializedName("UserCreated")
    var userCreated: String
)