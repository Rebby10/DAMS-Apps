package com.pertamina.digitalaudit.preference

import android.content.SharedPreferences
import com.pertamina.digitalaudit.model.UserModel

class PreferenceProvider(val preference: SharedPreferences) {

    fun setStringToPreference(key: SharedPreferencesKey, value: String?) {
        preference.edit().putString(key.toString(), value).apply()
    }

    fun getStringFromPreference(key: SharedPreferencesKey): String? {
        return preference.getString(key.toString(), "")
    }

    fun setIntToPreference(key: SharedPreferencesKey, value: Int) {
        preference.edit().putInt(key.toString(), value).apply()
    }

    fun getIntFromPreference(key: SharedPreferencesKey): Int {
        return preference.getInt(key.toString(), 0)
    }

    fun setLongToPreference(key: SharedPreferencesKey, value: Long) {
        preference.edit().putLong(key.toString(), value).apply()
    }

    fun getLongFromPreference(key: SharedPreferencesKey, defaultValue: Long): Long {
        return preference.getLong(key.toString(), defaultValue)
    }

    fun setBooleanToPreference(key: SharedPreferencesKey, value: Boolean) {
        preference.edit().putBoolean(key.toString(), value).apply()
    }

    fun getBooleanFromPreference(key: SharedPreferencesKey,
                                 defaultValue: Boolean? = false): Boolean {
        return preference.getBoolean(key.toString(), defaultValue!!)
    }

    fun clearPreferences() {
        preference.edit().clear().apply()
    }

    fun setAuthPreferences(user: UserModel.User?) {
        user ?: return
        setStringToPreference(SharedPreferencesKey.USER_ID, user.userId)
        setStringToPreference(SharedPreferencesKey.DISPLAY_NAME, user.name)
        setStringToPreference(SharedPreferencesKey.USER_EMAIL, user.email)
        setStringToPreference(SharedPreferencesKey.USER_PHOTO_URL, user.photoUrl)
        setStringToPreference(SharedPreferencesKey.USER_OFFICE_LOCATION, user.officeLocation ?: "-")
        setStringToPreference(SharedPreferencesKey.USER_COMPANY_NAME, user.companyName ?: "-")
        setStringToPreference(SharedPreferencesKey.USER_JOB_TITLE, user.jobTitle ?: "-")
        setStringToPreference(SharedPreferencesKey.USER_DEPARTMENT, user.department ?: "-")
    }

    fun getAuthPreferences(): UserModel.User {
        val user = UserModel.User()
        user.userId = getStringFromPreference(SharedPreferencesKey.USER_ID)
        user.name = getStringFromPreference(SharedPreferencesKey.DISPLAY_NAME)
        user.email = getStringFromPreference(SharedPreferencesKey.USER_EMAIL)
        user.photoUrl = getStringFromPreference(SharedPreferencesKey.USER_PHOTO_URL)
        user.officeLocation = getStringFromPreference(SharedPreferencesKey.USER_OFFICE_LOCATION)
        user.companyName = getStringFromPreference(SharedPreferencesKey.USER_COMPANY_NAME)
        user.jobTitle = getStringFromPreference(SharedPreferencesKey.USER_JOB_TITLE)
        user.department = getStringFromPreference(SharedPreferencesKey.USER_DEPARTMENT)
        return user
    }

    fun clearAuthPreferences() {
        setStringToPreference(SharedPreferencesKey.USER_ID, null)
        setStringToPreference(SharedPreferencesKey.USER_NAME, null)
        setStringToPreference(SharedPreferencesKey.USER_EMAIL, null)
        setStringToPreference(SharedPreferencesKey.FIREBASE_TOKEN_ID, null)
    }
}
