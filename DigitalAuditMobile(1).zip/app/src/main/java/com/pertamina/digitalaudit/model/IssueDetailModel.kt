package com.pertamina.digitalaudit.model

import com.google.gson.annotations.SerializedName
import com.pertamina.framework.base.BaseResponse
import java.io.Serializable

/**
 * Created by M Hafidh Abdul Aziz on 28/03/21.
 */

class IssueDetailModel : BaseResponse() {

    @SerializedName("Result")
    var data: IssueDetail? = null

    class IssueDetail : Serializable {
        @SerializedName("IssueId")
        var issueId: String? = ""

        @SerializedName("Title")
        var title: String? = ""

        @SerializedName("Descriptions")
        var descriptions: String? = ""

        @SerializedName("QuestionId")
        var questionId: String? = ""

        @SerializedName("Code")
        var code: String? = ""

        @SerializedName("Question")
        var question: String? = ""

        @SerializedName("TargetClosing")
        var targetClosing: String? = ""

        @SerializedName("RecurringFinding")
        var recurringFinding: Int? = 0

        @SerializedName("UserCreated")
        var userCreated: String? = ""

        @SerializedName("DateCreated")
        var dateCreated: String? = ""

        @SerializedName("UserModified")
        var userModified: String? = ""

        @SerializedName("DateModified")
        var dateModified: String? = ""

        @SerializedName("LastUpdate")
        var lastUpdate: String? = ""

        @SerializedName("AuditType")
        var auditType: AuditTypeModel.AuditType? = null

        @SerializedName("IssueCategory")
        var issueCategory: IssueCategoryModel.IssueCategory? = null

        @SerializedName("AuditLocation")
        var auditLocation: AuditLocationModel.AuditLocation? = null

        @SerializedName("AssignGroup")
        var assignGroup: AssignGroupModel.AssignGroup? = null

        @SerializedName("AssignUser")
        var assignUser: AssignUserModel.AssignUser? = null

        @SerializedName("Creator")
        var creator: CreatorModel.Creator? = null

        @SerializedName("Priority")
        var priority: PriorityModel.Priority? = null

        @SerializedName("Status")
        var status: StatusModel.Status? = null

        @SerializedName("IsConnectedToAction")
        var isConnectedToAction: Boolean = false
    }
}
