package com.pertamina.digitalaudit.presentation.startinspection.actionpage

import androidx.lifecycle.MutableLiveData
import com.pertamina.digitalaudit.model.ActionModel
import com.pertamina.digitalaudit.model.query.GetActionQuery
import com.pertamina.digitalaudit.repository.actions.ActionsRepository
import com.pertamina.framework.base.BaseViewModel
import com.pertamina.framework.base.Resource
import kotlinx.coroutines.launch

class ActionsViewModel(
    private val actionsRepository: ActionsRepository
) : BaseViewModel() {

    val showProgressBar = MutableLiveData(false)
    val showEmptyState = MutableLiveData(false)
    val isFromReport = MutableLiveData(false)

    val actionsResponse = MutableLiveData<Resource<List<ActionModel.Action>>>()
    val deletedActionResponse = MutableLiveData<Resource<ActionModel>>()

    var inspectionId: String? = null
    var questionId: String? = null

    fun getActionsList() {
        val query = GetActionQuery()
        query.inspectionId = inspectionId
        query.questionId = questionId
        showProgressBar.value = true
        launch {
            val request = actionsRepository.getActionList(query)
            actionsResponse.value = request
            showProgressBar.value = false
        }
    }

    fun deleteSelectedAction(actionId: String) {
        showProgressBar.value = true
        launch {
            val request = actionsRepository.deleteAction(actionId)
            deletedActionResponse.value = request
            showProgressBar.value = false
        }
    }
}
