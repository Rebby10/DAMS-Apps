package com.pertamina.digitalaudit.presentation.map

import androidx.lifecycle.MutableLiveData
import com.pertamina.digitalaudit.model.InspectionModel
import com.pertamina.digitalaudit.model.IssueModel
import com.pertamina.digitalaudit.model.Reschedule
import com.pertamina.digitalaudit.model.ScheduleModel
import com.pertamina.digitalaudit.model.UserModel
import com.pertamina.digitalaudit.model.query.GetInspectionQuery
import com.pertamina.digitalaudit.model.query.GetIssueQuery
import com.pertamina.digitalaudit.model.query.GetRescheduleQuery
import com.pertamina.digitalaudit.model.query.GetScheduleQuery
import com.pertamina.digitalaudit.preference.PreferenceProvider
import com.pertamina.digitalaudit.repository.common.CommonRepository
import com.pertamina.digitalaudit.util.CommonConstant
import com.pertamina.framework.base.BaseViewModel
import com.pertamina.framework.base.Resource
import kotlinx.coroutines.launch

/**
 * Created by M Hafidh Abdul Aziz on 12/03/21.
 */

class MapViewModel(
    private val commonRepository: CommonRepository,
    val preference: PreferenceProvider
) : BaseViewModel() {

    companion object {
        const val SCHEDULE = 0
        const val RESCHEDULE = 1
    }

    val isLoading = MutableLiveData(false)
    val showEmptyState = MutableLiveData(false)
    val isIssueReportByMeState = MutableLiveData(false)
    val isIssueAssignToMeState = MutableLiveData(false)
    val isScheduleState = MutableLiveData(false)
    val isRescheduleState = MutableLiveData(false)
    private val isInspectionState = MutableLiveData(false)

    var bTextSearch = MutableLiveData("")

    val issueListResponse = MutableLiveData<Resource<List<IssueModel.Issue>>>()
    val scheduleListResponse = MutableLiveData<Resource<List<ScheduleModel.Schedule>>>()
    val rescheduleListResponse = MutableLiveData<Resource<List<Reschedule>>>()
    val inspectionListResponse = MutableLiveData<Resource<List<InspectionModel.Inspection>>>()

    var user = UserModel.User()

    fun getUserData() {
        user = preference.getAuthPreferences()
    }

    fun getIssue(search: String?) {
        val query = GetIssueQuery()
        if (isIssueReportByMeState.value == true) {
            query.userCreated = user.userId
        } else if (isIssueAssignToMeState.value == true) {
            query.assignUser = user.userId
        }
        query.title = search
        query.sortBy = CommonConstant.SORT_BY_DATE_CREATED
        query.orderBy = CommonConstant.ORDER_BY_DESC
        isLoading.value = true
        launch {
            val request = commonRepository.getHomeIssueList(query)
            issueListResponse.value = request
            isLoading.value = false
        }
    }

    fun getSchedule(search: String?) {
        val query = GetScheduleQuery()
        query.userId = user.userId
        query.title = search
        query.orderBy = CommonConstant.ORDER_BY_DESC
        isLoading.value = true
        launch {
            val request = commonRepository.getHomeScheduleList(query)
            scheduleListResponse.value = request
            isLoading.value = false
        }
    }

    fun getReschedule(search: String?) {
        val query = GetRescheduleQuery()
        query.userId = user.userId
        query.title = search
        query.orderBy = CommonConstant.ORDER_BY_DESC
        isLoading.value = true
        launch {
            val request = commonRepository.getHomeRescheduleList(query)
            rescheduleListResponse.value = request
            isLoading.value = false
        }
    }

    fun getInspection(search: String?) {
        val query = GetInspectionQuery().apply {
            userCreated = user.userId
            textSearch = search
        }
        isLoading.value = true
        launch {
            val request = commonRepository.getHomeInspectionList(query)
            inspectionListResponse.value = request
            isLoading.value = false
        }
    }

    fun setState(
        isIssueReportByMe: Boolean = false,
        isIssueAssignToMe: Boolean = false,
        isSchedule: Boolean = false,
        isReschedule: Boolean = false,
        isInspection: Boolean = false
    ) {
        isIssueReportByMeState.value = isIssueReportByMe
        isIssueAssignToMeState.value = isIssueAssignToMe
        isScheduleState.value = isSchedule
        isRescheduleState.value = isReschedule
        isInspectionState.value = isInspection
        showEmptyState.value = false
    }
}
