package com.pertamina.digitalaudit.presentation.actiondetail

import android.view.View
import com.pertamina.framework.base.BaseView

interface ActionDetailView : BaseView {
    fun onClickEditAction(view: View)
    fun onClickChangeActionStatus(view: View)
    fun onClickCreateActionRepair(view: View)
    fun onClickSaveAction(view: View)
}
