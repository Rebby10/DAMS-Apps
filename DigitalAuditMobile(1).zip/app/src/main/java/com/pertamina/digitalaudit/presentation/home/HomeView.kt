package com.pertamina.digitalaudit.presentation.home

import android.view.View
import com.pertamina.framework.base.BaseView

interface HomeView : BaseView {
    fun onClickLoadMoreIssue(view: View)
    fun onClickLoadMoreSchedule(view: View)
    fun onClickLoadMoreInspection(view: View)
}
