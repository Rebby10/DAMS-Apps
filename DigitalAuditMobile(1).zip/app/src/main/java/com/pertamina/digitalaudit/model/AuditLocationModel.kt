package com.pertamina.digitalaudit.model

import com.google.gson.annotations.SerializedName
import com.pertamina.framework.base.BaseResponse
import java.io.Serializable

class AuditLocationModel : BaseResponse() {

    @SerializedName("Result")
    var data: List<AuditLocation>? = null

    class AuditLocation: Serializable {
        @SerializedName("AuditLocationId")
        var auditLocationId: String? = ""

        @SerializedName("Name")
        var name: String? = ""

        @SerializedName("Address")
        var address: String? = ""

        @SerializedName("ZipCode")
        var zipCode: String? = ""

        @SerializedName("LatLong")
        var latLong: String? = ""

        @SerializedName("Region")
        var region: RegionModel.Region? = null
    }
}
