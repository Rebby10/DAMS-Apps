package com.pertamina.digitalaudit.presentation.actionrepair

import androidx.lifecycle.MutableLiveData
import com.pertamina.digitalaudit.model.ActionRepairMasterDataModel
import com.pertamina.digitalaudit.model.ActionRepairModel
import com.pertamina.digitalaudit.model.body.ActionRepairReqBody
import com.pertamina.digitalaudit.preference.PreferenceProvider
import com.pertamina.digitalaudit.repository.actions.ActionsRepository
import com.pertamina.digitalaudit.repository.common.CommonRepository
import com.pertamina.framework.base.BaseViewModel
import com.pertamina.framework.base.Resource
import kotlinx.coroutines.launch
import java.io.File

class ActionRepairViewModel(
    private val actionsRepository: ActionsRepository,
    private val commonRepository: CommonRepository,
    val preference: PreferenceProvider
) : BaseViewModel() {

    val showProgressBar = MutableLiveData(false)
    var bTextRepairCause = MutableLiveData("")
    var bTextRepairAction = MutableLiveData("")
    var bTextRepairDate = MutableLiveData("")
    var bTextRepairFileName = MutableLiveData("")

    var actionRepairCategoryId = MutableLiveData<String?>(null)
    var rootCauseCategoryId = MutableLiveData<String?>(null)

    val actionRepairResponse = MutableLiveData<Resource<ActionRepairModel>>()
    val actionRepairMasterDataResponse =
        MutableLiveData<Resource<ActionRepairMasterDataModel.ActionRepairMasterData>>()

    var actionId: String = ""

    fun saveRepairAction(file: File) {
        showProgressBar.value = true
        launch {
            val request = actionsRepository.saveActionRepair(
                ActionRepairReqBody(
                    actionId = actionId,
                    rootCause = bTextRepairCause.value.orEmpty(),
                    rootCauseCategoryId = rootCauseCategoryId.value.orEmpty(),
                    actionRepair = bTextRepairAction.value.orEmpty(),
                    actionRepairCategoryId = actionRepairCategoryId.value.orEmpty(),
                    repairDate = bTextRepairDate.value.orEmpty()
                ), file
            )
            actionRepairResponse.value = request
            showProgressBar.value = false
        }
    }

    fun getActionRepairMasterData() {
        showProgressBar.value = true
        launch {
            val request = commonRepository.getActionRepairMasterData()
            actionRepairMasterDataResponse.value = request
            showProgressBar.value = false
        }
    }

    fun getSelectedActionRepairCategorySpinnerItemPosition(): Int {
        val prevSelected = actionRepairCategoryId.value
        prevSelected.let {
            actionRepairMasterDataResponse.value?.data?.actionRepairCategory?.let { list ->
                val data = list.toMutableList()
                return list.indexOf(data.find { it.id == prevSelected })
            }
        }
        return 0
    }

    fun getSelectedRootCauseCategorySpinnerItemPosition(): Int {
        val prevSelected = rootCauseCategoryId.value
        prevSelected.let {
            actionRepairMasterDataResponse.value?.data?.rootCauseCategory?.let { list ->
                val data = list.toMutableList()
                return list.indexOf(data.find { it.id == prevSelected })
            }
        }
        return 0
    }

}
