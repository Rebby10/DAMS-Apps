package com.pertamina.digitalaudit.presentation.chat

import android.view.View
import com.pertamina.framework.base.BaseView

/**
 * Created by M Hafidh Abdul Aziz on 20/03/21.
 */

interface ChatView : BaseView {
    fun onClickAddAttachment(view: View)
    fun onClickSendChat(view: View)
    fun onClickGuide(view: View)
    fun onClickDetail(view: View)
}
