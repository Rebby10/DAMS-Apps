package com.pertamina.digitalaudit.repository.inspection

import com.pertamina.digitalaudit.model.InspectionModel
import com.pertamina.digitalaudit.model.IssueModel
import com.pertamina.digitalaudit.model.body.CreateInspectionReqBody
import com.pertamina.digitalaudit.model.body.InspectionResultReqBody
import com.pertamina.digitalaudit.model.body.SubmitInspectionInfoReqBody
import com.pertamina.digitalaudit.model.body.SubmitInspectionSignatureReqBody
import com.pertamina.digitalaudit.model.body.UploadInspectionFileReqBody
import com.pertamina.digitalaudit.model.query.GetInspectionFileQuery
import com.pertamina.digitalaudit.model.query.GetInspectionQuery
import com.pertamina.digitalaudit.model.reportinspection.ReportChecklistResultResponse
import com.pertamina.digitalaudit.model.reportinspection.ReportOverviewResponse
import com.pertamina.digitalaudit.model.reportinspection.ReportSummaryResponse
import com.pertamina.digitalaudit.model.reportinspection.ReportTitlePageResponse
import com.pertamina.digitalaudit.model.startinspection.*
import com.pertamina.framework.base.BaseResponse
import com.pertamina.framework.base.Resource
import okhttp3.ResponseBody

interface InspectionRepository {

    @Throws(Exception::class)
    suspend fun getInspectionList(query: GetInspectionQuery): Resource<List<InspectionModel.Inspection>>

    @Throws(Exception::class)
    suspend fun createNewInspection(reqBody: CreateInspectionReqBody): Resource<InspectionModel.Inspection>

    @Throws(Exception::class)
    suspend fun startInspection(inspectionId: String): Resource<StartInspectionResponseModel>

    @Throws(Exception::class)
    suspend fun startInspectionIssue(inspectionId: String): Resource<List<IssueModel.Issue>>

    @Throws(Exception::class)
    suspend fun getInspectionByPage(
        inspectionId: String,
        pageId: String
    ): Resource<InspectionPageResponse>

    @Throws(Exception::class)
    suspend fun startInspectionPageList(inspectionId: String): Resource<List<InspectionPage>>

    @Throws(Exception::class)
    suspend fun getInspectionFile(query: GetInspectionFileQuery): Resource<InspectionModel>

    @Throws(Exception::class)
    suspend fun downloadFile(fileUrl: String): Resource<ResponseBody>

    @Throws(Exception::class)
    suspend fun uploadInspectionFile(reqBody: UploadInspectionFileReqBody): Resource<BaseResponse>

    @Throws(Exception::class)
    suspend fun getAllImageFile(inspectionId: String, questionId: Int, typeId: Int): Resource<ImageFileInspection>

    @Throws(Exception::class)
    suspend fun deleteInspectionFile(fileId: String): Resource<InspectionModel>

    @Throws(Exception::class)
    suspend fun submitInspectionInfo(reqBody: SubmitInspectionInfoReqBody): Resource<InspectionAddInfoResponse>

    @Throws(Exception::class)
    suspend fun getInspectionInfo(inspectionId: String): Resource<List<InspectionInfo>>

    @Throws(Exception::class)
    suspend fun getInspectionSignature(inspectionId: String): Resource<InspectionModel>

    @Throws(Exception::class)
    suspend fun submitInspectionSignature(reqBody: SubmitInspectionSignatureReqBody): Resource<InspectionModel>

    @Throws(Exception::class)
    suspend fun deleteInspectionSignature(signatureId: String): Resource<InspectionModel>

    @Throws(Exception::class)
    suspend fun sendInspectionResult(reqBody: InspectionResultReqBody): Resource<AnswerInspectionResultResponse>

    @Throws(Exception::class)
    suspend fun completeInspection(inspectionId: String): Resource<List<InspectionCompletedItem>>

    @Throws(Exception::class)
    suspend fun getInspectionReportOverview(inspectionId: String): Resource<ReportOverviewResponse>

    @Throws(Exception::class)
    suspend fun getInspectionReportSummary(inspectionId: String): Resource<ReportSummaryResponse>

    @Throws(Exception::class)
    suspend fun getInspectionReportTitlePage(inspectionId: String): Resource<ReportTitlePageResponse>

    @Throws(Exception::class)
    suspend fun getInspectionReportChecklistResult(inspectionId: String): Resource<ReportChecklistResultResponse>

    @Throws(Exception::class)
    suspend fun getInspectionReportFailedItems(inspectionId: String): Resource<List<IssueModel.Issue>>

    @Throws(Exception::class)
    suspend fun getInspectionReportInfo(inspectionId: String): Resource<List<InspectionInfo>>
}
