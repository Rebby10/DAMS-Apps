package com.pertamina.digitalaudit.presentation.splashscreen

import android.content.Intent
import android.os.Bundle
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.databinding.ActivitySplashBinding
import com.pertamina.digitalaudit.presentation.login.LoginActivity
import com.pertamina.digitalaudit.presentation.main.MainActivity
import com.pertamina.framework.ViewDataBindingOwner
import com.pertamina.framework.base.BaseActivity
import org.koin.androidx.viewmodel.ext.android.viewModel

class SplashScreenActivity : BaseActivity<SplashScreenViewModel>(), SplashScreenView,
    ViewDataBindingOwner<ActivitySplashBinding> {

    override val layoutResourceId: Int = R.layout.activity_splash
    override val viewModel: SplashScreenViewModel by viewModel()
    override var binding: ActivitySplashBinding? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        redirectPage()
    }

    private fun redirectPage() {
        goToLoginActivity()
    }

    private fun goToMainActivity() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish()
    }

    private fun goToLoginActivity() {
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
        finish()
    }
}