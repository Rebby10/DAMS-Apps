package com.pertamina.digitalaudit.model.query

import com.google.gson.annotations.SerializedName
import java.io.Serializable

class GetInspectionQuery : Serializable {
    @SerializedName("UserTypeId")
    var userTypeId: Int = 1

    @SerializedName("StatusId")
    var statusId: Int? = null

    @SerializedName("RegionId")
    var regionId: String? = null

    @SerializedName("Text")
    var textSearch: String? = null

    @SerializedName("AuditLocationId")
    var auditLocationId: String? = null

    @SerializedName("UserCreated")
    var userCreated: String? = null

    @SerializedName("page_size")
    var pageSize: Int? = null

    @SerializedName("page_number")
    var pageNumber: Int? = null

    @SerializedName("sort_by")
    var sortBy: String? = null

    @SerializedName("order_by")
    var orderBy: String? = null
}
