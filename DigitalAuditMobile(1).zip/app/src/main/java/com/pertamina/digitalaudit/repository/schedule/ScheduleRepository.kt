package com.pertamina.digitalaudit.repository.schedule

import com.pertamina.digitalaudit.model.ScheduleDetailModel
import com.pertamina.digitalaudit.model.ScheduleModel
import com.pertamina.digitalaudit.model.UserAssignModel
import com.pertamina.digitalaudit.model.body.CreateScheduleReqBody
import com.pertamina.digitalaudit.model.body.RescheduleApprovalReqBody
import com.pertamina.digitalaudit.model.body.RescheduleReqBody
import com.pertamina.digitalaudit.model.body.UpdateScheduleReqBody
import com.pertamina.framework.base.Resource

interface ScheduleRepository {

    @Throws(Exception::class)
    suspend fun getScheduleList(): Resource<List<ScheduleModel.Schedule>>

    @Throws(Exception::class)
    suspend fun createNewSchedule(reqBody: CreateScheduleReqBody): Resource<ScheduleModel.Schedule>

    @Throws(Exception::class)
    suspend fun getScheduleDetail(scheduleId: String): Resource<ScheduleDetailModel>

    @Throws(Exception::class)
    suspend fun deleteSchedule(scheduleId: String): Resource<ScheduleModel>

    @Throws(Exception::class)
    suspend fun updateSchedule(reqBody: UpdateScheduleReqBody): Resource<ScheduleModel.Schedule>

    @Throws(Exception::class)
    suspend fun getAuditeeByName(name: String?): Resource<List<UserAssignModel.UserAssign>>

    @Throws(Exception::class)
    suspend fun confirmReschedule(reqBody: RescheduleApprovalReqBody): Resource<ScheduleModel.Schedule>

    @Throws(Exception::class)
    suspend fun reschedule(reqBody: RescheduleReqBody): Resource<ScheduleModel.Schedule>
}
