package com.pertamina.digitalaudit.presentation.createschedule

import android.view.View
import com.pertamina.framework.base.BaseView

/**
 * Created by M Hafidh Abdul Aziz on 11/03/21.
 */

interface CreateScheduleView : BaseView {
    fun onClickSubmitSchedule(view: View)
    fun onClickChooseAuditor(view: View)
    fun onClickChooseAuditee(view: View)
    fun onClickChooseLocation(view: View)
    fun onClickChooseAuditTypeTemplate(view: View)
}
