package com.pertamina.digitalaudit.repository.actions

import com.pertamina.digitalaudit.model.ActionDetailModel
import com.pertamina.digitalaudit.model.ActionModel
import com.pertamina.digitalaudit.model.ActionRepairModel
import com.pertamina.digitalaudit.model.IssueStatusModel
import com.pertamina.digitalaudit.model.LogModel
import com.pertamina.digitalaudit.model.UserAssignModel
import com.pertamina.digitalaudit.model.body.CreateActionReqBody
import com.pertamina.digitalaudit.model.body.UpdateActionReqBody
import com.pertamina.digitalaudit.model.body.UpdateActionStatusReqBody
import com.pertamina.framework.base.BaseResponse
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Part
import retrofit2.http.Path
import retrofit2.http.Query
import retrofit2.http.Url

interface ActionsService {

    @GET("Action/query")
    suspend fun getActionListWithQuery(
        @Query("ActionId") actionId: String?,
        @Query("Title") title: String?,
        @Query("AuditLocationId") AuditLocationId: String?,
        @Query("PriorityId") PriorityId: Int?,
        @Query("StatusId") StatusId: Int?,
        @Query("UserCreated") UserCreated: String?,
        @Query("AssignUser") AssignUser: String?,
        @Query("StartDate") StartDate: String?,
        @Query("EndDate") EndDate: String?,
        @Query("AuditTypeId") AuditTypeId: String?,
        @Query("IsConnectedToIssue") IsConnectedToIssue: Boolean?,
        @Query("page_size") PageSize: Int?,
        @Query("page_number") PageNumber: Int?,
        @Query("sort_by") SortBy: String?,
        @Query("order_by") OrderBy: String?,
        @Query("InspectionId") InspectionId: String?,
        @Query("QuestionId") QuestionId: String?,
        @Query("IssueId") IssueId: String?
    ): ActionModel

    @DELETE("Action/{id}")
    suspend fun deleteAction(@Path("id") actionId: String?): ActionModel

    @GET("Action/{id}")
    suspend fun getDetailAction(@Path("id") actionId: String?): ActionDetailModel

    @POST("Action")
    suspend fun createAction(@Body body: CreateActionReqBody): ActionModel

    @PUT("Action")
    suspend fun updateAction(@Body body: UpdateActionReqBody): ActionModel

    @GET("Action/Log/query")
    suspend fun getActionLog(
        @Query("ActionId") actionId: String?,
        @Query("LastDate") lastDate: String?
    ): LogModel

    @FormUrlEncoded
    @POST("Action/Log")
    suspend fun sendActionLog(
        @Field("ActionId") actionId: String,
        @Field("text") text: String?,
        @Field("UserCreated") UserCreated: String
    ): BaseResponse

    @GET("Action/assignee")
    suspend fun getAssigneeByName(
        @Query("name") name: String?,
        @Query("page_size") pageSize: Int?,
        @Query("page_number") pageNumber: Int?
    ): UserAssignModel

    @GET("Master/Issue/Status")
    suspend fun getIssueStatusList(): IssueStatusModel

    @PUT("Action/Status")
    suspend fun updateActionStatus(@Body body: UpdateActionStatusReqBody): ActionModel

    @POST("Action/Repair")
    @Multipart
    suspend fun saveActionRepair(
        @Part("ActionId") actionId: RequestBody,
        @Part("RootCause") rootCause: RequestBody,
        @Part("RootCauseCategoryId") rootCauseCategoryId: RequestBody,
        @Part("ActionRepair") actionRepair: RequestBody,
        @Part("ActionRepairCategoryId") actionRepairCategoryId: RequestBody,
        @Part("RepairDate") repairDate: RequestBody,
        @Part file: MultipartBody.Part
    ): ActionRepairModel

    @POST("Action/Log")
    @Multipart
    suspend fun sendLogChatFile(
        @Part("ActionId") actionId: RequestBody,
        @Part("UserCreated") userCreated: RequestBody,
        @Part file: MultipartBody.Part
    ): BaseResponse

    @GET
    suspend fun downloadFile(@Url fileUrl: String): ResponseBody
}
