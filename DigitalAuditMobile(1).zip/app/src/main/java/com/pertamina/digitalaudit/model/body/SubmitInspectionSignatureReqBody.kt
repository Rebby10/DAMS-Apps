package com.pertamina.digitalaudit.model.body

import com.google.gson.annotations.SerializedName

data class SubmitInspectionSignatureReqBody(
    @SerializedName("InspectionId")
    var inspectionId: String,
    @SerializedName("Title")
    var title: String,
    @SerializedName("Name")
    var name: String,
    @SerializedName("Signature")
    var signature: String,
    @SerializedName("UserCreated")
    var userCreated: String
)