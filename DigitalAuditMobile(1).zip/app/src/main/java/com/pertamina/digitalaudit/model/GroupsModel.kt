package com.pertamina.digitalaudit.model

import com.google.gson.annotations.SerializedName

class GroupsModel {
    @SerializedName("Result")
    var data: Groups? = null

    class Groups {
        @SerializedName("UserGroupId")
        var userGroupId: String? = ""

        @SerializedName("Name")
        var name: String? = ""

        @SerializedName("UserId")
        var userId: String? = ""

        @SerializedName("Username")
        var username: String? = ""

        @SerializedName("OfficialName")
        var officialName: String? = ""

        @SerializedName("UserMember")
        var UserMember: List<UserMemberModel.UserMember>? = null

        @SerializedName("UserType")
        var userType: AssignGroupModel.UserType? = null

    }
}
