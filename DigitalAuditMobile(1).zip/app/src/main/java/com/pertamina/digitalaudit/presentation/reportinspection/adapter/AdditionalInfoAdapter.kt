package com.pertamina.digitalaudit.presentation.reportinspection.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.model.startinspection.InspectionInfo
import com.pertamina.framework.base.BaseRecyclerViewAdapter
import com.pertamina.framework.base.BaseViewHolder
import kotlinx.android.synthetic.main.item_additional_info.view.*

class AdditionalInfoAdapter : BaseRecyclerViewAdapter<InspectionInfo>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BaseViewHolder<InspectionInfo> {
        val view = LayoutInflater.from(parent.context).inflate(viewType, parent, false)
        return ListViewHolder(parent.context, view)
    }

    override fun onBindViewHolder(
        holder: BaseViewHolder<InspectionInfo>,
        position: Int
    ) {
        holder.bindData(getItem(position))
    }

    override fun getItemViewType(position: Int): Int {
        return R.layout.item_additional_info
    }

    class ListViewHolder(context: Context, val view: View) :
        BaseViewHolder<InspectionInfo>(context, view) {

        private var tvTitleNote = view.tvTitleNote
        private var tvNote = view.tvNote

        override fun bindData(data: InspectionInfo) {
            tvTitleNote.text = data.title
            tvNote.text = data.notes
        }
    }
}