package com.pertamina.digitalaudit.model.startinspection

import com.google.gson.annotations.SerializedName

/**
 * @author Asadurrahman Al Qayyim
 * @date 10/4/2021
 */


data class ImageFileInspection (
        @field:SerializedName("Result")
        val data: List<ImageFileInspectionResponse>? = null,
)

data class ImageFileInspectionResponse (
        @field:SerializedName("QuestionId")
        val questionId: Int = 0,
        @field:SerializedName("Filename")
        val fileName: String? = null,
        @field:SerializedName("LinkFile")
        val linkFile: String? = null,
        @field:SerializedName("FileTypeId")
        val fileTypeId: Int = 1
)