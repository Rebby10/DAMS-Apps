package com.pertamina.digitalaudit.model

import com.google.gson.annotations.SerializedName
import com.pertamina.framework.base.BaseResponse
import java.io.Serializable

class AssignGroupModel : BaseResponse() {

    @SerializedName("Result")
    var data: List<AssignGroup>? = null

    class AssignGroup: Serializable {
        @SerializedName("UserGroupId")
        var userGroupId: String? = ""

        @SerializedName("UserType")
        var userType: UserType? = null

        @SerializedName("Name")
        var name: String? = null

        @SerializedName("UserId")
        var userId: String? = ""

        @SerializedName("Username")
        var username: String? = null

        @SerializedName("OfficialName")
        var officialName: String? = null
    }

    class UserType {

        @SerializedName("UserTypeId")
        var userTypeId: String? = ""

        @SerializedName("Name")
        var name: String? = ""

    }
}
