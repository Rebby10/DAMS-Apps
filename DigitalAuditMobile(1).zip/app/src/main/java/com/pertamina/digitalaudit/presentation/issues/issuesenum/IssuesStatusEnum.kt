package com.pertamina.digitalaudit.presentation.issues.issuesenum

enum class IssuesStatusEnum(val status: String) {
    OPEN("Open"),
    ONPROGRESS("On Progress"),
    CLOSE("Close"),
    CONFIRMED("Confirmed"),
    UNCONFIRMED("Unconfirmed")
}
