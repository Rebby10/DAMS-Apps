package com.pertamina.digitalaudit.model.query

import com.google.gson.annotations.SerializedName
import java.io.Serializable

class GetInspectionFileQuery : Serializable {
    @SerializedName("InspectionId ")
    var inspectionId: String? = null

    @SerializedName("QuestionId ")
    var questionId: Int? = null

    @SerializedName("FileTypeId ")
    var fileTypeId: Int? = null

    @SerializedName("page_size")
    var pageSize: Int? = 0

    @SerializedName("page_number")
    var pageNumber: Int? = 0

    @SerializedName("sort_by")
    var sortBy: String? = null

    @SerializedName("order_by")
    var orderBy: String? = null
}