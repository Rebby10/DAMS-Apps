package com.pertamina.digitalaudit.presentation.createissue

import android.text.TextWatcher
import android.view.View
import com.pertamina.framework.base.BaseView

/**
 * Created by M Hafidh Abdul Aziz on 15/03/21.
 */

interface CreateIssueView : BaseView {
    fun onClickCreateIssue(view: View)
    fun onClickChooseUser(view: View)
    fun onClickChooseLocation(view: View)

    var bTextWatcherIssueTitle: TextWatcher
    var bTextWatcherIssueDescription: TextWatcher
}
