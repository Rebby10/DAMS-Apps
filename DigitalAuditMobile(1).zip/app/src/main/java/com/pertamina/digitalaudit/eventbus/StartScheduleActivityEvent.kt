package com.pertamina.digitalaudit.eventbus

class StartScheduleActivityEvent {
}
