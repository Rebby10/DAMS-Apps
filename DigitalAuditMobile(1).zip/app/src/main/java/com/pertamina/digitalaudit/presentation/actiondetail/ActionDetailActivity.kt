package com.pertamina.digitalaudit.presentation.actiondetail

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.databinding.ActivityActionDetailBinding
import com.pertamina.digitalaudit.model.ActionDetailModel
import com.pertamina.digitalaudit.model.IssueStatusModel
import com.pertamina.digitalaudit.presentation.actionrepair.ActionRepairActivity
import com.pertamina.digitalaudit.presentation.createaction.CreateActionActivity
import com.pertamina.digitalaudit.presentation.login.LoginActivity
import com.pertamina.digitalaudit.presentation.sheet.CommonOptionsSheet
import com.pertamina.digitalaudit.util.SnackBar
import com.pertamina.framework.NetworkState
import com.pertamina.framework.ViewDataBindingOwner
import com.pertamina.framework.base.BaseActivity
import com.pertamina.framework.util.DateHelper
import kotlinx.android.synthetic.main.activity_action_detail.*
import kotlinx.android.synthetic.main.toolbar_layout.*
import org.koin.androidx.viewmodel.ext.android.viewModel

class ActionDetailActivity : BaseActivity<ActionDetailViewModel>(), ActionDetailView,
    ViewDataBindingOwner<ActivityActionDetailBinding> {

    override val layoutResourceId: Int = R.layout.activity_action_detail
    override val viewModel: ActionDetailViewModel by viewModel()
    override var binding: ActivityActionDetailBinding? = null
    private lateinit var menuBottomSheet: CommonOptionsSheet

    companion object {

        private const val EXTRA_ACTION_ID = "EXTRA_ACTION_ID"

        fun startThisActivity(context: Context, actionId: String) {
            val intent = Intent(context, ActionDetailActivity::class.java)
            intent.putExtra(EXTRA_ACTION_ID, actionId)
            context.startActivity(intent)
        }
    }

    private var updateActionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                viewModel.getActionDetail()
            }
        }

    private var actionRepairLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                viewModel.getActionDetail()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setupToolbar()
        getExtraData()
        getActionDetail()
        observeActionDetail()
        observeStatusList()
        subscribeUpdateAction()
        manageSaveButton(false)
    }

    private fun setupToolbar() {
        tvTitleToolbar.text = getString(R.string.actions_detail_action)
        btnBackToolbar.apply {
            visibility = View.VISIBLE
            setOnClickListener {
                onBackPressed()
            }
        }
    }

    private fun getExtraData() {
        viewModel.actionId = intent?.getStringExtra(EXTRA_ACTION_ID).orEmpty()
    }

    private fun getActionDetail() {
        viewModel.getActionDetail()
    }

    private fun observeActionDetail() {
        observeData(viewModel.actionDetailResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { actionDetail ->
                            viewModel.detailActionStatusId.value =
                                actionDetail.data?.status?.statusId ?: 0
                            viewModel.prevDetailActionStatusId.value =
                                actionDetail.data?.status?.statusId ?: 0
                            viewModel.getStatusList()
                            viewModel.setActionSelfAssign(getAssignedUserId(actionDetail.data))
                            setDataToView(actionDetail.data)
                        }
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message
                                ?: getString(R.string.general_server_error_message)
                        )
                        when (it.code) {
                            401 -> {
                                viewModel.preference.clearPreferences()
                                logout(Intent(this, LoginActivity::class.java))
                            }
                            else -> {
                                //do nothing just to avoid error warning
                            }
                        }
                    }
                }
            }
        }
    }

    private fun observeStatusList() {
        observeData(viewModel.statusListResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        initIssueStatusSheet(it.data)
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message ?: getString(R.string.general_server_error_message)
                        )
                    }
                }
            }
        }
    }

    private fun subscribeUpdateAction() {
        observeData(viewModel.updateActionResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        SnackBar.snackBarShowSuccess(
                            this,
                            parentLayout,
                            it.message ?: getString(R.string.actions_status_update_message)
                        )
                        manageSaveButton(false)
                        getActionDetail()
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message ?: getString(R.string.general_server_error_message)
                        )
                        when (it.code) {
                            401 -> {
                                viewModel.preference.clearPreferences()
                                logout(Intent(this, LoginActivity::class.java))
                            }
                        }
                    }
                }
            }
        }
    }

    private fun setDataToView(actionDetail: ActionDetailModel.ActionDetail?) {
        viewModel.isDetailActionStateAuto.value = actionDetail?.issue?.issueId != null
        viewModel.bTextDetailActionInspectionTitle.value = null //todo ask attribute when inspection done
        viewModel.bTextDetailActionInspectionDescription.value = null //todo ask attribute when inspection done
        viewModel.bTextDetailActionRelatedIssueTitle.value = actionDetail?.issue?.title.orEmpty()

        viewModel.bTextDetailActionTitle.value = actionDetail?.title
        viewModel.bTextDetailActionDescription.value = actionDetail?.descriptions
        viewModel.bTextDetailActionLocation.value = actionDetail?.auditLocation?.name
        viewModel.bTextDetailActionCreatedAt.value = DateHelper.changeFormat(
            actionDetail?.dateCreated.orEmpty(),
            DateHelper.yyyy_MM_dd_T_HHmmss,
            DateHelper.dd_MMM_yyyy_hh_mm_a
        )
        viewModel.bTextDetailActionCreatedBy.value =
            getString(R.string.created_by_argument, actionDetail?.creator?.displayName)
        viewModel.bTextDetailActionAssignTo.value =
            getString(R.string.assign_to_argument, getAssignedUser(actionDetail))
        viewModel.bTextDetailActionPriority.value =
            getString(R.string.priority_argument, actionDetail?.priority?.name)
        viewModel.bTextDetailActionTargetClosing.value = getString(
            R.string.target_closing_argument, DateHelper.changeFormat(
                actionDetail?.targetClosing.orEmpty(),
                DateHelper.yyyy_MM_dd_T_HHmmss,
                DateHelper.dd_MMM_yyyy_hh_mm_a
            )
        )
    }

    private fun getAssignedUser(actionDetail: ActionDetailModel.ActionDetail?): String {
        actionDetail?.assignUser?.displayName?.let {
            return it
        }
        actionDetail?.assignGroup?.name?.let {
            return it
        }
        return ""
    }

    private fun getAssignedUserId(actionDetail: ActionDetailModel.ActionDetail?): String {
        actionDetail?.assignUser?.userId?.let {
            return it
        }
        actionDetail?.assignGroup?.userId?.let {
            return it
        }
        return ""
    }

    private fun initIssueStatusSheet(data: List<IssueStatusModel.IssueStatus>?) {
        viewModel.bTextDetailActionStatus.value = getString(
            R.string.issues_detail_status,
            data?.get(viewModel.getSelectedStatusItemPosition())
        )
        val menuList: MutableList<CommonOptionsSheet.BottomSheetMenuModel> = mutableListOf()
        for (menu in data ?: emptyList()) {
            menuList.add(
                CommonOptionsSheet.BottomSheetMenuModel(
                    0, menu.statusId ?: 0,
                    menu.name.orEmpty()
                )
            )
        }
        menuBottomSheet = CommonOptionsSheet(this, menuList).apply {
            setCancelable(true)
            setMenuItemListener(object :
                CommonOptionsSheet.MenuItemClickListener {
                override fun onBottomSheetItemClicked(menu: String, id: Int) {
                    dismiss()
                    viewModel.detailActionStatusId.value = id
                    viewModel.bTextDetailActionStatus.value =
                        getString(R.string.issues_detail_status, menu)
                    manageSaveButton(viewModel.prevDetailActionStatusId.value != viewModel.detailActionStatusId.value)
                }
            })
        }
    }

    private fun showMenuBottomSheet() {
        if (this::menuBottomSheet.isInitialized) menuBottomSheet.show()
    }

    private fun manageSaveButton(enable: Boolean) {
        btnSave.run {
            isEnabled = enable
            alpha = if (enable) 1f else .5f
        }
    }

    override fun onClickEditAction(view: View) {
        val intent = Intent(this, CreateActionActivity::class.java)
        intent.putExtra(CreateActionActivity.EXTRA_ACTION_ID, viewModel.actionId)
        updateActionLauncher.launch(intent)
    }

    override fun onClickChangeActionStatus(view: View) {
        showMenuBottomSheet()
    }

    override fun onClickCreateActionRepair(view: View) {
        val intent = Intent(this, ActionRepairActivity::class.java)
        intent.putExtra(ActionRepairActivity.EXTRA_ACTION_ID, viewModel.actionId)
        actionRepairLauncher.launch(intent)
    }

    override fun onClickSaveAction(view: View) {
        viewModel.updateStatusAction()
    }
}
