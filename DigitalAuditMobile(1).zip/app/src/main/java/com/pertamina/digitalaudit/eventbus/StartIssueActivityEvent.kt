package com.pertamina.digitalaudit.eventbus

class StartIssueActivityEvent {
}
