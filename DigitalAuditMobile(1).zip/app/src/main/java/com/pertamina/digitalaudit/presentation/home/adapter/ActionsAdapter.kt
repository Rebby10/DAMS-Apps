package com.pertamina.digitalaudit.presentation.home.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.model.ActionModel
import com.pertamina.digitalaudit.presentation.issues.helper.IssuesStatusViewHelper
import com.pertamina.framework.base.BaseRecyclerViewAdapter
import com.pertamina.framework.base.BaseViewHolder
import com.pertamina.framework.util.DateHelper
import kotlinx.android.synthetic.main.item_home_actions.view.*

/**
 * Created by M Hafidh Abdul Aziz on 08/03/21.
 */

class ActionsAdapter : BaseRecyclerViewAdapter<ActionModel.Action>() {

    private var listener: ActionsClickListener? = null

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BaseViewHolder<ActionModel.Action> {
        val view = LayoutInflater.from(parent.context).inflate(viewType, parent, false)
        return ListViewHolder(parent.context, view, listener)
    }

    override fun onBindViewHolder(holder: BaseViewHolder<ActionModel.Action>, position: Int) {
        holder.bindData(getItem(position))
    }

    override fun getItemViewType(position: Int): Int {
        return R.layout.item_home_actions
    }

    class ListViewHolder(context: Context, val view: View, listener: ActionsClickListener?) :
        BaseViewHolder<ActionModel.Action>(context, view) {

        private lateinit var data: ActionModel.Action
        private var holderListener: ActionsClickListener? = listener

        private var tvTitleAction = view.tvTitleAction
        private var tvReportedBy = view.tvActionReportedBy
        private var tvActionPriorityType = view.tvActionPriorityType
        private var tvActionTargetClosing = view.tvActionTargetClosing
        private var tvStatusAction = view.tvActionStatus
        private var tvLocation = view.tvActionLocation

        @SuppressLint("SetTextI18n")
        override fun bindData(data: ActionModel.Action) {
            this.data = data
            tvTitleAction.text = data.title
            tvReportedBy.text = "Reported by ${data.creator?.displayName}"
            data.targetClosing?.let {
                tvActionTargetClosing.text = DateHelper.changeFormat(
                    it,
                    DateHelper.yyyy_MM_dd_T_HHmmss,
                    DateHelper.dd_MMM_yyyy
                )
            }
            tvLocation.text = data.auditLocation?.name

            tvActionPriorityType.apply {
                data.priority?.let { priority ->
                    text = priority.name
                    setTextColor(
                        ContextCompat.getColor(
                            context,
                            IssuesStatusViewHelper.getPriorityTextColor(priority.name.orEmpty())
                        )
                    )
                }
            }

            tvStatusAction.apply {
                data.status?.let { status ->
                    text = status.name
                    setBackgroundResource(IssuesStatusViewHelper.getStatusBackgroundColor(status.name.orEmpty()))
                    setTextColor(
                        ContextCompat.getColor(
                            context,
                            IssuesStatusViewHelper.getStatusTextColor(status.name.orEmpty())
                        )
                    )
                }
            }

            itemView.setOnClickListener {
                holderListener?.onClickActions(data.actionId.orEmpty(), data.title.orEmpty())
            }
        }
    }

    fun setActionsClickListener(listener: ActionsClickListener) {
        this.listener = listener
    }

    interface ActionsClickListener {
        fun onClickActions(actionsId: String, actionTitle: String)
    }
}
