package com.pertamina.digitalaudit.presentation.home

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.recyclerview.widget.LinearLayoutManager
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.databinding.FragmentHomeBinding
import com.pertamina.digitalaudit.eventbus.StartScheduleActivityEvent
import com.pertamina.digitalaudit.model.AuditLocationModel
import com.pertamina.digitalaudit.presentation.chat.ChatActivity
import com.pertamina.digitalaudit.presentation.createschedule.CreateScheduleActivity
import com.pertamina.digitalaudit.presentation.home.adapter.InspectionAdapter
import com.pertamina.digitalaudit.presentation.home.adapter.IssuesAdapter
import com.pertamina.digitalaudit.presentation.home.adapter.ScheduleAdapter
import com.pertamina.digitalaudit.presentation.inspection.InspectionViewModel
import com.pertamina.digitalaudit.presentation.login.LoginActivity
import com.pertamina.digitalaudit.presentation.main.MainActivity
import com.pertamina.digitalaudit.presentation.map.MapActivity
import com.pertamina.digitalaudit.presentation.notification.NotificationActivity
import com.pertamina.digitalaudit.presentation.reportinspection.ReportInspectionActivity
import com.pertamina.digitalaudit.presentation.scheduledetail.ScheduleDetailActivity
import com.pertamina.digitalaudit.presentation.startinspection.StartInspectionActivity
import com.pertamina.digitalaudit.util.SnackBar
import com.pertamina.framework.NetworkState
import com.pertamina.framework.ViewDataBindingOwner
import com.pertamina.framework.base.BaseFragment
import com.pertamina.framework.extensions.sharedGraphViewModel
import kotlinx.android.synthetic.main.fragment_home.*
import kotlinx.android.synthetic.main.toolbar_layout.*
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode

/**
 * Created by M Hafidh Abdul Aziz on 11/03/21.
 */

class HomeFragment : BaseFragment<HomeViewModel>(), HomeView,
    ViewDataBindingOwner<FragmentHomeBinding> {

    override val layoutResourceId: Int = R.layout.fragment_home
    override val viewModel: HomeViewModel by sharedGraphViewModel(R.id.nav_graph_home)
    override var binding: FragmentHomeBinding? = null

    private var listIssueAdapter: IssuesAdapter? = null
    private var listScheduleAdapter: ScheduleAdapter? = null
    private var listInspectionAdapter: InspectionAdapter? = null

    companion object {
        private const val MAX_DATA_SHOWN = 3
    }

    private var newScheduleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                viewModel.getHomeData()
            }
        }

    private var rescheduleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                viewModel.getHomeData()
            }
        }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupToolbar()
        setupView()
        setupRv()
        observeIssueList()
        observeScheduleList()
        observeInspectionList()
        observeHomeOverview()
    }

    private fun setupToolbar() {
        tvTitleToolbar.apply {
            text = getString(R.string.title_home)
            gravity = Gravity.START
        }
        menuAction1.apply {
            visibility = View.VISIBLE
            setImageResource(R.drawable.ic_search)
            setOnClickListener {
                manageSearchLayout(true)
            }
        }
        menuAction2.apply {
            visibility = View.VISIBLE
            setImageResource(R.drawable.ic_map)
            setOnClickListener {
                MapActivity.startThisActivity(requireContext(), isFromSchedule = true)
            }
        }
        menuAction3.apply {
            visibility = View.VISIBLE
            setImageResource(R.drawable.ic_notification)
            setOnClickListener {
                NotificationActivity.startThisActivity(requireContext())
            }
        }
        ivClearSearch.setOnClickListener {
            etSearchToolbar.setText("")
            manageSearchLayout(false)
            viewModel.getHomeData()
        }
    }

    private fun setupView() {
        (activity as MainActivity).manageFloatingButtonAdd(true)
        etSearchToolbar.setOnKeyListener { _, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_UP) {
                if (etSearchToolbar.text.toString().isNotEmpty()) {
                    viewModel.getHomeOverview(etSearchToolbar.text.toString())
                } else {
                    viewModel.getHomeData()
                }
            }
            false
        }
    }

    private fun setupRv() {
        listIssueAdapter = IssuesAdapter()
        listIssueAdapter?.setIssueClickListener(object : IssuesAdapter.IssueClickListener {
            override fun onClickIssue(issueId: String, issueTitle: String, latLng: String?) {
                ChatActivity.startThisActivityFromIssue(
                    this@HomeFragment.requireContext(),
                    issueId, issueTitle,
                    false
                )
            }
        })
        val managerIssue = LinearLayoutManager(requireContext())
        rvHomeOpenIssues.apply {
            layoutManager = managerIssue
            setHasFixedSize(true)
            adapter = listIssueAdapter
        }
        listScheduleAdapter = ScheduleAdapter()
        listScheduleAdapter?.setScheduleClickListener(object :
            ScheduleAdapter.ScheduleClickListener {
            override fun onClickSchedule(
                scheduleId: String,
                scheduleStatus: String
            ) {
                val intent = Intent(activity, ScheduleDetailActivity::class.java)
                intent.putExtra(ScheduleDetailActivity.EXTRA_SCHEDULE_ID, scheduleId)
                intent.putExtra(ScheduleDetailActivity.EXTRA_SCHEDULE_STATUS, scheduleStatus)
                rescheduleLauncher.launch(intent)
            }
        })
        val managerSchedule = LinearLayoutManager(requireContext())
        rvHomeSchedule.apply {
            layoutManager = managerSchedule
            setHasFixedSize(true)
            adapter = listScheduleAdapter
        }
        listInspectionAdapter = InspectionAdapter()
        listInspectionAdapter?.setInspectionClickListener(object :
            InspectionAdapter.InspectionClickListener {
            override fun onClickInspection(
                inspectionId: String,
                location: AuditLocationModel.AuditLocation?,
                startDate: String,
                statusId: Int
            ) {
                if (statusId == InspectionViewModel.COMPLETED_ID) {
                    ReportInspectionActivity.startThisActivity(requireContext(), inspectionId)
                } else {
                    StartInspectionActivity.startThisActivity(
                        requireContext(),
                        inspectionId,
                        location?.name.orEmpty(),
                        startDate
                    )
                }
            }
        })
        val managerInspection = LinearLayoutManager(requireContext())
        rvHomeInspection.apply {
            layoutManager = managerInspection
            setHasFixedSize(true)
            adapter = listInspectionAdapter
        }
    }

    private fun observeIssueList() {
        observeData(viewModel.issueListResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { data ->
                            if (data.isNotEmpty()) {
                                viewModel.hideLoadMoreIssue.value = data.size < MAX_DATA_SHOWN
                                viewModel.showEmptyStateIssue.value = false
                                listIssueAdapter?.setData(data)
                            } else {
                                viewModel.showEmptyStateIssue.value = true
                            }
                        } ?: run {
                            viewModel.showEmptyStateIssue.value = true
                        }
                    }
                    NetworkState.ERROR -> {
                        when (it.code) {
                            401 -> {
                                viewModel.preference.clearPreferences()
                                logout(Intent(requireContext(), LoginActivity::class.java))
                            }
                            404 -> {
                                viewModel.showEmptyStateIssue.value = true
                                listIssueAdapter?.removeAllData()
                            }
                            else -> {
                                //do nothing just to avoid error warning
                            }
                        }
                    }
                }
            }
        }
    }

    private fun observeScheduleList() {
        observeData(viewModel.scheduleListResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { data ->
                            if (data.isNotEmpty()) {
                                viewModel.hideLoadMoreSchedule.value = data.size < MAX_DATA_SHOWN
                                viewModel.showEmptyStateSchedule.value = false
                                listScheduleAdapter?.setData(data)
                            } else {
                                viewModel.showEmptyStateSchedule.value = true
                            }
                        } ?: run {
                            viewModel.showEmptyStateSchedule.value = true
                        }
                    }
                    NetworkState.ERROR -> {
                        when (it.code) {
                            404 -> {
                                viewModel.showEmptyStateSchedule.value = true
                                listScheduleAdapter?.removeAllData()
                            }
                            else -> {
                                //do nothing just to avoid error warning
                            }
                        }
                    }
                }
            }
        }
    }

    private fun observeInspectionList() {
        observeData(viewModel.inspectionListResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { data ->
                            if (data.isNotEmpty()) {
                                viewModel.hideLoadMoreInspection.value = data.size < MAX_DATA_SHOWN
                                viewModel.showEmptyStateInspection.value = false
                                listInspectionAdapter?.setData(data)
                            } else {
                                viewModel.showEmptyStateInspection.value = true
                            }
                        } ?: run {
                            viewModel.showEmptyStateInspection.value = true
                        }
                    }
                    NetworkState.ERROR -> {
                        when (it.code) {
                            401 -> {
                                SnackBar.snackBarShowError(
                                    requireContext(),
                                    parentLayout,
                                    it.message
                                        ?: getString(R.string.general_server_error_message)
                                )
                                viewModel.preference.clearPreferences()
                                logout(Intent(requireContext(), LoginActivity::class.java))
                            }
                            404 -> {
                                viewModel.showEmptyStateInspection.value = true
                                listInspectionAdapter?.removeAllData()
                            }
                            else -> {
                                //do nothing just to avoid error warning
                            }
                        }
                    }
                }
            }
        }
    }

    private fun observeHomeOverview() {
        observeData(viewModel.homeOverviewResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.data?.let { result ->
                            result.issue?.data?.let { issue ->
                                if (issue.isNotEmpty()) {
                                    viewModel.hideLoadMoreIssue.value = issue.size < MAX_DATA_SHOWN
                                    viewModel.showEmptyStateIssue.value = false
                                    listIssueAdapter?.setData(issue)
                                } else {
                                    viewModel.showEmptyStateIssue.value = true
                                }
                            } ?: run {
                                viewModel.showEmptyStateIssue.value = true
                            }
                            result.schedule?.data.let { schedule ->
                                if (schedule?.isNotEmpty() == true) {
                                    viewModel.hideLoadMoreSchedule.value =
                                        schedule.size < MAX_DATA_SHOWN
                                    viewModel.showEmptyStateSchedule.value = false
                                    listScheduleAdapter?.setData(schedule)
                                } else {
                                    viewModel.showEmptyStateSchedule.value = true
                                }
                            } ?: run {
                                viewModel.showEmptyStateSchedule.value = true
                            }
                            result.inspection?.data.let { inspection ->
                                if (inspection?.isNotEmpty() == true) {
                                    viewModel.hideLoadMoreInspection.value =
                                        inspection.size < MAX_DATA_SHOWN
                                    viewModel.showEmptyStateInspection.value = false
                                    listInspectionAdapter?.setData(inspection)
                                } else {
                                    viewModel.showEmptyStateInspection.value = true
                                }
                            } ?: run {
                                viewModel.showEmptyStateInspection.value = true
                            }
                        }
                    }
                    NetworkState.ERROR -> {
                        when (it.code) {
                            401 -> {
                                SnackBar.snackBarShowError(
                                    requireContext(),
                                    parentLayout,
                                    it.message
                                        ?: getString(R.string.general_server_error_message)
                                )
                                viewModel.preference.clearPreferences()
                                logout(Intent(requireContext(), LoginActivity::class.java))
                            }
                            404 -> {
                                viewModel.showEmptyStateIssue.value = true
                                listIssueAdapter?.removeAllData()
                                listScheduleAdapter?.removeAllData()
                                listInspectionAdapter?.removeAllData()
                            }
                            else -> {
                                //do nothing just to avoid error warning
                            }
                        }
                    }
                }
            }
        }
    }

    private fun manageSearchLayout(isShow: Boolean) {
        tvTitleToolbar.visibility = if (isShow) View.GONE else View.VISIBLE
        menuAction1.visibility = if (isShow) View.GONE else View.VISIBLE
        etSearchToolbar.visibility = if (isShow) View.VISIBLE else View.GONE
        ivClearSearch.visibility = if (isShow) View.VISIBLE else View.GONE
    }

    override fun onStart() {
        super.onStart()
        EventBus.getDefault().register(this)
    }

    override fun onStop() {
        super.onStop()
        EventBus.getDefault().unregister(this)
    }

    @Subscribe(sticky = true, threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: StartScheduleActivityEvent) {
        val intent = Intent(activity, CreateScheduleActivity::class.java)
        newScheduleLauncher.launch(intent)
        EventBus.getDefault().removeStickyEvent(event)
    }

    override fun onClickLoadMoreIssue(view: View) {
        activity?.let {
            (it as MainActivity).setActiveTab(isIssue = true)
        }
    }

    override fun onClickLoadMoreSchedule(view: View) {
        MapActivity.startThisActivity(requireContext(), isFromSchedule = true)
    }

    override fun onClickLoadMoreInspection(view: View) {
        activity?.let {
            (it as MainActivity).setActiveTab(isInspection = true)
        }
    }
}
