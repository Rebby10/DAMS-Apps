package com.pertamina.digitalaudit.presentation.reportinspection

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.gms.maps.*
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.pertamina.digitalaudit.BuildConfig
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.databinding.ActivityReportInspectionBinding
import com.pertamina.digitalaudit.model.IssueModel
import com.pertamina.digitalaudit.model.reportinspection.ReportChecklistResultResponse
import com.pertamina.digitalaudit.model.reportinspection.ReportOverviewResponse
import com.pertamina.digitalaudit.model.reportinspection.ReportSummaryResponse
import com.pertamina.digitalaudit.model.reportinspection.ReportTitlePageResponse
import com.pertamina.digitalaudit.model.startinspection.InspectionInfo
import com.pertamina.digitalaudit.presentation.createaction.CreateActionActivity
import com.pertamina.digitalaudit.presentation.issuedetails.IssueDetailActivity
import com.pertamina.digitalaudit.presentation.issues.helper.IssuesStatusViewHelper
import com.pertamina.digitalaudit.presentation.map.adapter.ToolbarMenuAdapter
import com.pertamina.digitalaudit.presentation.reportinspection.adapter.AdditionalInfoAdapter
import com.pertamina.digitalaudit.presentation.reportinspection.adapter.ChecklistResultPageAdapter
import com.pertamina.digitalaudit.presentation.reportinspection.adapter.ImagesPreviewAdapter
import com.pertamina.digitalaudit.presentation.reportinspection.adapter.TitlePageAdapter
import com.pertamina.digitalaudit.presentation.sheet.ImagesReportSheet
import com.pertamina.digitalaudit.presentation.startinspection.actionpage.ActionsActivity
import com.pertamina.digitalaudit.presentation.startinspection.actionpage.ActionsViewModel
import com.pertamina.digitalaudit.presentation.startinspection.startpage.adapter.InspectionIssueAdapter
import com.pertamina.digitalaudit.util.CommonConstant
import com.pertamina.digitalaudit.util.CommonFunction
import com.pertamina.digitalaudit.util.DownloadFile
import com.pertamina.digitalaudit.util.GridSpacingItemDecoration
import com.pertamina.digitalaudit.util.SnackBar
import com.pertamina.framework.NetworkState
import com.pertamina.framework.ViewDataBindingOwner
import com.pertamina.framework.base.BaseActivity
import com.pertamina.framework.util.DateHelper
import com.pertamina.framework.util.toPx
import kotlinx.android.synthetic.main.activity_action_page.*
import kotlinx.android.synthetic.main.activity_chat.*
import kotlinx.android.synthetic.main.activity_report_inspection.*
import kotlinx.android.synthetic.main.activity_report_inspection.parentLayout
import kotlinx.android.synthetic.main.layout_empty_state.*
import kotlinx.android.synthetic.main.progressbar_dialog_layout.view.*
import kotlinx.android.synthetic.main.report_check_list_result_layout.*
import kotlinx.android.synthetic.main.report_failed_items_layout.*
import kotlinx.android.synthetic.main.report_info_layout.*
import kotlinx.android.synthetic.main.report_overview_layout.*
import kotlinx.android.synthetic.main.report_summary_layout.*
import kotlinx.android.synthetic.main.report_title_page_layout.*
import kotlinx.android.synthetic.main.toolbar_layout.*
import okhttp3.ResponseBody
import org.koin.androidx.viewmodel.ext.android.viewModel
import java.io.File
import java.io.IOException
import kotlin.math.roundToInt


class ReportInspectionActivity : BaseActivity<ReportInspectionViewModel>(), ReportInspectionView,
    ViewDataBindingOwner<ActivityReportInspectionBinding>, OnMapReadyCallback {

    override var binding: ActivityReportInspectionBinding? = null
    override val layoutResourceId: Int = R.layout.activity_report_inspection
    override val viewModel: ReportInspectionViewModel by viewModel()
    private val actionViewModel: ActionsViewModel by viewModel()
    private val failedItemsAdapter = InspectionIssueAdapter()

    private lateinit var toolbarMenuAdapter: ToolbarMenuAdapter
    private lateinit var map: GoogleMap
    private var mAlertDialog: AlertDialog? = null
    private var fileExt: String? = null

    companion object {
        private const val EXTRA_INSPECTION_ID = "EXTRA_INSPECTION_ID"

        fun startThisActivity(context: Context, inspectionId: String) {
            val intent = Intent(context, ReportInspectionActivity::class.java)
            intent.putExtra(EXTRA_INSPECTION_ID, inspectionId)
            context.startActivity(intent)
        }
    }

    private var createActionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                onClickReportMenuItem(viewModel.selectedMenuTabId)
            }
        }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MapsInitializer.initialize(applicationContext)
        getExtraData()
        setupToolbar()
        setupReportMenu()
        setupMap()

        observeReportOverview()
        observeReportSummary()
        observeReportTitlePage()
        observeReportChecklistResult()
        observeReportFailedItems()
        observeReportInfo()
        observeActionList()
        observeDownloadFile()
        observeImageFile()
    }

    private fun setupMap() {
        val mapFragment =
            supportFragmentManager.findFragmentById(R.id.overviewMapFragment) as? SupportMapFragment
        mapFragment?.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap
        map.setPadding(0, 15.toPx(), 0, 0)
        val uiSettings = map.uiSettings
        uiSettings?.isZoomGesturesEnabled = true
        uiSettings?.isScrollGesturesEnabled = true
    }

    private fun observeActionList() {
        observeData(actionViewModel.actionsResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { data ->
                            if (data.isNotEmpty()) {
                                viewModel.failedItemList?.map { issue ->
                                    data.forEach { action ->
                                        if (action.questionId == issue.questionId)
                                            issue.actions.add(action)
                                    }
                                }
                                viewModel.failedItemList?.let { it1 ->
                                    mappingReportFailedItemsToView(
                                        it1
                                    )
                                }
                            }
                        }
                    }
                    NetworkState.ERROR -> {
                    }
                }
            }
        }
    }

    private fun getExtraData() {
        viewModel.inspectionId = intent?.getStringExtra(EXTRA_INSPECTION_ID)
    }

    private fun setupToolbar() {
        tvTitleToolbar.text = getString(R.string.report_label)
        btnBackToolbar.apply {
            visibility = View.VISIBLE
            setImageResource(R.drawable.ic_back)
            setOnClickListener {
                onBackPressed()
            }
        }
    }

    private fun setupReportMenu() {
        val toolbarMenu = ArrayList(listOf(*resources.getStringArray(R.array.report_menu)))
        toolbarMenuAdapter = ToolbarMenuAdapter(arrayListOf()).apply {
            setSelectedMenuPosition(ReportInspectionViewModel.OVERVIEW)
            addData(toolbarMenu)
        }
        rvReportMenu.run {
            layoutManager = LinearLayoutManager(context, RecyclerView.HORIZONTAL, false)
            adapter = toolbarMenuAdapter
        }

        toolbarMenuAdapter.setListener(object :
            ToolbarMenuAdapter.OnToolbarMenuInteractionListener {
            override fun onMenuItemClicked(menuPosition: Int) {
                toolbarMenuAdapter.setSelectedMenuPosition(menuPosition)
                if (viewModel.selectedMenuTabId == menuPosition) {
                    return
                }
                viewModel.selectedMenuTabId = menuPosition
                onClickReportMenuItem(menuPosition)
            }
        })
    }

    private fun observeReportOverview() {
        observeData(viewModel.reportOverviewResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { result ->
                            mappingOverviewToView(result)
                        }
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message
                                ?: getString(R.string.general_server_error_message)
                        )
                    }
                }
            }
        }
    }

    private fun observeReportSummary() {
        observeData(viewModel.reportSummaryResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { result ->
                            mappingReportSummaryToView(result)
                        }
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message
                                ?: getString(R.string.general_server_error_message)
                        )
                    }
                }
            }
        }
    }

    private fun observeReportTitlePage() {
        observeData(viewModel.titlePageResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { result ->
                            mappingReportTitlePageToView(result)
                        }
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message
                                ?: getString(R.string.general_server_error_message)
                        )
                    }
                }
            }
        }
    }

    private fun observeReportChecklistResult() {
        observeData(viewModel.checklistResultResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { result ->
                            mappingReportChecklistResultToView(result)
                        }
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message
                                ?: getString(R.string.general_server_error_message)
                        )
                    }
                }
            }
        }
    }

    private fun observeReportFailedItems() {
        observeData(viewModel.failedItemsResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { result ->
                            mappingReportFailedItemsToView(result.toMutableList())
                            viewModel.failedItemList = result.toMutableList()
                            actionViewModel.inspectionId = viewModel.inspectionId
                            actionViewModel.getActionsList()
                            emptyStateFailedItems.visibility = View.GONE
                        }
                    }
                    NetworkState.ERROR -> {
                        when (it.code) {
                            404 -> {
                                emptyStateFailedItems.visibility = View.VISIBLE
                            }
                            else -> {
                                SnackBar.snackBarShowError(
                                    this,
                                    parentLayout,
                                    it.message
                                        ?: getString(R.string.general_server_error_message)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    private fun observeReportInfo() {
        observeData(viewModel.infoResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { result ->
                            emptyStateInfo.visibility = View.GONE
                            mappingReportAdditionalInfoToView(result)
                        }
                    }
                    NetworkState.ERROR -> {
                        when (it.code) {
                            404 -> {
                                emptyStateInfo.visibility = View.VISIBLE
                            }
                            else -> {
                                SnackBar.snackBarShowError(
                                    this,
                                    parentLayout,
                                    it.message
                                        ?: getString(R.string.general_server_error_message)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    private fun onClickReportMenuItem(position: Int) {
        when (position) {
            ReportInspectionViewModel.OVERVIEW -> {
                viewModel.setActiveTab(isShowOverview = true)
                if (viewModel.reportOverviewResponse.value?.data == null) {
                    viewModel.getInspectionReportOverview()
                }
            }
            ReportInspectionViewModel.REPORT_SUMMARY -> {
                viewModel.setActiveTab(isShowReportSummary = true)
                if (viewModel.reportSummaryResponse.value?.data == null) {
                    viewModel.getInspectionReportSummary()
                }
            }
            ReportInspectionViewModel.TITLE_PAGE -> {
                viewModel.setActiveTab(isShowTitlePage = true)
                if (viewModel.titlePageResponse.value?.data == null) {
                    viewModel.getInspectionReportTitlePage()
                }
            }
            ReportInspectionViewModel.CHECKLIST_RESULT -> {
                viewModel.setActiveTab(isShowCheckListResult = true)
                if (viewModel.checklistResultResponse.value?.data == null) {
                    viewModel.getInspectionReportChecklistResult()
                }
            }
            ReportInspectionViewModel.FAILED_ITEMS -> {
                viewModel.setActiveTab(isShowFailedItems = true)
                viewModel.getInspectionReportFailedItems()
            }
            ReportInspectionViewModel.INFO -> {
                viewModel.setActiveTab(isShowInfo = true)
                if (viewModel.infoResponse.value?.data == null) {
                    viewModel.getInspectionReportInfo()
                }
            }
        }
    }

    @SuppressLint("SetTextI18n")
    private fun mappingOverviewToView(result: ReportOverviewResponse) {
        tvOverviewTitle.text = result.data?.title
        tvOverviewDescription.text = result.data?.descriptions
        tvPreparedByValue.text = result.data?.preparedBy
        result.data?.score?.let {
            val number2digits: Double = (it * 100.0).roundToInt() / 100.0
            tvInspectionScoreValue.text = getString(
                R.string.report_score_value,
                number2digits.toString(), "%"
            )
        }
        result.data?.completedDate?.let {
            tvOverviewCompleteByAuditorValue.text = DateHelper.changeFormat(
                it,
                DateHelper.yyyy_MM_dd_T_HHmmss,
                DateHelper.dd_MM_yy_HH_mm
            )
        }
        result.data?.approvedDate?.let {
            tvOverviewApprovedByAuditeeValue.text = DateHelper.changeFormat(
                it,
                DateHelper.yyyy_MM_dd_T_HHmmss,
                DateHelper.dd_MM_yy_HH_mm
            )
        }
        result.data?.conductedOn?.let {
            tvConductedOnValue.text = DateHelper.changeFormat(
                it,
                DateHelper.yyyy_MM_dd_T_HHmmss,
                DateHelper.dd_MM_yy_HH_mm
            )
        }
        tvOverviewLocation.text = result.data?.locationName
        tvOverviewLocationDetail.text = result.data?.address
        tvOverviewStatus.apply {
            result.data?.statusInspection?.let { status ->
                text = status
                setBackgroundResource(
                    IssuesStatusViewHelper.getStatusBackgroundColor(
                        status
                    )
                )
                setTextColor(
                    ContextCompat.getColor(
                        context,
                        IssuesStatusViewHelper.getStatusTextColor(status)
                    )
                )
            }
        }
        result.data?.let {
            if (it.latLong?.isNotEmpty() == true) {
                addMarker(it.latLong)
            }
        }
    }

    private fun mappingReportSummaryToView(result: ReportSummaryResponse) {
        tvPreviousRecommendationIssue.text = getString(
            R.string.report_issues_recommendation_value,
            result.data?.previousRecomendation?.issue?.size
        )
        tvPreviousRecommendationAction.text = getString(
            R.string.report_actions_recommendation_value,
            result.data?.previousRecomendation?.action?.size
        )
        result.data?.score?.let {
            val number2digits: Double = (it * 100.0).roundToInt() / 100.0
            tvCurrentRecommendationScore.text = getString(
                R.string.report_score_value,
                number2digits.toString(), "%"
            )
        }
        tvCurrentRecommendationIssue.text = getString(
            R.string.report_issues_recommendation_value,
            result.data?.previousRecomendation?.issue?.size
        )
        tvCurrentRecommendationAction.text = getString(
            R.string.report_actions_recommendation_value,
            result.data?.previousRecomendation?.action?.size
        )
        tvIssueByPriorityFilesValue.text = getString(
            R.string.report_files_value,
            result.data?.images?.size
        )
        val gridManager = GridLayoutManager(this, 10)
        val filesAdapter = ImagesPreviewAdapter()
        filesAdapter.setItemClickListener(object : ImagesPreviewAdapter.ItemClickListener {
            override fun onClickItem(url: String) {
                showImageZoom(url)
            }
        })
        rvFiles.apply {
            layoutManager = gridManager
            setHasFixedSize(true)
            adapter = filesAdapter
            addItemDecoration(GridSpacingItemDecoration(10, 16, false))
        }
        filesAdapter.setData(result.data?.images ?: mutableListOf())
    }

    private fun mappingReportTitlePageToView(result: ReportTitlePageResponse) {
        val llManager = LinearLayoutManager(this)
        val titlePageAdapter = TitlePageAdapter()
        rvReportTitlePage.apply {
            layoutManager = llManager
            setHasFixedSize(true)
            adapter = titlePageAdapter
        }
        titlePageAdapter.setData(result.data?.templatePage ?: mutableListOf())
    }

    private fun mappingReportChecklistResultToView(result: ReportChecklistResultResponse) {
        val llManager = LinearLayoutManager(this)
        val checklistResultPageAdapter = ChecklistResultPageAdapter()
        checklistResultPageAdapter.setItemClickListener(object :
            ChecklistResultPageAdapter.ItemClickListener {
            override fun onClickAttachment(questionId: String) {
                viewModel.getImagesByQuestionFromAPI(questionId.toInt())
            }

            override fun onClickVoiceNote(questionId: String) {
                //TODO("Not yet implemented")
            }

            override fun onClickActions(questionId: String) {
                ActionsActivity.startThisActivity(
                    this@ReportInspectionActivity,
                    viewModel.inspectionId.orEmpty(),
                    questionId
                )
            }
        })
        rvCheckListResult.apply {
            layoutManager = llManager
            setHasFixedSize(true)
            adapter = checklistResultPageAdapter
        }
        checklistResultPageAdapter.setData(result.data ?: mutableListOf())
    }

    private fun goToIssueDetail(data: IssueModel.Issue) {
        val intent = Intent(this, IssueDetailActivity::class.java)
        intent.putExtra(IssueDetailActivity.EXTRA_ISSUE_ID, data.issueId)
        intent.putExtra(IssueDetailActivity.EXTRA_INSPECTION_ID, viewModel.inspectionId)
        intent.putExtra(IssueDetailActivity.EXTRA_INSPECTION_ISSUE_DATA, data)
        startActivity(intent)
    }

    private fun mappingReportFailedItemsToView(result: MutableList<IssueModel.Issue>) {
        val llManager = LinearLayoutManager(this)
        failedItemsAdapter.setItemClickListener(object : InspectionIssueAdapter.ItemClickListener {
            override fun onClickAddAction(data: IssueModel.Issue) {
                val intent = Intent(this@ReportInspectionActivity, CreateActionActivity::class.java)
                intent.putExtra(
                    CreateActionActivity.EXTRA_INSPECTION_ID,
                    viewModel.inspectionId.orEmpty()
                )
                intent.putExtra(CreateActionActivity.EXTRA_ISSUE_DATA, data)
                createActionLauncher.launch(intent)
            }

            override fun onClickIssue(data: IssueModel.Issue) {
                goToIssueDetail(data)
            }

        })
        rvFailedItems.apply {
            layoutManager = llManager
            setHasFixedSize(true)
            adapter = failedItemsAdapter
        }
        failedItemsAdapter.setData(result)
    }

    private fun mappingReportAdditionalInfoToView(result: List<InspectionInfo>) {
        val llManager = LinearLayoutManager(this)
        val additionalInfoAdapter = AdditionalInfoAdapter()
        rvAdditionalInfo.apply {
            layoutManager = llManager
            setHasFixedSize(true)
            adapter = additionalInfoAdapter
        }
        additionalInfoAdapter.setData(result)
    }

    private fun addMarker(latLong: String) {
        val latLng = latLong.split(",").toTypedArray()
        val latitude = latLng[0].toDouble()
        val longitude = latLng[1].toDouble()
        val locationLatLng = LatLng(latitude, longitude)

        if (latitude != 0.0 && longitude != 0.0 && this::map.isInitialized) {
            val icon = BitmapDescriptorFactory.fromResource(R.drawable.ic_map_pin_red)
            map.addMarker(
                MarkerOptions().position(locationLatLng)
                    .icon(icon)
            )
            setCameraMove(latitude, longitude)
        }
    }

    private fun setCameraMove(latitude: Double, longitude: Double) {
        map.animateCamera(
            CameraUpdateFactory.newLatLngZoom(
                LatLng(latitude, longitude),
                15f
            )
        )
    }

    private fun observeDownloadFile() {
        observeData(viewModel.downloadFileResponse) { result ->
            result?.let {
                hideDownloadDialog()
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { body ->
                            showMessageDialogDownloadComplete(body)
                        } ?: run {
                            Toast.makeText(
                                this@ReportInspectionActivity,
                                getString(R.string.file_not_found),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message ?: getString(R.string.general_server_error_message)
                        )
                    }
                }
            }
        }
    }

    private fun observeImageFile() {
        observeData(viewModel.imageFileResponse) { result ->
            result?.let {
                hideDownloadDialog()
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { body ->
                            val listOfLinkImage: MutableList<String> = mutableListOf()
                            body.data?.forEach { file ->
                                listOfLinkImage.add(file.linkFile.toString())
                            }
                            openImageAttachments(listOfLinkImage)
                        } ?: run {
                            Toast.makeText(
                                this@ReportInspectionActivity,
                                getString(R.string.file_not_found),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message ?: getString(R.string.general_server_error_message)
                        )
                    }
                }
            }
        }
    }

    override fun onClickDownloadPdf(view: View) {
        fileExt = ".pdf"
        val pdfFileUrl =
            BuildConfig.BASE_URL + CommonConstant.INSPECTION_REPORT_PDF_URL + viewModel.inspectionId.orEmpty()
        checkPermissionBeforeDownload(pdfFileUrl)
    }

    override fun onClickDownloadWord(view: View) {
        fileExt = ".docx"
        val wordFileUrl =
            BuildConfig.BASE_URL + CommonConstant.INSPECTION_REPORT_WORD_URL + viewModel.inspectionId.orEmpty()
        checkPermissionBeforeDownload(wordFileUrl)
    }

    private fun checkPermissionBeforeDownload(fileUrl: String) {
        if (CommonFunction.isConnectingToInternet(this)) {
            val writeExternalStorage =
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            val readExternalStorage =
                Manifest.permission.READ_EXTERNAL_STORAGE
            val hasWritePermission: Int =
                ContextCompat.checkSelfPermission(this, writeExternalStorage)
            val hasReadPermission: Int =
                ContextCompat.checkSelfPermission(this, readExternalStorage)
            val permissions: MutableList<String> =
                java.util.ArrayList()
            if (hasReadPermission != PackageManager.PERMISSION_GRANTED &&
                hasWritePermission != PackageManager.PERMISSION_GRANTED
            ) {
                permissions.add(writeExternalStorage)
                permissions.add(readExternalStorage)
            }
            when {
                permissions.isNotEmpty() -> {
                    val params =
                        permissions.toTypedArray()
                    requestPermissions(params, 100)
                }
                File(
                    getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),
                    viewModel.inspectionId.orEmpty() + fileExt
                ).exists() -> {
                    DownloadFile.viewFile(
                        this,
                        File(
                            getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),
                            viewModel.inspectionId.orEmpty() + fileExt
                        )
                    )
                }
                else -> {
                    startDownloadFile(fileUrl)
                }
            }
        } else {
            DownloadFile.showDialogInfoCLose(
                this,
                getString(R.string.error_download_file)
            )
        }
    }

    private fun startDownloadFile(fileUrl: String) {
        getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)?.let {
            val fileDownload = File(it, viewModel.inspectionId.orEmpty() + fileExt)
            if (!fileDownload.exists() && fileDownload.length() <= 0) {
                showStartDownloadDialog()
            }
            viewModel.startDownloadFile(fileUrl)
        }
    }

    private fun showMessageDialogDownloadComplete(body: ResponseBody?) {
        try {
            val fileDownload = File(
                getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),
                viewModel.inspectionId.orEmpty() + fileExt
            )
            DownloadFile.copyFile(body?.byteStream(), fileDownload)
            val alertDialog = AlertDialog.Builder(this)
                .setMessage(getString(R.string.download_complete))
                .setPositiveButton(getString(R.string.view_label)) { dialog, _ ->
                    dialog.dismiss()
                    DownloadFile.viewFile(this, fileDownload)
                }
                .setNegativeButton(getString(R.string.close_label)) { dialog, _ ->
                    dialog.dismiss()
                }
            alertDialog.show()
        } catch (e: IOException) {
            Log.d("TAG", "file not download:")
        }
    }

    private fun showStartDownloadDialog() {
        val mDialogView =
            LayoutInflater.from(this).inflate(R.layout.progressbar_dialog_layout, null)
        mDialogView.tvMessage.text = getString(R.string.downloading_file_label)
        val mBuilder = AlertDialog.Builder(this)
            .setView(mDialogView)
        mAlertDialog = mBuilder.show()
    }

    private fun hideDownloadDialog() {
        if (mAlertDialog != null) {
            mAlertDialog?.dismiss()
        }
    }

    private fun showImageZoom(url: String) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(R.layout.custom_dialog)
        val imageView: ImageView = dialog.findViewById(R.id.ivPreview)
        val ivClose: ImageView = dialog.findViewById(R.id.ivClose)
        ivClose.setOnClickListener {
            dialog.dismiss()
        }
        Glide.with(this).load(url)
            .into(imageView)
        dialog.show()
    }

    private fun openImageAttachments(listOfLinkImage: MutableList<String>) {
        val bundle = Bundle()
        bundle.putStringArrayList("EXISTING_IMAGE", ArrayList(listOfLinkImage))
        bundle.putBoolean("FROM_REPORT", true)
        val dialog = ImagesReportSheet()
        dialog.arguments = bundle
        dialog.show(supportFragmentManager, "add_photo")
    }
}
