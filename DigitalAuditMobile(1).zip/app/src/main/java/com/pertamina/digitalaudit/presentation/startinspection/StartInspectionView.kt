package com.pertamina.digitalaudit.presentation.startinspection

import com.pertamina.framework.base.BaseView

interface StartInspectionView : BaseView
