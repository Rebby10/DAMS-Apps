package com.pertamina.digitalaudit.model.startinspection

import com.google.gson.annotations.SerializedName
import com.pertamina.framework.base.BaseResponse

class ListInspectionPage : BaseResponse() {

    @field:SerializedName("Result")
    val data: List<InspectionPage>? = null
}
