package com.pertamina.digitalaudit.presentation.inspectionfilter

import android.view.View
import com.pertamina.framework.base.BaseView

interface InspectionFilterView : BaseView {
    fun onClickApplyFilter(view: View)
    fun onClickChooseLocation(view: View)
    fun onClickChooseRegion(view: View)
}
