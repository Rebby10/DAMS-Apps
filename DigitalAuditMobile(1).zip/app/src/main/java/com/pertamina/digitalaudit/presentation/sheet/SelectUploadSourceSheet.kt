package com.pertamina.digitalaudit.presentation.sheet

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.coordinatorlayout.widget.CoordinatorLayout
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.pertamina.digitalaudit.R
import kotlinx.android.synthetic.main.sheet_select_upload_source.*

class SelectUploadSourceSheet : BottomSheetDialogFragment() {

    interface SelectUploadSourceBottomSheetFragmentListener{
        fun onSelectCamera()
        fun onSelectGallery()
        fun onSelectFile()
    }
    var listener : SelectUploadSourceBottomSheetFragmentListener? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.sheet_select_upload_source, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setEvent()
    }

    private fun setEvent(){
        camera_container.setOnClickListener {
            listener?.onSelectCamera()
            dismiss()
        }
        gallery_container.setOnClickListener {
            listener?.onSelectGallery()
            dismiss()
        }
        file_container.setOnClickListener {
            listener?.onSelectFile()
            dismiss()
        }
    }

    private var bottomSheetBehavior: BottomSheetBehavior<*>? = null
    override fun onStart() {
        super.onStart()
        val dialog = dialog

        if (dialog != null) {
            val bottomSheet: View? = dialog.findViewById(R.id.container)
            bottomSheet?.layoutParams?.height = ViewGroup.LayoutParams.MATCH_PARENT
            view?.post {
                val parent = view?.parent as View
                val params = parent.layoutParams as CoordinatorLayout.LayoutParams
                val behavior = params.behavior
                bottomSheetBehavior = behavior as BottomSheetBehavior<*>?

                bottomSheet?.layoutParams?.height = ViewGroup.LayoutParams.MATCH_PARENT
                bottomSheetBehavior?.setPeekHeight(requireView().measuredHeight)
            }
        }
    }
}
