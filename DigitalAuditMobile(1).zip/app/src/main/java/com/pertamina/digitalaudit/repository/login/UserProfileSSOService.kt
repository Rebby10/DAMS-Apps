package com.pertamina.digitalaudit.repository.login

import com.pertamina.digitalaudit.model.UserProfileModel
import retrofit2.http.GET

interface UserProfileSSOService {

    @GET("connect/userinfo")
    suspend fun getUserProfileDataFromSSO(): UserProfileModel
}
