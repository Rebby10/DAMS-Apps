package com.pertamina.digitalaudit.repository.common

import com.pertamina.digitalaudit.model.ActionRepairMasterDataModel
import com.pertamina.digitalaudit.model.AuditTypeModel
import com.pertamina.digitalaudit.model.FAQMasterDataModel
import com.pertamina.digitalaudit.model.HomeOverviewModel
import com.pertamina.digitalaudit.model.InspectionModel
import com.pertamina.digitalaudit.model.IssueModel
import com.pertamina.digitalaudit.model.LocationModel
import com.pertamina.digitalaudit.model.PriorityModel
import com.pertamina.digitalaudit.model.RegionModel
import com.pertamina.digitalaudit.model.Reschedule
import com.pertamina.digitalaudit.model.ScheduleModel
import com.pertamina.digitalaudit.model.TemplateModel
import com.pertamina.digitalaudit.model.query.GetHomeOverviewQuery
import com.pertamina.digitalaudit.model.query.GetInspectionQuery
import com.pertamina.digitalaudit.model.query.GetIssueQuery
import com.pertamina.digitalaudit.model.query.GetLocationQuery
import com.pertamina.digitalaudit.model.query.GetRegionQuery
import com.pertamina.digitalaudit.model.query.GetRescheduleQuery
import com.pertamina.digitalaudit.model.query.GetScheduleQuery
import com.pertamina.digitalaudit.model.query.GetTemplateQuery
import com.pertamina.framework.base.Resource

interface CommonRepository {

    @Throws(Exception::class)
    suspend fun getHomeIssueList(query: GetIssueQuery): Resource<List<IssueModel.Issue>>

    @Throws(Exception::class)
    suspend fun getHomeScheduleList(query: GetScheduleQuery): Resource<List<ScheduleModel.Schedule>>

    @Throws(Exception::class)
    suspend fun getHomeRescheduleList(query: GetRescheduleQuery): Resource<List<Reschedule>>

    @Throws(Exception::class)
    suspend fun getHomeInspectionList(query: GetInspectionQuery): Resource<List<InspectionModel.Inspection>>

    @Throws(Exception::class)
    suspend fun getHomeOverview(query: GetHomeOverviewQuery): Resource<HomeOverviewModel>

    @Throws(Exception::class)
    suspend fun getFAQMasterData(): Resource<List<FAQMasterDataModel.FAQ>>

    @Throws(Exception::class)
    suspend fun getRegionMasterData(query: GetRegionQuery): Resource<List<RegionModel.Region>>

    @Throws(Exception::class)
    suspend fun getActionRepairMasterData(): Resource<ActionRepairMasterDataModel.ActionRepairMasterData>

    @Throws(Exception::class)
    suspend fun getLocation(query: GetLocationQuery?): Resource<List<LocationModel.Location>>

    @Throws(Exception::class)
    suspend fun getTemplate(query: GetTemplateQuery): Resource<List<TemplateModel.Template>>

    @Throws(Exception::class)
    suspend fun getPriority(): Resource<List<PriorityModel.Priority>>

    @Throws(Exception::class)
    suspend fun getAuditType(): Resource<List<AuditTypeModel.AuditType>>
}
