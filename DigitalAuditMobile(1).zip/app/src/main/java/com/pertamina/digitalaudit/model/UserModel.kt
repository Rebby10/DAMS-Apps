package com.pertamina.digitalaudit.model

import com.google.gson.annotations.SerializedName
import com.pertamina.framework.base.BaseResponse

class UserModel : BaseResponse() {
    @SerializedName("Result")
    var data: User? = null

    class User {

        @SerializedName("UserId")
        var userId: String? = ""

        @SerializedName("DisplayName")
        var name: String? = ""

        @SerializedName("Email")
        var email: String? = ""

        @SerializedName("CompanyName")
        var companyName: String? = "-"

        @SerializedName("JobTitle")
        var jobTitle: String? = "-"

        @SerializedName("Photo")
        var photoUrl: String? = ""

        @SerializedName("Department")
        var department: String? = "-"

        @SerializedName("OfficeLocation")
        var officeLocation: String? = "-"
    }
}
