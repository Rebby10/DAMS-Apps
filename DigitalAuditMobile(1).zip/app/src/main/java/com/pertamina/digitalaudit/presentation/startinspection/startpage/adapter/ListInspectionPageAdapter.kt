package com.pertamina.digitalaudit.presentation.startinspection.startpage.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.model.startinspection.InspectionPage
import com.pertamina.framework.base.BaseRecyclerViewAdapter
import com.pertamina.framework.base.BaseViewHolder
import kotlinx.android.synthetic.main.item_inspection_page.view.*

class ListInspectionPageAdapter : BaseRecyclerViewAdapter<InspectionPage>() {

    private var listener: ItemClickListener? = null

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BaseViewHolder<InspectionPage> {
        val view = LayoutInflater.from(parent.context).inflate(viewType, parent, false)
        return ListViewHolder(parent.context, view, listener)
    }

    override fun onBindViewHolder(
        holder: BaseViewHolder<InspectionPage>,
        position: Int
    ) {
        holder.bindData(getItem(position))
    }

    override fun getItemViewType(position: Int): Int {
        return R.layout.item_inspection_page
    }

    class ListViewHolder(context: Context, val view: View, listener: ItemClickListener?) :
        BaseViewHolder<InspectionPage>(context, view) {

        private var holderListener: ItemClickListener? = listener
        private var tvPageName = view.tvPageName

        override fun bindData(data: InspectionPage) {
            tvPageName.text = data.title
            itemView.setOnClickListener {
                holderListener?.onClickItem(data)
            }
        }
    }

    fun setItemClickListener(listener: ItemClickListener) {
        this.listener = listener
    }

    interface ItemClickListener {
        fun onClickItem(data: InspectionPage)
    }
}