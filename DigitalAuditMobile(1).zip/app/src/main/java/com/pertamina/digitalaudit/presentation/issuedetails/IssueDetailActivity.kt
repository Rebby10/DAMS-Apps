package com.pertamina.digitalaudit.presentation.issuedetails

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.databinding.ActivityIssueDetailBinding
import com.pertamina.digitalaudit.model.IssueDetailModel
import com.pertamina.digitalaudit.model.IssueModel
import com.pertamina.digitalaudit.model.IssueStatusModel
import com.pertamina.digitalaudit.presentation.actionofissue.ActionOfIssueActivity
import com.pertamina.digitalaudit.presentation.createaction.CreateActionActivity
import com.pertamina.digitalaudit.presentation.createissue.CreateIssueActivity
import com.pertamina.digitalaudit.presentation.login.LoginActivity
import com.pertamina.digitalaudit.presentation.sheet.CommonOptionsSheet
import com.pertamina.digitalaudit.util.SnackBar
import com.pertamina.framework.NetworkState
import com.pertamina.framework.ViewDataBindingOwner
import com.pertamina.framework.base.BaseActivity
import com.pertamina.framework.util.DateHelper
import kotlinx.android.synthetic.main.activity_issue_detail.*
import kotlinx.android.synthetic.main.toolbar_layout.*
import org.koin.androidx.viewmodel.ext.android.viewModel

/**
 * Created by M Hafidh Abdul Aziz on 16/03/21.
 */

class IssueDetailActivity : BaseActivity<IssueDetailViewModel>(), IssueDetailView,
    ViewDataBindingOwner<ActivityIssueDetailBinding> {

    override val layoutResourceId: Int = R.layout.activity_issue_detail
    override val viewModel: IssueDetailViewModel by viewModel()
    override var binding: ActivityIssueDetailBinding? = null
    private lateinit var menuBottomSheet: CommonOptionsSheet
    private var detailIssue: IssueModel.Issue? = null

    companion object {

        const val EXTRA_ISSUE_ID = "EXTRA_ISSUE_ID"
        const val EXTRA_INSPECTION_ID = "EXTRA_INSPECTION_ID"
        const val EXTRA_INSPECTION_ISSUE_DATA = "EXTRA_INSPECTION_ISSUE_DATA"
        private const val EXTRA_IS_ASSIGN_TO_ME = "EXTRA_IS_ASSIGN_TO_ME"

        fun startThisActivity(context: Context, issueId: String, isAssignToMe: Boolean) {
            val intent = Intent(context, IssueDetailActivity::class.java)
            intent.putExtra(EXTRA_ISSUE_ID, issueId)
            intent.putExtra(EXTRA_IS_ASSIGN_TO_ME, isAssignToMe)
            context.startActivity(intent)
        }
    }

    private var updateIssueLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                viewModel.getIssueDetail()
            }
        }

    private var createActionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                getIssueDetail()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setupToolbar()
        getExtraData()
        getIssueDetail()
        observeIssueDetail()
        observeStatusList()
        subscribeUpdateIssue()
        manageSaveButton(false)
    }

    private fun setupToolbar() {
        tvTitleToolbar.text = getString(R.string.issues_detail_issue)
        btnBackToolbar.apply {
            visibility = View.VISIBLE
            setOnClickListener {
                onBackPressed()
            }
        }
    }

    override fun onClickEditIssue(view: View) {
        val intent = Intent(this, CreateIssueActivity::class.java)
        intent.putExtra(CreateIssueActivity.EXTRA_ISSUE_ID, viewModel.issueId)
        updateIssueLauncher.launch(intent)
    }

    override fun onClickChangeIssueStatus(view: View) {
        showMenuBottomSheet()
    }

    override fun onClickCreateActions(view: View) {
        val intent = Intent(this, CreateActionActivity::class.java)
        intent.putExtra(
            CreateActionActivity.EXTRA_INSPECTION_ID,
            viewModel.inspectionId
        )
        intent.putExtra(CreateActionActivity.EXTRA_ISSUE_DATA, detailIssue)
        createActionLauncher.launch(intent)
    }

    override fun onClickSaveIssue(view: View) {
        viewModel.updateIssue()
    }

    override fun onClickViewActions(view: View) {
        ActionOfIssueActivity.startThisActivity(this, viewModel.issueId)
    }

    private fun getExtraData() {
        detailIssue = intent.getSerializableExtra(EXTRA_INSPECTION_ISSUE_DATA) as? IssueModel.Issue
        viewModel.issueId = intent?.getStringExtra(EXTRA_ISSUE_ID).orEmpty()
        viewModel.inspectionId = intent?.getStringExtra(EXTRA_INSPECTION_ID).orEmpty()
        viewModel.isDetailIssueStateAuditee.value = intent?.getBooleanExtra(EXTRA_IS_ASSIGN_TO_ME, false) ?: false
        viewModel.isFromInspection.value = viewModel.inspectionId.isNotEmpty()
    }

    private fun getIssueDetail() {
        viewModel.getIssueDetail()
    }

    private fun observeIssueDetail() {
        observeData(viewModel.issueDetailResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { issueDetail ->
                            viewModel.isActionExist.value = issueDetail.data?.isConnectedToAction
                            viewModel.detailIssueStatusId.value =
                                issueDetail.data?.status?.statusId ?: 0
                            viewModel.prevDetailIssueStatusId.value =
                                issueDetail.data?.status?.statusId ?: 0
                            viewModel.getIssueStatusList()
                            setDataToView(issueDetail.data)
                        }
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message ?: getString(R.string.general_server_error_message)
                        )
                        when (it.code) {
                            401 -> {
                                viewModel.preference.clearPreferences()
                                logout(Intent(this, LoginActivity::class.java))
                            }
                            else -> {
                                //do nothing just to avoid error warning
                            }
                        }
                    }
                }
            }
        }
    }

    private fun observeStatusList() {
        observeData(viewModel.statusListResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        initIssueStatusSheet(it.data)
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            getString(R.string.general_server_error_message)
                        )
                    }
                }
            }
        }
    }

    private fun subscribeUpdateIssue() {
        observeData(viewModel.updateIssueResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        SnackBar.snackBarShowSuccess(
                            this,
                            parentLayout,
                            it.message ?: getString(R.string.issues_status_update_message)
                        )
                        manageSaveButton(false)
                        getIssueDetail()
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message ?: getString(R.string.general_server_error_message)
                        )
                        when (it.code) {
                            401 -> {
                                viewModel.preference.clearPreferences()
                                logout(Intent(this, LoginActivity::class.java))
                            }
                        }
                    }
                }
            }
        }
    }

    private fun setDataToView(issueDetail: IssueDetailModel.IssueDetail?) {
        viewModel.isFromInspection.value = issueDetail?.questionId?.isNotEmpty()
        viewModel.bTextDetailIssueAutoTitle.value = "" //todo ask for attribute when inspection done
        viewModel.bTextDetailIssueAutoDescription.value =
            issueDetail?.code + " - " + issueDetail?.question
        viewModel.bTextDetailIssueTitle.value = issueDetail?.title
        viewModel.bTextDetailIssueDescription.value = issueDetail?.descriptions
        viewModel.bTextDetailIssueLocation.value = issueDetail?.auditLocation?.name
        viewModel.bTextDetailIssueCreatedAt.value = DateHelper.changeFormat(
            issueDetail?.dateCreated.orEmpty(),
            DateHelper.yyyy_MM_dd_T_HHmmss,
            DateHelper.dd_MMM_yyyy_hh_mm_a
        )
        viewModel.bTextDetailIssueCreatedBy.value =
            getString(R.string.created_by_argument, issueDetail?.creator?.displayName)
        viewModel.bTextDetailIssueAssignTo.value =
            getString(R.string.assign_to_argument, issueDetail?.assignUser?.displayName)
        viewModel.bTextDetailIssuePriority.value =
            getString(R.string.priority_argument, issueDetail?.priority?.name)
        viewModel.bTextDetailIssueTargetClosing.value = getString(
            R.string.target_closing_argument, DateHelper.changeFormat(
                issueDetail?.targetClosing.orEmpty(),
                DateHelper.yyyy_MM_dd_T_HHmmss,
                DateHelper.dd_MMM_yyyy_hh_mm_a
            )
        )
        viewModel.bTextDetailIssueCategory.value =
            getString(R.string.category_issue_argument, issueDetail?.issueCategory?.name)
        viewModel.bTextDetailIssueIdentification.value =
            getString(R.string.recurring_finding_argument, issueDetail?.recurringFinding.toString())
    }

    private fun initIssueStatusSheet(data: List<IssueStatusModel.IssueStatus>?) {
        viewModel.bTextDetailIssueStatus.value = getString(
            R.string.issues_detail_status,
            data?.get(viewModel.getSelectedStatusItemPosition())
        )
        val menuList: MutableList<CommonOptionsSheet.BottomSheetMenuModel> = mutableListOf()
        for (menu in data ?: emptyList()) {
            menuList.add(
                CommonOptionsSheet.BottomSheetMenuModel(
                    0, menu.statusId ?: 0,
                    menu.name.orEmpty()
                )
            )
        }
        menuBottomSheet = CommonOptionsSheet(this, menuList).apply {
            setCancelable(true)
            setMenuItemListener(object :
                CommonOptionsSheet.MenuItemClickListener {
                override fun onBottomSheetItemClicked(menu: String, id: Int) {
                    dismiss()
                    viewModel.detailIssueStatusId.value = id
                    viewModel.bTextDetailIssueStatus.value =
                        getString(R.string.issues_detail_status, menu)
                    manageSaveButton(viewModel.prevDetailIssueStatusId.value != viewModel.detailIssueStatusId.value)
                }
            })
        }
    }

    private fun showMenuBottomSheet() {
        if (this::menuBottomSheet.isInitialized) menuBottomSheet.show()
    }

    private fun manageSaveButton(enable: Boolean) {
        btnSave.run {
            isEnabled = enable
            alpha = if (enable) 1f else .5f
        }
    }
}
