package com.pertamina.digitalaudit.model.startinspection

import com.google.gson.annotations.SerializedName
import com.pertamina.digitalaudit.model.InspectionModel
import com.pertamina.framework.base.BaseResponse
import java.io.Serializable

class StartInspectionResponseModel : BaseResponse() {

    @field:SerializedName("Result")
    val data: StartInspectionModel? = null
}

data class StartInspectionModel(

    @field:SerializedName("Inspection")
    val inspection: InspectionModel.Inspection? = null,

    @field:SerializedName("Descriptions")
    val descriptions: String? = null,

    @field:SerializedName("TemplatePage")
    val templatePage: List<InspectionPage?>? = null,

    @field:SerializedName("TemplateCategory")
    val templateCategory: TemplateCategory? = null,

    @field:SerializedName("Title")
    val title: String? = null,

    @field:SerializedName("Code")
    val code: String? = null,

    @field:SerializedName("TemplatePermissionType")
    val templatePermissionType: TemplatePermissionType? = null,

    @field:SerializedName("TemplatePermission")
    val templatePermission: List<TemplatePermissionItem?>? = null,

    @field:SerializedName("TemplateId")
    val templateId: String? = null
) : Serializable

data class SectionItem(

    @field:SerializedName("PageId")
    val pageId: String? = null,

    @field:SerializedName("SeqNo")
    val seqNo: Int? = null,

    @field:SerializedName("Question")
    val question: List<QuestionItem>? = null,

    @field:SerializedName("SectionId")
    val sectionId: String? = null,

    @field:SerializedName("Name")
    val name: String? = null
) : Serializable

data class TemplatePermissionItem(

    @field:SerializedName("OfficialName")
    val officialName: String? = null,

    @field:SerializedName("Username")
    val username: String? = null,

    @field:SerializedName("UserId")
    val userId: String? = null
) : Serializable

data class QuestionItem(

    @field:SerializedName("PageId")
    val pageId: String? = null,

    @field:SerializedName("Response")
    val response: Response? = null,

    @field:SerializedName("SeqNo")
    val seqNo: Int? = null,

    @field:SerializedName("Answer")
    var answer: Answer? = null,

    @field:SerializedName("IsMandatory")
    val isMandatory: Boolean? = null,

    @field:SerializedName("QuestionId")
    val questionId: Int? = null,

    @field:SerializedName("Question")
    val question: String? = null,

    @field:SerializedName("Code")
    val code: String? = null,

    @field:SerializedName("SectionId")
    val sectionId: String? = null,

    //aditional
    var isImageAttached: Boolean = false,
    var isVoiceAttached: Boolean = false
) : Serializable

data class TemplateCategory(

    @field:SerializedName("CategoryId")
    val categoryId: Int? = null,

    @field:SerializedName("Name")
    val name: String? = null
) : Serializable

data class Response(

    @field:SerializedName("ResponseId")
    val responseId: Int? = null,

    @field:SerializedName("Name")
    val name: String? = null,

    @field:SerializedName("ResponseType")
    val responseType: ResponseType? = null,

    @field:SerializedName("ResponseList")
    val responseList: List<ResponseListItem>? = null
) : Serializable

data class ResponseType(

    @field:SerializedName("TypeId")
    val typeId: Int? = null,

    @field:SerializedName("Name")
    val name: String? = null
) : Serializable

data class TemplatePermissionType(

    @field:SerializedName("TemplatePermissionTypeId")
    val templatePermissionTypeId: Int? = null,

    @field:SerializedName("Name")
    val name: String? = null
) : Serializable

data class ResponseListItem(

    @field:SerializedName("SeqNo")
    val seqNo: Int? = null,

    @field:SerializedName("Score")
    val score: Int? = null,

    @field:SerializedName("ListId")
    val listId: Int? = null,

    @field:SerializedName("ResponseId")
    val responseId: Int? = null,

    @field:SerializedName("IsFailedResponse")
    val isFailedResponse: Boolean? = null,

    @field:SerializedName("Name")
    val name: String? = null,

    var isSelected: Boolean = false
) : Serializable

data class Answer(
    @field:SerializedName("ResultId")
    val resultId: String? = null,
    @field:SerializedName("AnswerId")
    val answerId: Int? = null,
    @field:SerializedName("AnswerText")
    var answerText: String? = null,
    @field:SerializedName("LinkFile")
    val linkFile: String? = null,
    @field:SerializedName("Notes")
    var notes: String? = null,
) : Serializable
