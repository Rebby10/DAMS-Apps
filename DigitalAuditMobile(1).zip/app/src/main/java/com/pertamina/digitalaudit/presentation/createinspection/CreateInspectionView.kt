package com.pertamina.digitalaudit.presentation.createinspection

import android.view.View
import com.pertamina.framework.base.BaseView

interface CreateInspectionView : BaseView {
    fun onClickCreateInspection(view: View)
    fun onClickChooseLocation(view: View)
    fun onClickChooseAuditTypeTemplate(view: View)
    fun onClickChooseAuditor(view: View)
    fun onClickChooseAuditee(view: View)
}
