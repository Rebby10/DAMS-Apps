package com.pertamina.digitalaudit.presentation.login

import androidx.lifecycle.MutableLiveData
import com.pertamina.digitalaudit.model.UserModel
import com.pertamina.digitalaudit.model.UserProfileModel
import com.pertamina.digitalaudit.preference.PreferenceProvider
import com.pertamina.digitalaudit.preference.SharedPreferencesKey
import com.pertamina.digitalaudit.repository.login.LoginRepository
import com.pertamina.framework.base.BaseViewModel
import com.pertamina.framework.base.Resource
import kotlinx.coroutines.Dispatchers.IO
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * @author Asadurrahman Al Qayyim
 * @date 22-Mar-21
 */

class LoginViewModel(
    private val loginRepository: LoginRepository,
    val preference: PreferenceProvider
) :
    BaseViewModel() {
    val showProgressBar = MutableLiveData(false)
    val userDataResponse = MutableLiveData<Resource<UserModel.User>>()
    val userProfileDataResponse = MutableLiveData<Resource<UserProfileModel>>()

    fun getUserData() {
        showProgressBar.value = true
        launch {
            val email = userProfileDataResponse.value?.data?.email ?: ""
            val request = loginRepository.getUserData(email)
            request.data?.let { data ->
                withContext(IO) { preference.setAuthPreferences(data) }
            }
            userDataResponse.value = request
            showProgressBar.value = false
        }
    }

    fun getUserDataFromSSO() {
        launch {
            val request = loginRepository.getUserDataFromSSO()
            userProfileDataResponse.value = request
            request.data?.username?.let {
                preference.setStringToPreference(SharedPreferencesKey.USER_NAME, it)
            }
            request.data?.sub?.let {
                preference.setStringToPreference(SharedPreferencesKey.SUB, it)
            }
        }
    }
}
