package com.pertamina.digitalaudit.model

import com.google.gson.annotations.SerializedName
import com.pertamina.framework.base.BaseResponse

class ActionDetailModel : BaseResponse() {

    @SerializedName("Result")
    var data: ActionDetail? = null

    class ActionDetail {
        @SerializedName("ActionId")
        var actionId: String? = ""

        @SerializedName("Title")
        var title: String? = ""

        @SerializedName("Descriptions")
        var descriptions: String? = ""

        @SerializedName("QuestionId")
        var questionId: String? = ""

        @SerializedName("Code")
        var code: String? = ""

        @SerializedName("Question")
        var question: String? = ""

        @SerializedName("AuditType")
        var auditType: AuditTypeModel.AuditType? = null

        @SerializedName("Issue")
        var issue: IssueModel.Issue? = null

        @SerializedName("AuditLocation")
        var auditLocation: AuditLocationModel.AuditLocation? = null

        @SerializedName("AssignGroup")
        var assignGroup: AssignGroupModel.AssignGroup? = null

        @SerializedName("AssignUser")
        var assignUser: AssignUserModel.AssignUser? = null

        @SerializedName("Creator")
        var creator: CreatorModel.Creator? = null

        @SerializedName("Priority")
        var priority: PriorityModel.Priority? = null

        @SerializedName("Status")
        var status: StatusModel.Status? = null

        @SerializedName("TargetClosing")
        var targetClosing: String? = ""

        @SerializedName("DateCreated")
        var dateCreated: String? = ""
    }
}
