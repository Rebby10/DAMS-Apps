package com.pertamina.digitalaudit.presentation.action

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.databinding.FragmentActionBinding
import com.pertamina.digitalaudit.eventbus.StartActionActivityEvent
import com.pertamina.digitalaudit.model.query.GetActionQuery
import com.pertamina.digitalaudit.presentation.chat.ChatActivity
import com.pertamina.digitalaudit.presentation.createaction.CreateActionActivity
import com.pertamina.digitalaudit.presentation.home.adapter.ActionsAdapter
import com.pertamina.digitalaudit.presentation.issues.IssuesViewModel
import com.pertamina.digitalaudit.presentation.login.LoginActivity
import com.pertamina.digitalaudit.presentation.main.MainActivity
import com.pertamina.digitalaudit.presentation.map.adapter.ToolbarMenuAdapter
import com.pertamina.digitalaudit.presentation.sheet.CommonOptionsSheet
import com.pertamina.digitalaudit.presentation.sortandfilter.SortAndFilterActivity
import com.pertamina.digitalaudit.util.SnackBar
import com.pertamina.framework.NetworkState
import com.pertamina.framework.ViewDataBindingOwner
import com.pertamina.framework.base.BaseFragment
import com.pertamina.framework.extensions.sharedGraphViewModel
import kotlinx.android.synthetic.main.fragment_action.*
import kotlinx.android.synthetic.main.fragment_action.parentLayout
import kotlinx.android.synthetic.main.fragment_issues.*
import kotlinx.android.synthetic.main.layout_empty_state.*
import kotlinx.android.synthetic.main.toolbar_layout.*
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import org.koin.android.ext.android.inject

/**
 * Created by M Hafidh Abdul Aziz on 11/03/21.
 */

class ActionFragment : BaseFragment<ActionViewModel>(), ActionView,
    ViewDataBindingOwner<FragmentActionBinding>, CommonOptionsSheet.MenuItemClickListener,
    ActionsAdapter.ActionsClickListener {

    override val layoutResourceId: Int = R.layout.fragment_action
    override val viewModel: ActionViewModel by sharedGraphViewModel(R.id.nav_graph_action)
    override var binding: FragmentActionBinding? = null

    private lateinit var toolbarMenuAdapter: ToolbarMenuAdapter
    private var menuBottomSheet: CommonOptionsSheet? = null
    private var actionAdapter: ActionsAdapter? = null
    private var chosenActionId: String = ""
    private var chosenActionTitle: String = ""
    private val sortAndFilterQuery: GetActionQuery by inject()

    private lateinit var menuList: MutableList<CommonOptionsSheet.BottomSheetMenuModel>
    private val actionMenu: Array<String> by lazy {
        resources.getStringArray(R.array.actions_item_menu)
    }

    private var sortFilterLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                if (viewModel.filterMenuPosition == ActionViewModel.REPORTED_BY_ME)
                    viewModel.applyFilterActionReportByMe(sortAndFilterQuery)
                else viewModel.applyFilterActionAssignToMe(sortAndFilterQuery)
            }
        }

    private var newActionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                viewModel.getAllDataAPI()
            }
        }

    private var updateActionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                viewModel.getAllDataAPI()
            }
        }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupToolbar()
        setupView()
        setupRv()
        observeActionReportByMeList()
        observeActionAssignToMeList()
        observeDeletedAction()
        observeUpdateAction()
    }

    private fun setupToolbar() {
        tvTitleToolbar.apply {
            text = getString(R.string.title_action)
            gravity = Gravity.START
        }
        menuAction1.apply {
            visibility = View.VISIBLE
            setImageResource(R.drawable.ic_search)
            setOnClickListener {
                manageSearchLayout(true)
            }
        }
        menuAction2.apply {
            visibility = View.VISIBLE
            setImageResource(R.drawable.ic_filter)
            setOnClickListener {
                activity?.let { it1 ->
                    val intent = Intent(it1, SortAndFilterActivity::class.java)
                    intent.putExtra(SortAndFilterActivity.EXTRA_IS_FROM_ACTIONS, true)
                    sortFilterLauncher.launch(intent)
                }
            }
        }
        ivClearSearch.setOnClickListener {
            etSearchToolbar.setText("")
            manageSearchLayout(false)
            viewModel.getAllDataAPI()
        }
    }

    private fun setupView() {
        (activity as MainActivity).closeFabMenu()
        (activity as MainActivity).manageFloatingButtonAdd(true)
        etSearchToolbar.setOnKeyListener { _, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_UP) {
                if (etSearchToolbar.text.toString().isNotEmpty()) {
                    val query = GetActionQuery()
                    query.title = etSearchToolbar.text.toString()
                    if (viewModel.filterMenuPosition == ActionViewModel.REPORTED_BY_ME) {
                        viewModel.reportByMeActionList(query)
                    } else {
                        viewModel.assignToMeActionList(query)
                    }
                } else {
                    viewModel.getAllDataAPI()
                }
            }
            false
        }
        val toolbarMenu = ArrayList(listOf(*resources.getStringArray(R.array.filter_issues_menu)))
        toolbarMenuAdapter = ToolbarMenuAdapter(arrayListOf()).apply {
            setSelectedMenuPosition(IssuesViewModel.REPORTED_BY_ME)
            addData(toolbarMenu)
        }
        rvActionMenuFilter.run {
            layoutManager = LinearLayoutManager(context, RecyclerView.HORIZONTAL, false)
            adapter = toolbarMenuAdapter
        }

        toolbarMenuAdapter.setListener(object :
            ToolbarMenuAdapter.OnToolbarMenuInteractionListener {
            override fun onMenuItemClicked(menuPosition: Int) {
                toolbarMenuAdapter.setSelectedMenuPosition(menuPosition)
                onClickFilterMenuItem(menuPosition)
            }
        })
    }

    private fun setupRv() {
        actionAdapter = ActionsAdapter()
        actionAdapter?.setActionsClickListener(this)
        val manager = LinearLayoutManager(activity)
        rvAction.apply {
            layoutManager = manager
            setHasFixedSize(true)
            adapter = actionAdapter
        }
    }

    private fun observeActionReportByMeList() {
        observeData(viewModel.reportByMeActionList) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { data ->
                            if (data.isNotEmpty()) {
                                viewModel.showEmptyState.value = false
                                if (viewModel.filterMenuPosition == ActionViewModel.REPORTED_BY_ME) {
                                    actionAdapter?.setData(data)
                                }
                            } else {
                                if (viewModel.filterMenuPosition == ActionViewModel.REPORTED_BY_ME) {
                                    viewModel.showEmptyState.value = true
                                    tvEmptyMessage.text = getString(R.string.actions_empty)
                                }
                            }
                        }
                    }
                    NetworkState.ERROR -> {
                        when (it.code) {
                            404 -> {
                                tvEmptyMessage.text = it.message
                                viewModel.showEmptyState.value = true
                                actionAdapter?.removeAllData()
                            }
                            else -> {
                                SnackBar.snackBarShowError(
                                    requireContext(),
                                    parentLayout,
                                    it.message
                                        ?: getString(R.string.general_server_error_message)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    private fun observeActionAssignToMeList() {
        observeData(viewModel.assignToMeActionList) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { data ->
                            if (data.isNotEmpty()) {
                                viewModel.showEmptyState.value = false
                                if (viewModel.filterMenuPosition == ActionViewModel.ASSIGN_TO_ME) {
                                    actionAdapter?.setData(data)
                                }
                            } else {
                                if (viewModel.filterMenuPosition == ActionViewModel.ASSIGN_TO_ME) {
                                    viewModel.showEmptyState.value = true
                                    tvEmptyMessage.text = getString(R.string.actions_empty)
                                }
                            }
                        }
                    }
                    NetworkState.ERROR -> {
                        when (it.code) {
                            404 -> {
                                tvEmptyMessage.text = it.message
                                viewModel.showEmptyState.value = true
                                actionAdapter?.removeAllData()
                            }
                            else -> {
                                SnackBar.snackBarShowError(
                                    requireContext(),
                                    parentLayout,
                                    it.message
                                        ?: getString(R.string.general_server_error_message)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    private fun observeDeletedAction() {
        observeData(viewModel.deletedActionResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        SnackBar.snackBarShowSuccess(
                            requireContext(),
                            parentLayout,
                            it.message ?: getString(R.string.deleted_data_message)
                        )
                        viewModel.deletedActionResponse.value = null
                        viewModel.getAllDataAPI()
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            requireContext(),
                            parentLayout,
                            it.message ?: getString(R.string.general_server_error_message)
                        )
                        when (it.code) {
                            401 -> {
                                viewModel.preference.clearPreferences()
                                logout(Intent(context, LoginActivity::class.java))
                            }
                        }
                    }
                }
            }
        }
    }

    private fun observeUpdateAction() {
        observeData(viewModel.updateActionResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        SnackBar.snackBarShowSuccess(
                            requireContext(),
                            parentLayout,
                            it.message ?: getString(R.string.actions_status_update_message)
                        )
                        viewModel.updateActionResponse.value = null
                        viewModel.getAllDataAPI()
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            requireContext(),
                            parentLayout,
                            it.message ?: getString(R.string.general_server_error_message)
                        )
                        when (it.code) {
                            401 -> {
                                viewModel.preference.clearPreferences()
                                logout(Intent(context, LoginActivity::class.java))
                            }
                        }
                    }
                }
            }
        }
    }

    private fun showMenuBottomSheet(actionsId: String, actionTitle: String) {
        chosenActionId = actionsId
        chosenActionTitle = actionTitle
        menuList = mutableListOf()
        menuList.clear()
        val actionMenuIcon = resources.obtainTypedArray(R.array.issues_item_menu_icon)
        for (position in actionMenu.indices) {
            menuList.add(
                CommonOptionsSheet.BottomSheetMenuModel(
                    actionMenuIcon.getResourceId(position, 0), 0,
                    actionMenu[position]
                )
            )
        }
        actionMenuIcon.recycle()
        menuBottomSheet = CommonOptionsSheet(requireContext(), menuList).apply {
            setCancelable(true)
            setMenuItemListener(this@ActionFragment)
        }
        menuBottomSheet?.show()
    }

    private fun manageSearchLayout(isShow: Boolean) {
        tvTitleToolbar.visibility = if (isShow) View.GONE else View.VISIBLE
        menuAction1.visibility = if (isShow) View.GONE else View.VISIBLE
        etSearchToolbar.visibility = if (isShow) View.VISIBLE else View.GONE
        ivClearSearch.visibility = if (isShow) View.VISIBLE else View.GONE
    }

    override fun onBottomSheetItemClicked(menu: String, id: Int) {
        when (menu) {
            getString(R.string.menu_view_details) -> {
                menuBottomSheet?.dismiss()
                ChatActivity.startThisActivityFromAction(
                    this@ActionFragment.requireContext(),
                    chosenActionId, chosenActionTitle
                )
            }
            getString(R.string.menu_mark_complete) -> {
                menuBottomSheet?.dismiss()
                viewModel.updateStatusAction(chosenActionId)
            }
            getString(R.string.menu_edit) -> {
                menuBottomSheet?.dismiss()
                val intent = Intent(activity, CreateActionActivity::class.java)
                intent.putExtra(CreateActionActivity.EXTRA_ACTION_ID, chosenActionId)
                updateActionLauncher.launch(intent)
            }
            getString(R.string.menu_delete) -> {
                menuBottomSheet?.dismiss()
                showConfirmationDelete()
            }
        }
    }

    override fun onClickActions(actionsId: String, actionTitle: String) {
        showMenuBottomSheet(actionsId, actionTitle)
    }

    @Subscribe(sticky = true, threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: StartActionActivityEvent) {
        val intent = Intent(activity, CreateActionActivity::class.java)
        newActionLauncher.launch(intent)
        EventBus.getDefault().removeStickyEvent(event)
    }

    override fun onStart() {
        super.onStart()
        EventBus.getDefault().register(this)
    }

    override fun onStop() {
        super.onStop()
        EventBus.getDefault().unregister(this)
    }

    private fun showConfirmationDelete() {
        val alertDialog: AlertDialog? = activity?.let {
            val builder = AlertDialog.Builder(it)
            builder.apply {
                setPositiveButton(R.string.confirmation_yes) { dialog, _ ->
                    viewModel.deleteSelectedAction(chosenActionId)
                    dialog.dismiss()
                }
                setNegativeButton(R.string.confirmation_no) { dialog, _ ->
                    dialog.dismiss()
                }
            }
            builder.setMessage(R.string.confirmation_message)
            builder.create()
        }
        alertDialog?.show()
    }

    override fun onClickFilterMenuItem(menuPosition: Int) {
        viewModel.filterMenuPosition = menuPosition
        resetData()
        viewModel.getAllDataAPI()
    }

    private fun resetData() {
        val reportByMeActionList = viewModel.reportByMeActionList.value?.data
        val assignToMeActionList = viewModel.assignToMeActionList.value?.data
        if (viewModel.filterMenuPosition == IssuesViewModel.REPORTED_BY_ME) {
            if (reportByMeActionList == null) actionAdapter?.removeAllData()
        } else {
            if (assignToMeActionList == null) actionAdapter?.removeAllData()
        }
    }
}
