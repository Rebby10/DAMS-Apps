package com.pertamina.digitalaudit.presentation.chat

import androidx.lifecycle.MutableLiveData
import com.pertamina.digitalaudit.model.LogModel
import com.pertamina.digitalaudit.model.UserModel
import com.pertamina.digitalaudit.model.body.ActionLogReqBody
import com.pertamina.digitalaudit.model.body.IssueLogReqBody
import com.pertamina.digitalaudit.preference.PreferenceProvider
import com.pertamina.digitalaudit.repository.actions.ActionsRepository
import com.pertamina.digitalaudit.repository.issues.IssuesRepository
import com.pertamina.framework.base.BaseResponse
import com.pertamina.framework.base.BaseViewModel
import com.pertamina.framework.base.Resource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.ResponseBody
import java.io.File

/**
 * Created by M Hafidh Abdul Aziz on 20/03/21.
 */

class ChatViewModel(
    private val issuesRepository: IssuesRepository,
    private val actionsRepository: ActionsRepository,
    val preference: PreferenceProvider
) : BaseViewModel() {

    val logListResponse = MutableLiveData<Resource<List<LogModel.Log>>>()
    val sendLogChatResponse = MutableLiveData<Resource<BaseResponse>>()
    val downloadFileResponse = MutableLiveData<Resource<ResponseBody>>()
    val bTextChat = MutableLiveData("")
    val showProgressBar = MutableLiveData(false)
    val showEmptyState = MutableLiveData(false)
    val showRecommendation = MutableLiveData(false)
    var issueId: String = ""
    var actionId: String = ""
    var fromIssue: Boolean = false
    var fromAction: Boolean = false
    var user = UserModel.User()

    init {
        getUserData()
    }

    private fun getUserData() {
        launch {
            withContext(Dispatchers.IO) {
                user = preference.getAuthPreferences()
            }
        }
    }

    fun getLogChat() {
        showProgressBar.value = true
        launch {
            val request: Resource<List<LogModel.Log>>
            if (fromIssue) {
                request = issuesRepository.getIssueLog(issueId)
                logListResponse.value = request
            } else if (fromAction) {
                request = actionsRepository.getActionLog(actionId)
                logListResponse.value = request
            }
            showProgressBar.value = false
        }
    }

    fun sendLogChat(text: String?) {
        showProgressBar.value = true
        launch {
            val request: Resource<BaseResponse>
            if (fromIssue) {
                request = issuesRepository.sendLogChat(
                    IssueLogReqBody(
                        issueId,
                        text,
                        user.userId.orEmpty()
                    )
                )
                sendLogChatResponse.value = request
            } else if (fromAction) {
                request = actionsRepository.sendLogChat(
                    ActionLogReqBody(
                        actionId,
                        text,
                        user.userId.orEmpty()
                    )
                )
                sendLogChatResponse.value = request
            }
            showProgressBar.value = false
        }
    }

    fun sendLogChatFile(imageFile: File) {
        showProgressBar.value = true
        launch {
            val request: Resource<BaseResponse>
            if (fromIssue) {
                request =
                    issuesRepository.sendLogChatFile(issueId, user.userId.orEmpty(), imageFile)
                sendLogChatResponse.value = request
            } else if (fromAction) {
                request =
                    actionsRepository.sendLogChatFile(actionId, user.userId.orEmpty(), imageFile)
                sendLogChatResponse.value = request
            }
            showProgressBar.value = false
        }
    }

    fun startDownloadFile(fileUrl: String) {
        showProgressBar.value = true
        launch {
            val request: Resource<ResponseBody>
            if (fromIssue) {
                request = issuesRepository.downloadFile(fileUrl)
                downloadFileResponse.value = request
            } else if (fromAction) {
                request =
                    actionsRepository.downloadFile(fileUrl)
                downloadFileResponse.value = request
            }
            showProgressBar.value = false
        }
    }
}
