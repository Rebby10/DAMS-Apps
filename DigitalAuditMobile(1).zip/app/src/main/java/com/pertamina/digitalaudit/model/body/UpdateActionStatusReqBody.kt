package com.pertamina.digitalaudit.model.body

import com.google.gson.annotations.SerializedName

class UpdateActionStatusReqBody(
    @SerializedName("ActionId")
    var actionId: String,
    @SerializedName("StatusId")
    var statusId: Int
)
