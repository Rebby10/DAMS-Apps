package com.pertamina.digitalaudit.application

import android.app.Application
import com.ashokvarma.gander.Gander
import com.ashokvarma.gander.imdb.GanderIMDB
import com.pertamina.digitalaudit.module.customObjectModule
import com.pertamina.digitalaudit.module.networkModule
import com.pertamina.digitalaudit.module.repositoryModule
import com.pertamina.digitalaudit.module.preferenceModule
import com.pertamina.digitalaudit.module.viewModelModule
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.startKoin

class DigitalAuditApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        Gander.setGanderStorage(GanderIMDB.getInstance())
        setupKoin()
    }

    private fun setupKoin(){
        startKoin {
            printLogger() // Koin Logger
            androidContext(this@DigitalAuditApplication)
            modules(listOf(
                preferenceModule,
                customObjectModule,
                viewModelModule,
                networkModule,
                repositoryModule)
            )
        }
    }
}