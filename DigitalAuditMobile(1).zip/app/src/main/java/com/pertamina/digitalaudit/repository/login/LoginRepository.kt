package com.pertamina.digitalaudit.repository.login

import com.pertamina.digitalaudit.model.TokenModel
import com.pertamina.digitalaudit.model.UserModel
import com.pertamina.digitalaudit.model.UserProfileModel
import com.pertamina.framework.base.Resource
import kotlin.jvm.Throws

interface LoginRepository {

    @Throws(Exception::class)
    suspend fun login(tokenUser: String, tokenPassword: String): Resource<TokenModel.Token>

    @Throws(Exception::class)
    suspend fun getUserData(email: String): Resource<UserModel.User>

    @Throws(Exception::class)
    suspend fun getUserDataFromSSO(): Resource<UserProfileModel>
}
