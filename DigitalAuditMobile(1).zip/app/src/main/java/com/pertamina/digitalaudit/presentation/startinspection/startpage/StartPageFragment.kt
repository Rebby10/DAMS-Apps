package com.pertamina.digitalaudit.presentation.startinspection.startpage

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.animation.Animation
import android.view.animation.RotateAnimation
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.transition.Slide
import androidx.transition.Transition
import androidx.transition.TransitionManager
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.databinding.FragmentStartPageBinding
import com.pertamina.digitalaudit.model.IssueModel
import com.pertamina.digitalaudit.model.startinspection.Answer
import com.pertamina.digitalaudit.model.startinspection.InspectionPage
import com.pertamina.digitalaudit.model.startinspection.QuestionItem
import com.pertamina.digitalaudit.model.startinspection.ResponseListItem
import com.pertamina.digitalaudit.presentation.main.MainActivity
import com.pertamina.digitalaudit.presentation.sheet.AddNoteSheet
import com.pertamina.digitalaudit.presentation.sheet.AddPhotoSheet
import com.pertamina.digitalaudit.presentation.sheet.AddVoiceNoteSheet
import com.pertamina.digitalaudit.presentation.startinspection.StartInspectionViewModel
import com.pertamina.digitalaudit.presentation.startinspection.actionpage.ActionsActivity
import com.pertamina.digitalaudit.presentation.startinspection.startpage.adapter.InspectionIssueAdapter
import com.pertamina.digitalaudit.presentation.startinspection.startpage.adapter.ListInspectionPageAdapter
import com.pertamina.digitalaudit.presentation.startinspection.startpage.adapter.ListInspectionSectionAdapter
import com.pertamina.digitalaudit.util.CommonConstant.AUDIO_FILE_TYPE
import com.pertamina.digitalaudit.util.CommonConstant.IMAGE_FILE_TYPE
import com.pertamina.digitalaudit.util.SnackBar
import com.pertamina.framework.NetworkState
import com.pertamina.framework.ViewDataBindingOwner
import com.pertamina.framework.base.BaseFragment
import kotlinx.android.synthetic.main.fragment_start_page.*
import org.koin.androidx.viewmodel.ext.android.sharedViewModel
import org.koin.androidx.viewmodel.ext.android.viewModel
import java.io.File
import java.util.*

class StartPageFragment : BaseFragment<StartPageViewModel>(), StartPageView,
    ViewDataBindingOwner<FragmentStartPageBinding> {

    fun newInstance(): StartPageFragment {
        val args = Bundle()
        val fragment = StartPageFragment()
        fragment.arguments = args
        return fragment
    }

    override var binding: FragmentStartPageBinding? = null
    override val layoutResourceId: Int = R.layout.fragment_start_page
    override val viewModel: StartPageViewModel by viewModel()
    private val parentViewModel: StartInspectionViewModel by sharedViewModel()
    private var listInspectionPageAdapter: ListInspectionPageAdapter? = null
    private var listInspectionSectionAdapter: ListInspectionSectionAdapter? = null
    private var issueFromLastInspection: InspectionIssueAdapter? = null
    private var selectedPage: InspectionPage? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupInspectionTemplateView()
        setupInspectionPageList()
        setupInspectionPageSection()
        setupIssuesFromLastInspection()
        observeSaveInProgress()
        observeStartInspectionSelectedPage()
        observeStartInspectionResult()
        observeIssueFromLastInspection()
        observeInspectionCompletedResponse()
        observeImageFileFromAPI()
        observeAudioFileFromAPI()
        observeIssuePage()
    }

    private fun setupInspectionTemplateView() {
        viewModel.startInspectionData = parentViewModel.startInspectionResponse.value?.data?.data
        viewModel.startInspectionListData =
            parentViewModel.startInspectionListPageResponse.value?.data
        viewModel.inspectionId = parentViewModel.inspectionId
        viewModel.startInspectionData?.templatePage?.forEach {
            it?.let { inspectionPage ->
                viewModel.saveAllQuestionList(inspectionPage)
                viewModel.getAllNotesSavedFromAPI()
                viewModel.getAllImageFileFromAPI()
                viewModel.getAllAudioFileFromAPI()
            }
        }
        val auditorName =
            getString(R.string.auditor_name_label, parentViewModel.inspectionAuditorName.orEmpty())
        val auditeeName =
            getString(R.string.auditee_name_label, parentViewModel.inspectionAuditeeName.orEmpty())
        viewModel.setDataToView(
            parentViewModel.inspectionLocation.orEmpty(),
            parentViewModel.inspectionDate.orEmpty(),
            auditorName,
            auditeeName
        )
    }

    private fun setupInspectionPageList() {
        val llManager = LinearLayoutManager(requireContext())
        listInspectionPageAdapter = ListInspectionPageAdapter()
        listInspectionPageAdapter?.setItemClickListener(object :
            ListInspectionPageAdapter.ItemClickListener {
            override fun onClickItem(data: InspectionPage) {
                saveInProgress()
                if (data.pageId?.isNotEmpty() == true) {
                    viewModel.getInspectionBySelectedPage(
                        viewModel.inspectionId.orEmpty(),
                        data.pageId.orEmpty()
                    )
                } else {
                    viewModel.getIssueFromLastInspectionPage(viewModel.inspectionId.orEmpty())
                }
                showPageList(false)
            }
        })
        rvInspectionListPage.apply {
            layoutManager = llManager
            setHasFixedSize(true)
            adapter = listInspectionPageAdapter
        }
        viewModel.startInspectionListData?.let {
            if (it.isNotEmpty()) {
                listInspectionPageAdapter?.setData(it)
                selectedPage = it[0]
                updateSelectedPageAndScoreView()
            }
        }
    }

    private fun setupInspectionPageSection() {
        val llManager = LinearLayoutManager(requireContext())
        llManager.isAutoMeasureEnabled = false
        listInspectionSectionAdapter = ListInspectionSectionAdapter()
        listInspectionSectionAdapter?.setItemClickListener(object :
            ListInspectionSectionAdapter.ItemClickListener {
            override fun onAddNote(data: QuestionItem, position: Int) {
                showAddNoteSheet(data, position)
            }

            override fun onAddAction(data: QuestionItem) {
                data.questionId?.let {
                    ActionsActivity.startThisActivity(
                        requireContext(),
                        viewModel.inspectionId.orEmpty(),
                        it.toString()
                    )
                }
            }

            override fun onAddVoiceNote(data: QuestionItem, position: Int) {
                data.questionId?.let {
                    showAddVoiceNoteSheet(it, position)
                }
            }

            override fun onAddPicture(data: QuestionItem, position: Int) {
                data.questionId?.let { showAddPhotoSheet(it, position) }
            }

            override fun onClickChoice(
                questionId: Int,
                data: ResponseListItem,
                sectionPosition: Int
            ) {
                //listInspectionSectionAdapter?.notifyItemChanged(sectionPosition)
                viewModel.allAnswerDataSaved[questionId] = Pair(data.listId ?: 0, data.name.orEmpty())
            }

            override fun onFreeTextChange(answerText: String, position: Int, questionId: Int) {
                viewModel.startInspectionData?.templatePage?.forEach {
                    it?.question?.let{ question ->
                        question.forEach { item ->
                            if (item.questionId == questionId){
                                item.answer?.answerText = answerText
                            }
                        }
                    }
                }
                viewModel.allAnswerDataSaved[questionId] = Pair(0, answerText)
                viewModel.startInspectionData
            }

            override fun onNumberTextChange(answerText: String, position: Int, questionId: Int) {
                viewModel.allAnswerDataSaved[questionId] = Pair(0, answerText)
            }

            override fun onDateTextChange(answerText: String, position: Int, questionId: Int) {
                viewModel.allAnswerDataSaved[questionId] = Pair(0, answerText)
            }

            override fun onLocationTextChange(answerText: String, position: Int, questionId: Int) {
                viewModel.allAnswerDataSaved[questionId] = Pair(0, answerText)
            }

            override fun onSignatureNameTextChange(
                answerText: String,
                position: Int,
                questionId: Int
            ) {
                //viewModel.updateListInspectionResultData(questionId, questionId, answerText, null)
            }
        })
        rvSections.apply {
            layoutManager = llManager
            setHasFixedSize(true)
            adapter = listInspectionSectionAdapter
        }

        //open inspection page 0 for initial data
        viewModel.startInspectionData?.templatePage?.let {
            it[0]?.section?.let { sectionList ->
                listInspectionSectionAdapter?.setData(sectionList)
            }
        }
    }

    private fun setupIssuesFromLastInspection() {
        val llManager = LinearLayoutManager(requireContext())
        issueFromLastInspection = InspectionIssueAdapter()
        issueFromLastInspection?.setItemClickListener(object :
            InspectionIssueAdapter.ItemClickListener {
            override fun onClickAddAction(data: IssueModel.Issue) {
                //todo check BE support or not, provide actions based on issue,
                // if not should hit endpoint get actions with issue id
            }

            override fun onClickIssue(data: IssueModel.Issue) {
                // do nothing
            }
        })
        rvIssuesFromLastInspection.apply {
            layoutManager = llManager
            setHasFixedSize(true)
            adapter = issueFromLastInspection
        }
    }

    private fun observeStartInspectionSelectedPage() {
        observeData(viewModel.inspectionByPageResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { response ->
                            clGroupInspectionPage.visibility = View.VISIBLE
                            rvIssuesFromLastInspection.visibility = View.GONE
                            selectedPage = response.data
                            changePageNavigationColor()
                            updateSelectedPageAndScoreView()
                            selectedPage?.let { page ->
                                listInspectionSectionAdapter?.setData(
                                    page.section ?: mutableListOf()
                                )
                            }
                            viewModel.getPageListWithoutIssueFromLastInspection()?.let { pageList ->
                                viewModel.isLastPage.value = selectedPage?.seqNo == pageList.size
                                viewModel.isIssuePage.value = false
                            }
                        }
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            requireContext(),
                            parentLayout,
                            it.message
                                ?: getString(R.string.general_server_error_message)
                        )
                    }
                }
            }
        }
    }

    private fun observeIssueFromLastInspection() {
        observeData(viewModel.issueFromLastInspectionResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { issues ->
                            clGroupInspectionPage.visibility = View.GONE
                            rvIssuesFromLastInspection.visibility = View.VISIBLE
                            viewModel.isLastPage.value = true
                            viewModel.isIssuePage.value = true
                            viewModel.startInspectionListData?.let { pageList ->
                                viewModel.bTextSelectedPage.value = pageList.lastOrNull()?.title
                            }
                            issueFromLastInspection?.setData(issues)
                        }
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            requireContext(),
                            parentLayout,
                            it.message ?: getString(R.string.general_server_error_message)
                        )
                    }
                }
            }
        }
    }

    private fun observeStartInspectionResult() {
        observeData(viewModel.startInspectionAnswerResultResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let {
                            // todo user response after success answer
                        }
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            requireContext(),
                            parentLayout,
                            it.message
                                ?: getString(R.string.general_server_error_message)
                        )
                    }
                }
            }
        }
    }

    private fun observeInspectionCompletedResponse() {
        observeData(viewModel.inspectionCompletedResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        val intent = Intent(requireContext(), MainActivity::class.java)
                        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK
                        intent.putExtra(MainActivity.EXTRA_FROM_COMPLETE_INSPECTION, true)
                        startActivity(intent)
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            requireContext(),
                            parentLayout,
                            it.message
                                ?: getString(R.string.general_server_error_message)
                        )
                    }
                }
            }
        }
    }

    private fun observeAudioFileFromAPI() {
        observeData(viewModel.allAudioFileResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        val fileNameAudioList: MutableList<String> = mutableListOf()
                        it.data?.data?.map { data ->
                            fileNameAudioList.add(data.linkFile.toString())
                            viewModel.allVoiceNotesDataSaved[data.questionId] = fileNameAudioList
                        }
                    }
                    else -> {
                        //do nothing
                    }
                }
            }
        }
    }

    private fun observeImageFileFromAPI() {
        observeData(viewModel.allImageFileResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        val listOfLinkImage: MutableList<String> = mutableListOf()
                        it.data?.data?.forEach { file ->
                            listOfLinkImage.add(file.linkFile.toString())
                            viewModel.allImageDataSaved[file.questionId] = listOfLinkImage
                        }
                    }
                    else -> {
                        //do nothing
                    }
                }
            }
        }
    }

    private fun observeSaveInProgress() {
        observeData(parentViewModel.saveInProgressClicked) { result ->
            result?.let {
                saveInProgress()
            }
        }
    }

    private fun observeIssuePage() {
        observeData(viewModel.isIssuePage) { result ->
            result?.let {
                if (it) {
                    ivBackArrow.setImageResource(R.drawable.ic_arrow_left_black_400)
                    tvBack.setTextColor(
                        ContextCompat.getColor(
                            requireContext(),
                            R.color.black_400
                        )
                    )
                    tvBackPage.setTextColor(
                        ContextCompat.getColor(
                            requireContext(),
                            R.color.black_400
                        )
                    )

                    ivNextArrow.setImageResource(R.drawable.ic_arrow_right_black_400)
                    tvNext.setTextColor(
                        ContextCompat.getColor(
                            requireContext(),
                            R.color.black_400
                        )
                    )
                    tvNextPage.setTextColor(
                        ContextCompat.getColor(
                            requireContext(),
                            R.color.black_400
                        )
                    )
                }
            }
        }
    }

    private fun updateSelectedPageAndScoreView() {
        viewModel.bTextSelectedPage.value = selectedPage?.title
        viewModel.getPageListWithoutIssueFromLastInspection()?.let {
            if (it.isNotEmpty()) {
                viewModel.bTextInfoTotalPage.value =
                    getString(
                        R.string.inspection_page_info,
                        selectedPage?.seqNo.toString(),
                        it.size.toString()
                    )
            } else {
                viewModel.bTextInfoTotalPage.value =
                    getString(
                        R.string.inspection_page_info,
                        it.size.toString(),
                        it.size.toString()
                    )
            }
        }
    }

    override fun onClickChangePage(view: View) {
        showPageList(rvInspectionListPage.visibility == View.GONE)
    }

    override fun onClickMarkAsComplete(view: View) {
        saveInProgress()
        viewModel.markInspectionAsComplete(viewModel.inspectionId.orEmpty())
    }

    override fun onClickBack(view: View) {
        if (viewModel.isIssuePage.value == false) {
            setPreviousPage()
        }
    }

    override fun onClickNext(view: View) {
        if (viewModel.isIssuePage.value == false) {
            setNextPage()
        }
    }

    private fun showPageList(isShow: Boolean) {
        val transition: Transition = Slide(Gravity.TOP)
        transition.duration = 500
        transition.addTarget(rvInspectionListPage)
        TransitionManager.beginDelayedTransition(
            parentLayout,
            transition
        )
        rvInspectionListPage.visibility = if (isShow) View.VISIBLE else View.GONE

        val anim = if (isShow) {
            RotateAnimation(
                0F,
                180F,
                Animation.RELATIVE_TO_SELF,
                0.5f,
                Animation.RELATIVE_TO_SELF,
                0.5f
            )
        } else {
            RotateAnimation(
                180F,
                0F,
                Animation.RELATIVE_TO_SELF,
                0.5f,
                Animation.RELATIVE_TO_SELF,
                0.5f
            )
        }
        anim.duration = 500
        anim.fillAfter = true
        ivArrow.startAnimation(anim)
    }

    private fun setNextPage() {
        viewModel.getPageListWithoutIssueFromLastInspection()?.let { list ->
            if (selectedPage?.seqNo != null && selectedPage?.seqNo != list.size) {
                saveInProgress()
                viewModel.getInspectionBySelectedPage(
                    viewModel.inspectionId.orEmpty(),
                    list[(selectedPage?.seqNo?.plus(1) ?: 0) - 1].pageId.orEmpty()
                )
            }
        }
    }

    private fun setPreviousPage() {
        viewModel.getPageListWithoutIssueFromLastInspection()?.let { list ->
            if (selectedPage?.seqNo != null && selectedPage?.seqNo != 1) {
                saveInProgress()
                viewModel.getInspectionBySelectedPage(
                    viewModel.inspectionId.orEmpty(),
                    list[(selectedPage?.seqNo?.minus(1) ?: 0) - 1].pageId.orEmpty()
                )
            }
        }
    }

    private fun changePageNavigationColor() {
        viewModel.getPageListWithoutIssueFromLastInspection()?.let { list ->
            selectedPage?.let {
                when (it.seqNo) {
                    1 -> {
                        ivBackArrow.setImageResource(R.drawable.ic_arrow_left_black_400)
                        tvBack.setTextColor(
                            ContextCompat.getColor(
                                requireContext(),
                                R.color.black_400
                            )
                        )
                        tvBackPage.setTextColor(
                            ContextCompat.getColor(
                                requireContext(),
                                R.color.black_400
                            )
                        )

                        ivNextArrow.setImageResource(R.drawable.ic_arrow_right_black)
                        tvNext.setTextColor(ContextCompat.getColor(requireContext(), R.color.black))
                        tvNextPage.setTextColor(
                            ContextCompat.getColor(
                                requireContext(),
                                R.color.grey_drawable
                            )
                        )
                    }
                    list.size -> {
                        ivBackArrow.setImageResource(R.drawable.ic_arrow_left_black)
                        tvBack.setTextColor(ContextCompat.getColor(requireContext(), R.color.black))
                        tvBackPage.setTextColor(
                            ContextCompat.getColor(
                                requireContext(),
                                R.color.grey_drawable
                            )
                        )

                        ivNextArrow.setImageResource(R.drawable.ic_arrow_right_black_400)
                        tvNext.setTextColor(
                            ContextCompat.getColor(
                                requireContext(),
                                R.color.black_400
                            )
                        )
                        tvNextPage.setTextColor(
                            ContextCompat.getColor(
                                requireContext(),
                                R.color.black_400
                            )
                        )
                    }
                    else -> {
                        ivBackArrow.setImageResource(R.drawable.ic_arrow_left_black)
                        tvBack.setTextColor(ContextCompat.getColor(requireContext(), R.color.black))
                        tvBackPage.setTextColor(
                            ContextCompat.getColor(
                                requireContext(),
                                R.color.grey_drawable
                            )
                        )

                        ivNextArrow.setImageResource(R.drawable.ic_arrow_right_black)
                        tvNext.setTextColor(ContextCompat.getColor(requireContext(), R.color.black))
                        tvNextPage.setTextColor(
                            ContextCompat.getColor(
                                requireContext(),
                                R.color.grey_drawable
                            )
                        )
                    }
                }
            }
        }
    }

    private fun showAddNoteSheet(data: QuestionItem, position: Int) {
        val existingNotes = viewModel.allNotesDataSaved[data.questionId]
        val dialog = AddNoteSheet(existingNotes)
        dialog.listener = object :
            AddNoteSheet.AddNoteSheetListener {
            override fun onSave(note: String) {
                val listData = listInspectionSectionAdapter?.getData()?.get(position)
                listData?.let{
                    it.question?.forEach { question ->
                        if (question.questionId == data.questionId){
                            if (question.answer == null){
                                val answer = Answer(notes = note)
                                question.answer = answer
                            } else {
                                question.answer?.notes = note
                            }
                        }
                    }
                    listInspectionSectionAdapter?.updateDataByPosition(listData, position)
                }
                data.questionId?.let {
                    viewModel.allNotesDataSaved[it] = note
                }
            }
        }
        dialog.show(parentFragmentManager, "add_note")
    }

    private fun showAddPhotoSheet(questionId: Int, position: Int) {
        val bundle = Bundle()
        bundle.putStringArrayList("EXISTING_IMAGE", getSelectedImageData(questionId))
        val dialog = AddPhotoSheet()
        dialog.arguments = bundle
        dialog.listener = object :
            AddPhotoSheet.AddPhotoSheetListener {
            override fun onSave(images: List<String>, files: List<File>) {
                val isImageExist = images.firstOrNull { it != "" } != null
                val listData = listInspectionSectionAdapter?.getData()?.get(position)
                listData?.let{
                    it.question?.forEach { question ->
                        if (question.questionId == questionId) {
                            question.isImageAttached = isImageExist
                        }
                    }
                    listInspectionSectionAdapter?.updateDataByPosition(listData, position)
                }

                viewModel.allImageDataSaved[questionId] = images
                viewModel.setUploadFileReqBody(IMAGE_FILE_TYPE, questionId, files)
            }
        }
        dialog.show(parentFragmentManager, "add_photo")
    }

    private fun getSelectedImageData(questionId: Int): ArrayList<String>? {
        var arrList: ArrayList<String>? = null
        viewModel.allImageDataSaved[questionId]?.let {
            arrList = ArrayList(it)
        }
        return arrList
    }

    private fun getSelectedVoiceData(questionId: Int): ArrayList<String>? {
        var arrList: ArrayList<String>? = null
        viewModel.allVoiceNotesDataSaved[questionId]?.let {
            arrList = ArrayList(it)
        }
        return arrList
    }

    private fun showAddVoiceNoteSheet(questionId: Int, position: Int) {
        val bundle = Bundle()
        bundle.putStringArrayList("EXISTING_VOICE", getSelectedVoiceData(questionId))
        val dialog = AddVoiceNoteSheet()
        dialog.arguments = bundle
        dialog.listener = object :
            AddVoiceNoteSheet.AddRecordSheetListener {
            override fun onSave(dataUri: List<String>, dataFile: List<File>) {
                val listData = listInspectionSectionAdapter?.getData()?.get(position)
                listData?.let{
                    it.question?.forEach { question ->
                        if (question.questionId == questionId) {
                            question.isVoiceAttached = dataUri.isNotEmpty()
                        }
                    }
                    listInspectionSectionAdapter?.updateDataByPosition(listData, position)
                }
                viewModel.allVoiceNotesDataSaved[questionId] = dataUri
                viewModel.setUploadFileReqBody(AUDIO_FILE_TYPE, questionId, dataFile)
            }
        }
        dialog.show(parentFragmentManager, "add_voice_note")
    }

    private fun saveInProgress(){
        viewModel.postAnswerInspectionResult()
        viewModel.uploadInspectionFile()
    }
}