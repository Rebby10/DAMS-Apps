package com.pertamina.digitalaudit.presentation.home.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.model.AuditLocationModel
import com.pertamina.digitalaudit.model.InspectionModel
import com.pertamina.digitalaudit.presentation.issues.helper.IssuesStatusViewHelper
import com.pertamina.framework.base.BaseRecyclerViewAdapter
import com.pertamina.framework.base.BaseViewHolder
import com.pertamina.framework.util.DateHelper
import kotlinx.android.synthetic.main.item_home_inspections.view.*

class InspectionAdapter : BaseRecyclerViewAdapter<InspectionModel.Inspection>() {

    private var listener: InspectionClickListener? = null

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BaseViewHolder<InspectionModel.Inspection> {
        val view = LayoutInflater.from(parent.context).inflate(viewType, parent, false)
        return ListViewHolder(parent.context, view, listener)
    }

    override fun onBindViewHolder(
        holder: BaseViewHolder<InspectionModel.Inspection>,
        position: Int
    ) {
        holder.bindData(getItem(position))
    }

    override fun getItemViewType(position: Int): Int {
        return R.layout.item_home_inspections
    }

    class ListViewHolder(context: Context, val view: View, listener: InspectionClickListener?) :
        BaseViewHolder<InspectionModel.Inspection>(context, view) {

        private lateinit var data: InspectionModel.Inspection
        private var holderListener: InspectionClickListener? = listener

        @SuppressLint("SetTextI18n")
        override fun bindData(data: InspectionModel.Inspection) = with(itemView) {
            this@ListViewHolder.data = data
            tvTitleInspection.text = data.template?.title
            tvInspectionAuditLocation.text = data.auditLocation?.name
            tvLocationAndAuditorNameInspection.text =
                context.getString(R.string.prepared_by, data.auditor?.users?.name)
            tvStatusInspection.apply {
                data.status?.let { status ->
                    text = status.name
                    setBackgroundResource(IssuesStatusViewHelper.getStatusBackgroundColor(status.name.orEmpty()))
                    setTextColor(
                        ContextCompat.getColor(
                            context,
                            IssuesStatusViewHelper.getStatusTextColor(status.name.orEmpty())
                        )
                    )
                }
            }
            var startDate = ""
            var endDate = ""
            data.startDate?.let {
                startDate = DateHelper.changeFormat(
                    it,
                    DateHelper.yyyy_MM_dd_T_HHmmss,
                    DateHelper.dd_MMM
                )
            }
            data.endDate?.let {
                endDate = DateHelper.changeFormat(
                    data.endDate.orEmpty(),
                    DateHelper.yyyy_MM_dd_T_HHmmss,
                    DateHelper.dd_MMM_yyyy
                )
            }
            tvInspectionRangeTime.text = "$startDate - $endDate"
            setOnClickListener {
                holderListener?.onClickInspection(
                    data.inspectionId.orEmpty(),
                    data.auditLocation,
                    data.startDate.orEmpty(),
                    data.status?.statusId ?: 0,
                )
            }
        }
    }

    fun setInspectionClickListener(listener: InspectionClickListener) {
        this.listener = listener
    }

    interface InspectionClickListener {
        fun onClickInspection(
            inspectionId: String,
            location: AuditLocationModel.AuditLocation?,
            startDate: String,
            statusId: Int
        )
    }
}
