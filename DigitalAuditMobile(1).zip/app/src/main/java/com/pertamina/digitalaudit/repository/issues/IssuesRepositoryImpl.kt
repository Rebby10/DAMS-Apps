package com.pertamina.digitalaudit.repository.issues

import com.pertamina.digitalaudit.model.*
import com.pertamina.digitalaudit.model.body.CreateIssueReqBody
import com.pertamina.digitalaudit.model.body.IssueLogReqBody
import com.pertamina.digitalaudit.model.body.SortAndFilterReqBody
import com.pertamina.digitalaudit.model.body.UpdateIssueReqBody
import com.pertamina.digitalaudit.util.CommonConstant
import com.pertamina.framework.ResponseHandler
import com.pertamina.framework.base.BaseResponse
import com.pertamina.framework.base.Resource
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.ResponseBody
import java.io.File

class IssuesRepositoryImpl(
    private val service: IssuesService,
    private val responseHandler: ResponseHandler
) : IssuesRepository {

    override suspend fun createNewIssue(reqBody: CreateIssueReqBody): Resource<IssueModel> {
        try {
            val request = service.createNewIssue(reqBody)
            request.let {
                return responseHandler.setSuccess(it)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun getIssueDetail(issueId: String): Resource<IssueDetailModel> {
        try {
            val request = service.getIssueDetail(issueId)
            request.let {
                return responseHandler.setSuccess(it)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun applyFilter(reqBody: SortAndFilterReqBody): Resource<List<IssueModel.Issue>> {
        try {
            val request = service.applyFilter(
                reqBody.issueId,
                reqBody.title,
                reqBody.auditLocationId,
                reqBody.priorityId,
                reqBody.statusId,
                reqBody.userCreated,
                reqBody.assignUser,
                reqBody.startDate,
                reqBody.endDate,
                reqBody.auditTypeId,
                reqBody.pageSize,
                reqBody.pageNumber,
                reqBody.sortBy,
                reqBody.orderBy,
                reqBody.isConnectedToAction
            )
            request.data.let {
                return responseHandler.setSuccess(it!!)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun getIssueCategory(): Resource<List<IssueCategoryModel.IssueCategory>> {
        try {
            val request = service.getIssueCategoryList()
            request.data.let {
                return responseHandler.setSuccess(it!!)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun getIssueStatus(): Resource<List<IssueStatusModel.IssueStatus>> {
        try {
            val request = service.getIssueStatusList()
            request.data.let {
                return responseHandler.setSuccess(it!!)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun deleteIssue(issueId: String): Resource<IssueModel> {
        try {
            val request = service.deleteIssue(issueId)
            request.let {
                return responseHandler.setSuccess(it)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun updateIssue(reqBody: UpdateIssueReqBody): Resource<IssueModel> {
        try {
            val request = service.updateIssue(reqBody)
            request.let {
                return responseHandler.setSuccess(it)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun getIssueLog(issueId: String): Resource<List<LogModel.Log>> {
        try {
            val request = service.getIssueLog(issueId, null)
            request.data.let {
                return responseHandler.setSuccess(it!!)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun sendLogChat(logReqBody: IssueLogReqBody): Resource<BaseResponse> {
        try {
            val request =
                service.sendIssueLog(logReqBody.issueId, logReqBody.text, logReqBody.userCreated)
            if (request.isSuccess) {
                return responseHandler.setSuccess(request)
            }
            return responseHandler.setException(Exception())
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun getAuditeeByName(name: String?, pageSize: Int?, pageNumber: Int?): Resource<List<UserAssignModel.UserAssign>> {
        try {
            val request = service.getAuditeeByName(name, pageSize, pageNumber)
            request.data.let {
                return responseHandler.setSuccess(it!!)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun sendLogChatFile(
        issueId: String,
        userCreated: String,
        file: File
    ): Resource<BaseResponse> {
        try {
            val issueIdBody =
                RequestBody.create(MediaType.parse(CommonConstant.MULTIPART_FORM_DATE), issueId)
            val userCreatedBody =
                RequestBody.create(MediaType.parse(CommonConstant.MULTIPART_FORM_DATE), userCreated)

            val fileReqBody =
                RequestBody.create(MediaType.parse(CommonConstant.MULTIPART_FORM_DATE), file)
            val fileBody: MultipartBody.Part =
                MultipartBody.Part.createFormData("File", file.name, fileReqBody)
            val request =
                service.sendLogChatFile(issueIdBody, userCreatedBody, fileBody)
            if (request.isSuccess) {
                return responseHandler.setSuccess(request)
            }
            return responseHandler.setException(Exception())
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun downloadFile(fileUrl: String): Resource<ResponseBody> {
        try {
            val request = service.downloadFile(fileUrl)
            request.let {
                return responseHandler.setSuccess(it)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

}
