package com.pertamina.digitalaudit.presentation.startinspection.startpage.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.animation.RotateAnimation
import androidx.recyclerview.widget.LinearLayoutManager
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.model.startinspection.QuestionItem
import com.pertamina.digitalaudit.model.startinspection.ResponseListItem
import com.pertamina.digitalaudit.model.startinspection.SectionItem
import com.pertamina.framework.base.BaseRecyclerViewAdapter
import com.pertamina.framework.base.BaseViewHolder
import kotlinx.android.synthetic.main.item_inspection_section.view.*

class ListInspectionSectionAdapter : BaseRecyclerViewAdapter<SectionItem>() {

    private var listener: ItemClickListener? = null

    override fun onCreateViewHolder(
            parent: ViewGroup,
            viewType: Int
    ): BaseViewHolder<SectionItem> {
        val view = LayoutInflater.from(parent.context).inflate(viewType, parent, false)
        return ListViewHolder(parent.context, view, listener)
    }

    override fun onBindViewHolder(
            holder: BaseViewHolder<SectionItem>,
            position: Int
    ) {
        holder.bindData(getItem(position))
    }

    override fun getItemViewType(position: Int): Int {
        return R.layout.item_inspection_section
    }

    class ListViewHolder(
            context: Context,
            val view: View,
            listener: ItemClickListener?
    ) :
        BaseViewHolder<SectionItem>(context, view) {

        private var holderListener: ItemClickListener? = listener
        private var tvPageName = view.tvSectionTitle
        private var rvSectionChild = view.rvSectionChild
        private var tvSectionChildEmpty = view.tvSectionChildEmpty
        private var vSectionDivider = view.vSectionDivider
        private var ivArrow = view.ivArrow

        override fun bindData(data: SectionItem) {
            tvPageName.text = data.name
            itemView.setOnClickListener {
                rotateSectionArrow(rvSectionChild.visibility == View.GONE)
                rvSectionChild.visibility =
                    if (rvSectionChild.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                vSectionDivider.visibility =
                    if (rvSectionChild.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                tvSectionChildEmpty.visibility =
                    if (data.question?.isEmpty() == true && tvSectionChildEmpty.visibility == View.GONE) View.VISIBLE else View.GONE
            }

            val llManager = LinearLayoutManager(context)
            llManager.isAutoMeasureEnabled = false
            val listSectionQuestionAdapter = ListSectionQuestionAdapter()
            listSectionQuestionAdapter.setItemClickListener(object :
                    ListSectionQuestionAdapter.ItemClickListener {
                override fun onAddNote(data: QuestionItem) {
                    holderListener?.onAddNote(data, adapterPosition)
                }

                override fun onAddAction(data: QuestionItem) {
                    holderListener?.onAddAction(data)
                }

                override fun onAddVoiceNote(data: QuestionItem) {
                    holderListener?.onAddVoiceNote(data, adapterPosition)
                }

                override fun onAddPicture(data: QuestionItem) {
                    holderListener?.onAddPicture(data, adapterPosition)
                }

                override fun onClickChoice(questionId: Int, data: ResponseListItem, position: Int) {
                    listSectionQuestionAdapter.notifyItemChanged(position)
                    holderListener?.onClickChoice(questionId, data, adapterPosition)
                }

                override fun onFreeTextChange(answerText: String, position: Int, questionId: Int) {
                    holderListener?.onFreeTextChange(answerText, position, questionId)
                }

                override fun onNumberTextChange(
                        answerText: String,
                        position: Int,
                        questionId: Int
                ) {
                    holderListener?.onNumberTextChange(answerText, position, questionId)
                }

                override fun onDateTextChange(answerText: String, position: Int, questionId: Int) {
                    holderListener?.onDateTextChange(answerText, position, questionId)
                }

                override fun onLocationTextChange(
                        answerText: String,
                        position: Int,
                        questionId: Int
                ) {
                    holderListener?.onLocationTextChange(answerText, position, questionId)
                }

                override fun onSignatureNameTextChange(
                        answerText: String,
                        position: Int,
                        questionId: Int
                ) {
                    holderListener?.onSignatureNameTextChange(answerText, position, questionId)
                }
            })
            rvSectionChild.apply {
                layoutManager = llManager
                adapter = listSectionQuestionAdapter
            }
            listSectionQuestionAdapter.setData(data.question ?: mutableListOf())

            rvSectionChild.visibility =
                if (data.question?.isNotEmpty() == true) View.VISIBLE else View.GONE
            rotateSectionArrow(data.question?.isNotEmpty() == true)
            vSectionDivider.visibility =
                if (rvSectionChild.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }

        private fun rotateSectionArrow(isShow: Boolean) {
            val anim = if (isShow) {
                RotateAnimation(
                        0F,
                        180F,
                        Animation.RELATIVE_TO_SELF,
                        0.5f,
                        Animation.RELATIVE_TO_SELF,
                        0.5f
                )
            } else {
                RotateAnimation(
                        180F,
                        0F,
                        Animation.RELATIVE_TO_SELF,
                        0.5f,
                        Animation.RELATIVE_TO_SELF,
                        0.5f
                )
            }
            anim.fillAfter = true
            ivArrow.startAnimation(anim)
        }
    }

    fun setItemClickListener(listener: ItemClickListener) {
        this.listener = listener
    }

    interface ItemClickListener {
        fun onAddNote(data: QuestionItem, position: Int)
        fun onAddAction(data: QuestionItem)
        fun onAddVoiceNote(data: QuestionItem, position: Int)
        fun onAddPicture(data: QuestionItem, position: Int)
        fun onClickChoice(questionId: Int, data: ResponseListItem, sectionPosition: Int)
        fun onFreeTextChange(answerText: String, position: Int, questionId: Int)
        fun onNumberTextChange(answerText: String, position: Int, questionId: Int)
        fun onDateTextChange(answerText: String, position: Int, questionId: Int)
        fun onLocationTextChange(answerText: String, position: Int, questionId: Int)
        fun onSignatureNameTextChange(answerText: String, position: Int, questionId: Int)
    }
}