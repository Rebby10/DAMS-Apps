package com.pertamina.digitalaudit.presentation.action

import androidx.lifecycle.MutableLiveData
import com.pertamina.digitalaudit.model.ActionModel
import com.pertamina.digitalaudit.model.UserModel
import com.pertamina.digitalaudit.model.body.UpdateActionStatusReqBody
import com.pertamina.digitalaudit.model.query.GetActionQuery
import com.pertamina.digitalaudit.preference.PreferenceProvider
import com.pertamina.digitalaudit.repository.actions.ActionsRepository
import com.pertamina.framework.base.BaseViewModel
import com.pertamina.framework.base.Resource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Created by M Hafidh Abdul Aziz on 03/03/21.
 */

class ActionViewModel(
    private val actionsRepository: ActionsRepository,
    val preference: PreferenceProvider
) : BaseViewModel() {

    companion object {
        private const val STATUS_CLOSED = 3
        const val REPORTED_BY_ME = 0
        const val ASSIGN_TO_ME = 1
    }

    val isLoading = MutableLiveData(false)
    val showEmptyState = MutableLiveData(false)

    val reportByMeActionList = MutableLiveData<Resource<List<ActionModel.Action>>>()
    val assignToMeActionList = MutableLiveData<Resource<List<ActionModel.Action>>>()
    val deletedActionResponse = MutableLiveData<Resource<ActionModel>>()
    val updateActionResponse = MutableLiveData<Resource<ActionModel>>()
    var filterMenuPosition = REPORTED_BY_ME

    var user = UserModel.User()

    init {
        getUserData()
    }

    private fun getUserData() {
        launch {
            withContext(Dispatchers.IO) {
                user = preference.getAuthPreferences()
            }
            getAllDataAPI()
        }
    }

    fun getAllDataAPI() {
        if (filterMenuPosition == REPORTED_BY_ME) {
            reportByMeActionList(GetActionQuery())
        } else {
            assignToMeActionList(GetActionQuery())
        }
    }

    fun reportByMeActionList(reqBody: GetActionQuery) {
        isLoading.value = true
        reqBody.userCreated = user.userId
        launch {
            val request = actionsRepository.getActionList(reqBody)
            reportByMeActionList.value = request
            isLoading.value = false
        }
    }

    fun assignToMeActionList(reqBody: GetActionQuery) {
        isLoading.value = true
        reqBody.assignUser = user.userId
        launch {
            val request = actionsRepository.getActionList(reqBody)
            assignToMeActionList.value = request
            isLoading.value = false
        }
    }

    fun deleteSelectedAction(actionId: String) {
        isLoading.value = true
        launch {
            val request = actionsRepository.deleteAction(actionId)
            deletedActionResponse.value = request
            isLoading.value = false
        }
    }

    fun applyFilterActionReportByMe(reqBody: GetActionQuery) {
        reqBody.userCreated = user.userId
        launch {
            val request = actionsRepository.getActionList(reqBody)
            reportByMeActionList.value = request
            isLoading.value = false
        }
    }

    fun applyFilterActionAssignToMe(reqBody: GetActionQuery) {
        reqBody.assignUser = user.userId
        launch {
            val request = actionsRepository.getActionList(reqBody)
            assignToMeActionList.value = request
            isLoading.value = false
        }
    }

    fun updateStatusAction(actionId: String) {
        isLoading.value = true
        launch {
            val request = actionsRepository.updateActionStatus(
                UpdateActionStatusReqBody(
                    actionId = actionId,
                    statusId = STATUS_CLOSED
                )
            )
            updateActionResponse.value = request
            isLoading.value = false
        }
    }

}
