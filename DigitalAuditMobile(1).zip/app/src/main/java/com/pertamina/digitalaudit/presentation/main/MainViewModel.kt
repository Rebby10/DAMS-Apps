package com.pertamina.digitalaudit.presentation.main

import com.pertamina.digitalaudit.preference.PreferenceProvider
import com.pertamina.framework.base.BaseViewModel

class MainViewModel(val preference: PreferenceProvider) : BaseViewModel(){

}