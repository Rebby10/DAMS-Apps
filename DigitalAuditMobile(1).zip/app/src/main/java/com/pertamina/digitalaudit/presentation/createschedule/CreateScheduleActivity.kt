package com.pertamina.digitalaudit.presentation.createschedule

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.databinding.ActivityCreateScheduleBinding
import com.pertamina.digitalaudit.model.ScheduleDetailModel
import com.pertamina.digitalaudit.model.UserAssignModel
import com.pertamina.digitalaudit.presentation.login.LoginActivity
import com.pertamina.digitalaudit.presentation.search.SearchActivity
import com.pertamina.digitalaudit.util.SnackBar
import com.pertamina.digitalaudit.util.ViewUtils
import com.pertamina.framework.NetworkState
import com.pertamina.framework.ViewDataBindingOwner
import com.pertamina.framework.base.BaseActivity
import com.pertamina.framework.customview.DateTimePicker
import com.pertamina.framework.util.DateHelper
import kotlinx.android.synthetic.main.activity_create_schedule.*
import kotlinx.android.synthetic.main.toolbar_layout.*
import org.koin.androidx.viewmodel.ext.android.viewModel

/**
 * Created by M Hafidh Abdul Aziz on 11/03/21.
 */

class CreateScheduleActivity : BaseActivity<CreateScheduleViewModel>(), CreateScheduleView,
    ViewDataBindingOwner<ActivityCreateScheduleBinding> {

    override val layoutResourceId: Int = R.layout.activity_create_schedule
    override val viewModel: CreateScheduleViewModel by viewModel()
    override var binding: ActivityCreateScheduleBinding? = null

    private var chooseLocationLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val locationId = result.data?.getStringExtra(SearchActivity.EXTRA_LOCATION_ID)
                val locationName = result.data?.getStringExtra(SearchActivity.EXTRA_LOCATION_NAME)
                viewModel.createScheduleLocationId.value = locationId.orEmpty()
                viewModel.bTextScheduleLocation.value = locationName
                tvCreateScheduleLocationError?.visibility = View.GONE
            }
        }

    private var chooseTemplateLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val templateId = result.data?.getStringExtra(SearchActivity.EXTRA_TEMPLATE_ID)
                val templateTitle = result.data?.getStringExtra(SearchActivity.EXTRA_TEMPLATE_TITLE)
                viewModel.createScheduleTemplateId.value = templateId.orEmpty()
                viewModel.bTextScheduleTemplate.value = templateTitle
                tvCreateScheduleAuditTypeTemplateError?.visibility = View.GONE
            }
        }

    private var chooseAuditeeLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val user: UserAssignModel.UserAssign? =
                    result.data?.getSerializableExtra(SearchActivity.EXTRA_USER_DATA) as UserAssignModel.UserAssign?
                user?.let {
                    viewModel.bTextScheduleAssignAuditeeName.value = it.displayName.orEmpty()
                    tvTitleAssignAuditeeError?.visibility = View.GONE
                    if (it.isGroup == true) {
                        viewModel.createScheduleAssignAuditeeGroupId.value = it.id.orEmpty()
                    } else {
                        viewModel.createScheduleAssignAuditeeUserId.value = it.id.orEmpty()
                    }
                }
            }
        }

    private var chooseAuditorLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val user: UserAssignModel.UserAssign? =
                    result.data?.getSerializableExtra(SearchActivity.EXTRA_USER_DATA) as UserAssignModel.UserAssign?
                user?.let {
                    viewModel.bTextScheduleAssignAuditorName.value = it.displayName.orEmpty()
                    tvTitleAssignAuditorError?.visibility = View.GONE
                    if (it.isGroup == true) {
                        viewModel.createScheduleAssignAuditorGroupId.value = it.id.orEmpty()
                    } else {
                        viewModel.createScheduleAssignAuditorUserId.value = it.id.orEmpty()
                    }
                }
            }
        }

    companion object {
        const val EXTRA_SCHEDULE_ID = "EXTRA_SCHEDULE_ID"

        fun startThisActivity(context: Context) {
            val intent = Intent(context, CreateScheduleActivity::class.java)
            context.startActivity(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        getExtraData()
        setupToolbar()
        subscribeCreateSchedule()
        subscribeUpdateSchedule()
        subscribeDetailSchedule()
        etCreateScheduleStartDate.setEventListener(object : DateTimePicker.OnGetDateListener {
            override fun onGetDate(date: String) {
                tvCreateScheduleStartDateError?.visibility = View.GONE
                viewModel.bTextScheduleStartDate.value = date
            }
        })
        etCreateScheduleEndDate.setEventListener(object : DateTimePicker.OnGetDateListener {
            override fun onGetDate(date: String) {
                tvCreateScheduleEndDateError?.visibility = View.GONE
                viewModel.bTextScheduleEndDate.value = date
            }
        })
    }

    private fun getExtraData() {
        viewModel.scheduleId = intent?.getStringExtra(EXTRA_SCHEDULE_ID).orEmpty()
        when {
            viewModel.scheduleId.isNotEmpty() -> {
                viewModel.getScheduleDetail()
            }
        }
    }

    private fun setupToolbar() {
        if (viewModel.scheduleId.isNotEmpty()) {
            tvTitleToolbar.text = getString(R.string.create_schedule_edit_label)
            btnSubmit.text = getString(R.string.create_schedule_update_label)
        } else {
            tvTitleToolbar.text = getString(R.string.create_schedule_label)
            btnSubmit.text = getString(R.string.apply_label)
        }
        btnBackToolbar.apply {
            visibility = View.VISIBLE
            setOnClickListener {
                onBackPressed()
            }
        }
    }

    private fun subscribeCreateSchedule() {
        observeData(viewModel.createScheduleResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        setResult(RESULT_OK)
                        finish()
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message ?: getString(R.string.general_server_error_message)
                        )
                        when (it.code) {
                            401 -> {
                                viewModel.preference.clearPreferences()
                                logout(Intent(this, LoginActivity::class.java))
                            }
                        }
                    }
                }
            }
        }
    }

    private fun subscribeUpdateSchedule() {
        observeData(viewModel.updateScheduleResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        setResult(RESULT_OK)
                        finish()
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message ?: getString(R.string.general_server_error_message)
                        )
                        when (it.code) {
                            401 -> {
                                viewModel.preference.clearPreferences()
                                logout(Intent(this, LoginActivity::class.java))
                            }
                        }
                    }
                }
            }
        }
    }

    private fun subscribeDetailSchedule() {
        observeData(viewModel.detailScheduleResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { scheduleDetail ->
                            setDataToView(scheduleDetail.data)
                        }
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message ?: getString(R.string.general_server_error_message)
                        )
                        when (it.code) {
                            401 -> {
                                viewModel.preference.clearPreferences()
                                logout(Intent(this, LoginActivity::class.java))
                            }
                            else -> {
                                //do nothing just to avoid error warning
                            }
                        }
                    }
                }
            }
        }
    }

    private fun setDataToView(data: ScheduleDetailModel.ScheduleDetail?) {
        etCreateScheduleStartDate.setText(
            DateHelper.changeFormat(
                data?.startDate.orEmpty(),
                DateHelper.yyyy_MM_dd_T_HHmmss,
                DateHelper.dd_MMM_yyyy_hh_mm_a
            )
        )
        etCreateScheduleEndDate.setText(
            DateHelper.changeFormat(
                data?.endDate.orEmpty(),
                DateHelper.yyyy_MM_dd_T_HHmmss,
                DateHelper.dd_MMM_yyyy_hh_mm_a
            )
        )
        viewModel.bTextScheduleStartDate.value = data?.startDate.orEmpty()
        viewModel.bTextScheduleEndDate.value = data?.endDate.orEmpty()
        viewModel.createScheduleLocationId.value = data?.auditLocation?.auditLocationId.orEmpty()
        viewModel.createScheduleTemplateId.value = data?.template?.templateId.orEmpty()
        viewModel.bTextScheduleAssignAuditeeName.value = getAssignedAuditee(data)
        viewModel.bTextScheduleAssignAuditorName.value = getAssignedAuditor(data)
    }

    private fun getAssignedAuditor(data: ScheduleDetailModel.ScheduleDetail?): String? {
        data?.auditor?.users?.let {
            viewModel.createScheduleAssignAuditorUserId.value = it.userId.orEmpty()
            return it.name
        }
        data?.auditor?.groups?.let {
            viewModel.createScheduleAssignAuditorGroupId.value = it.userGroupId.orEmpty()
            return it.officialName
        }
        return ""
    }

    private fun getAssignedAuditee(data: ScheduleDetailModel.ScheduleDetail?): String? {
        data?.auditee?.users?.let {
            viewModel.createScheduleAssignAuditeeUserId.value = it.userId.orEmpty()
            return it.name
        }
        data?.auditee?.groups?.let {
            viewModel.createScheduleAssignAuditeeGroupId.value = it.userGroupId.orEmpty()
            return it.officialName
        }
        return ""
    }

    override fun onClickSubmitSchedule(view: View) {
        var isValid = true

        if (viewModel.bTextScheduleAssignAuditorName.value.isNullOrEmpty()) {
            isValid = false
            tvTitleAssignAuditorError?.visibility = View.VISIBLE
        }

        if (viewModel.bTextScheduleStartDate.value.isNullOrEmpty()) {
            isValid = false
            tvCreateScheduleStartDateError?.visibility = View.VISIBLE
        }

        if (viewModel.bTextScheduleEndDate.value.isNullOrEmpty()) {
            isValid = false
            tvCreateScheduleEndDateError?.visibility = View.VISIBLE
        }

        if (viewModel.bTextScheduleAssignAuditeeName.value.isNullOrEmpty()) {
            isValid = false
            tvTitleAssignAuditeeError?.visibility = View.VISIBLE
        }

        if (viewModel.bTextScheduleLocation.value.isNullOrEmpty()) {
            isValid = false
            tvCreateScheduleLocationError?.visibility = View.VISIBLE
        }

        if (viewModel.bTextScheduleTemplate.value.isNullOrEmpty()) {
            isValid = false
            tvCreateScheduleAuditTypeTemplateError?.visibility = View.VISIBLE
        }

        if (isValid) {
            ViewUtils.hideKeyboard(this, view)
            if (viewModel.scheduleId.isNotEmpty()) {
                viewModel.updateSchedule()
            } else {
                viewModel.createNewSchedule()
            }
        }
    }

    override fun onClickChooseAuditor(view: View) {
        val intent = Intent(this, SearchActivity::class.java)
        intent.putExtra(SearchActivity.EXTRA_FROM_ISSUE, true)
        intent.putExtra(SearchActivity.EXTRA_TITLE, getString(R.string.choose_auditor))
        intent.putExtra(SearchActivity.EXTRA_IS_SEARCH_USER, true)
        chooseAuditorLauncher.launch(intent)
    }

    override fun onClickChooseAuditee(view: View) {
        val intent = Intent(this, SearchActivity::class.java)
        intent.putExtra(SearchActivity.EXTRA_FROM_ISSUE, true)
        intent.putExtra(SearchActivity.EXTRA_TITLE, getString(R.string.choose_auditee))
        intent.putExtra(SearchActivity.EXTRA_IS_SEARCH_USER, true)
        chooseAuditeeLauncher.launch(intent)
    }

    override fun onClickChooseLocation(view: View) {
        val intent = Intent(this, SearchActivity::class.java)
        intent.putExtra(SearchActivity.EXTRA_TITLE, getString(R.string.choose_location))
        intent.putExtra(SearchActivity.EXTRA_IS_SEARCH_LOCATION, true)
        chooseLocationLauncher.launch(intent)
    }

    override fun onClickChooseAuditTypeTemplate(view: View) {
        val intent = Intent(this, SearchActivity::class.java)
        intent.putExtra(SearchActivity.EXTRA_TITLE, getString(R.string.choose_audit_template))
        intent.putExtra(SearchActivity.EXTRA_IS_SEARCH_TEMPLATE, true)
        chooseTemplateLauncher.launch(intent)
    }
}
