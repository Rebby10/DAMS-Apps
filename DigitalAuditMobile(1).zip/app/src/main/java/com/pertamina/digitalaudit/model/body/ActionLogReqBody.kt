package com.pertamina.digitalaudit.model.body

import com.google.gson.annotations.SerializedName

data class ActionLogReqBody(
    @SerializedName("ActionId")
    var actionId: String,
    @SerializedName("text")
    var text: String?,
    @SerializedName("UserCreated")
    var userCreated: String
)
