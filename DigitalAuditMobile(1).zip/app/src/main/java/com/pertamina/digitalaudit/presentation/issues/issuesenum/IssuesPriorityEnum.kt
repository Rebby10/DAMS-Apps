package com.pertamina.digitalaudit.presentation.issues.issuesenum

enum class IssuesPriorityEnum(val priority: String) {
    LOW("Low"),
    NORMAL("Normal"),
    HIGH("High")
}