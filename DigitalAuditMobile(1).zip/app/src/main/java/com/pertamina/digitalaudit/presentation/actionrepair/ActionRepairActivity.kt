package com.pertamina.digitalaudit.presentation.actionrepair

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.databinding.ActivityActionRepairBinding
import com.pertamina.digitalaudit.model.ActionRepairMasterDataModel
import com.pertamina.digitalaudit.presentation.login.LoginActivity
import com.pertamina.digitalaudit.presentation.sheet.SelectUploadSourceSheet
import com.pertamina.digitalaudit.util.CommonConstant
import com.pertamina.digitalaudit.util.SnackBar
import com.pertamina.digitalaudit.util.ViewUtils
import com.pertamina.digitalaudit.util.camera.CameraActivity
import com.pertamina.framework.NetworkState
import com.pertamina.framework.ViewDataBindingOwner
import com.pertamina.framework.base.BaseActivity
import com.pertamina.framework.customview.DateTimePicker
import com.pertamina.framework.util.FileUtils
import com.pertamina.imageeditor.ImageEditorActivity
import kotlinx.android.synthetic.main.activity_action_repair.*
import kotlinx.android.synthetic.main.toolbar_layout.*
import org.koin.androidx.viewmodel.ext.android.viewModel
import pub.devrel.easypermissions.AfterPermissionGranted
import pub.devrel.easypermissions.EasyPermissions
import java.io.File
import java.io.FileOutputStream


class ActionRepairActivity : BaseActivity<ActionRepairViewModel>(), ActionRepairView,
    ViewDataBindingOwner<ActivityActionRepairBinding>, AdapterView.OnItemSelectedListener {

    override val layoutResourceId: Int = R.layout.activity_action_repair
    override val viewModel: ActionRepairViewModel by viewModel()
    override var binding: ActivityActionRepairBinding? = null
    private var fileUpload: File? = null

    private fun openImageEditorActivity(uri: Uri) {
        val intent = Intent(this, ImageEditorActivity::class.java)
        intent.putExtra("imageUri", uri.toString())
        imageEditorLauncher.launch(intent)
    }

    private var imageEditorLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val intent = result.data?.getStringExtra("imagePath")
                intent?.let {
                    fileUpload = File(intent)
                    viewModel.bTextRepairFileName.value = fileUpload?.name.orEmpty()
                    tvUploadFileEvidenceError.visibility = View.GONE
                }
            }
        }

    private var galleryLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                result.data?.let {
                    val imageUri: Uri? = it.data
                    imageUri?.let {
                        openImageEditorActivity(imageUri)
                    } ?: run {
                        showErrorUploadFile()
                    }
                } ?: run {
                    showErrorUploadFile()
                }
            }
        }
    private var cameraLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                result.data?.let {
                    val uri = Uri.parse(it.getStringExtra(CameraActivity.EXTRA_CAPTURED_URI))
                    uri?.let { data ->
                        openImageEditorActivity(data)
                    } ?: run { showErrorUploadFile() }
                } ?: run {
                    showErrorUploadFile()
                }
            }
        }
    private var fileManagerLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                result.data?.let { intent ->
                    val fileUri = intent.data
                    fileUri?.let {
                        fileUpload =
                            updateFileLocation(FileUtils.getDocumentFileNameByUri(this, fileUri))
                        copyUriStream(fileUri)
                        viewModel.bTextRepairFileName.value = fileUpload?.name.orEmpty()
                        tvUploadFileEvidenceError.visibility = View.GONE
                    } ?: run {
                        showErrorUploadFile()
                    }
                } ?: run {
                    showErrorUploadFile()
                }
            }
        }

    companion object {
        const val EXTRA_ACTION_ID = "EXTRA_ACTION_ID"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setupToolbar()
        getExtraData()
        subscribeActionRepairMasterData()
        subscribeActionRepair()
        etRepairChooseDate.setEventListener(object : DateTimePicker.OnGetDateListener {
            override fun onGetDate(date: String) {
                tvRepairChooseDateError?.visibility = View.GONE
                viewModel.bTextRepairDate.value = date
            }
        })
    }

    private fun setupToolbar() {
        tvTitleToolbar.text = getString(R.string.repair_create_title)
        btnBackToolbar.apply {
            visibility = View.VISIBLE
            setImageResource(R.drawable.ic_close)
            setOnClickListener {
                onBackPressed()
            }
        }
    }

    private fun getExtraData() {
        viewModel.actionId = intent?.getStringExtra(EXTRA_ACTION_ID).orEmpty()
        viewModel.getActionRepairMasterData()
    }

    private fun subscribeActionRepairMasterData() {
        observeData(viewModel.actionRepairMasterDataResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        initRootCauseCategorySpinner(it.data?.rootCauseCategory)
                        initActionRepairCategorySpinner(it.data?.actionRepairCategory)
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message ?: getString(R.string.general_server_error_message)
                        )
                        when (it.code) {
                            401 -> {
                                viewModel.preference.clearPreferences()
                                logout(Intent(this, LoginActivity::class.java))
                            }
                        }
                    }
                }
            }
        }
    }

    private fun subscribeActionRepair() {
        observeData(viewModel.actionRepairResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        SnackBar.snackBarShowSuccess(
                            this,
                            parentLayout,
                            it.message ?: getString(R.string.repair_success_message)
                        )
                        Handler(Looper.getMainLooper()).postDelayed({
                            setResult(RESULT_OK)
                            finish()
                        }, 1000)
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message ?: getString(R.string.general_server_error_message)
                        )
                        when (it.code) {
                            401 -> {
                                viewModel.preference.clearPreferences()
                                logout(Intent(this, LoginActivity::class.java))
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onClickChooseFile(view: View) {
        requestPermissionWriteExternalStorage()
    }

    override fun onClickSaveActionRepair(view: View) {
        var isValid = true
        if (viewModel.bTextRepairCause.value.isNullOrEmpty()) {
            isValid = false
            tvRepairCauseError?.visibility = View.VISIBLE
        }

        if (viewModel.bTextRepairAction.value.isNullOrEmpty()) {
            isValid = false
            tvRepairActionError?.visibility = View.VISIBLE
        }

        if (viewModel.actionRepairCategoryId.value.isNullOrEmpty()) {
            isValid = false
            tvCategoryActionRepairError?.visibility = View.VISIBLE
        }

        if (viewModel.rootCauseCategoryId.value.isNullOrEmpty()) {
            isValid = false
            tvCategoryRepairError?.visibility = View.VISIBLE
        }

        if (viewModel.bTextRepairDate.value.isNullOrEmpty()) {
            isValid = false
            tvRepairChooseDateError?.visibility = View.VISIBLE
        }

        if (viewModel.bTextRepairFileName.value?.isEmpty() == true) {
            isValid = false
            tvUploadFileEvidenceError?.visibility = View.VISIBLE
        }

        if (isValid) {
            ViewUtils.hideKeyboard(this, view)
            fileUpload?.let {
                viewModel.saveRepairAction(it)
            }
        }
    }

    override var bTextWatcherRepairCause: TextWatcher
        get() = object : TextWatcher {

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                tvRepairCauseError?.visibility = View.GONE
            }

            override fun afterTextChanged(s: Editable?) {}
        }
        set(_) {}

    override var bTextWatcherActionRepair: TextWatcher
        get() = object : TextWatcher {

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                tvRepairActionError?.visibility = View.GONE
            }

            override fun afterTextChanged(s: Editable?) {}
        }
        set(_) {}

    @AfterPermissionGranted(CommonConstant.RC_WRITE_EXTERNAL_STORAGE_PERM)
    private fun requestPermissionWriteExternalStorage() {
        val perms = arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (EasyPermissions.hasPermissions(this, *perms)) {
            showFilePickerDialog()
        } else {
            EasyPermissions.requestPermissions(
                this,
                getString(R.string.permission_to_access_file),
                CommonConstant.RC_WRITE_EXTERNAL_STORAGE_PERM,
                *perms
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this)
    }

    private fun showFilePickerDialog() {
        val dialog = SelectUploadSourceSheet()
        dialog.listener = object :
            SelectUploadSourceSheet.SelectUploadSourceBottomSheetFragmentListener {
            override fun onSelectCamera() {
                goToCamera()
            }

            override fun onSelectGallery() {
                goToGallery()
            }

            override fun onSelectFile() {
                goToFileManager()
            }
        }
        dialog.show(supportFragmentManager, "select_upload_source")
    }

    private fun goToCamera() {
        val intent = Intent(this, CameraActivity::class.java)
        cameraLauncher.launch(intent)
    }

    private fun goToGallery() {
        val photoPickerIntent = Intent(
            Intent.ACTION_PICK,
            android.provider.MediaStore.Images.Media.INTERNAL_CONTENT_URI
        )
        photoPickerIntent.type = "image/*"
        galleryLauncher.launch(photoPickerIntent)
    }

    private fun goToFileManager() {
        var chooseFile = Intent(Intent.ACTION_OPEN_DOCUMENT)
        chooseFile.addCategory(Intent.CATEGORY_OPENABLE)
        chooseFile.type = "*/*"
        val mimeTypes = arrayOf(
            "application/pdf",
            "application/msword",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "application/vnd.ms-excel",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        )
        chooseFile.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes)
        chooseFile = Intent.createChooser(chooseFile, "Choose a file")
        fileManagerLauncher.launch(chooseFile)
        createFolder()
    }

    private fun initActionRepairCategorySpinner(data: List<ActionRepairMasterDataModel.ActionRepairMasterData.ActionRepairCategory>?) {
        val actionRepair =
            ActionRepairMasterDataModel.ActionRepairMasterData.ActionRepairCategory().apply {
                name = getString(R.string.all_label)
            }
        val adapter =
            ArrayAdapter<ActionRepairMasterDataModel.ActionRepairMasterData.ActionRepairCategory>(
                this,
                android.R.layout.simple_spinner_item
            )
        adapter.add(actionRepair)
        data?.let { adapter.addAll(it) }
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spCategoryActionRepair.adapter = adapter
        spCategoryActionRepair.onItemSelectedListener = this
        spCategoryActionRepair.setSelection(viewModel.getSelectedActionRepairCategorySpinnerItemPosition())
    }

    private fun initRootCauseCategorySpinner(data: List<ActionRepairMasterDataModel.ActionRepairMasterData.ActionRepairCategory>?) {
        val rootCause =
            ActionRepairMasterDataModel.ActionRepairMasterData.ActionRepairCategory().apply {
                name = getString(R.string.all_label)
            }
        val adapter =
            ArrayAdapter<ActionRepairMasterDataModel.ActionRepairMasterData.ActionRepairCategory>(
                this,
                android.R.layout.simple_spinner_item
            )
        adapter.add(rootCause)
        data?.let { adapter.addAll(it) }
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spCategoryRepairCause.adapter = adapter
        spCategoryRepairCause.onItemSelectedListener = this
        spCategoryRepairCause.setSelection(viewModel.getSelectedRootCauseCategorySpinnerItemPosition())
    }

    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
        when (parent?.id) {
            R.id.spCategoryActionRepair -> {
                val category =
                    parent.selectedItem as ActionRepairMasterDataModel.ActionRepairMasterData.ActionRepairCategory
                viewModel.actionRepairCategoryId.value =
                    if (position == 0) null else category.id.orEmpty()
                if (position != 0) tvCategoryActionRepairError?.visibility = View.GONE
            }
            R.id.spCategoryRepairCause -> {
                val category =
                    parent.selectedItem as ActionRepairMasterDataModel.ActionRepairMasterData.ActionRepairCategory
                viewModel.rootCauseCategoryId.value =
                    if (position == 0) null else category.id.orEmpty()
                if (position != 0) tvCategoryRepairError?.visibility = View.GONE
            }
        }
    }

    override fun onNothingSelected(parent: AdapterView<*>?) {
        //do nothing
    }

    private fun createFolder() {
        val folder = getExternalFilesDir("/DigitalAuditFilesTemp")?.absolutePath
        folder?.let {
            fileUpload = File(it)
        }
        if (fileUpload?.exists() != true) {
            fileUpload?.mkdir()
        }
    }

    private fun updateFileLocation(fileName: String): File {
        val folder: File? = getExternalFilesDir("/DigitalAuditFilesTemp/")
        return File(folder?.absolutePath, fileName)
    }

    private fun copyUriStream(uri: Uri) {
        try {
            val inputStream = contentResolver.openInputStream(uri)
            fileUpload?.let {
                val fileOutputStream = FileOutputStream(it)
                if (inputStream != null) {
                    FileUtils.copyStream(inputStream, fileOutputStream)
                    fileOutputStream.close()
                    inputStream.close()
                }
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun showErrorUploadFile() {
        Toast.makeText(
            this,
            getString(R.string.error_upload_file),
            Toast.LENGTH_SHORT
        ).show()
    }
}
