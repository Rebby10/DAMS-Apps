package com.pertamina.digitalaudit.presentation.createaction

import android.text.TextWatcher
import android.view.View
import com.pertamina.framework.base.BaseView

interface CreateActionView : BaseView {
    fun onClickCreateAction(view: View)
    fun onClickChooseUser(view: View)
    fun onClickChooseIssue(view: View)
    fun onClickChooseLocation(view: View)

    var bTextWatcherActionTitle: TextWatcher
    var bTextWatcherActionDescription: TextWatcher
}
