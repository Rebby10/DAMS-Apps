package com.pertamina.digitalaudit.model

import com.google.gson.annotations.SerializedName
import com.pertamina.framework.base.BaseResponse
import java.io.Serializable

class AssignUserModel : BaseResponse() {

    @SerializedName("Result")
    var data: List<AssignUser>? = null

    class AssignUser: Serializable {
        @SerializedName("UserId")
        var userId: String? = ""

        @SerializedName("DisplayName")
        var displayName: String? = ""

        @SerializedName("Email")
        var email: String? = ""
    }
}