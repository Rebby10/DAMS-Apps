package com.pertamina.digitalaudit.presentation.splashscreen

import android.view.View
import com.pertamina.framework.base.BaseView

/**
 * Created by Asadurrahman Al Qayyim on 23/03/21.
 */

interface SplashScreenView : BaseView {
}