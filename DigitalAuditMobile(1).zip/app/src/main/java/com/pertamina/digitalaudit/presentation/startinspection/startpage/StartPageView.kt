package com.pertamina.digitalaudit.presentation.startinspection.startpage

import android.view.View
import com.pertamina.framework.base.BaseView

interface StartPageView : BaseView {
    fun onClickChangePage(view: View)
    fun onClickMarkAsComplete(view: View)
    fun onClickBack(view: View)
    fun onClickNext(view: View)
}
