package com.pertamina.digitalaudit.model

/**
 * Created by M Hafidh Abdul Aziz on 08/03/21.
 */

class Actions {
    var title : String? = ""
    var expiryActions : String? = ""
    var priorityType : String? = ""
    var reportBy : String? = ""
    var lastUpdated : String? = ""
}