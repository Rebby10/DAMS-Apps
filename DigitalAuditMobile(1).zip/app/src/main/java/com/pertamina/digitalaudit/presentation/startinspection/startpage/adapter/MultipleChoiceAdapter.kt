package com.pertamina.digitalaudit.presentation.startinspection.startpage.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.model.startinspection.ResponseListItem
import com.pertamina.framework.base.BaseRecyclerViewAdapter
import com.pertamina.framework.base.BaseViewHolder
import kotlinx.android.synthetic.main.item_inspection_question_multiple_choice_child.view.*

class MultipleChoiceAdapter : BaseRecyclerViewAdapter<ResponseListItem>() {

    private var listener: ItemClickListener? = null

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BaseViewHolder<ResponseListItem> {
        val view = LayoutInflater.from(parent.context).inflate(viewType, parent, false)
        return ListViewHolder(parent.context, view, listener)
    }

    override fun onBindViewHolder(
        holder: BaseViewHolder<ResponseListItem>,
        position: Int
    ) {
        holder.bindData(getItem(position))
    }

    override fun getItemViewType(position: Int): Int {
        return R.layout.item_inspection_question_multiple_choice_child
    }

    class ListViewHolder(
        context: Context,
        val view: View,
        listener: ItemClickListener?
    ) :
        BaseViewHolder<ResponseListItem>(context, view) {

        private var holderListener: ItemClickListener? = listener
        private var tvChoice = view.tvChoice
        private var clParentItemView = view.clParentItemView

        override fun bindData(data: ResponseListItem) {
            tvChoice.text = data.name
            if (data.isSelected) {
                clParentItemView.setBackgroundResource(R.drawable.bg_duck_egg_with_border_blue_and_radius_5)
            } else {
                clParentItemView.setBackgroundResource(R.drawable.bg_grey_with_radius_5)
            }
            itemView.setOnClickListener {
                holderListener?.onClickChoice(data, adapterPosition)
            }
        }
    }

    fun setItemClickListener(listener: ItemClickListener) {
        this.listener = listener
    }

    interface ItemClickListener {
        fun onClickChoice(data: ResponseListItem, position: Int)
    }
}