package com.pertamina.digitalaudit.model

import com.google.gson.annotations.SerializedName
import com.pertamina.framework.base.BaseResponse

class FAQMasterDataModel : BaseResponse() {

    @SerializedName("Result")
    var data: List<FAQ>? = null

    class FAQ {
        @SerializedName("FaqId")
        var faqId: String? = ""

        @SerializedName("Question")
        var question: String? = ""

        @SerializedName("Answer")
        var answer: String? = ""
    }
}