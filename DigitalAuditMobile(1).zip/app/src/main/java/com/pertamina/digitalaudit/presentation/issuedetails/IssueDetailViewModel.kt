package com.pertamina.digitalaudit.presentation.issuedetails

import androidx.lifecycle.MutableLiveData
import com.pertamina.digitalaudit.model.*
import com.pertamina.digitalaudit.model.body.UpdateIssueReqBody
import com.pertamina.digitalaudit.preference.PreferenceProvider
import com.pertamina.digitalaudit.repository.issues.IssuesRepository
import com.pertamina.framework.NonNullMutableLiveData
import com.pertamina.framework.base.BaseViewModel
import com.pertamina.framework.base.Resource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Created by M Hafidh Abdul Aziz on 16/03/21.
 */

class IssueDetailViewModel(
    private val issuesRepository: IssuesRepository,
    val preference: PreferenceProvider
) : BaseViewModel() {

    val showProgressBar = MutableLiveData(false)

    var bTextDetailIssueAutoTitle = MutableLiveData("")
    var bTextDetailIssueAutoDescription = MutableLiveData("")
    var bTextDetailIssueTitle = MutableLiveData("")
    var bTextDetailIssueDescription = MutableLiveData("")
    var bTextDetailIssueLocation = MutableLiveData("")
    var bTextDetailIssueCreatedAt = MutableLiveData("")
    var bTextDetailIssueCreatedBy = MutableLiveData("")
    var bTextDetailIssueAssignTo = MutableLiveData("")
    var bTextDetailIssuePriority = MutableLiveData("")
    var bTextDetailIssueTargetClosing = MutableLiveData("")
    var bTextDetailIssueCategory = MutableLiveData("")
    var bTextDetailIssueIdentification = MutableLiveData("")
    var bTextDetailIssueStatus = MutableLiveData("")

    var detailIssueStatusId = NonNullMutableLiveData(0)
    var prevDetailIssueStatusId = NonNullMutableLiveData(0)
    var isFromInspection = MutableLiveData(false)
    var isDetailIssueStateAuditee = MutableLiveData(false)
    var isActionExist = MutableLiveData(false)

    val issueDetailResponse = MutableLiveData<Resource<IssueDetailModel>>()
    val statusListResponse = MutableLiveData<Resource<List<IssueStatusModel.IssueStatus>>>()
    val updateIssueResponse = MutableLiveData<Resource<IssueModel>>()

    var issueId: String = ""
    var inspectionId: String = ""
    var user = UserModel.User()

    init {
        getUserData()
    }

    private fun getUserData() {
        launch {
            withContext(Dispatchers.IO) {
                user = preference.getAuthPreferences()
            }
        }
    }

    fun getIssueDetail() {
        showProgressBar.value = true
        launch {
            val request = issuesRepository.getIssueDetail(issueId)
            issueDetailResponse.value = request
            showProgressBar.value = false
        }
    }

    fun getIssueStatusList() {
        showProgressBar.value = true
        launch {
            val request = issuesRepository.getIssueStatus()
            statusListResponse.value = request
            showProgressBar.value = false
        }
    }

    fun getSelectedStatusItemPosition(): Int {
        val prevSelectedStatus = detailIssueStatusId.value
        prevSelectedStatus.let {
            statusListResponse.value?.data?.let { list ->
                val data = list.toMutableList()
                return list.indexOf(data.find { it.statusId == prevSelectedStatus })
            }
        }
        return 0
    }

    fun updateIssue() {
        showProgressBar.value = true
        launch {
            val request = issuesRepository.updateIssue(
                UpdateIssueReqBody(
                    issueId = issueId,
                    title = issueDetailResponse.value?.data?.data?.title,
                    descriptions = issueDetailResponse.value?.data?.data?.descriptions,
                    auditLocationId = issueDetailResponse.value?.data?.data?.auditLocation?.auditLocationId,
                    assignedGroup = issueDetailResponse.value?.data?.data?.assignGroup?.userGroupId,
                    assignedUser = issueDetailResponse.value?.data?.data?.assignUser?.userId,
                    creator = issueDetailResponse.value?.data?.data?.creator?.userId,
                    priorityId = issueDetailResponse.value?.data?.data?.priority?.priorityId,
                    targetClosing = issueDetailResponse.value?.data?.data?.targetClosing,
                    issueCategoryId = issueDetailResponse.value?.data?.data?.issueCategory?.issueCategoryId,
                    statusId = detailIssueStatusId.value,
                    userCreated = user.userId.orEmpty()
                )
            )
            updateIssueResponse.value = request
            showProgressBar.value = false
        }
    }
}
