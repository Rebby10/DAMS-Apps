package com.pertamina.digitalaudit.repository.inspection

import android.util.Log
import com.pertamina.digitalaudit.model.InspectionModel
import com.pertamina.digitalaudit.model.IssueModel
import com.pertamina.digitalaudit.model.body.CreateInspectionReqBody
import com.pertamina.digitalaudit.model.body.InspectionResultReqBody
import com.pertamina.digitalaudit.model.body.SubmitInspectionInfoReqBody
import com.pertamina.digitalaudit.model.body.SubmitInspectionSignatureReqBody
import com.pertamina.digitalaudit.model.body.UploadInspectionFileReqBody
import com.pertamina.digitalaudit.model.query.GetInspectionFileQuery
import com.pertamina.digitalaudit.model.query.GetInspectionQuery
import com.pertamina.digitalaudit.model.reportinspection.ReportChecklistResultResponse
import com.pertamina.digitalaudit.model.reportinspection.ReportOverviewResponse
import com.pertamina.digitalaudit.model.reportinspection.ReportSummaryResponse
import com.pertamina.digitalaudit.model.reportinspection.ReportTitlePageResponse
import com.pertamina.digitalaudit.model.startinspection.*
import com.pertamina.digitalaudit.preference.PreferenceProvider
import com.pertamina.digitalaudit.preference.SharedPreferencesKey
import com.pertamina.digitalaudit.util.CommonConstant
import com.pertamina.framework.ResponseHandler
import com.pertamina.framework.base.BaseResponse
import com.pertamina.framework.base.Resource
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.ResponseBody

class InspectionRepositoryImpl(
    private val preference: PreferenceProvider,
    private val service: InspectionService,
    private val responseHandler: ResponseHandler
) : InspectionRepository {

    override suspend fun getInspectionList(query: GetInspectionQuery): Resource<List<InspectionModel.Inspection>> {
        try {
            val request = service.getInspectionList(
                query.userTypeId,
                query.textSearch,
                query.statusId,
                query.regionId,
                query.auditLocationId,
                query.userCreated,
                query.pageSize,
                query.pageNumber,
                query.sortBy,
                query.orderBy
            )
            request.data.let {
                return responseHandler.setSuccess(it!!)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun createNewInspection(reqBody: CreateInspectionReqBody): Resource<InspectionModel.Inspection> {
        try {
            val request = service.createNewInspection(reqBody)
            request.let {
                return responseHandler.setSuccess(it)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun startInspection(inspectionId: String): Resource<StartInspectionResponseModel> {
        try {
            val request = service.startInspection(inspectionId)
            request.let {
                it.data?.templatePage?.forEach { inspectionPage ->
                    inspectionPage?.section?.forEach { section ->
                        section.question?.forEach { questionItem ->
                            questionItem.response?.responseList?.forEach{
                                it.isSelected = questionItem.answer?.answerId == it.listId
                            }
                        }
                    }
                }
                return responseHandler.setSuccess(request)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun startInspectionIssue(inspectionId: String): Resource<List<IssueModel.Issue>> {
        try {
            val request = service.startInspectionIssue(inspectionId)
            request.data.let {
                return responseHandler.setSuccess(it!!)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun getInspectionByPage(
        inspectionId: String,
        pageId: String
    ): Resource<InspectionPageResponse> {
        try {
            val request = service.startInspectionPage(inspectionId, pageId)
            request.let {
                it.data?.section?.forEach { section ->
                    section.question?.forEach { questionItem ->
                        questionItem.response?.responseList?.forEach{
                            it.isSelected = questionItem.answer?.answerId == it.listId
                        }
                    }
                }
                return responseHandler.setSuccess(request)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun startInspectionPageList(inspectionId: String): Resource<List<InspectionPage>> {
        try {
            val request = service.startInspectionPageList(inspectionId)
            request.data.let {
                return responseHandler.setSuccess(it!!)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun getInspectionFile(query: GetInspectionFileQuery): Resource<InspectionModel> {
        try {
            val request = service.getInspectionFile(
                query.inspectionId,
                query.questionId,
                query.fileTypeId,
                query.pageSize,
                query.pageNumber,
                query.sortBy,
                query.orderBy
            )
            request.let {
                return responseHandler.setSuccess(it)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun downloadFile(fileUrl: String): Resource<ResponseBody> {
        try {
            val request = service.downloadFile(fileUrl)
            request.let {
                return responseHandler.setSuccess(it)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun uploadInspectionFile(reqBody: UploadInspectionFileReqBody): Resource<BaseResponse> {
        try {
            val inspectionId =
                RequestBody.create(
                    MediaType.parse(CommonConstant.MULTIPART_FORM_DATE),
                    reqBody.inspectionId
                )
            val questionId =
                RequestBody.create(
                    MediaType.parse(CommonConstant.MULTIPART_FORM_DATE),
                    reqBody.questionId.toString()
                )

            val size = reqBody.files.size
            val fileBody = arrayOfNulls<MultipartBody.Part>(size)
            for (i in 0..size - 1) {
                val fileReqBody =
                    RequestBody.create(
                        MediaType.parse(CommonConstant.MULTIPART_FORM_DATE),
                        reqBody.files[i]
                    )

                fileBody[i] =
                    MultipartBody.Part.createFormData("File", reqBody.files[i].name, fileReqBody)
            }

            //MultipartBody.Part.createFormData("File", reqBody.file.name, fileReqBody)
            val fileTypeId =
                RequestBody.create(
                    MediaType.parse(CommonConstant.MULTIPART_FORM_DATE),
                    reqBody.fileTypeId.toString()
                )
            val userCreated =
                RequestBody.create(
                    MediaType.parse(CommonConstant.MULTIPART_FORM_DATE),
                    reqBody.userCreated
                )
            val request =
                service.uploadInspectionFile(
                    inspectionId,
                    questionId,
                    fileBody,
                    fileTypeId,
                    userCreated
                )
            if (request.isSuccess) {
                return responseHandler.setSuccess(request)
            }
            return responseHandler.setException(Exception())
        } catch (e: Exception) {
            Log.d("startpagefragment", "e:${e.localizedMessage}")
            return responseHandler.setException(e)
        }
    }

    override suspend fun getAllImageFile(inspectionId: String, questionId: Int, fileTypeId: Int): Resource<ImageFileInspection> {
        try {
            val request = service.getAllImageFile(inspectionId, questionId, fileTypeId)
            request.let {
                return responseHandler.setSuccess(it)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun deleteInspectionFile(fileId: String): Resource<InspectionModel> {
        try {
            val request = service.deleteInspectionFile(fileId)
            request.let {
                return responseHandler.setSuccess(it)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun submitInspectionInfo(reqBody: SubmitInspectionInfoReqBody): Resource<InspectionAddInfoResponse> {
        try {
            val request = service.submitInspectionInfo(reqBody)
            request.let {
                return responseHandler.setSuccess(it)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun getInspectionInfo(inspectionId: String): Resource<List<InspectionInfo>> {
        try {
            val request = service.getInspectionInfo(inspectionId)
            request.data.let {
                return responseHandler.setSuccess(it!!)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun getInspectionSignature(inspectionId: String): Resource<InspectionModel> {
        try {
            val request = service.getInspectionSignature(inspectionId)
            request.let {
                return responseHandler.setSuccess(it)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun submitInspectionSignature(reqBody: SubmitInspectionSignatureReqBody): Resource<InspectionModel> {
        try {
            val request = service.submitInspectionSignature(reqBody)
            request.let {
                return responseHandler.setSuccess(it)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun deleteInspectionSignature(signatureId: String): Resource<InspectionModel> {
        try {
            val request = service.deleteInspectionSignature(signatureId)
            request.let {
                return responseHandler.setSuccess(it)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun sendInspectionResult(reqBody: InspectionResultReqBody): Resource<AnswerInspectionResultResponse> {
        reqBody.userCreated = preference.getStringFromPreference(SharedPreferencesKey.USER_ID)
        try {
            val request = service.sendInspectionResult(reqBody)
            request.let {
                return responseHandler.setSuccess(it)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun completeInspection(inspectionId: String): Resource<List<InspectionCompletedItem>> {
        try {
            val request = service.completeInspection(inspectionId)
            request.data.let {
                return responseHandler.setSuccess(it!!)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun getInspectionReportOverview(inspectionId: String): Resource<ReportOverviewResponse> {
        try {
            val request = service.getInspectionReportOverview(inspectionId)
            request.let {
                return responseHandler.setSuccess(it)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun getInspectionReportSummary(inspectionId: String): Resource<ReportSummaryResponse> {
        try {
            val request = service.getInspectionReportSummary(inspectionId)
            request.let {
                return responseHandler.setSuccess(it)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun getInspectionReportTitlePage(inspectionId: String): Resource<ReportTitlePageResponse> {
        try {
            val request = service.getInspectionReportTitlePage(inspectionId)
            request.let {
                return responseHandler.setSuccess(it)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun getInspectionReportChecklistResult(inspectionId: String): Resource<ReportChecklistResultResponse> {
        try {
            val request = service.getInspectionReportChecklistResult(inspectionId)
            request.let {
                return responseHandler.setSuccess(it)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun getInspectionReportFailedItems(inspectionId: String): Resource<List<IssueModel.Issue>> {
        try {
            val request = service.getInspectionReportFailedItems(inspectionId)
            request.data.let {
                return responseHandler.setSuccess(it!!)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun getInspectionReportInfo(inspectionId: String): Resource<List<InspectionInfo>> {
        try {
            val request = service.getInspectionReportInfo(inspectionId)
            request.data.let {
                return responseHandler.setSuccess(it!!)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

}
