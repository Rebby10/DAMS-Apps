package com.pertamina.digitalaudit.presentation.home

import androidx.lifecycle.MutableLiveData
import com.pertamina.digitalaudit.model.HomeOverviewModel
import com.pertamina.digitalaudit.model.InspectionModel
import com.pertamina.digitalaudit.model.IssueModel
import com.pertamina.digitalaudit.model.ScheduleModel
import com.pertamina.digitalaudit.model.UserModel
import com.pertamina.digitalaudit.model.query.GetHomeOverviewQuery
import com.pertamina.digitalaudit.model.query.GetInspectionQuery
import com.pertamina.digitalaudit.model.query.GetIssueQuery
import com.pertamina.digitalaudit.model.query.GetScheduleQuery
import com.pertamina.digitalaudit.preference.PreferenceProvider
import com.pertamina.digitalaudit.repository.common.CommonRepository
import com.pertamina.digitalaudit.util.CommonConstant
import com.pertamina.framework.base.BaseViewModel
import com.pertamina.framework.base.Resource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class HomeViewModel(
    private val commonRepository: CommonRepository,
    val preference: PreferenceProvider
) : BaseViewModel() {

    val isLoading = MutableLiveData(false)
    var showEmptyStateIssue = MutableLiveData(false)
    var showEmptyStateSchedule = MutableLiveData(false)
    var showEmptyStateInspection = MutableLiveData(false)
    var hideLoadMoreIssue = MutableLiveData(false)
    var hideLoadMoreSchedule = MutableLiveData(false)
    var hideLoadMoreInspection = MutableLiveData(false)

    val issueListResponse = MutableLiveData<Resource<List<IssueModel.Issue>>>()
    val scheduleListResponse = MutableLiveData<Resource<List<ScheduleModel.Schedule>>>()
    val inspectionListResponse = MutableLiveData<Resource<List<InspectionModel.Inspection>>>()
    val homeOverviewResponse = MutableLiveData<Resource<HomeOverviewModel>>()

    var user = UserModel.User()

    init {
        getUserData()
    }

    private fun getUserData() {
        launch {
            withContext(Dispatchers.IO) {
                user = preference.getAuthPreferences()
            }
            getHomeData()
        }
    }

    fun getHomeData() {
        getIssue()
        getSchedule()
        getInspection()
    }

    private fun getIssue() {
        val query = GetIssueQuery()
        query.userCreated = user.userId
        query.pageSize = 3
        query.pageNumber = 1
        query.sortBy = CommonConstant.SORT_BY_DATE_CREATED
        query.orderBy = CommonConstant.ORDER_BY_DESC
        isLoading.value = true
        launch {
            val request = commonRepository.getHomeIssueList(query)
            issueListResponse.value = request
            isLoading.value = false
        }
    }

    private fun getSchedule() {
        val query = GetScheduleQuery()
        query.userId = user.userId
        query.pageSize = 3
        query.pageNumber = 1
        isLoading.value = true
        launch {
            val request = commonRepository.getHomeScheduleList(query)
            scheduleListResponse.value = request
            isLoading.value = false
        }
    }

    private fun getInspection() {
        val query = GetInspectionQuery()
        query.userCreated = user.userId
        query.pageSize = 3
        query.pageNumber = 1
        isLoading.value = true
        launch {
            val request = commonRepository.getHomeInspectionList(query)
            inspectionListResponse.value = request
            isLoading.value = false
        }
    }

    fun getHomeOverview(search: String?) {
        val query = GetHomeOverviewQuery()
        query.search = search
        query.pageSize = CommonConstant.DEFAULT_PAGE_SIZE
        query.pageNumber = 1 // set hardcode to 1 because only show maximum 3 data
        query.userId = user.userId
        isLoading.value = true
        launch {
            val request = commonRepository.getHomeOverview(query)
            homeOverviewResponse.value = request
            isLoading.value = false
        }
    }

}
