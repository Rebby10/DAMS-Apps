package com.pertamina.digitalaudit.repository.actions

import com.pertamina.digitalaudit.model.ActionDetailModel
import com.pertamina.digitalaudit.model.ActionModel
import com.pertamina.digitalaudit.model.ActionRepairModel
import com.pertamina.digitalaudit.model.IssueStatusModel
import com.pertamina.digitalaudit.model.LogModel
import com.pertamina.digitalaudit.model.UserAssignModel
import com.pertamina.digitalaudit.model.body.ActionLogReqBody
import com.pertamina.digitalaudit.model.body.ActionRepairReqBody
import com.pertamina.digitalaudit.model.body.CreateActionReqBody
import com.pertamina.digitalaudit.model.body.UpdateActionReqBody
import com.pertamina.digitalaudit.model.body.UpdateActionStatusReqBody
import com.pertamina.digitalaudit.model.query.GetActionQuery
import com.pertamina.digitalaudit.util.CommonConstant
import com.pertamina.framework.ResponseHandler
import com.pertamina.framework.base.BaseResponse
import com.pertamina.framework.base.Resource
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.ResponseBody
import java.io.File

class ActionsRepositoryImpl(
    private val service: ActionsService,
    private val responseHandler: ResponseHandler
) : ActionsRepository {

    override suspend fun getActionList(actionQuery: GetActionQuery?): Resource<List<ActionModel.Action>> {
        try {
            val request = service.getActionListWithQuery(
                actionQuery?.actionId,
                actionQuery?.title,
                actionQuery?.auditLocationId,
                actionQuery?.priorityId,
                actionQuery?.statusId,
                actionQuery?.userCreated,
                actionQuery?.assignUser,
                actionQuery?.startDate,
                actionQuery?.endDate,
                actionQuery?.auditTypeId,
                actionQuery?.isConnectedToIssue,
                actionQuery?.pageSize,
                actionQuery?.pageNumber,
                actionQuery?.sortBy,
                actionQuery?.orderBy,
                actionQuery?.inspectionId,
                actionQuery?.questionId,
                actionQuery?.issueId
            )
            request.data.let {
                return responseHandler.setSuccess(it!!)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun deleteAction(actionId: String): Resource<ActionModel> {
        try {
            val request = service.deleteAction(actionId)
            request.let {
                return responseHandler.setSuccess(it)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun createNewAction(reqBody: CreateActionReqBody): Resource<ActionModel> {
        try {
            val request = service.createAction(reqBody)
            request.let {
                return responseHandler.setSuccess(it)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun getActionDetail(actionId: String): Resource<ActionDetailModel> {
        try {
            val request = service.getDetailAction(actionId)
            request.let {
                return responseHandler.setSuccess(it)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun updateAction(reqBody: UpdateActionReqBody): Resource<ActionModel> {
        try {
            val request = service.updateAction(reqBody)
            request.let {
                return responseHandler.setSuccess(it)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun getActionLog(actionId: String): Resource<List<LogModel.Log>> {
        try {
            val request = service.getActionLog(actionId, null)
            request.data.let {
                return responseHandler.setSuccess(it!!)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun sendLogChat(logReqBody: ActionLogReqBody): Resource<BaseResponse> {
        try {
            val request =
                service.sendActionLog(logReqBody.actionId, logReqBody.text, logReqBody.userCreated)
            if (request.isSuccess) {
                return responseHandler.setSuccess(request)
            }
            return responseHandler.setException(Exception())
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun getAssigneeByName(
        name: String?,
        pageSize: Int?,
        pageNumber: Int?
    ): Resource<List<UserAssignModel.UserAssign>> {
        try {
            val request = service.getAssigneeByName(name, pageSize, pageNumber)
            request.data.let {
                return responseHandler.setSuccess(it!!)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun getIssueStatus(): Resource<List<IssueStatusModel.IssueStatus>> {
        try {
            val request = service.getIssueStatusList()
            request.data.let {
                return responseHandler.setSuccess(it!!)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun updateActionStatus(reqBody: UpdateActionStatusReqBody): Resource<ActionModel> {
        try {
            val request = service.updateActionStatus(reqBody)
            request.let {
                return responseHandler.setSuccess(it)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun saveActionRepair(
        reqBody: ActionRepairReqBody,
        file: File
    ): Resource<ActionRepairModel> {
        try {
            val actionIdBody =
                RequestBody.create(
                    MediaType.parse(CommonConstant.MULTIPART_FORM_DATE),
                    reqBody.actionId
                )
            val rootCauseBody =
                RequestBody.create(
                    MediaType.parse(CommonConstant.MULTIPART_FORM_DATE),
                    reqBody.rootCause
                )
            val rootCauseCategoryIdBody = RequestBody.create(
                MediaType.parse(CommonConstant.MULTIPART_FORM_DATE),
                reqBody.rootCauseCategoryId
            )
            val actionRepairBody =
                RequestBody.create(
                    MediaType.parse(CommonConstant.MULTIPART_FORM_DATE),
                    reqBody.actionRepair
                )
            val actionRepairCategoryIdBody = RequestBody.create(
                MediaType.parse(CommonConstant.MULTIPART_FORM_DATE),
                reqBody.actionRepairCategoryId
            )
            val repairDateBody =
                RequestBody.create(
                    MediaType.parse(CommonConstant.MULTIPART_FORM_DATE),
                    reqBody.repairDate
                )

            val fileReqBody =
                RequestBody.create(MediaType.parse(CommonConstant.MULTIPART_FORM_DATE), file)
            val fileBody: MultipartBody.Part =
                MultipartBody.Part.createFormData("Filename", file.name, fileReqBody)
            val request = service.saveActionRepair(
                actionIdBody,
                rootCauseBody,
                rootCauseCategoryIdBody,
                actionRepairBody,
                actionRepairCategoryIdBody,
                repairDateBody,
                fileBody
            )
            request.let {
                return responseHandler.setSuccess(it)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun sendLogChatFile(
        actionId: String,
        userCreated: String,
        file: File
    ): Resource<BaseResponse> {
        try {
            val actionIdBody =
                RequestBody.create(MediaType.parse(CommonConstant.MULTIPART_FORM_DATE), actionId)
            val userCreatedBody =
                RequestBody.create(MediaType.parse(CommonConstant.MULTIPART_FORM_DATE), userCreated)

            val fileReqBody =
                RequestBody.create(MediaType.parse(CommonConstant.MULTIPART_FORM_DATE), file)
            val fileBody: MultipartBody.Part =
                MultipartBody.Part.createFormData("File", file.name, fileReqBody)
            val request =
                service.sendLogChatFile(actionIdBody, userCreatedBody, fileBody)
            if (request.isSuccess) {
                return responseHandler.setSuccess(request)
            }
            return responseHandler.setException(Exception())
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }

    override suspend fun downloadFile(fileUrl: String): Resource<ResponseBody> {
        try {
            val request = service.downloadFile(fileUrl)
            request.let {
                return responseHandler.setSuccess(it)
            }
        } catch (e: Exception) {
            return responseHandler.setException(e)
        }
    }
}
