package com.pertamina.digitalaudit.presentation.createaction

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.activity.result.contract.ActivityResultContracts
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.databinding.ActivityCreateActionBinding
import com.pertamina.digitalaudit.model.ActionDetailModel
import com.pertamina.digitalaudit.model.IssueModel
import com.pertamina.digitalaudit.model.PriorityModel
import com.pertamina.digitalaudit.model.UserAssignModel
import com.pertamina.digitalaudit.presentation.login.LoginActivity
import com.pertamina.digitalaudit.presentation.main.MainActivity
import com.pertamina.digitalaudit.presentation.search.SearchActivity
import com.pertamina.digitalaudit.util.SnackBar
import com.pertamina.digitalaudit.util.ViewUtils
import com.pertamina.digitalaudit.util.camera.CameraActivity
import com.pertamina.framework.NetworkState
import com.pertamina.framework.ViewDataBindingOwner
import com.pertamina.framework.base.BaseActivity
import com.pertamina.framework.customview.DateTimePicker
import com.pertamina.framework.util.DateHelper
import kotlinx.android.synthetic.main.activity_create_action.*
import kotlinx.android.synthetic.main.toolbar_layout.*
import org.koin.androidx.viewmodel.ext.android.viewModel
import java.io.Serializable

class CreateActionActivity : BaseActivity<CreateActionViewModel>(), CreateActionView,
    ViewDataBindingOwner<ActivityCreateActionBinding>, AdapterView.OnItemSelectedListener {

    override val layoutResourceId: Int = R.layout.activity_create_action
    override val viewModel: CreateActionViewModel by viewModel()
    override var binding: ActivityCreateActionBinding? = null

    private var chooseUserLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val user: UserAssignModel.UserAssign? =
                    result.data?.getSerializableExtra(SearchActivity.EXTRA_USER_DATA) as UserAssignModel.UserAssign?
                user?.let {
                    viewModel.bTextCreateActionAssignToName.value = it.displayName.orEmpty()
                    tvCreateActionAssignToError?.visibility = View.GONE
                    if (it.isGroup == true) {
                        viewModel.createActionAssignToGroupId.value = it.id.orEmpty()
                    } else {
                        viewModel.createActionAssignToUserId.value = it.id.orEmpty()
                    }
                }
            }
        }

    private var chooseIssueLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val issueId = result.data?.getStringExtra(SearchActivity.EXTRA_ISSUE_ID)
                val issueTitle = result.data?.getStringExtra(SearchActivity.EXTRA_ISSUE_TITLE)
                viewModel.bTextCreateActionRelatedIssue.value = issueTitle.orEmpty()
                viewModel.createActionRelatedIssueId.value = issueId
            }
        }

    private var chooseLocationLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val locationId = result.data?.getStringExtra(SearchActivity.EXTRA_LOCATION_ID)
                val locationName = result.data?.getStringExtra(SearchActivity.EXTRA_LOCATION_NAME)
                viewModel.createActionLocationId.value = locationId.orEmpty()
                viewModel.bTextCreateActionLocation.value = locationName
                tvCreateActionLocationError?.visibility = View.GONE
            }
        }

    companion object {
        const val EXTRA_ISSUE_ID = "EXTRA_ISSUE_ID"
        const val EXTRA_ISSUE_TITLE = "EXTRA_ISSUE_TITLE"
        const val EXTRA_ACTION_ID = "EXTRA_ACTION_ID"
        const val EXTRA_INSPECTION_ID = "EXTRA_INSPECTION_ID"
        const val EXTRA_ISSUE_DATA = "EXTRA_ISSUE_DATA"
        const val EXTRA_QUESTION_ID = "EXTRA_QUESTION_ID"

        fun startThisActivity(
            activity: Activity,
            issueId: String,
            issueTitle: String
        ) {
            val intent = Intent(activity, CreateActionActivity::class.java)
            intent.putExtra(EXTRA_ISSUE_ID, issueId)
            intent.putExtra(EXTRA_ISSUE_TITLE, issueTitle)
            activity.startActivity(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        getExtraData()
        setupToolbar()
        subscribeCreateAction()
        subscribePriorityList()
        subscribeUpdateAction()
        subscribeDetailAction()
        etCreateActionTargetClosing.setEventListener(object : DateTimePicker.OnGetDateListener {
            override fun onGetDate(date: String) {
                tvCreateActionTargetClosingError?.visibility = View.GONE
                viewModel.bTextCreateActionTargetClosing.value = date
            }
        })
    }

    private fun setupToolbar() {
        if (viewModel.actionId != null) {
            tvTitleToolbar.text = getString(R.string.actions_edit)
            btnCreateAction.text = getString(R.string.actions_update)
        } else {
            tvTitleToolbar.text = getString(R.string.actions_create_new_title)
            btnCreateAction.text = getString(R.string.actions_create_new_title)
        }
        btnBackToolbar.apply {
            visibility = View.VISIBLE
            setImageResource(R.drawable.ic_close)
            setOnClickListener {
                onBackPressed()
            }
        }
    }

    private fun getExtraData() {
        viewModel.inspectionId = intent?.getStringExtra(EXTRA_INSPECTION_ID)
        viewModel.actionId = intent?.getStringExtra(EXTRA_ACTION_ID)
        viewModel.issueId = intent?.getStringExtra(EXTRA_ISSUE_ID)
        viewModel.issueTitle = intent?.getStringExtra(EXTRA_ISSUE_TITLE).orEmpty()
        if (intent.hasExtra(EXTRA_ISSUE_DATA)){
            val issue = intent.getSerializableExtra(EXTRA_ISSUE_DATA) as? IssueModel.Issue
            issue?.let{
                viewModel.questionId = it.questionId
                viewModel.issueId = it.issueId
                viewModel.createActionLocationId.value = it.auditLocation?.auditLocationId.orEmpty()
                viewModel.bTextCreateActionLocation.value = it.auditLocation?.name
                viewModel.bTextCreateActionAssignToName.value = it.assignUser?.displayName
                viewModel.createActionAssignToUserId.value = it.assignUser?.userId
                viewModel.issueTitle = it.title
                etCreateActionLocation.isEnabled = false
                etCreateActionAssignTo.isEnabled = false
            }
        }

        viewModel.actionId?.let{ viewModel.getActionDetail() }

        viewModel.issueId?.let{
            viewModel.isFromIssue = true
            viewModel.getPriorityList()
            mappingIssue(viewModel.issueId.orEmpty(), viewModel.issueTitle.orEmpty())
        }
    }

    private fun mappingIssue(issueId: String, issueTitle: String) {
        viewModel.createActionRelatedIssueId.value = issueId
        viewModel.bTextCreateActionRelatedIssue.value = issueTitle
        tvCreateActionRelatedIssue.text = getString(R.string.actions_related_issue)
        etCreateActionRelatedIssue.apply {
            isClickable = false
            isEnabled = false
            isFocusable = false
        }
    }

    private fun subscribeCreateAction() {
        observeData(viewModel.createActionResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        //val returnIntent = Intent()
                        //returnIntent.putExtra("EXTRA_ACTION_DATA", (it.data?.data) as Serializable)
                        setResult(RESULT_OK, Intent())
                        finish()
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message ?: getString(R.string.general_server_error_message)
                        )
                        when (it.code) {
                            401 -> {
                                viewModel.preference.clearPreferences()
                                logout(Intent(this, LoginActivity::class.java))
                            }
                        }
                    }
                }
            }
        }
    }

    private fun subscribePriorityList() {
        observeData(viewModel.priorityListResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        initPrioritySpinner(it.data)
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message ?: getString(R.string.general_server_error_message)
                        )
                    }
                }
            }
        }
    }

    private fun subscribeUpdateAction() {
        observeData(viewModel.updateActionResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        setResult(RESULT_OK)
                        finish()
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message ?: getString(R.string.general_server_error_message)
                        )
                        when (it.code) {
                            401 -> {
                                viewModel.preference.clearPreferences()
                                logout(Intent(this, LoginActivity::class.java))
                            }
                        }
                    }
                }
            }
        }
    }

    private fun subscribeDetailAction() {
        observeData(viewModel.actionDetailResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { actionDetail ->
                            setDataToView(actionDetail.data)
                            viewModel.getPriorityList()
                        }
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message ?: getString(R.string.general_server_error_message)
                        )
                        when (it.code) {
                            401 -> {
                                viewModel.preference.clearPreferences()
                                logout(Intent(this, LoginActivity::class.java))
                            }
                            else -> {
                                //do nothing just to avoid error warning
                            }
                        }
                    }
                }
            }
        }
    }

    private fun setDataToView(data: ActionDetailModel.ActionDetail?) {
        viewModel.bTextCreateActionTitle.value = data?.title
        viewModel.bTextCreateActionDescription.value = data?.descriptions
        viewModel.bTextCreateActionAssignToName.value = getAssignedUser(data)
        viewModel.bTextCreateActionRelatedIssue.value = data?.issue?.title.orEmpty()
        etCreateActionTargetClosing.setText(
            DateHelper.changeFormat(
                data?.targetClosing.orEmpty(),
                DateHelper.yyyy_MM_dd_T_HHmmss,
                DateHelper.dd_MMM_yyyy_hh_mm_a
            )
        )
        viewModel.bTextCreateActionTargetClosing.value = data?.targetClosing.orEmpty()
        viewModel.bTextCreateActionLocation.value = data?.auditLocation?.name.orEmpty()
        viewModel.createActionLocationId.value = data?.auditLocation?.auditLocationId.orEmpty()
        viewModel.createActionPriorityId.value = data?.priority?.priorityId ?: 0
        viewModel.createActionRelatedIssueId.value = data?.issue?.issueId
    }

    private fun getAssignedUser(data: ActionDetailModel.ActionDetail?): String {
        data?.assignUser?.displayName?.let {
            viewModel.createActionAssignToUserId.value = data.assignUser?.userId.orEmpty()
            return it
        }
        data?.assignGroup?.name?.let {
            viewModel.createActionAssignToGroupId.value = data.assignGroup?.userGroupId.orEmpty()
            return it
        }
        return ""
    }

    private fun initPrioritySpinner(data: List<PriorityModel.Priority>?) {
        val adapter =
            data?.let { ArrayAdapter(this, android.R.layout.simple_spinner_item, it) }
        adapter?.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spCreateActionPriority.adapter = adapter
        spCreateActionPriority.onItemSelectedListener = this
        spCreateActionPriority.setSelection(viewModel.getSelectedPrioritySpinnerItemPosition())
    }

    override fun onClickCreateAction(view: View) {
        var isValid = true
        if (viewModel.bTextCreateActionTitle.value.isNullOrEmpty()) {
            isValid = false
            tvCreateActionTitleError?.visibility = View.VISIBLE
        }

        if (viewModel.bTextCreateActionDescription.value.isNullOrEmpty()) {
            isValid = false
            tvCreateActionDescriptionError?.visibility = View.VISIBLE
        }

        if (viewModel.bTextCreateActionTargetClosing.value?.isEmpty() == true) {
            isValid = false
            tvCreateActionTargetClosingError?.visibility = View.VISIBLE
        }

        if (viewModel.bTextCreateActionAssignToName.value?.isEmpty() == true) {
            isValid = false
            tvCreateActionAssignToError?.visibility = View.VISIBLE
        }

        if (viewModel.bTextCreateActionLocation.value?.isEmpty() == true) {
            isValid = false
            tvCreateActionLocationError?.visibility = View.VISIBLE
        }

        if (isValid) {
            ViewUtils.hideKeyboard(this, view)
            if (viewModel.actionId != null) {
                viewModel.updateAction()
            } else {
                viewModel.createNewAction()
            }
        }
    }

    override fun onClickChooseUser(view: View) {
        val intent = Intent(this, SearchActivity::class.java)
        intent.putExtra(SearchActivity.EXTRA_FROM_ACTION, true)
        intent.putExtra(SearchActivity.EXTRA_TITLE, getString(R.string.choose_assignee))
        intent.putExtra(SearchActivity.EXTRA_IS_SEARCH_USER, true)
        chooseUserLauncher.launch(intent)
    }

    override fun onClickChooseIssue(view: View) {
        val intent = Intent(this, SearchActivity::class.java)
        intent.putExtra(SearchActivity.EXTRA_TITLE, getString(R.string.choose_related_issue))
        intent.putExtra(SearchActivity.EXTRA_IS_SEARCH_ISSUE, true)
        chooseIssueLauncher.launch(intent)
    }

    override fun onClickChooseLocation(view: View) {
        val intent = Intent(this, SearchActivity::class.java)
        intent.putExtra(SearchActivity.EXTRA_TITLE, getString(R.string.choose_location))
        intent.putExtra(SearchActivity.EXTRA_IS_SEARCH_LOCATION, true)
        chooseLocationLauncher.launch(intent)
    }

    override var bTextWatcherActionTitle: TextWatcher
        get() = object : TextWatcher {

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                tvCreateActionTitleError?.visibility = View.GONE
            }

            override fun afterTextChanged(s: Editable?) {}
        }
        set(_) {}

    override var bTextWatcherActionDescription: TextWatcher
        get() = object : TextWatcher {

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                tvCreateActionDescriptionError?.visibility = View.GONE
            }

            override fun afterTextChanged(s: Editable?) {}
        }
        set(_) {}

    override fun onNothingSelected(parent: AdapterView<*>?) {
        //do nothing
    }

    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
        when (parent?.id) {
            R.id.spCreateActionPriority -> {
                val priority = parent.selectedItem as PriorityModel.Priority
                viewModel.createActionPriorityId.value = priority.priorityId ?: 0
            }
        }
    }
}
