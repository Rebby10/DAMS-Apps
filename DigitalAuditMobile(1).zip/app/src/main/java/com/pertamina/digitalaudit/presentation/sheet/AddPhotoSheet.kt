package com.pertamina.digitalaudit.presentation.sheet

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.presentation.startinspection.adapter.ImagePreviewAdapter
import com.pertamina.digitalaudit.util.CommonConstant
import com.pertamina.digitalaudit.util.camera.CameraActivity
import com.pertamina.imageeditor.ImageEditorActivity
import kotlinx.android.synthetic.main.sheet_add_photo.*
import pub.devrel.easypermissions.AfterPermissionGranted
import pub.devrel.easypermissions.EasyPermissions
import java.io.File

class AddPhotoSheet : BottomSheetDialogFragment() {

    var listener: AddPhotoSheetListener? = null
    private var imagePreviewAdapter: ImagePreviewAdapter? = null
    private var imagesUri = mutableListOf<String>()
    private var imagesFile = mutableListOf<File>()
    private var bottomSheetBehavior: BottomSheetBehavior<*>? = null
    private var selectedPosition = 0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.sheet_add_photo, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setEvent()
        setupRecyclerView()
    }

    private fun setupRecyclerView(){
        imagesUri.add("")
        imagesUri.add("")
        imagesUri.add("")
        imagesUri.add("")
        val intent = arguments?.getStringArrayList("EXISTING_IMAGE")?.toMutableList()
        intent?.let{
            it.forEachIndexed { index, data ->
                imagesUri[index] = data
            }
        }
        imagePreviewAdapter = ImagePreviewAdapter()
        imagePreviewAdapter?.setOnImageClickListener(object :
                ImagePreviewAdapter.ImageClickListener {
            override fun onClickImage(position: Int, image: String) {
                selectedPosition = position
                if (image == "") requestPermissionWriteExternalStorage()
                else {
                    if (!image.contains("https")) {
                        val uri = Uri.fromFile(File(image))
                        Glide.with(requireContext()).load(uri)
                            .into(ivPreview)
                    } else {
                        Glide.with(requireContext()).load(image)
                            .centerCrop()
                            .into(ivPreview)
                    }
                }
            }

            override fun onClickDelete(position: Int, image: String) {
                imagesUri[position] = ""
                imagePreviewAdapter?.setData(imagesUri)
            }
        })
        val horizontalManager = LinearLayoutManager(requireContext(), RecyclerView.HORIZONTAL, false)
        rvPhotos.apply {
            layoutManager = horizontalManager
            setHasFixedSize(true)
            adapter = imagePreviewAdapter
        }
        imagePreviewAdapter?.setData(imagesUri)
    }

    private fun setEvent() {
        btnCancel.setOnClickListener {
            dismiss()
        }
        btnSave.setOnClickListener {
            imagesFile.clear()
            imagesUri.forEach {
                if (it != "" && !it.contains("https")) imagesFile.add(File(it))
            }
            listener?.onSave(imagesUri, imagesFile)
            dismiss()
        }
    }

    override fun onStart() {
        super.onStart()
        val dialog = dialog

        if (dialog != null) {
            val bottomSheet: View? = dialog.findViewById(R.id.container)
            bottomSheet?.layoutParams?.height = ViewGroup.LayoutParams.MATCH_PARENT
            view?.post {
                val parent = view?.parent as View
                val params = parent.layoutParams as CoordinatorLayout.LayoutParams
                val behavior = params.behavior
                bottomSheetBehavior = behavior as BottomSheetBehavior<*>?

                bottomSheet?.layoutParams?.height = ViewGroup.LayoutParams.MATCH_PARENT
                bottomSheetBehavior?.setPeekHeight(requireView().measuredHeight)
            }
        }
    }

    @AfterPermissionGranted(CommonConstant.RC_WRITE_EXTERNAL_STORAGE_PERM)
    private fun requestPermissionWriteExternalStorage() {
        val perms = arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (EasyPermissions.hasPermissions(requireContext(), *perms)) {
            showFilePickerDialog()
        } else {
            EasyPermissions.requestPermissions(
                this,
                getString(R.string.permission_to_access_file),
                CommonConstant.RC_WRITE_EXTERNAL_STORAGE_PERM,
                *perms
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this)
    }

    private fun showFilePickerDialog() {
        val dialog = SelectUploadSourceSheet()
        dialog.listener = object :
            SelectUploadSourceSheet.SelectUploadSourceBottomSheetFragmentListener {
            override fun onSelectCamera() {
                goToCamera()
            }

            override fun onSelectGallery() {
                goToGallery()
            }

            override fun onSelectFile() {
                //todo select file
            }
        }
        dialog.show(parentFragmentManager, "select_upload_source")
    }

    private fun goToCamera() {
        val intent = Intent(context, CameraActivity::class.java)
        cameraLauncher.launch(intent)
    }

    interface AddPhotoSheetListener {
        fun onSave(images: List<String>, files: List<File>)
    }

    private fun openImageEditorActivity(uri: Uri) {
        val intent = Intent(requireContext(), ImageEditorActivity::class.java)
        intent.putExtra("imageUri", uri.toString())
        imageEditorLauncher.launch(intent)
    }

    private var imageEditorLauncher =
            registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
                if (result.resultCode == Activity.RESULT_OK) {
                    val uri = Uri.parse(result.data?.getStringExtra("imagePath"))
                    uri?.let {
                        imagesUri[selectedPosition] = it.toString()
                        imagePreviewAdapter?.setData(imagesUri)
                        imagePreviewAdapter?.notifyDataSetChanged()
                    }
                }
            }

    private var cameraLauncher =
            registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
                if (result.resultCode == Activity.RESULT_OK) {
                    result.data?.let {
                        val uri = Uri.parse(it.getStringExtra(CameraActivity.EXTRA_CAPTURED_URI))
                        uri?.let { data ->
                            openImageEditorActivity(data)
                        } ?: run { showErrorUploadFile() }
                    } ?: run { showErrorUploadFile() }
                }
            }

    private var galleryLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                result.data?.let {
                    val imageUri: Uri? = it.data
                    imageUri?.let { uri ->
                        openImageEditorActivity(uri)
                    } ?: run { showErrorUploadFile() }
                } ?: run { showErrorUploadFile() }
            }
        }

    private fun showErrorUploadFile() {
        Toast.makeText(
                context,
                getString(R.string.error_upload_file),
                Toast.LENGTH_SHORT
        ).show()
    }

    private fun goToGallery() {
        val photoPickerIntent = Intent(Intent.ACTION_GET_CONTENT)
        photoPickerIntent.type = "image/*"
        galleryLauncher.launch(photoPickerIntent)
    }
}