package com.pertamina.digitalaudit.model

import com.google.gson.annotations.SerializedName
import com.pertamina.framework.base.BaseResponse

class ActionRepairMasterDataModel : BaseResponse() {

    @SerializedName("Result")
    var data: ActionRepairMasterData? = null

    class ActionRepairMasterData {
        @SerializedName("RootCauseCategory")
        var rootCauseCategory: List<ActionRepairCategory>? = null

        @SerializedName("ActionRepairCategory")
        var actionRepairCategory: List<ActionRepairCategory>? = null

        class ActionRepairCategory {
            @SerializedName("Id")
            var id: String? = null

            @SerializedName("Name")
            var name: String? = null

            /**
             * Pay attention here, you have to override the toString method as the
             * ArrayAdapter will reads the toString of the given object for the name
             *
             * @return name
             */
            override fun toString(): String {
                return name.orEmpty()
            }
        }
    }
}