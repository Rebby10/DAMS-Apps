package com.pertamina.digitalaudit.presentation.startinspection.startpage.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.animation.RotateAnimation
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.model.IssueModel
import com.pertamina.digitalaudit.presentation.issues.helper.IssuesStatusViewHelper
import com.pertamina.framework.base.BaseRecyclerViewAdapter
import com.pertamina.framework.base.BaseViewHolder
import kotlinx.android.synthetic.main.item_report_failed_items_parent.view.*

class InspectionIssueAdapter : BaseRecyclerViewAdapter<IssueModel.Issue>() {

    private var listener: ItemClickListener? = null

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BaseViewHolder<IssueModel.Issue> {
        val view = LayoutInflater.from(parent.context).inflate(viewType, parent, false)
        return ListViewHolder(parent.context, view, listener)
    }

    override fun onBindViewHolder(
        holder: BaseViewHolder<IssueModel.Issue>,
        position: Int
    ) {
        holder.bindData(getItem(position))
    }

    override fun getItemViewType(position: Int): Int {
        return R.layout.item_report_failed_items_parent
    }

    class ListViewHolder(context: Context, val view: View, listener: ItemClickListener?) :
        BaseViewHolder<IssueModel.Issue>(context, view) {

        private var holderListener: ItemClickListener? = listener
        private var tvPageName = view.tvTitleIssues
        private var tvQuestion = view.tvQuestion
        private var tvQuestionAnswer = view.tvQuestionAnswer
        private var rvActions = view.rvActionsFailedItems
        private var tvReportIssueStatus = view.tvReportIssueStatus
        private var tvReportIssueTotalAction = view.tvReportIssueTotalAction
        private var tvReportedBy = view.tvReportedBy
        private var ivArrow = view.ivArrowRight
        private var btnAddAction = view.btnAddAction
        private var hideRvAction = false


        @SuppressLint("SetTextI18n")
        override fun bindData(data: IssueModel.Issue) {
            tvPageName.setOnClickListener {
                holderListener?.onClickIssue(data)
            }
            tvQuestion.text = data.question
            tvQuestionAnswer.text = data.descriptions
            hideRvAction = data.actions.size == 0
            rotateSectionArrow(!hideRvAction)
            rvActions.visibility = if (!hideRvAction) View.VISIBLE else View.GONE
            tvPageName.text = data.title
            tvReportedBy.text = "Reported by ${data.creator?.displayName}"
            tvReportIssueStatus.apply {
                data.status?.let { status ->
                    text = status.name
                    setBackgroundResource(IssuesStatusViewHelper.getStatusBackgroundColor(status.name.orEmpty()))
                    setTextColor(
                        ContextCompat.getColor(
                            context,
                            IssuesStatusViewHelper.getStatusTextColor(status.name.orEmpty())
                        )
                    )
                }
            }
            ivArrow.setOnClickListener {
                rotateSectionArrow(hideRvAction)
                rvActions.visibility = if (hideRvAction) View.VISIBLE else View.GONE
                hideRvAction = !hideRvAction
            }
            btnAddAction.setOnClickListener {
                holderListener?.onClickAddAction(data)
            }

            val llManager = LinearLayoutManager(context)
            val listActionsOfIssueAdapter = InspectionIssueChildAdapter()
            rvActions.apply {
                layoutManager = llManager
                setHasFixedSize(true)
                adapter = listActionsOfIssueAdapter
            }
            listActionsOfIssueAdapter.setData(data.actions)
            tvReportIssueTotalAction.text = "${data.actions.size} Actions"
        }

        private fun rotateSectionArrow(isShow: Boolean) {
            val anim = if (isShow) {
                RotateAnimation(
                    0F,
                    180F,
                    Animation.RELATIVE_TO_SELF,
                    0.5f,
                    Animation.RELATIVE_TO_SELF,
                    0.5f
                )
            } else {
                RotateAnimation(
                    180F,
                    0F,
                    Animation.RELATIVE_TO_SELF,
                    0.5f,
                    Animation.RELATIVE_TO_SELF,
                    0.5f
                )
            }
            anim.fillAfter = true
            ivArrow.startAnimation(anim)
        }
    }

    fun setItemClickListener(listener: ItemClickListener) {
        this.listener = listener
    }

    interface ItemClickListener {
        fun onClickAddAction(data: IssueModel.Issue)
        fun onClickIssue(data: IssueModel.Issue)
    }
}