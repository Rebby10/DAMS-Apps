package com.pertamina.digitalaudit.model.startinspection

import com.google.gson.annotations.SerializedName

data class InspectionInfoResponse(

	@field:SerializedName("TotalResult")
	val totalResult: Int? = null,

	@field:SerializedName("TotalData")
	val totalData: Int? = null,

	@field:SerializedName("Result")
	val data: List<InspectionInfo>? = null
)

data class InspectionInfo(

	@field:SerializedName("InfoId")
	val infoId: String? = null,

	@field:SerializedName("InspectionId")
	val inspectionId: String? = null,

	@field:SerializedName("Title")
	var title: String? = null,

	@field:SerializedName("Notes")
	var notes: String? = null
)
