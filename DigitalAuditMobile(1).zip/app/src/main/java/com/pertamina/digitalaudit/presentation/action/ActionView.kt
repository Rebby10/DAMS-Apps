package com.pertamina.digitalaudit.presentation.action

import com.pertamina.framework.base.BaseView

/**
 * Created by M Hafidh Abdul Aziz on 03/03/21.
 */

interface ActionView : BaseView {
    fun onClickFilterMenuItem(menuPosition: Int)
}