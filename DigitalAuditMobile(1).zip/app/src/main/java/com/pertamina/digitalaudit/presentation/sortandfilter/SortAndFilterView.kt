package com.pertamina.digitalaudit.presentation.sortandfilter

import android.view.View
import com.pertamina.framework.base.BaseView

/**
 * Created by M Hafidh Abdul Aziz on 13/03/21.
 */

interface SortAndFilterView : BaseView {
    fun onClickApplyFilter(view: View)
    fun onClickChooseLocation(view: View)
}