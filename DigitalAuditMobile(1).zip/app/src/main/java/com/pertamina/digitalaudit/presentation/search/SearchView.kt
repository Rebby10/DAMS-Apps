package com.pertamina.digitalaudit.presentation.search

import android.view.View
import android.widget.TextView
import com.pertamina.framework.base.BaseView

interface SearchView : BaseView {
    fun onClickClear(view: View)
    var bOnEditorActionListener: TextView.OnEditorActionListener
}
