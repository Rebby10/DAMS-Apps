package com.pertamina.digitalaudit.presentation.issues

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.databinding.FragmentIssuesBinding
import com.pertamina.digitalaudit.eventbus.StartIssueActivityEvent
import com.pertamina.digitalaudit.model.body.SortAndFilterReqBody
import com.pertamina.digitalaudit.presentation.chat.ChatActivity
import com.pertamina.digitalaudit.presentation.createissue.CreateIssueActivity
import com.pertamina.digitalaudit.presentation.home.adapter.IssuesAdapter
import com.pertamina.digitalaudit.presentation.issuedetails.IssueDetailActivity
import com.pertamina.digitalaudit.presentation.issues.IssuesViewModel.Companion.ASSIGN_TO_ME
import com.pertamina.digitalaudit.presentation.issues.IssuesViewModel.Companion.REPORTED_BY_ME
import com.pertamina.digitalaudit.presentation.main.MainActivity
import com.pertamina.digitalaudit.presentation.map.MapActivity
import com.pertamina.digitalaudit.presentation.map.adapter.ToolbarMenuAdapter
import com.pertamina.digitalaudit.presentation.sheet.IssueOptionsSheet
import com.pertamina.digitalaudit.presentation.sortandfilter.SortAndFilterActivity
import com.pertamina.digitalaudit.util.SnackBar
import com.pertamina.framework.NetworkState
import com.pertamina.framework.ViewDataBindingOwner
import com.pertamina.framework.base.BaseFragment
import com.pertamina.framework.extensions.sharedGraphViewModel
import kotlinx.android.synthetic.main.fragment_issues.*
import kotlinx.android.synthetic.main.layout_empty_state.*
import kotlinx.android.synthetic.main.toolbar_layout.*
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import org.koin.android.ext.android.inject

/**
 * Created by M Hafidh Abdul Aziz on 11/03/21.
 */

class IssuesFragment : BaseFragment<IssuesViewModel>(), IssuesView,
    ViewDataBindingOwner<FragmentIssuesBinding>, IssuesAdapter.IssueClickListener,
    IssueOptionsSheet.MenuItemClickListener {

    override val layoutResourceId: Int = R.layout.fragment_issues
    override val viewModel: IssuesViewModel by sharedGraphViewModel(R.id.nav_graph_issues)
    override var binding: FragmentIssuesBinding? = null

    private lateinit var toolbarMenuAdapter: ToolbarMenuAdapter
    private var issuesAdapter: IssuesAdapter? = null
    private var chosenIssueId: String = ""
    private var chosenIssueTitle: String = ""
    private var menuBottomSheet: IssueOptionsSheet? = null
    private val sortAndFilterModel: SortAndFilterReqBody by inject()

    private var sortFilterLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                if (viewModel.filterMenuPosition == REPORTED_BY_ME)
                    viewModel.applyFilterIssueReportByMe(sortAndFilterModel)
                else viewModel.applyFilterIssueAssignToMe(sortAndFilterModel)
            }
        }

    private var newIssueLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                viewModel.getAllDataAPI()
            }
        }

    private var updateIssueLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                viewModel.getAllDataAPI()
            }
        }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupToolbar()
        setupView()
        setupRv()
        observeIssueList()
        observeAssignToMeIssueList()
        observeDeletedIssue()
    }

    override fun onClickFilterMenuItem(menuPosition: Int) {
        viewModel.filterMenuPosition = menuPosition
        resetData()
        viewModel.getAllDataAPI()
    }

    override fun onResume() {
        super.onResume()
        toolbarMenuAdapter.setSelectedMenuPosition(viewModel.filterMenuPosition)
    }

    override fun onStart() {
        super.onStart()
        EventBus.getDefault().register(this)
    }

    override fun onStop() {
        super.onStop()
        EventBus.getDefault().unregister(this)
    }

    override fun onClickIssueFilter(view: View) {
        if (viewModel.filterMenuPosition == REPORTED_BY_ME) sortAndFilterModel.userCreated =
            viewModel.user.userId
        else sortAndFilterModel.assignUser = viewModel.user.userId

        val intent = Intent(activity, SortAndFilterActivity::class.java)
        sortFilterLauncher.launch(intent)
    }

    override fun onClickIssue(issueId: String, issueTitle: String, latLng: String?) {
        showMenuBottomSheet(issueId, issueTitle)
    }

    override fun onBottomSheetItemClicked(menu: String) {
        when (menu) {
            getString(R.string.menu_view) -> {
                menuBottomSheet?.dismiss()
                ChatActivity.startThisActivityFromIssue(
                    this@IssuesFragment.requireContext(),
                    chosenIssueId, chosenIssueTitle,
                    viewModel.filterMenuPosition == ASSIGN_TO_ME
                )
            }
            getString(R.string.menu_resolve) -> {
                menuBottomSheet?.dismiss()
                IssueDetailActivity.startThisActivity(
                    requireContext(),
                    chosenIssueId, viewModel.filterMenuPosition == ASSIGN_TO_ME
                )
            }
            getString(R.string.menu_edit) -> {
                menuBottomSheet?.dismiss()
                val intent = Intent(activity, CreateIssueActivity::class.java)
                intent.putExtra(CreateIssueActivity.EXTRA_ISSUE_ID, chosenIssueId)
                updateIssueLauncher.launch(intent)
            }
            getString(R.string.menu_delete) -> {
                menuBottomSheet?.dismiss()
                showConfirmationDelete()
            }
        }
    }

    private fun observeIssueList() {
        observeData(viewModel.reportByMeIssueList) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { data ->
                            if (data.isNotEmpty()) {
                                viewModel.showEmptyState.value = false
                                if (viewModel.filterMenuPosition == REPORTED_BY_ME) {
                                    issuesAdapter?.setData(data)
                                }
                            } else {
                                if (viewModel.filterMenuPosition == REPORTED_BY_ME) {
                                    viewModel.showEmptyState.value = true
                                    tvEmptyMessage.text = getString(R.string.issues_empty)
                                }
                            }
                        }
                    }
                    NetworkState.ERROR -> {
                        when (it.code) {
                            404 -> {
                                if (viewModel.filterMenuPosition == REPORTED_BY_ME) {
                                    tvEmptyMessage.text = it.message
                                    viewModel.showEmptyState.value = true
                                    issuesAdapter?.removeAllData()
                                }
                            }
                            else -> {
                                if (viewModel.filterMenuPosition == REPORTED_BY_ME) {
                                    SnackBar.snackBarShowError(
                                        requireContext(),
                                        parentLayout,
                                        it.message
                                            ?: getString(R.string.general_server_error_message)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private fun observeAssignToMeIssueList() {
        observeData(viewModel.assignToMeIssueList) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { data ->
                            if (data.isNotEmpty()) {
                                viewModel.showEmptyState.value = false
                                if (viewModel.filterMenuPosition == ASSIGN_TO_ME) {
                                    issuesAdapter?.setData(data)
                                }
                            } else {
                                if (viewModel.filterMenuPosition == ASSIGN_TO_ME) {
                                    viewModel.showEmptyState.value = true
                                    tvEmptyMessage.text = getString(R.string.issues_empty)
                                }
                            }
                        }
                    }
                    NetworkState.ERROR -> {
                        when (it.code) {
                            404 -> {
                                if (viewModel.filterMenuPosition == ASSIGN_TO_ME) {
                                    tvEmptyMessage.text = it.message
                                    viewModel.showEmptyState.value = true
                                    issuesAdapter?.removeAllData()
                                }
                            }
                            else -> {
                                if (viewModel.filterMenuPosition == ASSIGN_TO_ME) {
                                    SnackBar.snackBarShowError(
                                        requireContext(),
                                        parentLayout,
                                        it.message
                                            ?: getString(R.string.general_server_error_message)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private fun observeDeletedIssue() {
        observeData(viewModel.deletedIssueResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        SnackBar.snackBarShowSuccess(
                            requireContext(),
                            parentLayout,
                            it.message ?: getString(R.string.deleted_data_message)
                        )
                        viewModel.deletedIssueResponse.value = null
                        viewModel.getAllDataAPI()
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            requireContext(),
                            parentLayout,
                            it.message ?: getString(R.string.general_server_error_message)
                        )
                    }
                }
            }
        }
    }

    private fun resetData() {
        val reportByMeIssueList = viewModel.reportByMeIssueList.value?.data
        val assignToMeIssueList = viewModel.assignToMeIssueList.value?.data
        if (viewModel.filterMenuPosition == REPORTED_BY_ME) {
            if (reportByMeIssueList == null) issuesAdapter?.removeAllData()
        } else {
            if (assignToMeIssueList == null) issuesAdapter?.removeAllData()
        }
    }

    private fun setupToolbar() {
        tvTitleToolbar.apply {
            text = getString(R.string.title_issues)
            gravity = Gravity.START
        }
        menuAction1.apply {
            visibility = View.VISIBLE
            setImageResource(R.drawable.ic_search)
            setOnClickListener {
                manageSearchLayout(true)
            }
        }
        menuAction2.apply {
            visibility = View.VISIBLE
            setImageResource(R.drawable.ic_map)
            setOnClickListener {
                MapActivity.startThisActivity(
                    this@IssuesFragment.requireContext(),
                    selectedMenuPosition = viewModel.filterMenuPosition,
                    isFromIssue = true
                )
            }
        }
        ivClearSearch.setOnClickListener {
            etSearchToolbar.setText("")
            manageSearchLayout(false)
            viewModel.getAllDataAPI()
        }
    }

    private fun setupView() {
        (activity as MainActivity).closeFabMenu()
        (activity as MainActivity).manageFloatingButtonAdd(true)
        etSearchToolbar.setOnKeyListener { _, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_UP) {
                if (etSearchToolbar.text.toString().isNotEmpty()) {
                    val query = SortAndFilterReqBody()
                    query.title = etSearchToolbar.text.toString()
                    if (viewModel.filterMenuPosition == REPORTED_BY_ME) {
                        viewModel.reportByMeIssueList(query)
                    } else {
                        viewModel.assignToMeIssueList(query)
                    }
                } else {
                    viewModel.getAllDataAPI()
                }
            }
            false
        }

        val toolbarMenu = ArrayList(listOf(*resources.getStringArray(R.array.filter_issues_menu)))
        toolbarMenuAdapter = ToolbarMenuAdapter(arrayListOf()).apply {
            setSelectedMenuPosition(REPORTED_BY_ME)
            addData(toolbarMenu)
        }
        rvIssueMenuFilter.run {
            layoutManager = LinearLayoutManager(context, RecyclerView.HORIZONTAL, false)
            adapter = toolbarMenuAdapter
        }

        toolbarMenuAdapter.setListener(object :
            ToolbarMenuAdapter.OnToolbarMenuInteractionListener {
            override fun onMenuItemClicked(menuPosition: Int) {
                toolbarMenuAdapter.setSelectedMenuPosition(menuPosition)
                onClickFilterMenuItem(menuPosition)
            }
        })
    }

    private fun showMenuBottomSheet(issueId: String, issueTitle: String) {
        chosenIssueId = issueId
        chosenIssueTitle = issueTitle
        menuBottomSheet =
            IssueOptionsSheet(requireContext(), viewModel.filterMenuPosition).apply {
                setCancelable(true)
                setMenuItemListener(this@IssuesFragment)
            }
        menuBottomSheet?.show()
    }

    private fun setupRv() {
        issuesAdapter = IssuesAdapter()
        issuesAdapter?.setIssueClickListener(this)
        val manager = LinearLayoutManager(activity)
        rvIssues.apply {
            layoutManager = manager
            setHasFixedSize(true)
            adapter = issuesAdapter
        }
    }

    @Subscribe(sticky = true, threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: StartIssueActivityEvent) {
        val intent = Intent(activity, CreateIssueActivity::class.java)
        newIssueLauncher.launch(intent)
        EventBus.getDefault().removeStickyEvent(event)
    }

    private fun showConfirmationDelete() {
        val alertDialog: AlertDialog? = activity?.let {
            val builder = AlertDialog.Builder(it)
            builder.apply {
                setPositiveButton(R.string.confirmation_yes) { dialog, _ ->
                    viewModel.deleteSelectedIssue(chosenIssueId)
                    dialog.dismiss()
                }
                setNegativeButton(R.string.confirmation_no) { dialog, _ ->
                    dialog.dismiss()
                }
            }
            builder.setMessage(R.string.confirmation_message)
            builder.create()
        }
        alertDialog?.show()
    }

    private fun manageSearchLayout(isShow: Boolean) {
        tvTitleToolbar.visibility = if (isShow) View.GONE else View.VISIBLE
        menuAction1.visibility = if (isShow) View.GONE else View.VISIBLE
        etSearchToolbar.visibility = if (isShow) View.VISIBLE else View.GONE
        ivClearSearch.visibility = if (isShow) View.VISIBLE else View.GONE
    }

}
