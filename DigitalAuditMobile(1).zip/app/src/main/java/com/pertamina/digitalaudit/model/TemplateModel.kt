package com.pertamina.digitalaudit.model

import com.google.gson.annotations.SerializedName
import com.pertamina.framework.base.BaseResponse

class TemplateModel : BaseResponse() {

    @SerializedName("Result")
    var data: List<Template>? = null

    class Template : BaseItem() {
        @SerializedName("TemplateId")
        var templateId: String? = ""

        @SerializedName("PermissionEntityId")
        var permissionEntityId: String? = ""

        @SerializedName("Code")
        var code: String? = ""

        @SerializedName("Title")
        var title: String? = ""

        @SerializedName("Descriptions")
        var descriptions: String? = ""

        @SerializedName("DateCreated")
        var dateCreated: String? = ""

        @SerializedName("DateModified")
        var dateModified: String? = ""

        @SerializedName("PermissionType")
        var permissionType: PermissionType? = null

        @SerializedName("Category")
        var category: Category? = null

        @SerializedName("Permission")
        var permissions: List<Permission>? = null

        /**
         * Pay attention here, you have to override the toString method as the
         * ArrayAdapter will reads the toString of the given object for the name
         *
         * @return name
         */
        override fun toString(): String {
            return title.orEmpty()
        }
    }

    class PermissionType {
        @SerializedName("TemplatePermissionTypeId")
        var templatePermissionTypeId: String? = ""

        @SerializedName("Name")
        var name: String? = ""
    }

    class Category {
        @SerializedName("CategoryId")
        var categoryId: String? = ""

        @SerializedName("Name")
        var name: String? = ""
    }

    class Permission {
        @SerializedName("UserId")
        var userId: String? = ""

        @SerializedName("Username")
        var username: String? = ""

        @SerializedName("OfficialName")
        var officialName: String? = ""
    }
}