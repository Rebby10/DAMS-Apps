package com.pertamina.digitalaudit.presentation.chat.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.pertamina.digitalaudit.R
import com.pertamina.framework.base.BaseRecyclerViewAdapter
import com.pertamina.framework.base.BaseViewHolder
import kotlinx.android.synthetic.main.item_recommendation.view.*

class RecommendationAdapter : BaseRecyclerViewAdapter<String>() {

    private var listener: RecommendationClickListener? = null

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BaseViewHolder<String> {
        val view = LayoutInflater.from(parent.context).inflate(viewType, parent, false)
        return ListViewHolder(parent.context, view, listener)
    }

    override fun onBindViewHolder(
        holder: BaseViewHolder<String>,
        position: Int
    ) {
        holder.bindData(getItem(position))
    }

    override fun getItemViewType(position: Int): Int {
        return R.layout.item_recommendation
    }

    class ListViewHolder(context: Context, val view: View, listener: RecommendationClickListener?) :
        BaseViewHolder<String>(context, view) {

        private lateinit var data: String
        private var holderListener: RecommendationClickListener? = listener

        private var tvRecommendation = view.tvRecommendation

        override fun bindData(data: String) {
            this.data = data
            tvRecommendation.text = data
            itemView.setOnClickListener {
                holderListener?.onClicRecommendation(data)
            }
        }
    }

    fun setRecommendationClickListener(listener: RecommendationClickListener) {
        this.listener = listener
    }

    interface RecommendationClickListener {
        fun onClicRecommendation(recommendation: String)
    }
}
