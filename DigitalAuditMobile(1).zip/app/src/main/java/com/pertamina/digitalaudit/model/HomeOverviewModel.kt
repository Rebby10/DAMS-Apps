package com.pertamina.digitalaudit.model

import com.google.gson.annotations.SerializedName
import com.pertamina.framework.base.BaseResponse

class HomeOverviewModel : BaseResponse() {

    @SerializedName("Result")
    var data: Overview? = null

    class Overview {
        @SerializedName("Schedule")
        var schedule: ScheduleHome? = null

        @SerializedName("Issue")
        var issue: IssueHome? = null

        @SerializedName("Inspection")
        var inspection: InspectionHome? = null
    }
}

class ScheduleHome {
    @SerializedName("Data")
    var data: List<ScheduleModel.Schedule>? = null

    @SerializedName("TotalData")
    var totalData: Int? = 0
}

class IssueHome {
    @SerializedName("Data")
    var data: List<IssueModel.Issue>? = null

    @SerializedName("TotalData")
    var totalData: Int? = 0
}

class InspectionHome {
    @SerializedName("Data")
    var data: List<InspectionModel.Inspection>? = null

    @SerializedName("TotalData")
    var totalData: Int? = 0
}
