package com.pertamina.digitalaudit.model.body

import com.google.gson.annotations.SerializedName

data class InspectionResultReqBody(
    @SerializedName("InspectionId")
    var inspectionId: String?,
    @SerializedName("QuestionId")
    var questionId: Int? = null,
    @SerializedName("AnswerId")
    var answerId: Int? = null,
    @SerializedName("AnswerText")
    var answerText: String?,
    @SerializedName("Notes")
    var notes: String?
){
    @SerializedName("UserCreated")
    var userCreated: String? = null
}