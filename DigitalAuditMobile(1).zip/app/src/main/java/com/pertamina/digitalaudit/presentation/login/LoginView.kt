package com.pertamina.digitalaudit.presentation.login

import android.view.View
import com.pertamina.framework.base.BaseView

/**
 * Created by M Hafidh Abdul Aziz on 21/03/21.
 */

interface LoginView : BaseView {
    fun onClickLogin(view: View)
}