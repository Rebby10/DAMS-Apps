package com.pertamina.digitalaudit.presentation.startinspection.actionpage.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.model.ActionModel
import com.pertamina.digitalaudit.presentation.issues.helper.IssuesStatusViewHelper
import com.pertamina.framework.base.BaseRecyclerViewAdapter
import com.pertamina.framework.base.BaseViewHolder
import com.pertamina.framework.util.DateHelper
import kotlinx.android.synthetic.main.item_actions_of_issues_inspection.view.*

class InspectionActionAdapter : BaseRecyclerViewAdapter<ActionModel.Action>() {

    private var listener: DeleteActionClickListener? = null
    private var isFromReport: Boolean = false

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BaseViewHolder<ActionModel.Action> {
        val view = LayoutInflater.from(parent.context).inflate(viewType, parent, false)
        return ListViewHolder(parent.context, view, listener, isFromReport)
    }

    override fun onBindViewHolder(holder: BaseViewHolder<ActionModel.Action>, position: Int) {
        holder.bindData(getItem(position))
    }

    override fun getItemViewType(position: Int): Int {
        return R.layout.item_actions_of_issues_inspection
    }

    class ListViewHolder(
        context: Context,
        val view: View,
        listener: DeleteActionClickListener?,
        fromReport: Boolean
    ) :
        BaseViewHolder<ActionModel.Action>(context, view) {

        private lateinit var data: ActionModel.Action
        private var holderListener: DeleteActionClickListener? = listener
        private var isFromReport = fromReport

        private var tvTitleAction = view.tvTitleAction
        private var tvReportedBy = view.tvReportedBy
        private var tvActionPriorityType = view.tvActionPriorityType
        private var tvActionUpdatedAt = view.tvActionUpdatedAt
        private var tvStatusAction = view.tvActionStatus
        private var clActionDelete = view.clActionDelete

        @SuppressLint("SetTextI18n")
        override fun bindData(data: ActionModel.Action) {
            this.data = data
            tvTitleAction.text = data.title
            tvReportedBy.text = "Reported by ${data.creator?.displayName}"
            data.targetClosing?.let {
                tvActionUpdatedAt.text = DateHelper.changeFormat(
                    it,
                    DateHelper.yyyy_MM_dd_T_HHmmss,
                    DateHelper.dd_MMMM_yyyy
                )
            }

            tvActionPriorityType.apply {
                data.priority?.let { priority ->
                    text = priority.name
                    setTextColor(
                        ContextCompat.getColor(
                            context,
                            IssuesStatusViewHelper.getPriorityTextColor(priority.name.orEmpty())
                        )
                    )
                }
            }

            tvStatusAction.apply {
                data.status?.let { status ->
                    text = status.name
                    setBackgroundResource(IssuesStatusViewHelper.getStatusBackgroundColor(status.name.orEmpty()))
                    setTextColor(
                        ContextCompat.getColor(
                            context,
                            IssuesStatusViewHelper.getStatusTextColor(status.name.orEmpty())
                        )
                    )
                }
            }
            clActionDelete.apply {
                visibility = if (isFromReport) View.GONE else View.VISIBLE
                setOnClickListener {
                    holderListener?.onClickDeleteAction(data.actionId.orEmpty())
                }
            }
        }
    }

    fun setIsFromReport(fromReport: Boolean) {
        this.isFromReport = fromReport
    }

    fun setDeleteActionClickListener(listener: DeleteActionClickListener) {
        this.listener = listener
    }

    interface DeleteActionClickListener {
        fun onClickDeleteAction(actionsId: String)
    }
}