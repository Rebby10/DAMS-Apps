package com.pertamina.digitalaudit.presentation.createschedule

import androidx.lifecycle.MutableLiveData
import com.pertamina.digitalaudit.model.ScheduleDetailModel
import com.pertamina.digitalaudit.model.ScheduleModel
import com.pertamina.digitalaudit.model.body.Auditee
import com.pertamina.digitalaudit.model.body.Auditor
import com.pertamina.digitalaudit.model.body.CreateScheduleReqBody
import com.pertamina.digitalaudit.model.body.UpdateScheduleReqBody
import com.pertamina.digitalaudit.preference.PreferenceProvider
import com.pertamina.digitalaudit.repository.schedule.ScheduleRepository
import com.pertamina.framework.NonNullMutableLiveData
import com.pertamina.framework.base.BaseViewModel
import com.pertamina.framework.base.Resource
import kotlinx.coroutines.launch

/**
 * Created by M Hafidh Abdul Aziz on 11/03/21.
 */

class CreateScheduleViewModel(
    private val scheduleRepository: ScheduleRepository,
    val preference: PreferenceProvider
) : BaseViewModel() {
    val showProgressBar = MutableLiveData(false)

    var bTextScheduleStartDate = MutableLiveData("")
    var bTextScheduleEndDate = MutableLiveData("")
    var bTextScheduleAssignAuditorName = MutableLiveData("")
    var bTextScheduleAssignAuditeeName = MutableLiveData("")
    var bTextScheduleLocation = MutableLiveData("")
    var bTextScheduleTemplate = MutableLiveData("")

    var createScheduleLocationId = NonNullMutableLiveData("")
    var createScheduleTemplateId = NonNullMutableLiveData("")
    var createScheduleAssignAuditeeUserId = MutableLiveData<String>(null)
    var createScheduleAssignAuditeeGroupId = MutableLiveData<String>(null)
    var createScheduleAssignAuditorUserId = MutableLiveData<String>(null)
    var createScheduleAssignAuditorGroupId = MutableLiveData<String>(null)

    val createScheduleResponse = MutableLiveData<Resource<ScheduleModel.Schedule>>()
    val updateScheduleResponse = MutableLiveData<Resource<ScheduleModel.Schedule>>()
    val detailScheduleResponse = MutableLiveData<Resource<ScheduleDetailModel>>()

    var scheduleId: String = ""

    fun createNewSchedule() {
        showProgressBar.value = true
        launch {
            val request = scheduleRepository.createNewSchedule(
                CreateScheduleReqBody(
                    auditLocationId = createScheduleLocationId.value,
                    startDate = bTextScheduleStartDate.value.orEmpty(),
                    endDate = bTextScheduleEndDate.value.orEmpty(),
                    templateId = createScheduleTemplateId.value,
                    auditor = Auditor(
                        createScheduleAssignAuditorUserId.value,
                        createScheduleAssignAuditorGroupId.value
                    ),
                    auditee = Auditee(
                        createScheduleAssignAuditeeUserId.value,
                        createScheduleAssignAuditeeGroupId.value
                    )
                )
            )
            createScheduleResponse.value = request
            showProgressBar.value = false
        }
    }

    fun updateSchedule() {
        showProgressBar.value = true
        launch {
            val request = scheduleRepository.updateSchedule(
                UpdateScheduleReqBody(
                    id = scheduleId,
                    auditLocationId = createScheduleLocationId.value,
                    startDate = bTextScheduleStartDate.value.orEmpty(),
                    endDate = bTextScheduleEndDate.value.orEmpty(),
                    templateId = createScheduleTemplateId.value,
                    auditor = Auditor(
                        createScheduleAssignAuditorUserId.value,
                        createScheduleAssignAuditorGroupId.value
                    ),
                    auditee = Auditee(
                        createScheduleAssignAuditeeUserId.value,
                        createScheduleAssignAuditeeGroupId.value
                    )
                )
            )
            updateScheduleResponse.value = request
            showProgressBar.value = false
        }
    }

    fun getScheduleDetail() {
        showProgressBar.value = true
        launch {
            val request = scheduleRepository.getScheduleDetail(scheduleId)
            detailScheduleResponse.value = request
            showProgressBar.value = false
        }
    }
}
