package com.pertamina.digitalaudit.module

import com.pertamina.digitalaudit.repository.actions.ActionsRepository
import com.pertamina.digitalaudit.repository.actions.ActionsRepositoryImpl
import com.pertamina.digitalaudit.repository.common.CommonRepository
import com.pertamina.digitalaudit.repository.common.CommonRepositoryImpl
import com.pertamina.digitalaudit.repository.inspection.InspectionRepository
import com.pertamina.digitalaudit.repository.inspection.InspectionRepositoryImpl
import com.pertamina.digitalaudit.repository.issues.IssuesRepository
import com.pertamina.digitalaudit.repository.issues.IssuesRepositoryImpl
import com.pertamina.digitalaudit.repository.login.LoginRepository
import com.pertamina.digitalaudit.repository.login.LoginRepositoryImpl
import com.pertamina.digitalaudit.repository.schedule.ScheduleRepository
import com.pertamina.digitalaudit.repository.schedule.ScheduleRepositoryImpl
import org.koin.dsl.module

val repositoryModule = module {

    single<IssuesRepository> { IssuesRepositoryImpl(get(), get()) }
    single<LoginRepository> { LoginRepositoryImpl(get(), get(), get()) }
    single<ActionsRepository> { ActionsRepositoryImpl(get(), get()) }
    single<ScheduleRepository> { ScheduleRepositoryImpl(get(), get()) }
    single<CommonRepository> { CommonRepositoryImpl(get(), get()) }
    single<InspectionRepository> { InspectionRepositoryImpl(get(), get(), get()) }
}
