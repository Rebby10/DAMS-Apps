package com.pertamina.digitalaudit.presentation.notification

import androidx.lifecycle.MutableLiveData
import com.pertamina.framework.base.BaseViewModel

/**
 * Created by M Hafidh Abdul Aziz on 20/03/21.
 */

class NotificationViewModel : BaseViewModel() {

    val showProgressBar = MutableLiveData(false)
}
