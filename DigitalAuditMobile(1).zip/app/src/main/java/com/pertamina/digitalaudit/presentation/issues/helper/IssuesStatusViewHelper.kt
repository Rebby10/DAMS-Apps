package com.pertamina.digitalaudit.presentation.issues.helper

import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.presentation.issues.issuesenum.IssuesPriorityEnum
import com.pertamina.digitalaudit.presentation.issues.issuesenum.IssuesStatusEnum

/**
 * @author Asadurrahman Al Qayyim
 * @date 3/22/2021
 */

object IssuesStatusViewHelper {

    fun getStatusBackgroundColor(status: String): Int {
        return when (status) {
            IssuesStatusEnum.OPEN.status -> {
                R.drawable.bg_red_24_with_radius_2
            }
            IssuesStatusEnum.ONPROGRESS.status -> {
                R.drawable.bg_royal_blue_13_with_radius_2
            }
            IssuesStatusEnum.CLOSE.status, IssuesStatusEnum.CONFIRMED.status -> {
                R.drawable.bg_junggle_green_13_with_radius_2
            }
            IssuesStatusEnum.UNCONFIRMED.status -> {
                R.drawable.bg_grey_with_radius_2
            }
            else -> R.drawable.bg_grey_with_radius_2
        }
    }

    fun getStatusTextColor(status: String): Int {
        return when (status) {
            IssuesStatusEnum.OPEN.status -> {
                return R.color.primary_red_700
            }
            IssuesStatusEnum.ONPROGRESS.status -> {
                return R.color.royal_blue
            }
            IssuesStatusEnum.CLOSE.status, IssuesStatusEnum.CONFIRMED.status -> {
                return R.color.jungle_green
            }
            IssuesStatusEnum.UNCONFIRMED.status -> {
                return R.color.neutral_grey
            }
            else -> R.color.neutral_grey
        }
    }

    fun getPriorityTextColor(priority: String): Int {
        return when (priority) {
            IssuesPriorityEnum.LOW.priority -> {
                R.color.royal_blue
            }
            IssuesPriorityEnum.HIGH.priority -> {
                R.color.primary_red_700
            }
            IssuesPriorityEnum.NORMAL.priority -> {
                R.color.orange
            }
            else -> R.color.orange
        }

    }

}
