package com.pertamina.digitalaudit.presentation.scheduledetail

import androidx.lifecycle.MutableLiveData
import com.pertamina.digitalaudit.model.ScheduleDetailModel
import com.pertamina.digitalaudit.model.ScheduleModel
import com.pertamina.digitalaudit.model.UserModel
import com.pertamina.digitalaudit.model.body.RescheduleApprovalReqBody
import com.pertamina.digitalaudit.model.body.RescheduleReqBody
import com.pertamina.digitalaudit.preference.PreferenceProvider
import com.pertamina.digitalaudit.repository.schedule.ScheduleRepository
import com.pertamina.framework.base.BaseViewModel
import com.pertamina.framework.base.Resource
import kotlinx.coroutines.launch

/**
 * Created by M Hafidh Abdul Aziz on 20/03/21.
 */

class ScheduleDetailViewModel(
    private val scheduleRepository: ScheduleRepository,
    val preference: PreferenceProvider
) : BaseViewModel() {
    val showProgressBar = MutableLiveData(false)
    val isCanReschedule = MutableLiveData(false)
    val isRequester = MutableLiveData(false)
    val isApprover = MutableLiveData(false)

    var bTextScheduleTitle = MutableLiveData("")
    var bTextScheduleDate = MutableLiveData("")
    var bTextScheduleLocation = MutableLiveData("")
    var bTextScheduleTemplate = MutableLiveData("")
    var bTextScheduleAuditor = MutableLiveData("")
    var bTextScheduleAuditee = MutableLiveData("")
    var bTextRescheduleStartDate = MutableLiveData("")
    var bTextRescheduleEndDate = MutableLiveData("")
    var bTextRescheduleReasonDescription = MutableLiveData("")

    val detailScheduleResponse = MutableLiveData<Resource<ScheduleDetailModel>>()
    val rescheduleApprovalResponse = MutableLiveData<Resource<ScheduleModel.Schedule>>()
    val rescheduleResponse = MutableLiveData<Resource<ScheduleModel.Schedule>>()

    var scheduleId: String = ""
    var rescheduleId: String = ""
    var user = UserModel.User()

    init {
        getUserData()
    }

    private fun getUserData() {
        user = preference.getAuthPreferences()
    }

    fun getScheduleDetail() {
        showProgressBar.value = true
        launch {
            val request = scheduleRepository.getScheduleDetail(scheduleId)
            detailScheduleResponse.value = request
            showProgressBar.value = false
        }
    }

    fun confirmReschedule(isApprove: Boolean) {
        showProgressBar.value = true
        launch {
            val request = scheduleRepository.confirmReschedule(
                RescheduleApprovalReqBody(
                    scheduleId = scheduleId,
                    rescheduleId = rescheduleId,
                    isApproved = isApprove
                )
            )
            rescheduleApprovalResponse.value = request
            showProgressBar.value = false
        }
    }

    fun reschedule() {
        showProgressBar.value = true
        launch {
            val request = scheduleRepository.reschedule(
                RescheduleReqBody(
                    scheduleId = scheduleId,
                    userId = user.userId.orEmpty(),
                    startDate = bTextRescheduleStartDate.value.orEmpty(),
                    endDate = bTextRescheduleEndDate.value.orEmpty(),
                    descriptions = bTextRescheduleReasonDescription.value.orEmpty()
                )
            )
            rescheduleResponse.value = request
            showProgressBar.value = false
        }
    }
}
