package com.pertamina.digitalaudit.model.body

import com.google.gson.annotations.SerializedName

class ActionRepairReqBody(
    @SerializedName("ActionId")
    var actionId: String,
    @SerializedName("RootCause")
    var rootCause: String,
    @SerializedName("RootCauseCategoryId")
    var rootCauseCategoryId: String,
    @SerializedName("ActionRepair")
    var actionRepair: String,
    @SerializedName("ActionRepairCategoryId")
    var actionRepairCategoryId: String,
    @SerializedName("RepairDate")
    var repairDate: String
)
