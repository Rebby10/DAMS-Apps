package com.pertamina.digitalaudit.model.body

import com.google.gson.annotations.SerializedName

/**
 * Created by M Hafidh Abdul Aziz on 23/03/21.
 */

class CreateIssueReqBody(
    @SerializedName("Title")
    var title: String,
    @SerializedName("Descriptions")
    var descriptions: String,
    @SerializedName("AuditLocationId")
    var auditLocationId: String,
    @SerializedName("AssignGroup")
    var assignedGroup: String?,
    @SerializedName("AssignUser")
    var assignedUser: String?,
    @SerializedName("Creator")
    var creator: String,
    @SerializedName("PriorityId")
    var priorityId: Int,
    @SerializedName("TargetClosing")
    var targetClosing: String,
    @SerializedName("IssueCategoryId")
    var issueCategoryId: Int,
    @SerializedName("StatusId")
    var statusId: Int,
    @SerializedName("UserCreated")
    var userCreated: String
)
