package com.pertamina.digitalaudit.module

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import com.pertamina.digitalaudit.application.DigitalAuditApplication
import com.pertamina.digitalaudit.preference.PreferenceProvider
import org.koin.android.ext.koin.androidApplication
import org.koin.dsl.module

/**
 * @author asadurrahman.qayyim
 * @date 03/02/2021
 */

val preferenceModule = module {
    single { provideSettingsPreferences(androidApplication()) }
    single { PreferenceProvider(get()) }
}

private val PREFERENCES_FILE_KEY = DigitalAuditApplication::class.java.simpleName

private fun provideSettingsPreferences(app: Application): SharedPreferences =
        app.getSharedPreferences(PREFERENCES_FILE_KEY, Context.MODE_PRIVATE)