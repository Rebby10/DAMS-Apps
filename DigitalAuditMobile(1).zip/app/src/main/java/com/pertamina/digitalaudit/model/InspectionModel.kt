package com.pertamina.digitalaudit.model

import com.google.gson.annotations.SerializedName
import com.pertamina.framework.base.BaseResponse

class InspectionModel : BaseResponse() {

    @SerializedName("Result")
    var data: List<Inspection>? = null

    class Inspection {

        @SerializedName("InspectionId")
        var inspectionId: String? = ""

        @SerializedName("ScheduleId")
        var scheduleId: String? = ""

        @SerializedName("AuditLocation")
        var auditLocation: AuditLocationModel.AuditLocation? = null

        @SerializedName("StartDate")
        var startDate: String? = ""

        @SerializedName("EndDate")
        var endDate: String? = ""

        @SerializedName("Template")
        var template: TemplateModel.Template? = null

        @SerializedName("Status")
        var status: StatusModel.Status? = null

        @SerializedName("Auditor")
        var auditor: AuditorModel.Auditor? = null

        @SerializedName("Auditee")
        var auditee: AuditeeModel.Auditee? = null

        @SerializedName("DateCreated")
        var dateCreated: String? = ""

        @SerializedName("DateModified")
        var dateModified: String? = ""

    }
}
