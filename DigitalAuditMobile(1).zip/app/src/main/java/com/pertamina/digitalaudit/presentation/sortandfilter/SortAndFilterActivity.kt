package com.pertamina.digitalaudit.presentation.sortandfilter

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.activity.result.contract.ActivityResultContracts
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.databinding.ActivitySortAndFilterBinding
import com.pertamina.digitalaudit.model.AuditTypeModel
import com.pertamina.digitalaudit.model.IssueStatusModel
import com.pertamina.digitalaudit.model.PriorityModel
import com.pertamina.digitalaudit.presentation.search.SearchActivity
import com.pertamina.digitalaudit.util.SnackBar
import com.pertamina.framework.NetworkState
import com.pertamina.framework.ViewDataBindingOwner
import com.pertamina.framework.base.BaseActivity
import com.pertamina.framework.customview.DateTimePicker
import kotlinx.android.synthetic.main.activity_sort_and_filter.*
import kotlinx.android.synthetic.main.toolbar_layout.*
import org.koin.androidx.viewmodel.ext.android.viewModel

/**
 * Created by M Hafidh Abdul Aziz on 03/03/21.
 */

class SortAndFilterActivity : BaseActivity<SortAndFilterViewModel>(), SortAndFilterView,
    AdapterView.OnItemSelectedListener,
    ViewDataBindingOwner<ActivitySortAndFilterBinding> {

    override val layoutResourceId: Int = R.layout.activity_sort_and_filter
    override val viewModel: SortAndFilterViewModel by viewModel()
    override var binding: ActivitySortAndFilterBinding? = null

    private val sortByFilter: Array<String> by lazy {
        resources.getStringArray(R.array.filter_sort_by_menu)
    }

    private val actionsFilter: Array<String> by lazy {
        resources.getStringArray(R.array.filter_actions_menu)
    }

    private var chooseLocationLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val locationId = result.data?.getStringExtra(SearchActivity.EXTRA_LOCATION_ID)
                val locationName = result.data?.getStringExtra(SearchActivity.EXTRA_LOCATION_NAME)
                viewModel.bFilterLocationId.value = locationId
                viewModel.bTextFilterLocation.value = locationName
            }
        }

    companion object {
        const val EXTRA_IS_FROM_ACTIONS = "EXTRA_IS_FROM_ACTIONS"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupToolbar()
        getExtraData()
        initSortBySpinner()
        initActionsSpinner()
        observePriorityList()
        observeStatusList()
        observeAuditTypeList()
        etFilterStartDate.setEventListener(object : DateTimePicker.OnGetDateListener {
            override fun onGetDate(date: String) {
                viewModel.bTextFilterStartDate.value = date
            }
        })
        etFilterEndDate.setEventListener(object : DateTimePicker.OnGetDateListener {
            override fun onGetDate(date: String) {
                viewModel.bTextFilterEndDate.value = date
            }
        })
    }

    private fun observePriorityList() {
        observeData(viewModel.priorityListResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        initPrioritySpinner(it.data)
                    }
                    else -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message
                                ?: getString(R.string.general_server_error_message)
                        )
                    }
                }
            }
        }
    }

    private fun observeStatusList() {
        observeData(viewModel.statusListResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        initStatusSpinner(it.data)
                    }
                    else -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message
                                ?: getString(R.string.general_server_error_message)
                        )
                    }
                }
            }
        }
    }

    private fun observeAuditTypeList() {
        observeData(viewModel.auditTypeListResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        initAuditTypeSpinner(it.data)
                    }
                    else -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message
                                ?: getString(R.string.general_server_error_message)
                        )
                    }
                }
            }
        }
    }

    private fun setupToolbar() {
        tvTitleToolbar.text = getString(R.string.sort_n_filter)
        btnBackToolbar.apply {
            visibility = View.VISIBLE
            setImageResource(R.drawable.ic_close)
            setOnClickListener {
                onBackPressed()
            }
        }
    }

    private fun getExtraData() {
        viewModel.isFromActions.value = intent?.getBooleanExtra(EXTRA_IS_FROM_ACTIONS, false)
    }

    private fun initSortBySpinner() {
        val adapter =
            ArrayAdapter(this, android.R.layout.simple_spinner_item, sortByFilter)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spFilterSortBy.adapter = adapter
        spFilterSortBy.onItemSelectedListener = this
    }

    private fun initActionsSpinner() {
        val adapter =
            ArrayAdapter(this, android.R.layout.simple_spinner_item, actionsFilter)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spFilterActions.adapter = adapter
        spFilterActions.onItemSelectedListener = this
    }

    private fun initAuditTypeSpinner(data: List<AuditTypeModel.AuditType>?) {
        val auditType = AuditTypeModel.AuditType().apply {
            name = getString(R.string.all_label)
        }
        val adapter =
            ArrayAdapter<AuditTypeModel.AuditType>(this, android.R.layout.simple_spinner_item)
        adapter.add(auditType)
        data?.let { adapter.addAll(it) }
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spFilterAuditType.adapter = adapter
        spFilterAuditType.onItemSelectedListener = this
    }

    private fun initPrioritySpinner(data: List<PriorityModel.Priority>?) {
        val priority = PriorityModel.Priority().apply {
            name = getString(R.string.all_label)
        }
        val adapter =
            ArrayAdapter<PriorityModel.Priority>(this, android.R.layout.simple_spinner_item)
        adapter.add(priority)
        data?.let { adapter.addAll(it) }
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spFilterPriority.adapter = adapter
        spFilterPriority.onItemSelectedListener = this
        spFilterPriority.setSelection(viewModel.getSelectedPrioritySpinnerItemPosition())
    }

    private fun initStatusSpinner(data: List<IssueStatusModel.IssueStatus>?) {
        val issueStatus = IssueStatusModel.IssueStatus().apply {
            name = getString(R.string.all_label)
        }
        val adapter =
            ArrayAdapter<IssueStatusModel.IssueStatus>(this, android.R.layout.simple_spinner_item)
        adapter.add(issueStatus)
        data?.let { adapter.addAll(it) }
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spFilterStatus.adapter = adapter
        spFilterStatus.onItemSelectedListener = this
        spFilterStatus.setSelection(viewModel.getSelectedStatusSpinnerItemPosition())
    }

    override fun onClickApplyFilter(view: View) {
        if (viewModel.isFromActions.value == true) {
            viewModel.applySortAndFilterActions()
        } else {
            viewModel.applySortAndFilterModel()
        }
        setResult(Activity.RESULT_OK)
        finish()
    }

    override fun onClickChooseLocation(view: View) {
        val intent = Intent(this, SearchActivity::class.java)
        intent.putExtra(SearchActivity.EXTRA_TITLE, getString(R.string.choose_location))
        intent.putExtra(SearchActivity.EXTRA_IS_SEARCH_LOCATION, true)
        chooseLocationLauncher.launch(intent)
    }

    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
        when (parent?.id) {
            R.id.spFilterSortBy -> {
                viewModel.bTextFilterSortBy.value =
                    if (position == 0) null else sortByFilter[position]
            }
            R.id.spFilterAuditType -> {
                val auditType = parent.selectedItem as AuditTypeModel.AuditType
                viewModel.bFilterAuditTypeId.value =
                    if (position == 0) null else auditType.auditTypeId
            }
            R.id.spFilterPriority -> {
                val priority = parent.selectedItem as PriorityModel.Priority
                viewModel.bFilterPriorityId.value =
                    if (position == 0) null else priority.priorityId ?: 0
            }
            R.id.spFilterStatus -> {
                val status = parent.selectedItem as IssueStatusModel.IssueStatus
                viewModel.bFilterStatusId.value = if (position == 0) null else status.statusId ?: 0
            }
            R.id.spFilterActions -> {
                viewModel.bTextFilterActions.value =
                    if (position == 0) null else actionsFilter[position]
                viewModel.bFilterConnectedToActions.value =
                    when (viewModel.bTextFilterActions.value) {
                        getString(R.string.actions_created_label) -> {
                            true
                        }
                        getString(R.string.actions_not_created_label) -> {
                            false
                        }
                        else -> {
                            null
                        }
                    }
            }
        }
    }

    override fun onNothingSelected(p0: AdapterView<*>?) {
        //do nothing
    }
}
