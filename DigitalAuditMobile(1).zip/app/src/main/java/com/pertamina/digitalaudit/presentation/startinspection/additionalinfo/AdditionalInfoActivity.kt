package com.pertamina.digitalaudit.presentation.startinspection.additionalinfo

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.databinding.ActivityAdditionalInfoBinding
import com.pertamina.digitalaudit.model.body.SubmitInspectionInfoReqBody
import com.pertamina.digitalaudit.model.body.SubmitInspectionSignatureReqBody
import com.pertamina.digitalaudit.presentation.startinspection.additionalinfo.adapter.AdditionalInfoNoteAdapter
import com.pertamina.digitalaudit.presentation.startinspection.additionalinfo.adapter.AdditionalInfoSignatureAdapter
import com.pertamina.digitalaudit.util.SnackBar
import com.pertamina.framework.NetworkState
import com.pertamina.framework.ViewDataBindingOwner
import com.pertamina.framework.base.BaseActivity
import kotlinx.android.synthetic.main.activity_additional_info.*
import kotlinx.android.synthetic.main.toolbar_layout.*
import org.koin.androidx.viewmodel.ext.android.viewModel

class AdditionalInfoActivity : BaseActivity<AdditionalInfoViewModel>(), AdditionalInfoView,
    ViewDataBindingOwner<ActivityAdditionalInfoBinding> {

    override val layoutResourceId: Int = R.layout.activity_additional_info
    override val viewModel: AdditionalInfoViewModel by viewModel()
    override var binding: ActivityAdditionalInfoBinding? = null

    private var addInfoNoteAdapter: AdditionalInfoNoteAdapter? = null
    private var addInfoSignatureAdapter: AdditionalInfoSignatureAdapter? = null

    private val addInfoNotes: ArrayList<SubmitInspectionInfoReqBody> by lazy {
        ArrayList()
    }
    private val addInfoSignatures: ArrayList<SubmitInspectionSignatureReqBody> by lazy {
        ArrayList()
    }

    companion object {
        private const val EXTRA_INSPECTION_ID = "EXTRA_INSPECTION_ID"

        fun startThisActivity(context: Context, inspectionId: String) {
            val intent = Intent(context, AdditionalInfoActivity::class.java)
            intent.putExtra(EXTRA_INSPECTION_ID, inspectionId)
            context.startActivity(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        getExtraData()
        setupToolbar()
        setupInitialData()
        setupRv()
        observeGetAdditionalInfoNotes()
        observeSubmitAdditionalInfoNotes()
        observeGetAdditionalInfoSignatures()
    }

    private fun getExtraData() {
        viewModel.inspectionId = intent?.getStringExtra(EXTRA_INSPECTION_ID)
        viewModel.getAdditionalInfoNote()
        viewModel.getAdditionalInfoSignature()
    }

    private fun setupToolbar() {
        tvTitleToolbar.text = getString(R.string.additional_info_label)
        btnBackToolbar.apply {
            visibility = View.VISIBLE
            setImageResource(R.drawable.ic_back)
            setOnClickListener {
                onBackPressed()
            }
        }
    }

    private fun setupInitialData() {
        addInfoNotes.add(
            SubmitInspectionInfoReqBody(
                inspectionId = viewModel.inspectionId.orEmpty(),
                title = "",
                notes = "",
                userCreated = viewModel.user.userId.orEmpty()
            )
        )
        addInfoSignatures.add(
            SubmitInspectionSignatureReqBody(
                inspectionId = viewModel.inspectionId.orEmpty(),
                title = "",
                name = "",
                signature = "",
                userCreated = viewModel.user.userId.orEmpty()
            )
        )
    }

    private fun setupRv() {
        addInfoNoteAdapter = AdditionalInfoNoteAdapter()
        addInfoNoteAdapter?.setItemListener(object : AdditionalInfoNoteAdapter.ItemListener {
            @SuppressLint("NotifyDataSetChanged")
            override fun onDeleteItem(position: Int) {
                addInfoNotes.removeAt(position)
                addInfoNoteAdapter?.removeData(position)
            }

            override fun onTitleNoteChange(position: Int, titleNote: String) {
                addInfoNotes[position].title = titleNote
            }

            override fun onNoteChange(position: Int, note: String) {
                addInfoNotes[position].notes = note
            }
        })
        val llManagerNote = LinearLayoutManager(this)
        rvNotes.apply {
            layoutManager = llManagerNote
            setHasFixedSize(true)
            adapter = addInfoNoteAdapter
        }
        addInfoNoteAdapter?.setData(addInfoNotes)

        addInfoSignatureAdapter = AdditionalInfoSignatureAdapter()
        val llManagerSignature = LinearLayoutManager(this)
        rvSignatures.apply {
            layoutManager = llManagerSignature
            setHasFixedSize(true)
            adapter = addInfoSignatureAdapter
        }
        addInfoSignatureAdapter?.setData(addInfoSignatures)
    }

    private fun observeGetAdditionalInfoNotes() {
        observeData(viewModel.additionalInfoNotesResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let {

                        }
                    }
                    else -> {
                        //do nothing
                    }
                }
            }
        }
    }

    private fun observeSubmitAdditionalInfoNotes() {
        observeData(viewModel.submitAdditionalInfoNotesResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let {

                        }
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message
                                ?: getString(R.string.general_server_error_message)
                        )
                    }
                }
            }
        }
    }

    private fun observeGetAdditionalInfoSignatures() {
        observeData(viewModel.additionalInfoSignaturesResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let {

                        }
                    }
                    else -> {
                        //do nothing
                    }
                }
            }
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun onClickAddNote(view: View) {
        addInfoNotes.add(
            SubmitInspectionInfoReqBody(
                inspectionId = viewModel.inspectionId.orEmpty(),
                title = "",
                notes = "",
                userCreated = viewModel.user.userId.orEmpty()
            )
        )
        addInfoNoteAdapter?.setData(addInfoNotes)
    }

    override fun onClickAddSignature(view: View) {
        addInfoSignatures.add(
            SubmitInspectionSignatureReqBody(
                inspectionId = viewModel.inspectionId.orEmpty(),
                title = "",
                name = "",
                signature = "",
                userCreated = viewModel.user.userId.orEmpty()
            )
        )
        addInfoSignatureAdapter?.setData(addInfoSignatures)
    }

    override fun onClickAddSave(view: View) {
        viewModel.listAdditionalInfoNotes = addInfoNotes.toMutableList()
        viewModel.listAdditionalInfoSignatures = addInfoSignatures.toMutableList()
        viewModel.postAdditionalInfoNote()
//        viewModel.postAdditionalInfoSignature()
    }
}