package com.pertamina.digitalaudit.presentation.map.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.databinding.ItemToolbarMenuBinding

/**
 * Created by M Hafidh Abdul Aziz on 13/03/21.
 */

class ToolbarMenuAdapter(private val menus: ArrayList<String>) :
    RecyclerView.Adapter<ToolbarMenuAdapter.ListViewHolder>() {

    private var selectedPosition: Int = 0
    private var listener: OnToolbarMenuInteractionListener? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(viewType, parent, false)
        return ListViewHolder(view)
    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        holder.listener = listener
        holder.selectedPosition = selectedPosition
        holder.bindData(menus[position])
    }

    override fun getItemCount(): Int = menus.size

    override fun getItemViewType(position: Int): Int {
        return R.layout.item_toolbar_menu
    }

    class ListViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        private var binding: ItemToolbarMenuBinding = DataBindingUtil.bind(view)!!
        var listener: OnToolbarMenuInteractionListener? = null
        var selectedPosition = 0

        fun bindData(data: String) {
            binding.apply {
                tvItemMenu.text = data
                toolbarItemMenuContainer.run {
                    setBackgroundResource(
                        if (selectedPosition == adapterPosition) R.drawable.bg_select_item_menu
                        else R.drawable.bg_unselect_item_menu
                    )
                }

                if (selectedPosition == adapterPosition) {
                    tvItemMenu.setTextColor(
                        ContextCompat.getColor(
                            root.context,
                            R.color.white
                        )
                    )
                } else {
                    tvItemMenu.setTextColor(
                        ContextCompat.getColor(
                            root.context,
                            R.color.black_700
                        )
                    )
                }
            }

            itemView.setOnClickListener {
                listener?.onMenuItemClicked(adapterPosition)
            }
        }
    }

    fun addData(list: List<String>) {
        menus.clear()
        menus.addAll(list)
    }

    fun setListener(listener: OnToolbarMenuInteractionListener?) {
        this.listener = listener
    }

    interface OnToolbarMenuInteractionListener {
        fun onMenuItemClicked(menuPosition: Int)
    }

    fun setSelectedMenuPosition(position: Int) {
        this.selectedPosition = position
        notifyDataSetChanged()
    }
}