package com.pertamina.digitalaudit.model

import com.google.gson.annotations.SerializedName
import com.pertamina.framework.base.BaseResponse
import java.io.Serializable

class PriorityModel : BaseResponse() {

    @SerializedName("Result")
    var data: List<Priority>? = null

    class Priority: Serializable {
        @SerializedName("PriorityId")
        var priorityId: Int? = 0

        @SerializedName("Name")
        var name: String? = ""

        /**
         * Pay attention here, you have to override the toString method as the
         * ArrayAdapter will reads the toString of the given object for the name
         *
         * @return name
         */
        override fun toString(): String {
            return name.orEmpty()
        }
    }
}