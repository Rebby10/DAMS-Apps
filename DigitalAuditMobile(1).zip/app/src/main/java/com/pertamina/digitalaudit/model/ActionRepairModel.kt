package com.pertamina.digitalaudit.model

import com.google.gson.annotations.SerializedName
import com.pertamina.framework.base.BaseResponse

class ActionRepairModel : BaseResponse() {

    @SerializedName("Result")
    var data: ActionRepair? = null

    class ActionRepair {
        @SerializedName("ActionRepairId")
        var actionRepairId: String? = ""

        @SerializedName("Action")
        var action: ActionModel.Action? = null

        @SerializedName("RootCause")
        var rootCause: String? = ""

        @SerializedName("RootCauseCategory")
        var rootCauseCategory: ActionRepairMasterDataModel.ActionRepairMasterData.ActionRepairCategory? =
            null

        @SerializedName("ActionRepair")
        var actionRepair: String? = ""

        @SerializedName("ActionRepairCategory")
        var actionRepairCategory: ActionRepairMasterDataModel.ActionRepairMasterData.ActionRepairCategory? =
            null

        @SerializedName("RepairDate")
        var repairDate: String? = ""

        @SerializedName("Filename")
        var filename: String? = ""
    }
}