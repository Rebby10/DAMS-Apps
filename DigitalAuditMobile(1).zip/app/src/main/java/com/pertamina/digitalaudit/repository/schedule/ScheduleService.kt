package com.pertamina.digitalaudit.repository.schedule

import com.pertamina.digitalaudit.model.*
import com.pertamina.digitalaudit.model.body.CreateScheduleReqBody
import com.pertamina.digitalaudit.model.body.RescheduleApprovalReqBody
import com.pertamina.digitalaudit.model.body.RescheduleReqBody
import com.pertamina.digitalaudit.model.body.UpdateScheduleReqBody
import retrofit2.http.*

interface ScheduleService {

    @GET("Schedule")
    suspend fun getScheduleList(): ScheduleModel

    @POST("Schedule")
    suspend fun createNewSchedule(@Body body: CreateScheduleReqBody): ScheduleModel.Schedule

    @GET("Schedule/{id}")
    suspend fun getScheduleDetail(@Path("id") scheduleId: String): ScheduleDetailModel

    @GET("Schedule/query")
    suspend fun getScheduleListWithQuery(
        @Query("id") id: String?,
        @Query("audit_type_id") auditTypeId: String?,
        @Query("audit_type") auditType: String?,
        @Query("status_id") statusId: Int?,
        @Query("status") status: Int?,
        @Query("audit_location_id") auditLocationId: String?,
        @Query("location_name") locationName: String?,
        @Query("region_id") regionId: Int?,
        @Query("region_name") regionName: Int?,
        @Query("page_size") pageSize: String?,
        @Query("page_number") pageNumber: String?,
        @Query("sort_by") sortBy: String?,
        @Query("order_by") orderBy: String?
    ): ScheduleModel

    @DELETE("Schedule/{id}")
    suspend fun deleteSchedule(@Path("id") scheduleId: String?): ScheduleModel

    @PUT("Schedule")
    suspend fun updateSchedule(@Body body: UpdateScheduleReqBody): ScheduleModel.Schedule

    @GET("Issue/auditee")
    suspend fun getAuditeeByName(@Query("name") name: String?): UserAssignModel

    @POST("Reschedule/RescheduleApproval")
    suspend fun confirmReschedule(@Body body: RescheduleApprovalReqBody): ScheduleModel.Schedule

    @POST("Reschedule")
    suspend fun reschedule(@Body body: RescheduleReqBody): ScheduleModel.Schedule


}
