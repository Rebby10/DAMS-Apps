package com.pertamina.digitalaudit.presentation.main

import android.view.View
import com.pertamina.framework.base.BaseView

interface MainView : BaseView {
    fun onClickAdd(view: View)
    fun onClickAddSchedule(view: View)
    fun onClickAddIssue(view: View)
    fun onClickAddInspection(view: View)
    fun onClickAddAction(view: View)
}
