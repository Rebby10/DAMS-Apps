package com.pertamina.digitalaudit.presentation.startinspection.additionalinfo

import androidx.lifecycle.MutableLiveData
import com.pertamina.digitalaudit.model.InspectionModel
import com.pertamina.digitalaudit.model.UserModel
import com.pertamina.digitalaudit.model.body.SubmitInspectionInfoReqBody
import com.pertamina.digitalaudit.model.body.SubmitInspectionSignatureReqBody
import com.pertamina.digitalaudit.model.startinspection.InspectionAddInfoResponse
import com.pertamina.digitalaudit.model.startinspection.InspectionInfo
import com.pertamina.digitalaudit.preference.PreferenceProvider
import com.pertamina.digitalaudit.repository.inspection.InspectionRepository
import com.pertamina.framework.base.BaseViewModel
import com.pertamina.framework.base.Resource
import kotlinx.coroutines.launch

class AdditionalInfoViewModel(
    private val inspectionRepository: InspectionRepository,
    private val preference: PreferenceProvider
) : BaseViewModel() {
    val showProgressBar = MutableLiveData(false)

    var listAdditionalInfoNotes = mutableListOf<SubmitInspectionInfoReqBody>()
    var listAdditionalInfoSignatures = mutableListOf<SubmitInspectionSignatureReqBody>()
    val additionalInfoNotesResponse = MutableLiveData<Resource<List<InspectionInfo>>>()
    val submitAdditionalInfoNotesResponse = MutableLiveData<Resource<InspectionAddInfoResponse>>()
    val additionalInfoSignaturesResponse = MutableLiveData<Resource<InspectionModel>>()
    val submitAdditionalInfoSignatureResponse = MutableLiveData<Resource<InspectionModel>>()

    var inspectionId: String? = null
    var user = UserModel.User()

    init {
        getUserData()
    }

    private fun getUserData() {
        user = preference.getAuthPreferences()
    }

    fun getAdditionalInfoNote() {
        showProgressBar.value = true
        launch {
            val request = inspectionRepository.getInspectionInfo(inspectionId.orEmpty())
            additionalInfoNotesResponse.value = request
            showProgressBar.value = false
        }
    }

    fun postAdditionalInfoNote() {
        showProgressBar.value = true
        listAdditionalInfoNotes.forEach { data ->
            launch {
                val request = inspectionRepository.submitInspectionInfo(data)
                submitAdditionalInfoNotesResponse.value = request
                showProgressBar.value = false
            }
        }
    }

    fun getAdditionalInfoSignature() {
        showProgressBar.value = true
        launch {
            val request = inspectionRepository.getInspectionSignature(inspectionId.orEmpty())
            additionalInfoSignaturesResponse.value = request
            showProgressBar.value = false
        }
    }

    fun postAdditionalInfoSignature() {
        showProgressBar.value = true
        listAdditionalInfoSignatures.forEach { data ->
            launch {
                val request = inspectionRepository.submitInspectionSignature(data)
                submitAdditionalInfoSignatureResponse.value = request
                showProgressBar.value = false
            }
        }
    }
}