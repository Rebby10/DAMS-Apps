package com.pertamina.digitalaudit.presentation.startinspection.actionpage

import android.view.View
import com.pertamina.framework.base.BaseView

interface ActionsView : BaseView {

    fun onClickAdd(view: View)
}
