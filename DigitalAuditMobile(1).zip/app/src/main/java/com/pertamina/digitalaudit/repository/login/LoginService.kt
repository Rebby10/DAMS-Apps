package com.pertamina.digitalaudit.repository.login

import com.pertamina.digitalaudit.model.TokenModel
import com.pertamina.digitalaudit.model.TokenRequestModel
import com.pertamina.digitalaudit.model.UserModel
import com.pertamina.digitalaudit.model.UserProfileModel
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

interface LoginService {

    @POST("Util/Token")
    suspend fun login(
        @Body tokenRequest: TokenRequestModel
    ): TokenModel

    @GET("Master/Idaman/User")
    suspend fun getUserData(
        @Query("email") email: String
    ): UserModel

}
