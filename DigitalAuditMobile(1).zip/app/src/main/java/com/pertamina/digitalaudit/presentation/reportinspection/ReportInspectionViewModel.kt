package com.pertamina.digitalaudit.presentation.reportinspection

import androidx.lifecycle.MutableLiveData
import com.pertamina.digitalaudit.model.IssueModel
import com.pertamina.digitalaudit.model.reportinspection.ReportChecklistResultResponse
import com.pertamina.digitalaudit.model.reportinspection.ReportOverviewResponse
import com.pertamina.digitalaudit.model.reportinspection.ReportSummaryResponse
import com.pertamina.digitalaudit.model.reportinspection.ReportTitlePageResponse
import com.pertamina.digitalaudit.model.startinspection.ImageFileInspection
import com.pertamina.digitalaudit.model.startinspection.InspectionInfo
import com.pertamina.digitalaudit.repository.inspection.InspectionRepository
import com.pertamina.digitalaudit.util.CommonConstant
import com.pertamina.framework.base.BaseViewModel
import com.pertamina.framework.base.Resource
import kotlinx.coroutines.launch
import okhttp3.ResponseBody

class ReportInspectionViewModel(
    private val inspectionRepository: InspectionRepository
) : BaseViewModel() {

    companion object {
        const val OVERVIEW = 0
        const val REPORT_SUMMARY = 1
        const val TITLE_PAGE = 2
        const val CHECKLIST_RESULT = 3
        const val FAILED_ITEMS = 4
        const val INFO = 5
    }

    val showProgressBar = MutableLiveData(false)
    val showOverview = MutableLiveData(false)
    val showReportSummary = MutableLiveData(false)
    val showTitlePage = MutableLiveData(false)
    val showCheckListResult = MutableLiveData(false)
    val showFailedItems = MutableLiveData(false)
    val showInfo = MutableLiveData(false)
    val showEmptyState = MutableLiveData(false)

    val reportOverviewResponse = MutableLiveData<Resource<ReportOverviewResponse>>()
    val reportSummaryResponse = MutableLiveData<Resource<ReportSummaryResponse>>()
    val titlePageResponse = MutableLiveData<Resource<ReportTitlePageResponse>>()
    val checklistResultResponse = MutableLiveData<Resource<ReportChecklistResultResponse>>()
    val failedItemsResponse = MutableLiveData<Resource<List<IssueModel.Issue>>>()
    val infoResponse = MutableLiveData<Resource<List<InspectionInfo>>>()
    val downloadFileResponse = MutableLiveData<Resource<ResponseBody>>()
    val imageFileResponse = MutableLiveData<Resource<ImageFileInspection>>()
    var failedItemList: MutableList<IssueModel.Issue>? = mutableListOf()
    var inspectionId: String? = null
    var selectedMenuTabId: Int = -1

    init {
        getInspectionReportOverview()
        setActiveTab(isShowOverview = true)
    }

    fun getInspectionReportOverview() {
        showProgressBar.value = true
        launch {
            val request = inspectionRepository.getInspectionReportOverview(inspectionId.orEmpty())
            reportOverviewResponse.value = request
            showProgressBar.value = false
        }
    }

    fun getInspectionReportSummary() {
        showProgressBar.value = true
        launch {
            val request = inspectionRepository.getInspectionReportSummary(inspectionId.orEmpty())
            reportSummaryResponse.value = request
            showProgressBar.value = false
        }
    }

    fun getInspectionReportTitlePage() {
        showProgressBar.value = true
        launch {
            val request = inspectionRepository.getInspectionReportTitlePage(inspectionId.orEmpty())
            titlePageResponse.value = request
            showProgressBar.value = false
        }
    }

    fun getInspectionReportChecklistResult() {
        showProgressBar.value = true
        launch {
            val request =
                inspectionRepository.getInspectionReportChecklistResult(inspectionId.orEmpty())
            checklistResultResponse.value = request
            showProgressBar.value = false
        }
    }

    fun getInspectionReportFailedItems() {
        showProgressBar.value = true
        launch {
            val request =
                inspectionRepository.getInspectionReportFailedItems(inspectionId.orEmpty())
            failedItemsResponse.value = request
            showProgressBar.value = false
        }
    }

    fun getInspectionReportInfo() {
        showProgressBar.value = true
        launch {
            val request = inspectionRepository.getInspectionReportInfo(inspectionId.orEmpty())
            infoResponse.value = request
            showProgressBar.value = false
        }
    }

    fun setActiveTab(
        isShowOverview: Boolean = false,
        isShowReportSummary: Boolean = false,
        isShowTitlePage: Boolean = false,
        isShowCheckListResult: Boolean = false,
        isShowFailedItems: Boolean = false,
        isShowInfo: Boolean = false,
        isShowEmptyState: Boolean = false
    ) {
        showOverview.value = isShowOverview
        showReportSummary.value = isShowReportSummary
        showTitlePage.value = isShowTitlePage
        showCheckListResult.value = isShowCheckListResult
        showFailedItems.value = isShowFailedItems
        showInfo.value = isShowInfo
        showEmptyState.value = isShowEmptyState
    }

    fun startDownloadFile(fileUrl: String) {
        showProgressBar.value = true
        launch {
            val request = inspectionRepository.downloadFile(fileUrl)
            downloadFileResponse.value = request
            showProgressBar.value = false
        }
    }

    fun getImagesByQuestionFromAPI(questionId: Int) {
        showProgressBar.value = true
        inspectionId?.let { inspectionId ->
            launch {
                val request =
                    inspectionRepository.getAllImageFile(
                        inspectionId,
                        questionId,
                        CommonConstant.IMAGE_FILE_TYPE
                    )
                imageFileResponse.value = request
                showProgressBar.value = false
            }
        }

    }
}
