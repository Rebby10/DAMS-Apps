package com.pertamina.digitalaudit.presentation.account

import android.app.AlertDialog
import android.app.PendingIntent
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Toast
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.CenterCrop
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.request.RequestOptions
import com.google.android.material.snackbar.Snackbar
import com.pertamina.digitalaudit.BuildConfig
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.databinding.FragmentAccountBinding
import com.pertamina.digitalaudit.preference.SharedPreferencesKey
import com.pertamina.digitalaudit.presentation.login.LoginActivity
import com.pertamina.digitalaudit.presentation.login.authmanager.AuthStateManager
import com.pertamina.digitalaudit.presentation.main.MainActivity
import com.pertamina.digitalaudit.presentation.notification.NotificationActivity
import com.pertamina.framework.ViewDataBindingOwner
import com.pertamina.framework.base.BaseFragment
import com.pertamina.framework.extensions.sharedGraphViewModel
import kotlinx.android.synthetic.main.fragment_account.*
import kotlinx.android.synthetic.main.toolbar_layout.*
import net.openid.appauth.*


/**
 * Created by M Hafidh Abdul Aziz on 11/03/21.
 */

class AccountFragment : BaseFragment<AccountViewModel>(), AccountView,
    ViewDataBindingOwner<FragmentAccountBinding> {

    override val layoutResourceId: Int = R.layout.fragment_account
    override val viewModel: AccountViewModel by sharedGraphViewModel(R.id.nav_graph_account)
    override var binding: FragmentAccountBinding? = null
    private val mStateManager = lazy {
        AuthStateManager.getInstance(requireContext())
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupToolbar()
        setupView()
        observeAccountData()
    }

    private fun observeAccountData() {
        observeData(viewModel.user) { user ->
            user?.let {
                var requestOptions = RequestOptions()
                requestOptions = requestOptions.transform(CenterCrop(), RoundedCorners(200))
                Glide.with(this).load(user.photoUrl)
                    .apply(requestOptions)
                    .into(ivPhotoProfile)
                viewModel.setDataToView()
            }
        }
    }

    private fun setupToolbar() {
        tvTitleToolbar.apply {
            text = getString(R.string.title_account_details)
            gravity = Gravity.START
        }
        menuAction3.apply {
            visibility = View.VISIBLE
            setImageResource(R.drawable.ic_notification)
            setOnClickListener {
                NotificationActivity.startThisActivity(requireContext())
            }
        }
    }

    private fun setupView() {
        (activity as MainActivity).closeFabMenu()
        (activity as MainActivity).manageFloatingButtonAdd(false)
    }

    override fun onClickLogout(view: View) {
        val alertDialog: AlertDialog? = activity?.let {
            val builder = AlertDialog.Builder(it)
            builder.apply {
                setPositiveButton(R.string.confirmation_yes) { dialog, _ ->
                    endSession()
                    dialog.dismiss()
                }
                setNegativeButton(R.string.confirmation_no) { dialog, _ ->
                    dialog.dismiss()
                }
            }
            builder.setMessage(R.string.confirmation_message)
            builder.create()
        }
        alertDialog?.show()
    }

    private fun getServiceConfig(): AuthorizationServiceConfiguration{
        val ISSUER = BuildConfig.IDAMAN_ISSUER
        return AuthorizationServiceConfiguration(
                Uri.parse("${ISSUER}/connect/authorize"), // authorization endpoint
                Uri.parse("${ISSUER}/connect/token"), // token endpoint
                Uri.parse(""),
                Uri.parse("https://login.dev.idaman.pertamina.com/connect/endsession")
        )
    }

    private fun endSession() {
        val idToken = viewModel.preference.getStringFromPreference(SharedPreferencesKey.ID_TOKEN)
        val endSessionRequest = EndSessionRequest.Builder(getServiceConfig())
                .setIdTokenHint(idToken)
                .setPostLogoutRedirectUri(Uri.parse("com.auditaviasi.appauth:/endsession"))
                .build()

        val authService = context?.let { AuthorizationService(it) }
        val endSessionItent: Intent = authService?.getEndSessionRequestIntent(endSessionRequest)!!
        startActivityForResult(endSessionItent, RC_END_SESSION)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == RC_END_SESSION) {
            mStateManager.value.endSession()
            viewModel.preference.clearPreferences()
            logout(Intent(context, LoginActivity::class.java))
        }
    }

    private val RC_END_SESSION = 200
}
