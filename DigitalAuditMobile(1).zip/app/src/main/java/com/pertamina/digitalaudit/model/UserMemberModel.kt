package com.pertamina.digitalaudit.model

import com.google.gson.annotations.SerializedName

class UserMemberModel {
    @SerializedName("Result")
    var data: UserMember? = null

    class UserMember {

        @SerializedName("UserMemberId")
        var userMemberId: String? = ""

        @SerializedName("UserGroup")
        var userGroup: String? = ""

        @SerializedName("UserId")
        var userId: String? = ""

        @SerializedName("Username")
        var username: String? = ""

        @SerializedName("OfficialName")
        var officialName: String? = ""
    }
}
