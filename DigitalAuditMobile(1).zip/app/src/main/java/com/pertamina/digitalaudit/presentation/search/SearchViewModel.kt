package com.pertamina.digitalaudit.presentation.search

import androidx.lifecycle.MutableLiveData
import com.pertamina.digitalaudit.model.*
import com.pertamina.digitalaudit.model.body.SortAndFilterReqBody
import com.pertamina.digitalaudit.model.query.GetLocationQuery
import com.pertamina.digitalaudit.model.query.GetRegionQuery
import com.pertamina.digitalaudit.model.query.GetTemplateQuery
import com.pertamina.digitalaudit.preference.PreferenceProvider
import com.pertamina.digitalaudit.repository.actions.ActionsRepository
import com.pertamina.digitalaudit.repository.common.CommonRepository
import com.pertamina.digitalaudit.repository.issues.IssuesRepository
import com.pertamina.framework.base.BaseViewModel
import com.pertamina.framework.base.Resource
import kotlinx.coroutines.launch

class SearchViewModel(
    private val issuesRepository: IssuesRepository,
    private val actionsRepository: ActionsRepository,
    private val commonRepository: CommonRepository,
    val preference: PreferenceProvider
) : BaseViewModel() {

    companion object {
        const val PAGE_SIZE = 40
    }

    var showEmptyState = MutableLiveData(false)
    val showProgressBar = MutableLiveData(false)

    var bTextSearch = MutableLiveData("")

    val userAssignResponse = MutableLiveData<Resource<List<UserAssignModel.UserAssign>>>()
    val issueListResponse = MutableLiveData<Resource<List<IssueModel.Issue>>>()
    val locationListResponse = MutableLiveData<Resource<List<LocationModel.Location>>>()
    val templateListResponse = MutableLiveData<Resource<List<TemplateModel.Template>>>()
    val regionListResponse = MutableLiveData<Resource<List<RegionModel.Region>>>()

    var fromIssue: Boolean = false
    var fromAction: Boolean = false
    var isSearchUser: Boolean = false
    var isSearchIssue: Boolean = false
    var isSearchLocation: Boolean = false
    var isSearchTemplate: Boolean = false
    var isSearchRegion: Boolean = false
    var hasMoreData: Boolean = true
    var isLoadMore: Boolean = false
    var pageNumber: Int = 1

    var user = UserModel.User()

    fun getUserData() {
        user = preference.getAuthPreferences()
    }

    fun loadIssue(queryName: String?) {
        if (!hasMoreData) {
            return
        }
        val reqBody = SortAndFilterReqBody()
        reqBody.title = queryName
        reqBody.userCreated = user.userId
        reqBody.pageSize = PAGE_SIZE
        reqBody.pageNumber = pageNumber
        showProgressBar.value = true
        launch {
            val request = issuesRepository.applyFilter(reqBody)
            issueListResponse.value = request
            showProgressBar.value = false
        }
    }

    fun loadLocation(queryName: String?) {
        if (!hasMoreData) {
            return
        }
        val reqBody = GetLocationQuery()
        reqBody.name = queryName
        reqBody.pageSize = PAGE_SIZE
        reqBody.pageNumber = pageNumber
        showProgressBar.value = true
        launch {
            val request = commonRepository.getLocation(reqBody)
            locationListResponse.value = request
            showProgressBar.value = false
        }
    }

    fun loadTemplate(queryName: String?) {
        if (!hasMoreData) {
            return
        }
        val reqBody = GetTemplateQuery()
        reqBody.title = queryName
        reqBody.pageSize = PAGE_SIZE
        reqBody.pageNumber = pageNumber
        showProgressBar.value = true
        launch {
            val request = commonRepository.getTemplate(reqBody)
            templateListResponse.value = request
            showProgressBar.value = false
        }
    }

    fun loadUser(queryName: String?) {
        if (!hasMoreData) {
            return
        }
        if (fromIssue) {
            getIssueAuditeeByName(queryName)
        } else if (fromAction) {
            getActionAssigneeByName(queryName)
        }
    }

    fun loadRegion(queryName: String?) {
        if (!hasMoreData) {
            return
        }
        val reqBody = GetRegionQuery()
        reqBody.name = queryName
        reqBody.pageSize = PAGE_SIZE
        reqBody.pageNumber = pageNumber
        showProgressBar.value = true
        launch {
            val request = commonRepository.getRegionMasterData(reqBody)
            regionListResponse.value = request
            showProgressBar.value = false
        }
    }

    private fun getIssueAuditeeByName(queryName: String?) {
        showProgressBar.value = true
        launch {
            val request = issuesRepository.getAuditeeByName(queryName, PAGE_SIZE, pageNumber)
            userAssignResponse.value = request
            showProgressBar.value = false
        }
    }

    private fun getActionAssigneeByName(queryName: String?) {
        showProgressBar.value = true
        launch {
            val request = actionsRepository.getAssigneeByName(queryName, PAGE_SIZE, pageNumber)
            userAssignResponse.value = request
            showProgressBar.value = false
        }
    }
}
