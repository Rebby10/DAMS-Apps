package com.pertamina.digitalaudit.model

import com.google.gson.annotations.SerializedName
import com.pertamina.framework.base.BaseResponse

class UserProfileModel : BaseResponse() {
    @SerializedName("sub")
    var sub: String? = ""

    @SerializedName("preferred_username")
    var username: String? = ""

    @SerializedName("name")
    var name: String? = ""

    @SerializedName("email")
    var email: String? = "-"

    @SerializedName("email_verified")
    var email_verified: Boolean = false

    @SerializedName("idp")
    var idp: String? = ""

    @SerializedName("display_name")
    var displayName: String? = "-"

    @SerializedName("state")
    var state: String? = "-"

    @SerializedName("employee_id")
    var employeeId: String? = "-"

    @SerializedName("company_code")
    var companyCode: String? = "-"

}
