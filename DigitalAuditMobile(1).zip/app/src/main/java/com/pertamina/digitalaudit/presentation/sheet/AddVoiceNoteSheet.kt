package com.pertamina.digitalaudit.presentation.sheet

import android.Manifest
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SeekBar
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.pertamina.audiorecorder.AudioRecordListener
import com.pertamina.audiorecorder.MediaPlayListener
import com.pertamina.audiorecorder.Player
import com.pertamina.audiorecorder.Recorder
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.model.VoiceNoteModel
import com.pertamina.digitalaudit.presentation.sheet.adapter.VoiceNoteAdapter
import com.pertamina.digitalaudit.util.CommonConstant
import kotlinx.android.synthetic.main.sheet_add_record.*
import pub.devrel.easypermissions.AfterPermissionGranted
import pub.devrel.easypermissions.EasyPermissions
import java.io.File

class AddVoiceNoteSheet : BottomSheetDialogFragment(), AudioRecordListener, MediaPlayListener {

    lateinit var recorder: Recorder
    private var player: Player? = null
    var listener: AddRecordSheetListener? = null
    private var isRecording: Boolean = false
    private var voiceNoteAdapter: VoiceNoteAdapter = VoiceNoteAdapter()
    private var audioUriList = mutableListOf<VoiceNoteModel>()
    private var audioFiles = mutableListOf<File>()
    private var handler = Handler(Looper.getMainLooper())
    private var selectedUriAudio : String? = null
    private var vSeekBar: SeekBar? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.sheet_add_record, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val llManager = LinearLayoutManager(requireContext())
        super.onViewCreated(view, savedInstanceState)

        val intent = arguments?.getStringArrayList("EXISTING_VOICE")?.toMutableList()
        intent?.let{
            it.forEach {  stringUri ->
                val voiceNoteModel = VoiceNoteModel(stringUri, false)
                audioUriList.add(voiceNoteModel)
            }
        }
        vStartStopRecording.setOnClickListener {
            requestPermissionRecordAudio()
        }
        rvVoicePlayer.apply {
            layoutManager = llManager
            setHasFixedSize(true)
            adapter = voiceNoteAdapter
        }

        if (audioUriList.size > 0) voiceNoteAdapter.setData(audioUriList)
        voiceNoteAdapter.setItemClickListener(object :
            VoiceNoteAdapter.ItemClickListener {
            override fun onClickPlayPause(data: VoiceNoteModel, seekBar: SeekBar) {
                vSeekBar = seekBar
                if (selectedUriAudio == data.audioUri) {
                    playRecorder()
                } else {
                    player?.reset()
                    player = Player(this@AddVoiceNoteSheet)
                    Log.d("startpage", "play:${data.audioUri}")
                    player?.injectMedia(data.audioUri)
                    seekBar.max = player?.player!!.duration
                    playRecorder()
                }
                updateAudioUriList(data)
            }

            override fun onClickDelete(data: VoiceNoteModel) {
                audioUriList.remove(data)
                voiceNoteAdapter.setData(audioUriList)
            }
        })
        setEvent()
    }

    @AfterPermissionGranted(CommonConstant.RC_RECORD_AUDIO_PERM)
    private fun requestPermissionRecordAudio() {
        val perms = arrayOf(Manifest.permission.RECORD_AUDIO)
        if (EasyPermissions.hasPermissions(requireContext(), *perms)) {
            setStartStopRecordingView()
            if (!isRecording) startRecording()
            else stopRecording()
        } else {
            EasyPermissions.requestPermissions(
                this,
                getString(R.string.permission_to_record_audio),
                CommonConstant.RC_RECORD_AUDIO_PERM,
                *perms
            )
        }
    }

    private fun updateAudioUriList(data: VoiceNoteModel){
        val iterator: MutableListIterator<VoiceNoteModel> = audioUriList.listIterator()
        while (iterator.hasNext()) {
            val next = iterator.next()
            if (next.audioUri == data.audioUri) {
                next.isPlaying = !data.isPlaying
            } else {
                next.isPlaying = false
            }
            iterator.set(next)
        }
        voiceNoteAdapter.setData(audioUriList)
        selectedUriAudio = data.audioUri
    }

    private fun startRecording(){
        recorder = Recorder(requireContext(), this)
        recorder.startRecord()
        isRecording = true
        vRecordTime.base = SystemClock.elapsedRealtime()
        vRecordTime.stop()
        vRecordTime.start()
    }

    private fun stopRecording(){
        recorder.stopRecording()
        isRecording = false
        vRecordTime.stop()
    }

    private fun setEvent() {
        btnCancel.setOnClickListener {
            dismiss()
        }
        btnSave.setOnClickListener {
            if (!isRecording){
                audioUriList.forEach {
                    audioFiles.add(File(it.audioUri))
                }
                val uriList = audioUriList.map { it.audioUri }
                listener?.onSave(uriList, audioFiles)
                dismiss()
            } else {
                Toast.makeText(requireContext(), "In progress recording, please stop the recorder before saving", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setStartStopRecordingView() {
        vStartStopRecording.setBackgroundResource(if (!isRecording) R.drawable.bg_circle_red else R.drawable.bg_circle_blue)
        ivRecord.setImageResource(if (!isRecording) R.drawable.ic_stop else R.drawable.ic_record)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this)
    }

    override fun onAudioReady(audioUri: String?) {
        audioUri?.let{
            audioUriList.add(VoiceNoteModel(audioUri))
            voiceNoteAdapter.setData(audioUriList)
            isRecording = false
        }
    }

    override fun onRecordFailed(errorMessage: String?) {
        //not implemented
    }

    override fun onReadyForRecord() {
        //not implemented
    }

    interface AddRecordSheetListener {
        fun onSave(dataUri: List<String>, dataFile: List<File>)
    }

    override fun onStartMedia() {
        //not implemented
    }

    override fun onMediaCompleted() {
        val iterator: MutableListIterator<VoiceNoteModel> = audioUriList.listIterator()
        while (iterator.hasNext()) {
            val next = iterator.next()
            if (next.audioUri == selectedUriAudio) {
                next.isPlaying = false
            }
            iterator.set(next)
        }
        voiceNoteAdapter.setData(audioUriList)
    }

    private fun playRecorder() {
        if (player?.player!!.isPlaying)
            player?.stopPlaying()
        else {
            player?.startPlaying()
            handler.postDelayed(runnable(), 1000)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isRecording) stopRecording()
        handler.removeCallbacksAndMessages(null)
        player?.stopPlaying()
    }

    private fun runnable(): Runnable{
        return object : Runnable {
            override fun run() {
                try {
                    val position = player?.player!!.currentPosition
                    vSeekBar?.progress = position
                    handler.postDelayed(this, 1000)
                } catch (ed: IllegalStateException) {
                    ed.printStackTrace()
                }
            }
        }
    }
}