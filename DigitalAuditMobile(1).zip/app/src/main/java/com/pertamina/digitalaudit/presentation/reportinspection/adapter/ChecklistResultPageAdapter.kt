package com.pertamina.digitalaudit.presentation.reportinspection.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.animation.RotateAnimation
import androidx.recyclerview.widget.LinearLayoutManager
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.model.reportinspection.ReportChecklistResult
import com.pertamina.framework.base.BaseRecyclerViewAdapter
import com.pertamina.framework.base.BaseViewHolder
import kotlinx.android.synthetic.main.item_report_check_list_result.view.*

class ChecklistResultPageAdapter : BaseRecyclerViewAdapter<ReportChecklistResult>() {

    private var listener: ItemClickListener? = null

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BaseViewHolder<ReportChecklistResult> {
        val view = LayoutInflater.from(parent.context).inflate(viewType, parent, false)
        return ListViewHolder(parent.context, view, listener)
    }

    override fun onBindViewHolder(
        holder: BaseViewHolder<ReportChecklistResult>,
        position: Int
    ) {
        holder.bindData(getItem(position))
    }

    override fun getItemViewType(position: Int): Int {
        return R.layout.item_report_check_list_result
    }

    class ListViewHolder(context: Context, val view: View, listener: ItemClickListener?) :
        BaseViewHolder<ReportChecklistResult>(context, view) {

        private var holderListener: ItemClickListener? = listener
        private var tvPageNumber = view.tvPageNumber
        private var ivArrowRight = view.ivArrowRight
        private var rvCheckListResult = view.rvCheckListResult

        override fun bindData(data: ReportChecklistResult) {
            tvPageNumber.text = data.title
            itemView.setOnClickListener {
                rotateSectionArrow(rvCheckListResult.visibility == View.GONE)
                rvCheckListResult.visibility =
                    if (rvCheckListResult.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            }

            val llManager = LinearLayoutManager(context)
            val checklistResultSectionAdapter = ChecklistResultSectionAdapter()
            checklistResultSectionAdapter.setItemClickListener(object :
                ChecklistResultSectionAdapter.ItemClickListener {
                override fun onClickAttachment(questionId: String) {
                    holderListener?.onClickAttachment(questionId)
                }

                override fun onClickVoiceNote(questionId: String) {
                    holderListener?.onClickVoiceNote(questionId)
                }

                override fun onClickActions(questionId: String) {
                    holderListener?.onClickActions(questionId)
                }
            })
            rvCheckListResult.apply {
                layoutManager = llManager
                setHasFixedSize(true)
                adapter = checklistResultSectionAdapter
            }
            checklistResultSectionAdapter.setData(data.section ?: mutableListOf())

            rvCheckListResult.visibility =
                if (data.section?.isNotEmpty() == true && adapterPosition == 0) View.VISIBLE else View.GONE
            rotateSectionArrow(data.section?.isNotEmpty() == true && adapterPosition == 0)
        }

        private fun rotateSectionArrow(isShow: Boolean) {
            val anim = if (isShow) {
                RotateAnimation(
                    0F,
                    180F,
                    Animation.RELATIVE_TO_SELF,
                    0.5f,
                    Animation.RELATIVE_TO_SELF,
                    0.5f
                )
            } else {
                RotateAnimation(
                    180F,
                    0F,
                    Animation.RELATIVE_TO_SELF,
                    0.5f,
                    Animation.RELATIVE_TO_SELF,
                    0.5f
                )
            }
            anim.fillAfter = true
            ivArrowRight.startAnimation(anim)
        }
    }

    fun setItemClickListener(listener: ItemClickListener) {
        this.listener = listener
    }

    interface ItemClickListener {
        fun onClickAttachment(questionId: String)
        fun onClickVoiceNote(questionId: String)
        fun onClickActions(questionId: String)
    }
}