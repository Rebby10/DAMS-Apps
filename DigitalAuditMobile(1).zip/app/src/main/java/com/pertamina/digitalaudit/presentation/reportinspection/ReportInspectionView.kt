package com.pertamina.digitalaudit.presentation.reportinspection

import android.view.View
import com.pertamina.framework.base.BaseView

interface ReportInspectionView : BaseView {
    fun onClickDownloadPdf(view: View)
    fun onClickDownloadWord(view: View)
}
