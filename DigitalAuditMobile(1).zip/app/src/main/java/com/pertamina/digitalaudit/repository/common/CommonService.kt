package com.pertamina.digitalaudit.repository.common

import com.pertamina.digitalaudit.model.ActionRepairMasterDataModel
import com.pertamina.digitalaudit.model.AuditTypeModel
import com.pertamina.digitalaudit.model.FAQMasterDataModel
import com.pertamina.digitalaudit.model.HomeOverviewModel
import com.pertamina.digitalaudit.model.InspectionModel
import com.pertamina.digitalaudit.model.IssueModel
import com.pertamina.digitalaudit.model.LocationModel
import com.pertamina.digitalaudit.model.PriorityModel
import com.pertamina.digitalaudit.model.RegionModel
import com.pertamina.digitalaudit.model.RescheduleModel
import com.pertamina.digitalaudit.model.ScheduleModel
import com.pertamina.digitalaudit.model.TemplateModel
import retrofit2.http.GET
import retrofit2.http.Query

interface CommonService {

    @GET("Master/Audit/Location/query")
    suspend fun getLocationList(
        @Query("name") name: String?,
        @Query("page_size") pageSize: Int?,
        @Query("page_number") pageNumber: Int?
    ): LocationModel

    @GET("Master/Priority")
    suspend fun getPriorityList(): PriorityModel

    @GET("Master/Audit/Type")
    suspend fun getAuditTypeList(): AuditTypeModel

    @GET("Master/Template/query")
    suspend fun getTemplateList(
        @Query("title") title: String?,
        @Query("page_size") pageSize: Int?,
        @Query("page_number") pageNumber: Int?,
    ): TemplateModel

    @GET("Inspection/query")
    suspend fun getHomeInspectionList(
        @Query("UserCreated") userCreated: String?,
        @Query("Text") text: String?,
        @Query("page_size") pageSize: Int?,
        @Query("page_number") pageNumber: Int?,
        @Query("sort_by") SortBy: String?,
        @Query("order_by") OrderBy: String?
    ): InspectionModel

    @GET("Issue/query")
    suspend fun getHomeIssueList(
        @Query("UserCreated") userCreated: String?,
        @Query("AssignUser") assignUser: String?,
        @Query("Title") title: String?,
        @Query("page_size") pageSize: Int?,
        @Query("page_number") pageNumber: Int?,
        @Query("sort_by") SortBy: String?,
        @Query("order_by") OrderBy: String?
    ): IssueModel

    @GET("Schedule/query")
    suspend fun getHomeScheduleList(
        @Query("UserId") userId: String?,
        @Query("title") title: String?,
        @Query("page_size") pageSize: Int?,
        @Query("page_number") pageNumber: Int?,
        @Query("sort_by") SortBy: String?,
        @Query("order_by") OrderBy: String?
    ): ScheduleModel

    @GET("Reschedule/query")
    suspend fun getHomeRescheduleList(
        @Query("UserId") userId: String?,
        @Query("title") title: String?,
        @Query("sort_by") SortBy: String?,
        @Query("order_by") OrderBy: String?
    ): RescheduleModel

    @GET("Home/Overview/Search")
    suspend fun getHomeOverview(
        @Query("user_id") userId: String?,
        @Query("role_id") roleId: String?,
        @Query("search") search: String?,
        @Query("page_size") pageSize: Int?,
        @Query("page_number") pageNumber: Int?,
        @Query("sort_by") sortBy: String?,
        @Query("order_by") orderBy: String?
    ): HomeOverviewModel

    @GET("Master")
    suspend fun getActionRepairMasterData(): ActionRepairMasterDataModel

    @GET("Master/Region/query")
    suspend fun getRegionMasterData(
        @Query("name") name: String?,
        @Query("page_size") pageSize: Int?,
        @Query("page_number") pageNumber: Int?
    ): RegionModel

    @GET("Master/FAQ")
    suspend fun getFAQMasterData(): FAQMasterDataModel
}
