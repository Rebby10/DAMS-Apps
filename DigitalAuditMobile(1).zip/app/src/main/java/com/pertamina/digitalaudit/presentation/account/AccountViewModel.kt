package com.pertamina.digitalaudit.presentation.account

import androidx.lifecycle.MutableLiveData
import com.pertamina.digitalaudit.model.UserModel
import com.pertamina.digitalaudit.preference.PreferenceProvider
import com.pertamina.framework.base.BaseViewModel
import kotlinx.coroutines.launch

/**
 * Created by M Hafidh Abdul Aziz on 03/03/21.
 */

class AccountViewModel(val preference: PreferenceProvider) : BaseViewModel() {

    val showProgressBar = MutableLiveData(false)

    var bTextUserName = MutableLiveData("")
    var bTextUserEmail = MutableLiveData("")
    var bTextUserLocation = MutableLiveData("")
    var bTextUserCompany = MutableLiveData("")
    var bTextUserJobTitle = MutableLiveData("")
    var bTextUserDepartment = MutableLiveData("")

    val user = MutableLiveData<UserModel.User>()

    init {
        getUserData()
    }

    private fun getUserData() {
        showProgressBar.value = true
        launch {
            val request = preference.getAuthPreferences()
            user.value = request
            showProgressBar.value = false
        }
    }

    fun setDataToView() {
        bTextUserName.value = user.value?.name
        bTextUserEmail.value = user.value?.email
        bTextUserLocation.value = user.value?.officeLocation
        bTextUserCompany.value = user.value?.companyName
        bTextUserJobTitle.value = user.value?.jobTitle
        bTextUserDepartment.value = user.value?.department
    }
}
