package com.pertamina.digitalaudit.presentation.actionrepair

import android.text.TextWatcher
import android.view.View
import com.pertamina.framework.base.BaseView

interface ActionRepairView : BaseView {
    fun onClickChooseFile(view: View)
    fun onClickSaveActionRepair(view: View)

    var bTextWatcherRepairCause: TextWatcher
    var bTextWatcherActionRepair: TextWatcher
}
