package com.pertamina.digitalaudit.repository.inspection

import com.pertamina.digitalaudit.model.InspectionModel
import com.pertamina.digitalaudit.model.IssueModel
import com.pertamina.digitalaudit.model.body.CreateInspectionReqBody
import com.pertamina.digitalaudit.model.body.InspectionResultReqBody
import com.pertamina.digitalaudit.model.body.SubmitInspectionInfoReqBody
import com.pertamina.digitalaudit.model.body.SubmitInspectionSignatureReqBody
import com.pertamina.digitalaudit.model.reportinspection.ReportChecklistResultResponse
import com.pertamina.digitalaudit.model.reportinspection.ReportOverviewResponse
import com.pertamina.digitalaudit.model.reportinspection.ReportSummaryResponse
import com.pertamina.digitalaudit.model.reportinspection.ReportTitlePageResponse
import com.pertamina.digitalaudit.model.startinspection.*
import com.pertamina.framework.base.BaseResponse
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.Path
import retrofit2.http.Query
import retrofit2.http.Url


interface InspectionService {

    @GET("Inspection/query")
    suspend fun getInspectionList(
        @Query("UserTypeId") UserTypeId: Int?,
        @Query("Text") Text: String?,
        @Query("StatusId") StatusId: Int?,
        @Query("RegionId") RegionId: String?,
        @Query("AuditLocationId") AuditLocationId: String?,
        @Query("UserCreated") UserCreated: String?,
        @Query("page_size") PageSize: Int?,
        @Query("page_number") PageNumber: Int?,
        @Query("sort_by") SortBy: String?,
        @Query("order_by") OrderBy: String?
    ): InspectionModel

    @POST("Inspection")
    suspend fun createNewInspection(@Body body: CreateInspectionReqBody): InspectionModel.Inspection

    @GET("Inspection/Start/{InspectionId}")
    suspend fun startInspection(@Path("InspectionId") inspectionId: String?): StartInspectionResponseModel

    @GET("Inspection/Issue/{InspectionId}")
    suspend fun startInspectionIssue(@Path("InspectionId") inspectionId: String?): IssueModel

    @GET("Inspection/Page/{InspectionId}/{PageId}")
    suspend fun startInspectionPage(
        @Path("InspectionId") inspectionId: String?,
        @Path("PageId") pageId: String?
    ): InspectionPageResponse

    @GET("Inspection/Page/List/{InspectionId}")
    suspend fun startInspectionPageList(@Path("InspectionId") inspectionId: String?): ListInspectionPage

    @GET("Inspection/File/query")
    suspend fun getInspectionFile(
        @Query("InspectionId") InspectionId: String?,
        @Query("QuestionId") QuestionId: Int?,
        @Query("FileTypeId") FileTypeId: Int?,
        @Query("page_size") PageSize: Int?,
        @Query("page_number") PageNumber: Int?,
        @Query("sort_by") SortBy: String?,
        @Query("order_by") OrderBy: String?
    ): InspectionModel

    @POST("Inspection/File")
    @Multipart
    suspend fun uploadInspectionFile(
        @Part("InspectionId") inspectionId: RequestBody,
        @Part("QuestionId") questionId: RequestBody,
        @Part file: Array<MultipartBody.Part?>,
        @Part("FileTypeId") fileTypeId: RequestBody,
        @Part("UserCreated") userCreated: RequestBody,
    ): BaseResponse

    @DELETE("Inspection/File/{FileId}")
    suspend fun deleteInspectionFile(@Path("FileId") fileId: String?): InspectionModel

    @POST("Inspection/Info")
    suspend fun submitInspectionInfo(@Body body: SubmitInspectionInfoReqBody): InspectionAddInfoResponse

    @GET("Inspection/Info/{InspectionId}")
    suspend fun getInspectionInfo(@Path("InspectionId") inspectionId: String?): InspectionInfoResponse

    @GET("Inspection/Signature/{InspectionId}")
    suspend fun getInspectionSignature(@Path("InspectionId") inspectionId: String?): InspectionModel

    @POST("Inspection/Signature")
    suspend fun submitInspectionSignature(@Body body: SubmitInspectionSignatureReqBody): InspectionModel

    @DELETE("Inspection/Signature/{SignatureId}")
    suspend fun deleteInspectionSignature(@Path("SignatureId") signatureId: String?): InspectionModel

    @POST("Inspection/Result")
    suspend fun sendInspectionResult(@Body body: InspectionResultReqBody): AnswerInspectionResultResponse

    @POST("Inspection/Completed/{InspectionId}")
    suspend fun completeInspection(@Path("InspectionId") inspectionId: String?): InspectionCompletedResponse

    @GET
    suspend fun downloadFile(@Url fileUrl: String): ResponseBody

    @GET("Report/Inspection/Overview/{InspectionId}")
    suspend fun getInspectionReportOverview(@Path("InspectionId") inspectionId: String?): ReportOverviewResponse

    @GET("Inspection/File/query")
    suspend fun getAllImageFile(@Query("InspectionId") inspectionId: String,
                                @Query("QuestionId") questionId: Int,
                                @Query("FileTypeId") FileTypeId : Int = 1): ImageFileInspection

    @GET("Report/Inspection/Summary/{InspectionId}")
    suspend fun getInspectionReportSummary(@Path("InspectionId") inspectionId: String?): ReportSummaryResponse

    @GET("Report/Inspection/TitlePage/{InspectionId}")
    suspend fun getInspectionReportTitlePage(@Path("InspectionId") inspectionId: String?): ReportTitlePageResponse

    @GET("Report/Inspection/Result/{InspectionId}")
    suspend fun getInspectionReportChecklistResult(@Path("InspectionId") inspectionId: String?): ReportChecklistResultResponse

    @GET("Report/Inspection/Failed/{InspectionId}")
    suspend fun getInspectionReportFailedItems(@Path("InspectionId") inspectionId: String?): IssueModel

    @GET("Report/Inspection/Info/{InspectionId}")
    suspend fun getInspectionReportInfo(@Path("InspectionId") inspectionId: String?): InspectionInfoResponse

    @GET("/Report/Inspection/Download/pdf/{InspectionId}")
    suspend fun downloadInspectionReportPdf(@Path("InspectionId") inspectionId: String?): ResponseBody

    @GET("/Report/Inspection/Download/word/{InspectionId}")
    suspend fun downloadInspectionReportWord(@Path("InspectionId") inspectionId: String?): ResponseBody

}
