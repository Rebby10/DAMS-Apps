package com.pertamina.digitalaudit.repository.issues

import com.pertamina.digitalaudit.model.*
import com.pertamina.digitalaudit.model.body.CreateIssueReqBody
import com.pertamina.digitalaudit.model.body.UpdateIssueReqBody
import com.pertamina.framework.base.BaseResponse
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.http.*

interface IssuesService {

    @GET("Issue")
    suspend fun getIssueList(): IssueModel

    @POST("Issue")
    suspend fun createNewIssue(@Body body: CreateIssueReqBody): IssueModel

    @GET("Issue/{id}")
    suspend fun getIssueDetail(@Path("id") issueId: String): IssueDetailModel

    @GET("Issue/query")
    suspend fun applyFilter(
        @Query("IssueId") issueId: String?,
        @Query("Title") title: String?,
        @Query("AuditLocationId") AuditLocationId: String?,
        @Query("PriorityId") PriorityId: Int?,
        @Query("StatusId") StatusId: Int?,
        @Query("UserCreated") UserCreated: String?,
        @Query("AssignUser") AssignUser: String?,
        @Query("StartDate") StartDate: String?,
        @Query("EndDate") EndDate: String?,
        @Query("AuditTypeId") AuditTypeId: String?,
        @Query("page_size") PageSize: Int?,
        @Query("page_number") PageNumber: Int?,
        @Query("sort_by") SortBy: String?,
        @Query("order_by") OrderBy: String?,
        @Query("IsConnectedToAction") IsConnectedToAction: Boolean?
    ): IssueModel

    @GET("Issue/Log/query")
    suspend fun getIssueLog(
        @Query("IssueId") issueId: String?,
        @Query("LastDate") lastDate: String?
    ): LogModel

    @FormUrlEncoded
    @POST("Issue/Log")
    suspend fun sendIssueLog(
        @Field("IssueId") issueId: String,
        @Field("text") text: String?,
        @Field("UserCreated") UserCreated: String
    ): BaseResponse

    @GET("Master/Issue/Category")
    suspend fun getIssueCategoryList(): IssueCategoryModel

    @GET("Master/Issue/Status")
    suspend fun getIssueStatusList(): IssueStatusModel

    @DELETE("Issue/{id}")
    suspend fun deleteIssue(@Path("id") issueId: String?): IssueModel

    @PUT("Issue")
    suspend fun updateIssue(@Body body: UpdateIssueReqBody): IssueModel

    @GET("Issue/auditee")
    suspend fun getAuditeeByName(
        @Query("name") name: String?,
        @Query("page_size") pageSize: Int?,
        @Query("page_number") pageNumber: Int?
    ): UserAssignModel

    @POST("Issue/Log")
    @Multipart
    suspend fun sendLogChatFile(
        @Part("IssueId") issueId: RequestBody,
        @Part("UserCreated") userCreated: RequestBody,
        @Part file: MultipartBody.Part
    ): BaseResponse

    @GET
    suspend fun downloadFile(@Url fileUrl: String): ResponseBody
}
