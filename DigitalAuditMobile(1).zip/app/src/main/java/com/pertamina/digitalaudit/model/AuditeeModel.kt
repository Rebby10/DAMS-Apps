package com.pertamina.digitalaudit.model

import com.google.gson.annotations.SerializedName
import com.pertamina.framework.base.BaseResponse

class AuditeeModel : BaseResponse() {

    @SerializedName("Result")
    var data: List<Auditee>? = null

    class Auditee {

        @SerializedName("PicId")
        var picId: String? = ""

        @SerializedName("ScheduleId")
        var scheduleId: String? = ""

        @SerializedName("Users")
        var users: UserModel.User? = null

        @SerializedName("Groups")
        var groups: GroupsModel.Groups? = null

        @SerializedName("UserTye")
        var userType: AssignGroupModel.UserType? = null

        @SerializedName("Status")
        var status: StatusModel.Status? = null
    }
}
