package com.pertamina.digitalaudit.presentation.createissue

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.activity.result.contract.ActivityResultContracts
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.databinding.ActivityCreateIssueBinding
import com.pertamina.digitalaudit.model.IssueCategoryModel
import com.pertamina.digitalaudit.model.IssueDetailModel
import com.pertamina.digitalaudit.model.PriorityModel
import com.pertamina.digitalaudit.model.UserAssignModel
import com.pertamina.digitalaudit.presentation.login.LoginActivity
import com.pertamina.digitalaudit.presentation.search.SearchActivity
import com.pertamina.digitalaudit.util.SnackBar
import com.pertamina.digitalaudit.util.ViewUtils
import com.pertamina.framework.NetworkState
import com.pertamina.framework.ViewDataBindingOwner
import com.pertamina.framework.base.BaseActivity
import com.pertamina.framework.customview.DateTimePicker
import com.pertamina.framework.util.DateHelper
import kotlinx.android.synthetic.main.activity_create_issue.*
import kotlinx.android.synthetic.main.toolbar_layout.*
import org.koin.androidx.viewmodel.ext.android.viewModel


/**
 * Created by M Hafidh Abdul Aziz on 11/03/21.
 */

class CreateIssueActivity : BaseActivity<CreateIssueViewModel>(), CreateIssueView,
    AdapterView.OnItemSelectedListener,
    ViewDataBindingOwner<ActivityCreateIssueBinding> {

    override val layoutResourceId: Int = R.layout.activity_create_issue
    override val viewModel: CreateIssueViewModel by viewModel()
    override var binding: ActivityCreateIssueBinding? = null

    private var chooseUserLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val user: UserAssignModel.UserAssign? =
                    result.data?.getSerializableExtra(SearchActivity.EXTRA_USER_DATA) as UserAssignModel.UserAssign?
                user?.let {
                    viewModel.bTextCreateIssueAssignAuditeeName.value = it.displayName.orEmpty()
                    tvCreateIssueAssignAuditeeError?.visibility = View.GONE
                    if (it.isGroup == true) {
                        viewModel.createIssueAssignAuditeeGroupId.value = it.id.orEmpty()
                    } else {
                        viewModel.createIssueAssignAuditeeUserId.value = it.id.orEmpty()
                    }
                }
            }
        }

    private var chooseLocationLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val locationId = result.data?.getStringExtra(SearchActivity.EXTRA_LOCATION_ID)
                val locationName = result.data?.getStringExtra(SearchActivity.EXTRA_LOCATION_NAME)
                viewModel.createIssueLocationId.value = locationId.orEmpty()
                viewModel.bTextCreateIssueLocation.value = locationName
                tvCreateIssueLocationError?.visibility = View.GONE
            }
        }

    companion object {
        const val EXTRA_ISSUE_ID = "EXTRA_ISSUE_ID"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        getExtraData()
        setupToolbar()
        subscribeCreateIssue()
        subscribePriorityList()
        subscribeIssueCategoryList()
        subscribeUpdateIssue()
        subscribeDetailIssue()
        etCreateIssueTargetClosing.setEventListener(object : DateTimePicker.OnGetDateListener {
            override fun onGetDate(date: String) {
                tvCreateIssueTargetClosingError?.visibility = View.GONE
                viewModel.bTextCreateIssueTargetClosing.value = date
            }
        })
    }

    private fun getExtraData() {
        viewModel.issueId = intent?.getStringExtra(EXTRA_ISSUE_ID).orEmpty()
        if (viewModel.issueId.isNotEmpty()) {
            viewModel.getIssueDetail()
        } else {
            viewModel.getPriorityList()
            viewModel.getIssueCategoryList()
        }
    }

    private fun subscribeCreateIssue() {
        observeData(viewModel.createIssueResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        setResult(RESULT_OK)
                        finish()
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message ?: getString(R.string.general_server_error_message)
                        )
                        when (it.code) {
                            401 -> {
                                viewModel.preference.clearPreferences()
                                logout(Intent(this, LoginActivity::class.java))
                            }
                        }
                    }
                }
            }
        }
    }

    private fun subscribePriorityList() {
        observeData(viewModel.priorityListResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        initPrioritySpinner(it.data)
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message ?: getString(R.string.general_server_error_message)
                        )
                    }
                }
            }
        }
    }

    private fun subscribeIssueCategoryList() {
        observeData(viewModel.issueCategoryListResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        initIssueCategorySpinner(it.data)
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message ?: getString(R.string.general_server_error_message)
                        )
                    }
                }
            }
        }
    }

    private fun subscribeUpdateIssue() {
        observeData(viewModel.updateIssueResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        setResult(RESULT_OK)
                        finish()
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message ?: getString(R.string.general_server_error_message)
                        )
                        when (it.code) {
                            401 -> {
                                viewModel.preference.clearPreferences()
                                logout(Intent(this, LoginActivity::class.java))
                            }
                        }
                    }
                }
            }
        }
    }

    private fun subscribeDetailIssue() {
        observeData(viewModel.issueDetailResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { issueDetail ->
                            setDataToView(issueDetail.data)
                            viewModel.getPriorityList()
                            viewModel.getIssueCategoryList()
                        }
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message ?: getString(R.string.general_server_error_message)
                        )
                        when (it.code) {
                            401 -> {
                                viewModel.preference.clearPreferences()
                                logout(Intent(this, LoginActivity::class.java))
                            }
                            else -> {
                                //do nothing just to avoid error warning
                            }
                        }
                    }
                }
            }
        }
    }

    private fun setDataToView(data: IssueDetailModel.IssueDetail?) {
        viewModel.bTextCreateIssueTitle.value = data?.title
        viewModel.bTextCreateIssueDescription.value = data?.descriptions
        viewModel.bTextCreateIssueLocation.value = data?.auditLocation?.name.orEmpty()
        viewModel.createIssueLocationId.value = data?.auditLocation?.auditLocationId.orEmpty()
        viewModel.createIssuePriorityId.value = data?.priority?.priorityId ?: 0
        viewModel.bTextCreateIssueAssignAuditeeName.value = getAssignedUser(data)
        etCreateIssueTargetClosing.setText(
            DateHelper.changeFormat(
                data?.targetClosing.orEmpty(),
                DateHelper.yyyy_MM_dd_T_HHmmss,
                DateHelper.dd_MMM_yyyy_hh_mm_a
            )
        )
        viewModel.bTextCreateIssueTargetClosing.value = data?.targetClosing.orEmpty()
        viewModel.createIssueCategoryId.value = data?.issueCategory?.issueCategoryId ?: 0
    }

    private fun getAssignedUser(data: IssueDetailModel.IssueDetail?): String {
        data?.assignUser?.let {
            viewModel.createIssueAssignAuditeeUserId.value = it.userId
            return it.displayName.orEmpty()
        }
        data?.assignGroup?.let {
            viewModel.createIssueAssignAuditeeGroupId.value = it.userGroupId
            return it.name.orEmpty()
        }
        return ""
    }

    private fun setupToolbar() {
        if (viewModel.issueId.isNotEmpty()) {
            tvTitleToolbar.text = getString(R.string.issues_edit)
            btnCreateIssue.text = getString(R.string.issues_update)
        } else {
            tvTitleToolbar.text = getString(R.string.issues_create_new)
            btnCreateIssue.text = getString(R.string.issues_create_new)
        }
        btnBackToolbar.apply {
            visibility = View.VISIBLE
            setImageResource(R.drawable.ic_close)
            setOnClickListener {
                onBackPressed()
            }
        }
    }

    private fun initPrioritySpinner(data: List<PriorityModel.Priority>?) {
        val adapter =
            data?.let { ArrayAdapter(this, android.R.layout.simple_spinner_item, it) }
        adapter?.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spCreateIssuePriority.adapter = adapter
        spCreateIssuePriority.onItemSelectedListener = this
        spCreateIssuePriority.setSelection(viewModel.getSelectedPrioritySpinnerItemPosition())
    }

    private fun initIssueCategorySpinner(data: List<IssueCategoryModel.IssueCategory>?) {
        val adapter =
            data?.let { ArrayAdapter(this, android.R.layout.simple_spinner_item, it) }
        adapter?.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spCreateIssueCategory.adapter = adapter
        spCreateIssueCategory.onItemSelectedListener = this
        spCreateIssueCategory.setSelection(viewModel.getSelectedIssueCategorySpinnerItemPosition())
    }

    override fun onClickCreateIssue(view: View) {
        var isValid = true
        if (viewModel.bTextCreateIssueTitle.value.isNullOrEmpty()) {
            isValid = false
            tvCreateIssueTitleError?.visibility = View.VISIBLE
        }

        if (viewModel.bTextCreateIssueDescription.value.isNullOrEmpty()) {
            isValid = false
            tvCreateIssueDescriptionError?.visibility = View.VISIBLE
        }

        if (viewModel.bTextCreateIssueAssignAuditeeName.value.isNullOrEmpty()) {
            isValid = false
            tvCreateIssueAssignAuditeeError?.visibility = View.VISIBLE
        }

        if (viewModel.bTextCreateIssueTargetClosing.value.isNullOrEmpty()) {
            isValid = false
            tvCreateIssueTargetClosingError?.visibility = View.VISIBLE
        }

        if (viewModel.bTextCreateIssueLocation.value.isNullOrEmpty()) {
            isValid = false
            tvCreateIssueLocationError?.visibility = View.VISIBLE
        }

        if (isValid) {
            ViewUtils.hideKeyboard(this, view)
            if (viewModel.issueId.isNotEmpty()) {
                viewModel.updateIssue()
            } else {
                viewModel.createNewIssue()
            }
        }
    }

    override fun onClickChooseUser(view: View) {
        val intent = Intent(this, SearchActivity::class.java)
        intent.putExtra(SearchActivity.EXTRA_FROM_ISSUE, true)
        intent.putExtra(SearchActivity.EXTRA_TITLE, getString(R.string.choose_auditee))
        intent.putExtra(SearchActivity.EXTRA_IS_SEARCH_USER, true)
        chooseUserLauncher.launch(intent)
    }

    override fun onClickChooseLocation(view: View) {
        val intent = Intent(this, SearchActivity::class.java)
        intent.putExtra(SearchActivity.EXTRA_TITLE, getString(R.string.choose_location))
        intent.putExtra(SearchActivity.EXTRA_IS_SEARCH_LOCATION, true)
        chooseLocationLauncher.launch(intent)
    }

    override var bTextWatcherIssueTitle: TextWatcher
        get() = object : TextWatcher {

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                tvCreateIssueTitleError?.visibility = View.GONE
            }

            override fun afterTextChanged(s: Editable?) {}
        }
        set(_) {}

    override var bTextWatcherIssueDescription: TextWatcher
        get() = object : TextWatcher {

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                tvCreateIssueDescriptionError?.visibility = View.GONE
            }

            override fun afterTextChanged(s: Editable?) {}
        }
        set(_) {}

    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
        when (parent?.id) {
            R.id.spCreateIssueCategory -> {
                val issueCategory = parent.selectedItem as IssueCategoryModel.IssueCategory
                viewModel.createIssueCategoryId.value = issueCategory.issueCategoryId ?: 0
            }
            R.id.spCreateIssuePriority -> {
                val priority = parent.selectedItem as PriorityModel.Priority
                viewModel.createIssuePriorityId.value = priority.priorityId ?: 0
            }
        }
    }

    override fun onNothingSelected(parent: AdapterView<*>?) {
        //do nothing
    }
}
