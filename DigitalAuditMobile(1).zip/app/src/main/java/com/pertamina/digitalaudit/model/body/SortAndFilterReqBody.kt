package com.pertamina.digitalaudit.model.body

import com.google.gson.annotations.SerializedName
import java.io.Serializable

/**
 * Created by M Hafidh Abdul Aziz on 24/03/21.
 */

class SortAndFilterReqBody : Serializable {
    @SerializedName("IssueId")
    var issueId: String? = null

    @SerializedName("Title")
    var title: String? = null

    @SerializedName("AuditLocationId")
    var auditLocationId: String? = null

    @SerializedName("AuditTypeId")
    var auditTypeId: String? = null

    @SerializedName("PriorityId")
    var priorityId: Int? = null

    @SerializedName("StatusId")
    var statusId: Int? = null

    @SerializedName("UserCreated")
    var userCreated: String? = null

    @SerializedName("AssignUser")
    var assignUser: String? = null

    @SerializedName("StartDate")
    var startDate: String? = null

    @SerializedName("EndDate")
    var endDate: String? = null

    @SerializedName("page_size")
    var pageSize: Int? = null

    @SerializedName("page_number")
    var pageNumber: Int? = null

    @SerializedName("sort_by")
    var sortBy: String? = null

    @SerializedName("order_by")
    var orderBy: String? = null

    @SerializedName("IsConnectedToAction")
    var isConnectedToAction: Boolean? = null
}
