package com.pertamina.digitalaudit.presentation.search

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.databinding.ActivitySearchBinding
import com.pertamina.digitalaudit.model.*
import com.pertamina.digitalaudit.presentation.login.LoginActivity
import com.pertamina.digitalaudit.presentation.search.adapter.ListSearchItemAdapter
import com.pertamina.digitalaudit.util.SnackBar
import com.pertamina.digitalaudit.util.ViewUtils
import com.pertamina.framework.NetworkState
import com.pertamina.framework.ViewDataBindingOwner
import com.pertamina.framework.base.BaseActivity
import com.pertamina.framework.util.EndlessScrollListener
import kotlinx.android.synthetic.main.activity_search.*
import kotlinx.android.synthetic.main.layout_empty_state.*
import kotlinx.android.synthetic.main.toolbar_layout.*
import org.koin.androidx.viewmodel.ext.android.viewModel

class SearchActivity : BaseActivity<SearchViewModel>(), SearchView,
    ViewDataBindingOwner<ActivitySearchBinding>, ListSearchItemAdapter.SearchItemClickListener {

    override val layoutResourceId: Int = R.layout.activity_search
    override val viewModel: SearchViewModel by viewModel()
    override var binding: ActivitySearchBinding? = null

    private var scrollListener: EndlessScrollListener? = null
    private var listSearchAdapter: ListSearchItemAdapter? = null

    private var tempListUserAssign: ArrayList<UserAssignModel.UserAssign> = ArrayList()
    private var tempListIssue: ArrayList<IssueModel.Issue> = ArrayList()
    private var tempListLocation: ArrayList<LocationModel.Location> = ArrayList()
    private var tempListTemplate: ArrayList<TemplateModel.Template> = ArrayList()
    private var tempListRegion: ArrayList<RegionModel.Region> = ArrayList()

    companion object {
        const val EXTRA_FROM_ISSUE = "EXTRA_FROM_ISSUE"
        const val EXTRA_FROM_ACTION = "EXTRA_FROM_ACTION"
        const val EXTRA_TITLE = "EXTRA_TITLE"

        const val EXTRA_IS_SEARCH_USER = "EXTRA_IS_SEARCH_USER"
        const val EXTRA_USER_DATA = "EXTRA_USER_DATA"

        const val EXTRA_IS_SEARCH_ISSUE = "EXTRA_IS_SEARCH_ISSUE"
        const val EXTRA_ISSUE_ID = "EXTRA_ISSUE_ID"
        const val EXTRA_ISSUE_TITLE = "EXTRA_ISSUE_TITLE"

        const val EXTRA_IS_SEARCH_LOCATION = "EXTRA_IS_SEARCH_LOCATION"
        const val EXTRA_LOCATION_ID = "EXTRA_LOCATION_ID"
        const val EXTRA_LOCATION_NAME = "EXTRA_LOCATION_NAME"

        const val EXTRA_IS_SEARCH_TEMPLATE = "EXTRA_IS_SEARCH_TEMPLATE"
        const val EXTRA_TEMPLATE_ID = "EXTRA_TEMPLATE_ID"
        const val EXTRA_TEMPLATE_TITLE = "EXTRA_TEMPLATE_TITLE"

        const val EXTRA_IS_SEARCH_REGION = "EXTRA_IS_SEARCH_REGION"
        const val EXTRA_REGION_ID = "EXTRA_REGION_ID"
        const val EXTRA_REGION_NAME = "EXTRA_REGION_NAME"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupToolbar()
        getExtraData()
        setupRv()
        subscribeUserAssign()
        subscribeIssueList()
        subscribeLocationList()
        subscribeTemplateList()
        subscribeRegionList()
    }

    private fun setupToolbar() {
        tvTitleToolbar.text = intent?.getStringExtra(EXTRA_TITLE) ?: getString(R.string.choose_user)
        btnBackToolbar.apply {
            visibility = View.VISIBLE
            setImageResource(R.drawable.ic_close)
            setOnClickListener {
                onBackPressed()
            }
        }
    }

    private fun getExtraData() {
        viewModel.fromIssue = intent?.getBooleanExtra(EXTRA_FROM_ISSUE, false) ?: false
        viewModel.fromAction = intent?.getBooleanExtra(EXTRA_FROM_ACTION, false) ?: false
        viewModel.isSearchUser = intent?.getBooleanExtra(EXTRA_IS_SEARCH_USER, false) ?: false
        viewModel.isSearchIssue = intent?.getBooleanExtra(EXTRA_IS_SEARCH_ISSUE, false) ?: false
        viewModel.isSearchLocation =
            intent?.getBooleanExtra(EXTRA_IS_SEARCH_LOCATION, false) ?: false
        viewModel.isSearchTemplate =
            intent?.getBooleanExtra(EXTRA_IS_SEARCH_TEMPLATE, false) ?: false
        viewModel.isSearchRegion =
            intent?.getBooleanExtra(EXTRA_IS_SEARCH_REGION, false) ?: false
        viewModel.getUserData()
        loadData(null)
    }

    private fun setupRv() {
        val manager = LinearLayoutManager(this, RecyclerView.VERTICAL, false)
        listSearchAdapter = ListSearchItemAdapter()
        listSearchAdapter?.setSearchItemClickListener(this)
        scrollListener = object : EndlessScrollListener(manager) {
            override fun onLoadMore() {
                viewModel.isLoadMore = true
                loadData(if (viewModel.bTextSearch.value.isNullOrEmpty()) null else viewModel.bTextSearch.value)
            }
        }
        rvSearchItem.apply {
            layoutManager = manager
            setHasFixedSize(true)
            adapter = listSearchAdapter
            addOnScrollListener(scrollListener as EndlessScrollListener)
        }
    }

    private fun subscribeUserAssign() {
        observeData(viewModel.userAssignResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { data ->
                            if (data.isNotEmpty()) {
                                viewModel.showEmptyState.value = false
                                tempListUserAssign.addAll(data)
                                listSearchAdapter?.setData(tempListUserAssign)
                                viewModel.hasMoreData =
                                    tempListUserAssign.size % SearchViewModel.PAGE_SIZE == 0
                                viewModel.pageNumber += 1
                            } else {
                                if (!viewModel.isLoadMore) {
                                    viewModel.showEmptyState.value = true
                                    tvEmptyMessage.text = getString(R.string.data_not_found)
                                }
                            }
                        }
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message
                                ?: getString(R.string.general_server_error_message)
                        )
                        when (it.code) {
                            401 -> {
                                viewModel.preference.clearPreferences()
                                logout(Intent(this, LoginActivity::class.java))
                            }
                            404 -> {
                                tvEmptyMessage.text = it.message
                                viewModel.showEmptyState.value = true
                                listSearchAdapter?.removeAllData()
                            }
                            else -> {
                                //do nothing just to avoid error warning
                            }
                        }
                    }
                }
            }
        }
    }

    private fun subscribeIssueList() {
        observeData(viewModel.issueListResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { data ->
                            if (data.isNotEmpty()) {
                                viewModel.showEmptyState.value = false
                                tempListIssue.addAll(data)
                                listSearchAdapter?.setData(tempListIssue)
                                viewModel.hasMoreData =
                                    tempListIssue.size % SearchViewModel.PAGE_SIZE == 0
                                viewModel.pageNumber += 1
                            } else {
                                if (!viewModel.isLoadMore) {
                                    viewModel.showEmptyState.value = true
                                    tvEmptyMessage.text = getString(R.string.data_not_found)
                                }
                            }
                        }
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message
                                ?: getString(R.string.general_server_error_message)
                        )
                        when (it.code) {
                            401 -> {
                                viewModel.preference.clearPreferences()
                                logout(Intent(this, LoginActivity::class.java))
                            }
                            404 -> {
                                tvEmptyMessage.text = it.message
                                viewModel.showEmptyState.value = true
                                listSearchAdapter?.removeAllData()
                            }
                            else -> {
                                //do nothing just to avoid error warning
                            }
                        }
                    }
                }
            }
        }
    }

    private fun subscribeLocationList() {
        observeData(viewModel.locationListResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { data ->
                            if (data.isNotEmpty()) {
                                viewModel.showEmptyState.value = false
                                tempListLocation.addAll(data)
                                listSearchAdapter?.setData(tempListLocation)
                                viewModel.hasMoreData =
                                    tempListLocation.size % SearchViewModel.PAGE_SIZE == 0
                                viewModel.pageNumber += 1
                            } else {
                                if (!viewModel.isLoadMore) {
                                    viewModel.showEmptyState.value = true
                                    tvEmptyMessage.text = getString(R.string.data_not_found)
                                }
                            }
                        }
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message
                                ?: getString(R.string.general_server_error_message)
                        )
                        when (it.code) {
                            401 -> {
                                viewModel.preference.clearPreferences()
                                logout(Intent(this, LoginActivity::class.java))
                            }
                            404 -> {
                                tvEmptyMessage.text = it.message
                                viewModel.showEmptyState.value = true
                                listSearchAdapter?.removeAllData()
                            }
                            else -> {
                                //do nothing just to avoid error warning
                            }
                        }
                    }
                }
            }
        }
    }

    private fun subscribeTemplateList() {
        observeData(viewModel.templateListResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { data ->
                            if (data.isNotEmpty()) {
                                viewModel.showEmptyState.value = false
                                tempListTemplate.addAll(data)
                                listSearchAdapter?.setData(tempListTemplate)
                                viewModel.hasMoreData =
                                    tempListTemplate.size % SearchViewModel.PAGE_SIZE == 0
                                viewModel.pageNumber += 1
                            } else {
                                if (!viewModel.isLoadMore) {
                                    viewModel.showEmptyState.value = true
                                    tvEmptyMessage.text = getString(R.string.data_not_found)
                                }
                            }
                        }
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message
                                ?: getString(R.string.general_server_error_message)
                        )
                        when (it.code) {
                            401 -> {
                                viewModel.preference.clearPreferences()
                                logout(Intent(this, LoginActivity::class.java))
                            }
                            404 -> {
                                tvEmptyMessage.text = it.message
                                viewModel.showEmptyState.value = true
                                listSearchAdapter?.removeAllData()
                            }
                            else -> {
                                //do nothing just to avoid error warning
                            }
                        }
                    }
                }
            }
        }
    }

    private fun subscribeRegionList() {
        observeData(viewModel.regionListResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { data ->
                            if (data.isNotEmpty()) {
                                viewModel.showEmptyState.value = false
                                tempListRegion.addAll(data)
                                listSearchAdapter?.setData(tempListRegion)
                                viewModel.hasMoreData =
                                    tempListRegion.size % SearchViewModel.PAGE_SIZE == 0
                                viewModel.pageNumber += 1
                            } else {
                                if (!viewModel.isLoadMore) {
                                    viewModel.showEmptyState.value = true
                                    tvEmptyMessage.text = getString(R.string.data_not_found)
                                }
                            }
                        }
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message
                                ?: getString(R.string.general_server_error_message)
                        )
                        when (it.code) {
                            401 -> {
                                viewModel.preference.clearPreferences()
                                logout(Intent(this, LoginActivity::class.java))
                            }
                            404 -> {
                                tvEmptyMessage.text = it.message
                                viewModel.showEmptyState.value = true
                                listSearchAdapter?.removeAllData()
                            }
                            else -> {
                                //do nothing just to avoid error warning
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onClickClear(view: View) {
        viewModel.bTextSearch.value = ""
        resetData()
        loadData(null)
        ViewUtils.hideKeyboard(this, searchInputQuery)
    }

    override var bOnEditorActionListener: TextView.OnEditorActionListener
        get() = TextView.OnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                ViewUtils.hideKeyboard(this, searchInputQuery)
                resetData()
                if (viewModel.bTextSearch.value.isNullOrEmpty()) {
                    loadData(null)
                } else {
                    loadData(viewModel.bTextSearch.value)
                }
                return@OnEditorActionListener true
            }
            false
        }
        set(_) {}

    override fun onClickUser(user: UserAssignModel.UserAssign) {
        val result = Intent()
        result.putExtra(EXTRA_USER_DATA, user)
        setResult(Activity.RESULT_OK, result)
        finish()
    }

    override fun onClickIssue(issueId: String, issueTitle: String) {
        val result = Intent()
        result.putExtra(EXTRA_ISSUE_ID, issueId)
        result.putExtra(EXTRA_ISSUE_TITLE, issueTitle)
        setResult(Activity.RESULT_OK, result)
        finish()
    }

    override fun onClickTemplate(templateId: String, templateTitle: String) {
        val result = Intent()
        result.putExtra(EXTRA_TEMPLATE_ID, templateId)
        result.putExtra(EXTRA_TEMPLATE_TITLE, templateTitle)
        setResult(Activity.RESULT_OK, result)
        finish()
    }

    override fun onClickLocation(locationId: String, locationName: String) {
        val result = Intent()
        result.putExtra(EXTRA_LOCATION_ID, locationId)
        result.putExtra(EXTRA_LOCATION_NAME, locationName)
        setResult(Activity.RESULT_OK, result)
        finish()
    }

    override fun onClickRegion(regionId: String, regionName: String) {
        val result = Intent()
        result.putExtra(EXTRA_REGION_ID, regionId)
        result.putExtra(EXTRA_REGION_NAME, regionName)
        setResult(Activity.RESULT_OK, result)
        finish()
    }

    private fun loadData(query: String?) {
        when {
            viewModel.isSearchUser -> {
                viewModel.loadUser(query)
            }
            viewModel.isSearchIssue -> {
                viewModel.loadIssue(query)
            }
            viewModel.isSearchLocation -> {
                viewModel.loadLocation(query)
            }
            viewModel.isSearchTemplate -> {
                viewModel.loadTemplate(query)
            }
            viewModel.isSearchRegion -> {
                viewModel.loadRegion(query)
            }
        }
    }

    private fun resetData() {
        viewModel.hasMoreData = true
        viewModel.pageNumber = 1
        scrollListener?.resetState()
        tempListUserAssign.clear()
        tempListIssue.clear()
        tempListLocation.clear()
        tempListTemplate.clear()
        tempListRegion.clear()
    }
}
