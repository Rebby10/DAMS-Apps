package com.pertamina.digitalaudit.presentation.sortandfilter

import androidx.lifecycle.MutableLiveData
import com.pertamina.digitalaudit.model.AuditTypeModel
import com.pertamina.digitalaudit.model.IssueStatusModel
import com.pertamina.digitalaudit.model.PriorityModel
import com.pertamina.digitalaudit.model.body.SortAndFilterReqBody
import com.pertamina.digitalaudit.model.query.GetActionQuery
import com.pertamina.digitalaudit.preference.PreferenceProvider
import com.pertamina.digitalaudit.repository.common.CommonRepository
import com.pertamina.digitalaudit.repository.issues.IssuesRepository
import com.pertamina.framework.base.BaseViewModel
import com.pertamina.framework.base.Resource
import kotlinx.coroutines.launch
import java.util.*

/**
 * Created by M Hafidh Abdul Aziz on 13/03/21.
 */

class SortAndFilterViewModel(
    val preference: PreferenceProvider,
    private val sortAndFilterModel: SortAndFilterReqBody,
    private val sortAndFilterActionQuery: GetActionQuery,
    private val issuesRepository: IssuesRepository,
    private val commonRepository: CommonRepository
) : BaseViewModel() {
    var bTextFilterSortBy = MutableLiveData<String?>(null)
    var bTextFilterActions = MutableLiveData<String?>(null)
    var bTextFilterStartDate = MutableLiveData<String?>(null)
    var bTextFilterEndDate = MutableLiveData<String?>(null)
    var bTextFilterLocation = MutableLiveData("Semua")

    var bFilterAuditTypeId = MutableLiveData<String?>(null)
    var bFilterLocationId = MutableLiveData<String?>(null)
    var bFilterPriorityId = MutableLiveData<Int?>(null)
    var bFilterStatusId = MutableLiveData<Int?>(null)
    var bFilterConnectedToActions = MutableLiveData<Boolean?>(null)
    var isFromActions = MutableLiveData(false)
    val showProgressBar = MutableLiveData(false)

    val priorityListResponse = MutableLiveData<Resource<List<PriorityModel.Priority>>>()
    val statusListResponse = MutableLiveData<Resource<List<IssueStatusModel.IssueStatus>>>()
    val auditTypeListResponse = MutableLiveData<Resource<List<AuditTypeModel.AuditType>>>()

    init {
        getPriorityList()
        getIssueStatusList()
        getAuditTypeList()
    }

    private fun getPriorityList() {
        showProgressBar.value = true
        launch {
            val request = commonRepository.getPriority()
            priorityListResponse.value = request
            showProgressBar.value = false
        }
    }

    private fun getIssueStatusList() {
        showProgressBar.value = true
        launch {
            val request = issuesRepository.getIssueStatus()
            statusListResponse.value = request
            showProgressBar.value = false
        }
    }

    private fun getAuditTypeList() {
        showProgressBar.value = true
        launch {
            val request = commonRepository.getAuditType()
            auditTypeListResponse.value = request
            showProgressBar.value = false
        }
    }

    fun getSelectedPrioritySpinnerItemPosition(): Int {
        val prevSelectedPriority = sortAndFilterModel.priorityId
        prevSelectedPriority?.let {
            priorityListResponse.value?.data?.let { list ->
                val data = list.toMutableList()
                return list.indexOf(data.find { it.priorityId == prevSelectedPriority }) + ADDITIONAL_FIRST_POSITION
            }
        }
        return 0
    }

    fun getSelectedStatusSpinnerItemPosition(): Int {
        val prevSelectedStatus = sortAndFilterModel.statusId
        prevSelectedStatus?.let {
            statusListResponse.value?.data?.let { list ->
                val data = list.toMutableList()
                return list.indexOf(data.find { it.statusId == prevSelectedStatus }) + ADDITIONAL_FIRST_POSITION
            }
        }
        return 0
    }

    fun applySortAndFilterModel() {
        sortAndFilterModel.assignUser = null
        sortAndFilterModel.userCreated = null
        sortAndFilterModel.sortBy = bTextFilterSortBy.value?.replace(" ", "")
            ?.lowercase(Locale.getDefault())
        sortAndFilterModel.auditLocationId = bFilterLocationId.value
        sortAndFilterModel.auditTypeId = bFilterAuditTypeId.value
        sortAndFilterModel.priorityId = bFilterPriorityId.value
        sortAndFilterModel.statusId = bFilterStatusId.value
        sortAndFilterModel.startDate = bTextFilterStartDate.value
        sortAndFilterModel.endDate = bTextFilterEndDate.value
        sortAndFilterModel.isConnectedToAction = bFilterConnectedToActions.value
        sortAndFilterModel.orderBy = "desc"
    }

    fun applySortAndFilterActions() {
        sortAndFilterActionQuery.sortBy = bTextFilterSortBy.value?.replace(" ", "")
            ?.lowercase(Locale.getDefault())
        sortAndFilterActionQuery.auditLocationId = bFilterLocationId.value
        sortAndFilterActionQuery.auditTypeId = bFilterAuditTypeId.value
        sortAndFilterActionQuery.startDate = bTextFilterStartDate.value
        sortAndFilterActionQuery.endDate = bTextFilterEndDate.value
        sortAndFilterActionQuery.orderBy = "desc"
    }

    companion object {
        private const val ADDITIONAL_FIRST_POSITION = 1
    }
}