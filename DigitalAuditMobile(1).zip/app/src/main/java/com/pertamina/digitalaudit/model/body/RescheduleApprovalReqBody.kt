package com.pertamina.digitalaudit.model.body

import com.google.gson.annotations.SerializedName

class RescheduleApprovalReqBody(
    @SerializedName("ScheduleId")
    var scheduleId: String,
    @SerializedName("RescheduleId")
    var rescheduleId: String,
    @SerializedName("IsApproved")
    var isApproved: Boolean
)