package com.pertamina.digitalaudit.presentation.sheet.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SeekBar
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.model.VoiceNoteModel
import com.pertamina.framework.base.BaseRecyclerViewAdapter
import com.pertamina.framework.base.BaseViewHolder
import kotlinx.android.synthetic.main.item_record.view.*

/**
 * @author Asadurrahman Al Qayyim
 * @date 10/1/2021
 */

class VoiceNoteAdapter : BaseRecyclerViewAdapter<VoiceNoteModel>() {

    private var listener: ItemClickListener? = null

    override fun onCreateViewHolder(
            parent: ViewGroup,
            viewType: Int
    ): BaseViewHolder<VoiceNoteModel> {
        val view = LayoutInflater.from(parent.context).inflate(viewType, parent, false)
        return ListViewHolder(parent.context, view, listener)
    }

    override fun onBindViewHolder(
            holder: BaseViewHolder<VoiceNoteModel>,
            position: Int
    ) {
        holder.bindData(getItem(position))
    }

    override fun getItemViewType(position: Int): Int {
        return R.layout.item_record
    }

    class ListViewHolder(context: Context, val view: View, listener: ItemClickListener?) :
            BaseViewHolder<VoiceNoteModel>(context, view) {

        private var holderListener: ItemClickListener? = listener
        private var seekbar = view.progressRecord
        private var ivPlayPause = view.ivPlayPause
        private var ivDelete = view.ivDelete

        override fun bindData(data: VoiceNoteModel) {
            seekbar.setOnTouchListener { _, _ -> true }
            if (data.isPlaying) ivPlayPause.setImageResource(R.drawable.ic_baseline_pause_24)
            else ivPlayPause.setImageResource(R.drawable.ic_play)
            ivPlayPause.setOnClickListener {
                holderListener?.onClickPlayPause(data, seekbar)
            }
            ivDelete.setOnClickListener {
                holderListener?.onClickDelete(data)
            }
        }
    }

    fun setItemClickListener(listener: ItemClickListener) {
        this.listener = listener
    }

    interface ItemClickListener {
        fun onClickPlayPause(data: VoiceNoteModel, seekBar: SeekBar)
        fun onClickDelete(data: VoiceNoteModel)
    }
}