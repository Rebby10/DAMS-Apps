package com.pertamina.digitalaudit.presentation.startinspection.additionalinfo.adapter

import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.model.body.SubmitInspectionInfoReqBody
import com.pertamina.framework.base.BaseRecyclerViewAdapter
import com.pertamina.framework.base.BaseViewHolder
import kotlinx.android.synthetic.main.item_inspection_additional_info_note.view.*

class AdditionalInfoNoteAdapter : BaseRecyclerViewAdapter<SubmitInspectionInfoReqBody>() {

    private var listener: ItemListener? = null

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BaseViewHolder<SubmitInspectionInfoReqBody> {
        val view = LayoutInflater.from(parent.context).inflate(viewType, parent, false)
        return ListViewHolder(parent.context, view, listener)
    }

    override fun onBindViewHolder(
        holder: BaseViewHolder<SubmitInspectionInfoReqBody>,
        position: Int
    ) {
        holder.bindData(getItem(position))
    }

    override fun getItemViewType(position: Int): Int {
        return R.layout.item_inspection_additional_info_note
    }

    class ListViewHolder(context: Context, val view: View, listener: ItemListener?) :
        BaseViewHolder<SubmitInspectionInfoReqBody>(context, view) {

        private var holderListener: ItemListener? = listener
        private var etTitleNote = view.etTitleNote
        private var clActionDelete = view.clActionDelete
        private var etNote = view.etNote

        override fun bindData(data: SubmitInspectionInfoReqBody) {
            etTitleNote.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    holderListener?.onTitleNoteChange(
                        adapterPosition,
                        s.toString()
                    )
                }

                override fun beforeTextChanged(
                    s: CharSequence?,
                    start: Int,
                    count: Int,
                    after: Int
                ) {
                }

                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                }
            })
            etNote.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    holderListener?.onNoteChange(
                        adapterPosition,
                        s.toString()
                    )
                }

                override fun beforeTextChanged(
                    s: CharSequence?,
                    start: Int,
                    count: Int,
                    after: Int
                ) {
                }

                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                }
            })
            clActionDelete.setOnClickListener {
                holderListener?.onDeleteItem(adapterPosition)
            }
        }
    }

    fun setItemListener(listener: ItemListener) {
        this.listener = listener
    }

    interface ItemListener {
        fun onDeleteItem(position: Int)
        fun onTitleNoteChange(position: Int, titleNote: String)
        fun onNoteChange(position: Int, note: String)
    }
}