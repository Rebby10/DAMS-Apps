package com.pertamina.digitalaudit.model.query

import com.google.gson.annotations.SerializedName
import java.io.Serializable

class GetHomeOverviewQuery : Serializable {
    @SerializedName("user_id")
    var userId: String? = null

    @SerializedName("role_id")
    var roleId: String? = null

    @SerializedName("search")
    var search: String? = null

    @SerializedName("page_size")
    var pageSize: Int? = 0

    @SerializedName("page_number")
    var pageNumber: Int? = 0

    @SerializedName("sort_by")
    var sortBy: String? = null

    @SerializedName("order_by")
    var orderBy: String? = null
}
