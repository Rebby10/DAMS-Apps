package com.pertamina.digitalaudit.presentation.reportinspection.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.model.reportinspection.TemplatePageItem
import com.pertamina.framework.base.BaseRecyclerViewAdapter
import com.pertamina.framework.base.BaseViewHolder
import kotlinx.android.synthetic.main.item_title_page.view.*

class TitlePageAdapter : BaseRecyclerViewAdapter<TemplatePageItem>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BaseViewHolder<TemplatePageItem> {
        val view = LayoutInflater.from(parent.context).inflate(viewType, parent, false)
        return ListViewHolder(parent.context, view)
    }

    override fun onBindViewHolder(
        holder: BaseViewHolder<TemplatePageItem>,
        position: Int
    ) {
        holder.bindData(getItem(position))
    }

    override fun getItemViewType(position: Int): Int {
        return R.layout.item_title_page
    }

    class ListViewHolder(context: Context, val view: View) :
        BaseViewHolder<TemplatePageItem>(context, view) {

        private var tvPageQuestion = view.tvPageQuestion
        private var tvPageQuestionValue = view.tvPageQuestionValue

        override fun bindData(data: TemplatePageItem) {
            tvPageQuestion.text = data.title
            tvPageQuestionValue.text = data.descriptions
        }
    }
}