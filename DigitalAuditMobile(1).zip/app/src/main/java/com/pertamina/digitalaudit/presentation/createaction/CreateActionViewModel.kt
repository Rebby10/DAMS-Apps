package com.pertamina.digitalaudit.presentation.createaction

import androidx.lifecycle.MutableLiveData
import com.pertamina.digitalaudit.model.ActionDetailModel
import com.pertamina.digitalaudit.model.ActionModel
import com.pertamina.digitalaudit.model.PriorityModel
import com.pertamina.digitalaudit.model.UserModel
import com.pertamina.digitalaudit.model.body.CreateActionReqBody
import com.pertamina.digitalaudit.model.body.UpdateActionReqBody
import com.pertamina.digitalaudit.preference.PreferenceProvider
import com.pertamina.digitalaudit.repository.actions.ActionsRepository
import com.pertamina.digitalaudit.repository.common.CommonRepository
import com.pertamina.framework.NonNullMutableLiveData
import com.pertamina.framework.base.BaseViewModel
import com.pertamina.framework.base.Resource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class CreateActionViewModel(
    private val actionsRepository: ActionsRepository,
    private val commonRepository: CommonRepository,
    val preference: PreferenceProvider
) : BaseViewModel() {
    val showProgressBar = MutableLiveData(false)
    var bTextCreateActionTitle = MutableLiveData("")
    var bTextCreateActionDescription = MutableLiveData("")
    var bTextCreateActionTargetClosing = MutableLiveData("")
    var bTextCreateActionAssignToName = MutableLiveData("")
    var bTextCreateActionRelatedIssue = MutableLiveData("")
    var bTextCreateActionLocation = MutableLiveData("")

    var createActionLocationId = NonNullMutableLiveData("")
    var createActionPriorityId = NonNullMutableLiveData(0)
    var createActionAssignToUserId = MutableLiveData<String>(null)
    var createActionAssignToGroupId = MutableLiveData<String>(null)
    var createActionRelatedIssueId = MutableLiveData<String>(null)

    val createActionResponse = MutableLiveData<Resource<ActionModel>>()
    val updateActionResponse = MutableLiveData<Resource<ActionModel>>()
    val actionDetailResponse = MutableLiveData<Resource<ActionDetailModel>>()
    val priorityListResponse = MutableLiveData<Resource<List<PriorityModel.Priority>>>()

    var user = UserModel.User()
    var actionId: String? = null
    var isFromIssue: Boolean = false
    var inspectionId: String? = null
    var questionId: String? = null
    var location: String? = null
    var issueId: String? = null
    var issueTitle: String? = null

    init {
        getUserData()
    }

    companion object {
        private const val STATUS_ID_OPEN = 1
    }

    private fun getUserData() {
        launch {
            withContext(Dispatchers.IO) {
                user = preference.getAuthPreferences()
            }
        }
    }

    fun createNewAction() {
        showProgressBar.value = true
        launch {
            val request = actionsRepository.createNewAction(
                CreateActionReqBody(
                    title = bTextCreateActionTitle.value.orEmpty(),
                    descriptions = bTextCreateActionDescription.value.orEmpty(),
                    auditLocationId = createActionLocationId.value,
                    assignedGroup = createActionAssignToGroupId.value,
                    assignedUser = createActionAssignToUserId.value,
                    issueId = createActionRelatedIssueId.value,
                    creator = user.userId.orEmpty(),
                    priorityId = createActionPriorityId.value,
                    targetClosing = bTextCreateActionTargetClosing.value.orEmpty(),
                    statusId = STATUS_ID_OPEN,
                    inspectionId = inspectionId,
                    questionId = questionId
                )
            )
            createActionResponse.value = request
            showProgressBar.value = false
        }
    }

    fun updateAction() {
        showProgressBar.value = true
        launch {
            val request = actionsRepository.updateAction(
                UpdateActionReqBody(
                    actionId = actionId.orEmpty(),
                    title = bTextCreateActionTitle.value.orEmpty(),
                    descriptions = bTextCreateActionDescription.value.orEmpty(),
                    auditLocationId = createActionLocationId.value,
                    assignedGroup = createActionAssignToGroupId.value,
                    assignedUser = createActionAssignToUserId.value,
                    issueId = createActionRelatedIssueId.value,
                    creator = user.userId.orEmpty(),
                    priorityId = createActionPriorityId.value,
                    targetClosing = bTextCreateActionTargetClosing.value,
                    statusId = STATUS_ID_OPEN
                )
            )
            updateActionResponse.value = request
            showProgressBar.value = false
        }
    }

    fun getActionDetail() {
        showProgressBar.value = true
        launch {
            val request =
                    actionsRepository.getActionDetail(actionId.orEmpty())
            actionDetailResponse.value = request
            showProgressBar.value = false
        }
    }

    fun getPriorityList() {
        showProgressBar.value = true
        launch {
            val request = commonRepository.getPriority()
            priorityListResponse.value = request
            showProgressBar.value = false
        }
    }

    fun getSelectedPrioritySpinnerItemPosition(): Int {
        val prevSelectedPriority = createActionPriorityId.value
        prevSelectedPriority.let {
            priorityListResponse.value?.data?.let { list ->
                val data = list.toMutableList()
                return list.indexOf(data.find { it.priorityId == prevSelectedPriority })
            }
        }
        return 0
    }
}
