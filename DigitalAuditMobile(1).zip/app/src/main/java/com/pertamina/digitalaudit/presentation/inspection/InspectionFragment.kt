package com.pertamina.digitalaudit.presentation.inspection

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.databinding.FragmentInspectionBinding
import com.pertamina.digitalaudit.eventbus.StartInspectionActivityEvent
import com.pertamina.digitalaudit.model.AuditLocationModel
import com.pertamina.digitalaudit.model.query.GetInspectionQuery
import com.pertamina.digitalaudit.presentation.createinspection.CreateInspectionActivity
import com.pertamina.digitalaudit.presentation.home.adapter.InspectionAdapter
import com.pertamina.digitalaudit.presentation.inspectionfilter.InspectionFilterActivity
import com.pertamina.digitalaudit.presentation.login.LoginActivity
import com.pertamina.digitalaudit.presentation.main.MainActivity
import com.pertamina.digitalaudit.presentation.map.MapActivity
import com.pertamina.digitalaudit.presentation.map.adapter.ToolbarMenuAdapter
import com.pertamina.digitalaudit.presentation.reportinspection.ReportInspectionActivity
import com.pertamina.digitalaudit.presentation.startinspection.StartInspectionActivity
import com.pertamina.digitalaudit.util.CommonConstant
import com.pertamina.digitalaudit.util.SnackBar
import com.pertamina.framework.NetworkState
import com.pertamina.framework.ViewDataBindingOwner
import com.pertamina.framework.base.BaseFragment
import com.pertamina.framework.extensions.sharedGraphViewModel
import kotlinx.android.synthetic.main.fragment_inspection.*
import kotlinx.android.synthetic.main.layout_empty_state.*
import kotlinx.android.synthetic.main.toolbar_layout.*
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import org.koin.android.ext.android.inject

/**
 * Created by M Hafidh Abdul Aziz on 11/03/21.
 */

class InspectionFragment : BaseFragment<InspectionViewModel>(), InspectionView,
    ViewDataBindingOwner<FragmentInspectionBinding>, InspectionAdapter.InspectionClickListener {

    override val layoutResourceId: Int = R.layout.fragment_inspection
    override val viewModel: InspectionViewModel by sharedGraphViewModel(R.id.nav_graph_inspection)
    override var binding: FragmentInspectionBinding? = null

    private lateinit var toolbarMenuAdapter: ToolbarMenuAdapter
    private var inspectionAdapter: InspectionAdapter? = null
    private lateinit var toolbarMenu: ArrayList<String>
    private val inspectionFilterQuery: GetInspectionQuery by inject()

    companion object {
        private const val FIRST_INDEX = 0
    }

    private var newInspectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                viewModel.getInspectionData()
            }
        }

    private var filterLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                if (inspectionFilterQuery.userTypeId == CommonConstant.USER_TYPE_AUDITOR_ID) {
                    toolbarMenu =
                        ArrayList(listOf(*resources.getStringArray(R.array.filter_inspection_menu_auditor)))
                    viewModel.selectedStatusId = InspectionViewModel.SCHEDULED_ID
                } else if (inspectionFilterQuery.userTypeId == CommonConstant.USER_TYPE_AUDITEE_ID) {
                    toolbarMenu =
                        ArrayList(listOf(*resources.getStringArray(R.array.filter_inspection_menu_auditee)))
                    viewModel.selectedStatusId = InspectionViewModel.NEED_APPROVAL_ID
                }
                toolbarMenuAdapter.setSelectedMenuPosition(FIRST_INDEX)
                toolbarMenuAdapter.addData(toolbarMenu)
                viewModel.selectedUserTypeId = inspectionFilterQuery.userTypeId
                viewModel.selectedRegionId = inspectionFilterQuery.regionId
                viewModel.selectedLocationId = inspectionFilterQuery.auditLocationId
                viewModel.getInspectionData()
            }
        }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupToolbar()
        setupView()
        setupRv()
        observeInspectionList()
    }

    private fun setupToolbar() {
        tvTitleToolbar.apply {
            text = getString(R.string.title_inspection)
            gravity = Gravity.START
        }
        menuAction1.apply {
            visibility = View.VISIBLE
            setImageResource(R.drawable.ic_search)
            setOnClickListener {
                manageSearchLayout(true)
            }
        }
        menuAction2.apply {
            visibility = View.VISIBLE
            setImageResource(R.drawable.ic_map)
            setOnClickListener {
                MapActivity.startThisActivity(
                    this@InspectionFragment.requireContext(),
                    isFromInspection = true
                )
            }
        }
        ivClearSearch.setOnClickListener {
            etSearchToolbar.setText("")
            manageSearchLayout(false)
            viewModel.searchQuery = null
            viewModel.getInspectionData()
        }
    }

    private fun setupView() {
        (activity as MainActivity).closeFabMenu()
        (activity as MainActivity).manageFloatingButtonAdd(true)
        toolbarMenu =
            ArrayList(listOf(*resources.getStringArray(R.array.filter_inspection_menu_auditor)))
        toolbarMenuAdapter = ToolbarMenuAdapter(arrayListOf())
        rvInspectionMenuFilter.run {
            layoutManager = LinearLayoutManager(context, RecyclerView.HORIZONTAL, false)
            adapter = toolbarMenuAdapter
        }
        toolbarMenuAdapter.setSelectedMenuPosition(FIRST_INDEX)
        toolbarMenuAdapter.addData(toolbarMenu)

        toolbarMenuAdapter.setListener(object :
            ToolbarMenuAdapter.OnToolbarMenuInteractionListener {
            override fun onMenuItemClicked(menuPosition: Int) {
                toolbarMenuAdapter.setSelectedMenuPosition(menuPosition)
                onClickFilterMenuItem(menuPosition)
            }
        })
        etSearchToolbar.setOnKeyListener { _, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_UP) {
                if (etSearchToolbar.text.toString().isNotEmpty()) {
                    viewModel.searchQuery = etSearchToolbar.text.toString()
                } else {
                    viewModel.searchQuery = null
                }
                viewModel.getInspectionData()
            }
            false
        }
        swipeRefresh.setOnRefreshListener {
            viewModel.selectedRegionId = null
            viewModel.selectedLocationId = null
            viewModel.getInspectionData()
        }
    }

    private fun setupRv() {
        inspectionAdapter = InspectionAdapter()
        inspectionAdapter?.setInspectionClickListener(this)
        val manager = LinearLayoutManager(activity)
        rvInspection.apply {
            layoutManager = manager
            setHasFixedSize(true)
            adapter = inspectionAdapter
        }
    }

    private fun observeInspectionList() {
        observeData(viewModel.inspectionList) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { data ->
                            if (data.isNotEmpty()) {
                                viewModel.showEmptyState.value = false
                                inspectionAdapter?.setData(data)
                            } else {
                                viewModel.showEmptyState.value = true
                                tvEmptyMessage.text = getString(R.string.issues_empty)
                            }
                        }
                    }
                    NetworkState.ERROR -> {
                        when (it.code) {
                            401 -> {
                                SnackBar.snackBarShowError(
                                    requireContext(),
                                    parentLayout,
                                    it.message
                                        ?: getString(R.string.general_server_error_message)
                                )
                                viewModel.preference.clearPreferences()
                                logout(Intent(context, LoginActivity::class.java))
                            }
                            404 -> {
                                tvEmptyMessage.text = it.message
                                viewModel.showEmptyState.value = true
                                inspectionAdapter?.removeAllData()
                            }
                            else -> {
                                SnackBar.snackBarShowError(
                                    requireContext(),
                                    parentLayout,
                                    getString(R.string.general_server_error_message)
                                )
                                inspectionAdapter?.removeAllData()
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onClickFilterMenuItem(menuPosition: Int) {
        if (inspectionFilterQuery.userTypeId == CommonConstant.USER_TYPE_AUDITOR_ID) {
            viewModel.selectedStatusId = menuPosition + 1
        } else if (inspectionFilterQuery.userTypeId == CommonConstant.USER_TYPE_AUDITEE_ID) {
            viewModel.selectedStatusId =
                if (menuPosition == FIRST_INDEX) InspectionViewModel.NEED_APPROVAL_ID else InspectionViewModel.COMPLETED_ID
        }
        viewModel.selectedUserTypeId = inspectionFilterQuery.userTypeId
        viewModel.getInspectionData()
    }

    override fun onClickFilterInspection(view: View) {
        val intent = Intent(activity, InspectionFilterActivity::class.java)
        filterLauncher.launch(intent)
    }

    private fun manageSearchLayout(isShow: Boolean) {
        tvTitleToolbar.visibility = if (isShow) View.GONE else View.VISIBLE
        menuAction1.visibility = if (isShow) View.GONE else View.VISIBLE
        etSearchToolbar.visibility = if (isShow) View.VISIBLE else View.GONE
        ivClearSearch.visibility = if (isShow) View.VISIBLE else View.GONE
    }

    override fun onStart() {
        super.onStart()
        EventBus.getDefault().register(this)
    }

    override fun onStop() {
        super.onStop()
        EventBus.getDefault().unregister(this)
    }

    @Subscribe(sticky = true, threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: StartInspectionActivityEvent) {
        val intent = Intent(activity, CreateInspectionActivity::class.java)
        newInspectionLauncher.launch(intent)
        EventBus.getDefault().removeStickyEvent(event)
    }

    override fun onClickInspection(
        inspectionId: String,
        location: AuditLocationModel.AuditLocation?,
        startDate: String,
        statusId: Int
    ) {
        if (statusId == InspectionViewModel.COMPLETED_ID) {
            ReportInspectionActivity.startThisActivity(requireContext(), inspectionId)
        } else {
            StartInspectionActivity.startThisActivity(
                requireContext(),
                inspectionId,
                location?.name.orEmpty(),
                startDate
            )
        }
    }

}
