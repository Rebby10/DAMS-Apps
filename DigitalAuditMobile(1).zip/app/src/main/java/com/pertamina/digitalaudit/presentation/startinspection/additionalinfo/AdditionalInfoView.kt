package com.pertamina.digitalaudit.presentation.startinspection.additionalinfo

import android.view.View
import com.pertamina.framework.base.BaseView

interface AdditionalInfoView : BaseView {
    fun onClickAddNote(view: View)
    fun onClickAddSignature(view: View)
    fun onClickAddSave(view: View)
}