package com.pertamina.digitalaudit.model

import com.google.gson.annotations.SerializedName
import com.pertamina.framework.base.BaseResponse

class ScheduleModel : BaseResponse() {

    @SerializedName("Result")
    var data: List<Schedule>? = null

    class Schedule {
        @SerializedName("ScheduleId")
        var scheduleId: String? = ""

        @SerializedName("StartDate")
        var startDate: String? = ""

        @SerializedName("EndDate")
        var endDate: String? = ""

        @SerializedName("AuditLocation")
        var auditLocation: AuditLocationModel.AuditLocation? = null

        @SerializedName("Template")
        var template: TemplateModel.Template? = null

        @SerializedName("Status")
        var status: StatusModel.Status? = null

        @SerializedName("Auditor")
        var auditor: AuditorModel.Auditor? = null

        @SerializedName("Auditee")
        var auditee: AuditeeModel.Auditee? = null
    }
}
