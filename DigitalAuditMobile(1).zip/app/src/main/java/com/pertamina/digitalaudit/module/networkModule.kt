package com.pertamina.digitalaudit.module

import com.ashokvarma.gander.GanderInterceptor
import com.google.gson.GsonBuilder
import com.pertamina.digitalaudit.BuildConfig
import com.pertamina.digitalaudit.preference.PreferenceProvider
import com.pertamina.digitalaudit.preference.SharedPreferencesKey
import com.pertamina.digitalaudit.repository.actions.ActionsService
import com.pertamina.digitalaudit.repository.common.CommonService
import com.pertamina.digitalaudit.repository.inspection.InspectionService
import com.pertamina.digitalaudit.repository.issues.IssuesService
import com.pertamina.digitalaudit.repository.login.LoginService
import com.pertamina.digitalaudit.repository.login.UserProfileSSOService
import com.pertamina.digitalaudit.repository.schedule.ScheduleService
import com.pertamina.framework.ResponseHandler
import okhttp3.Credentials
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Request
import org.koin.android.ext.koin.androidContext
import org.koin.core.qualifier.named
import org.koin.dsl.module
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

private const val CONNECT_TIMEOUT = 10L
private const val BASE_URL = BuildConfig.BASE_URL
private const val IDAMAN_URL = BuildConfig.IDAMAN_ISSUER
private const val IDAMAN_URL_RETROFIT = "IDAMAN_URL_RETROFIT"
private const val BASE_URL_RETROFIT = "BASE_URL_RETROFIT"
private const val IDAMAN_URL_CLIENT = "IDAMAN_URL_CLIENT"
private const val BASE_URL_CLIENT = "BASE_URL_CLIENT"

private const val TIMEOUT: Long = 60
val networkModule = module {
    single { GsonBuilder().create() }

    single(named(IDAMAN_URL_CLIENT)) {
        OkHttpClient.Builder().apply {
            connectTimeout(TIMEOUT, TimeUnit.SECONDS)
            writeTimeout(TIMEOUT, TimeUnit.SECONDS)
            readTimeout(TIMEOUT, TimeUnit.SECONDS)
            cache(null)
            addInterceptor(GanderInterceptor(androidContext()).showNotification(true))
            addInterceptor { chain ->
                val request = requestBuilderIdamanIssuer(chain, get())
                chain.proceed(request)
            }
        }.build()
    }

    single(named(BASE_URL_CLIENT)) {
        OkHttpClient.Builder().apply {
            connectTimeout(TIMEOUT, TimeUnit.SECONDS)
            writeTimeout(TIMEOUT, TimeUnit.SECONDS)
            readTimeout(TIMEOUT, TimeUnit.SECONDS)
            cache(null)
            addInterceptor(GanderInterceptor(androidContext()).showNotification(true))
            addInterceptor { chain ->
                val request = requestBuilderBaseUrl(chain, get())
                chain.proceed(request)
            }
        }.build()
    }

    single<Retrofit>(named(BASE_URL_RETROFIT)) {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create(get()))
            .client(get(named(BASE_URL_CLIENT)))
            .build()
    }

    single<Retrofit>(named(IDAMAN_URL_RETROFIT)) {
        Retrofit.Builder()
                .baseUrl(IDAMAN_URL)
                .addConverterFactory(GsonConverterFactory.create(get()))
                .client(get(named(IDAMAN_URL_CLIENT)))
                .build()
    }

    factory { get<Retrofit>(named(BASE_URL_RETROFIT)).create(IssuesService::class.java) }
    factory { get<Retrofit>(named(BASE_URL_RETROFIT)).create(LoginService::class.java) }
    factory { get<Retrofit>(named(IDAMAN_URL_RETROFIT)).create(UserProfileSSOService::class.java) }
    factory { get<Retrofit>(named(BASE_URL_RETROFIT)).create(CommonService::class.java) }
    factory { get<Retrofit>(named(BASE_URL_RETROFIT)).create(ActionsService::class.java) }
    factory { get<Retrofit>(named(BASE_URL_RETROFIT)).create(ScheduleService::class.java) }
    factory { get<Retrofit>(named(BASE_URL_RETROFIT)).create(InspectionService::class.java) }
    factory { ResponseHandler() }
}

private fun requestBuilderIdamanIssuer(
    chain: Interceptor.Chain,
    preferenceProvider: PreferenceProvider
): Request {
    val original = chain.request()
    val token = preferenceProvider.getStringFromPreference(SharedPreferencesKey.ACCESS_TOKEN)
    return original.newBuilder()
        .header("Authorization", "Bearer $token")
        .build()
}

private fun requestBuilderBaseUrl(
    chain: Interceptor.Chain,
    preferenceProvider: PreferenceProvider
): Request {
    val original = chain.request()
    val username = preferenceProvider.getStringFromPreference(SharedPreferencesKey.USER_NAME) ?: ""
    val sub = preferenceProvider.getStringFromPreference(SharedPreferencesKey.SUB) ?: ""
    val accessToken = Credentials.basic(username, sub)
    return original.newBuilder()
        .header("Authorization", accessToken)
        .build()
}
