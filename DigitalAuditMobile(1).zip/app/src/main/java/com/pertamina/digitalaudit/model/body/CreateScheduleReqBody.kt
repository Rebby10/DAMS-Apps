package com.pertamina.digitalaudit.model.body

import com.google.gson.annotations.SerializedName

data class CreateScheduleReqBody(
    @SerializedName("AuditLocationId")
    var auditLocationId: String,
    @SerializedName("StartDate")
    var startDate: String,
    @SerializedName("EndDate")
    var endDate: String,
    @SerializedName("TemplateId")
    var templateId: String,
    @SerializedName("Auditor")
    var auditor: Auditor?,
    @SerializedName("Auditee")
    var auditee: Auditee
)

data class Auditor(
    @SerializedName("UserId")
    var userSyncId: String?,
    @SerializedName("UserGroupId")
    var userGroupId: String?
)

data class Auditee(
    @SerializedName("UserId")
    var userSyncId: String?,
    @SerializedName("UserGroupId")
    var userGroupId: String?
)
