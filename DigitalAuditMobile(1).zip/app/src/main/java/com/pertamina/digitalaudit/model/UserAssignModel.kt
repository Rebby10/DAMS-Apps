package com.pertamina.digitalaudit.model

import com.google.gson.annotations.SerializedName
import com.pertamina.framework.base.BaseResponse
import java.io.Serializable

class UserAssignModel : BaseResponse() {

    @SerializedName("Result")
    var data: List<UserAssign>? = null

    class UserAssign : Serializable, BaseItem() {
        @SerializedName("Id")
        var id: String? = ""

        @SerializedName("DisplayName")
        var displayName: String? = ""

        @SerializedName("IsGroup")
        var isGroup: Boolean? = false
    }
}
