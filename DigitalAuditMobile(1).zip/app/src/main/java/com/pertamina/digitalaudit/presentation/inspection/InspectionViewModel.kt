package com.pertamina.digitalaudit.presentation.inspection

import androidx.lifecycle.MutableLiveData
import com.pertamina.digitalaudit.model.InspectionModel
import com.pertamina.digitalaudit.model.UserModel
import com.pertamina.digitalaudit.model.query.GetInspectionQuery
import com.pertamina.digitalaudit.preference.PreferenceProvider
import com.pertamina.digitalaudit.repository.inspection.InspectionRepository
import com.pertamina.digitalaudit.util.CommonConstant
import com.pertamina.framework.base.BaseViewModel
import com.pertamina.framework.base.Resource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class InspectionViewModel(
    private val inspectionRepository: InspectionRepository,
    val preference: PreferenceProvider
) : BaseViewModel() {

    companion object {
        const val SCHEDULED_ID = 1
        const val ON_PROGRESS_ID = 2
        const val NEED_APPROVAL_ID = 3
        const val COMPLETED_ID = 4
    }

    val showProgressBar = MutableLiveData(false)
    val showEmptyState = MutableLiveData(false)

    val inspectionList = MutableLiveData<Resource<List<InspectionModel.Inspection>>>()

    var selectedStatusId = SCHEDULED_ID
    var selectedUserTypeId = CommonConstant.USER_TYPE_AUDITOR_ID
    var selectedRegionId: String? = null
    var selectedLocationId: String? = null
    var searchQuery: String? = null
    var user = UserModel.User()

    init {
        getUserData()
    }

    private fun getUserData() {
        launch {
            withContext(Dispatchers.IO) {
                user = preference.getAuthPreferences()
            }
            getInspectionData()
        }
    }

    fun getInspectionData() {
        showProgressBar.value = true
        val query = GetInspectionQuery().apply {
            statusId = selectedStatusId
            userTypeId = selectedUserTypeId
            userCreated = user.userId
            regionId = selectedRegionId
            textSearch = searchQuery
            auditLocationId = selectedLocationId
        }
        launch {
            val request = inspectionRepository.getInspectionList(query)
            inspectionList.value = request
            showProgressBar.value = false
        }
    }

}
