package com.pertamina.digitalaudit.module

import com.pertamina.digitalaudit.model.body.SortAndFilterReqBody
import com.pertamina.digitalaudit.model.query.GetActionQuery
import com.pertamina.digitalaudit.model.query.GetInspectionQuery
import org.koin.dsl.module

/**
 * @author Asadurrahman Al Qayyim
 * @date 3/30/2021
 */

val customObjectModule = module {
    single { SortAndFilterReqBody() }
    single { GetActionQuery() }
    single { GetInspectionQuery() }
}
