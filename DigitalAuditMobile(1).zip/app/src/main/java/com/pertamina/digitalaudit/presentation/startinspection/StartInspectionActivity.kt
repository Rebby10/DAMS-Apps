package com.pertamina.digitalaudit.presentation.startinspection

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.databinding.ActivityStartInspectionBinding
import com.pertamina.digitalaudit.model.AuditeeModel
import com.pertamina.digitalaudit.model.AuditorModel
import com.pertamina.digitalaudit.presentation.login.LoginActivity
import com.pertamina.digitalaudit.presentation.main.MainActivity
import com.pertamina.digitalaudit.presentation.reportinspection.ReportInspectionActivity
import com.pertamina.digitalaudit.presentation.sheet.CommonOptionsSheet
import com.pertamina.digitalaudit.presentation.startinspection.additionalinfo.AdditionalInfoActivity
import com.pertamina.digitalaudit.presentation.startinspection.startpage.StartPageFragment
import com.pertamina.digitalaudit.util.SnackBar
import com.pertamina.framework.NetworkState
import com.pertamina.framework.ViewDataBindingOwner
import com.pertamina.framework.base.BaseActivity
import com.pertamina.framework.util.DateHelper
import kotlinx.android.synthetic.main.activity_start_inspection.*
import kotlinx.android.synthetic.main.toolbar_layout.*
import org.koin.androidx.viewmodel.ext.android.viewModel

class StartInspectionActivity : BaseActivity<StartInspectionViewModel>(), StartInspectionView,
    ViewDataBindingOwner<ActivityStartInspectionBinding> {

    override val layoutResourceId: Int = R.layout.activity_start_inspection
    override val viewModel: StartInspectionViewModel by viewModel()
    override var binding: ActivityStartInspectionBinding? = null

    private var menuBottomSheet: CommonOptionsSheet? = null
    private lateinit var menuList: MutableList<CommonOptionsSheet.BottomSheetMenuModel>
    private val actionsMenu: Array<String> by lazy {
        resources.getStringArray(R.array.start_inspection_actions_menu)
    }

    companion object {
        private const val EXTRA_INSPECTION_ID = "EXTRA_INSPECTION_ID"
        private const val EXTRA_INSPECTION_LOCATION = "EXTRA_INSPECTION_LOCATION"
        private const val EXTRA_INSPECTION_START_DATE = "EXTRA_INSPECTION_START_DATE"

        fun startThisActivity(
            context: Context,
            inspectionId: String,
            inspectionLocation: String,
            inspectionDate: String
        ) {
            val intent = Intent(context, StartInspectionActivity::class.java)
            intent.putExtra(EXTRA_INSPECTION_ID, inspectionId)
            intent.putExtra(EXTRA_INSPECTION_LOCATION, inspectionLocation)
            intent.putExtra(EXTRA_INSPECTION_START_DATE, inspectionDate)
            context.startActivity(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        getExtraData()
        setupToolbar()
        observeStartInspection()
        observeStartInspectionListPage()
        observeInspectionCompletedResponse()
    }

    private fun getExtraData() {
        viewModel.inspectionLocation = intent?.getStringExtra(EXTRA_INSPECTION_LOCATION)
        viewModel.inspectionDate = DateHelper.changeFormat(
            intent?.getStringExtra(EXTRA_INSPECTION_START_DATE).orEmpty(),
            DateHelper.yyyy_MM_dd_T_HHmmss,
            DateHelper.dd_MMM_yyyy_hh_mm_a
        )
        viewModel.inspectionId = intent?.getStringExtra(EXTRA_INSPECTION_ID)
        viewModel.getStartInspectionListPage()
        viewModel.getStartInspection()
    }

    private fun setupToolbar() {
        tvTitleToolbar.text = intent?.getStringExtra(EXTRA_INSPECTION_LOCATION)
            ?: getString(R.string.start_inspection_label)
        menuAction1.apply {
            visibility = View.VISIBLE
            setImageResource(R.drawable.ic_more)
            setOnClickListener {
                showMenuBottomSheet()
            }
        }
        btnBackToolbar.apply {
            visibility = View.VISIBLE
            setImageResource(R.drawable.ic_back)
            setOnClickListener {
                onBackPressed()
            }
        }
    }

    private fun observeStartInspection() {
        observeData(viewModel.startInspectionResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { data ->
                            changeMainFragmentContent(StartPageFragment().newInstance())
                            data.data?.inspection?.let { inspection ->
                                viewModel.inspectionAuditorName = getAuditor(inspection.auditor)
                                viewModel.inspectionAuditeeName = getAuditee(inspection.auditee)
                            }
                        }
                    }
                    NetworkState.ERROR -> {
                        when (it.code) {
                            401 -> {
                                SnackBar.snackBarShowError(
                                    this,
                                    parentLayout,
                                    it.message
                                        ?: getString(R.string.general_server_error_message)
                                )
                                viewModel.preference.clearPreferences()
                                logout(Intent(this, LoginActivity::class.java))
                            }
                            else -> {
                                SnackBar.snackBarShowError(
                                    this,
                                    parentLayout,
                                    getString(R.string.general_server_error_message)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    private fun observeStartInspectionListPage() {
        observeData(viewModel.startInspectionListPageResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        //do nothing
                    }
                    NetworkState.ERROR -> {
                        when (it.code) {
                            401 -> {
                                SnackBar.snackBarShowError(
                                    this,
                                    parentLayout,
                                    it.message
                                        ?: getString(R.string.general_server_error_message)
                                )
                                viewModel.preference.clearPreferences()
                                logout(Intent(this, LoginActivity::class.java))
                            }
                            else -> {
                                SnackBar.snackBarShowError(
                                    this,
                                    parentLayout,
                                    getString(R.string.general_server_error_message)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    private fun observeInspectionCompletedResponse() {
        observeData(viewModel.inspectionCompletedResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        navigateToHome()
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message
                                ?: getString(R.string.general_server_error_message)
                        )
                    }
                }
            }
        }
    }

    private fun changeMainFragmentContent(fragment: Fragment, addToBackStack: Boolean = false) {
        if (addToBackStack) {
            supportFragmentManager
                .beginTransaction()
                .replace(R.id.flStartInspectionContainer, fragment)
                .addToBackStack(fragment::class.java.simpleName)
                .commit()
        } else {
            supportFragmentManager
                .beginTransaction()
                .replace(R.id.flStartInspectionContainer, fragment)
                .commit()
        }
    }

    private fun showMenuBottomSheet() {
        menuList = mutableListOf()
        menuList.clear()
        val actionsMenuIcon = resources.obtainTypedArray(R.array.start_inspection_actions_menu_icon)
        for (position in actionsMenu.indices) {
            menuList.add(
                CommonOptionsSheet.BottomSheetMenuModel(
                    actionsMenuIcon.getResourceId(position, 0), 0,
                    actionsMenu[position]
                )
            )
        }
        actionsMenuIcon.recycle()
        menuBottomSheet = CommonOptionsSheet(this, menuList).apply {
            setCancelable(true)
            setMenuItemListener(object : CommonOptionsSheet.MenuItemClickListener {
                override fun onBottomSheetItemClicked(menu: String, id: Int) {
                    handleBottomSheetItemClicked(menu)
                }
            })
        }
        menuBottomSheet?.show()
    }

    private fun handleBottomSheetItemClicked(menu: String) {
        when (menu) {
            getString(R.string.inspection_menu_save_progress) -> {
                menuBottomSheet?.dismiss()
                viewModel.saveInProgressClicked.value = true
                //navigateToHome()
            }
            getString(R.string.inspection_menu_mark_complete) -> {
                menuBottomSheet?.dismiss()
                viewModel.markInspectionAsComplete()
            }
            getString(R.string.inspection_menu_additional_info) -> {
                menuBottomSheet?.dismiss()
                AdditionalInfoActivity.startThisActivity(this, viewModel.inspectionId.orEmpty())
            }
            getString(R.string.inspection_menu_view_report) -> {
                menuBottomSheet?.dismiss()
                ReportInspectionActivity.startThisActivity(this, viewModel.inspectionId.orEmpty())
            }
        }
    }

    private fun navigateToHome() {
        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK
        intent.putExtra(MainActivity.EXTRA_FROM_COMPLETE_INSPECTION, true)
        startActivity(intent)
    }

    private fun getAuditee(auditee: AuditeeModel.Auditee?): String {
        auditee?.users?.name?.let {
            return it
        }
        auditee?.groups?.officialName?.let {
            return it
        }
        return ""
    }

    private fun getAuditor(auditor: AuditorModel.Auditor?): String {
        auditor?.users?.name?.let {
            return it
        }
        auditor?.groups?.officialName?.let {
            return it
        }
        return ""
    }
}
