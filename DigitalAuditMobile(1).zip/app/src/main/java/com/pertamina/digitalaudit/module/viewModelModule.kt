package com.pertamina.digitalaudit.module

import com.pertamina.digitalaudit.presentation.account.AccountViewModel
import com.pertamina.digitalaudit.presentation.action.ActionViewModel
import com.pertamina.digitalaudit.presentation.actiondetail.ActionDetailViewModel
import com.pertamina.digitalaudit.presentation.actionofissue.ActionOfIssueViewModel
import com.pertamina.digitalaudit.presentation.actionrepair.ActionRepairViewModel
import com.pertamina.digitalaudit.presentation.chat.ChatViewModel
import com.pertamina.digitalaudit.presentation.createaction.CreateActionViewModel
import com.pertamina.digitalaudit.presentation.createinspection.CreateInspectionViewModel
import com.pertamina.digitalaudit.presentation.createissue.CreateIssueViewModel
import com.pertamina.digitalaudit.presentation.createschedule.CreateScheduleViewModel
import com.pertamina.digitalaudit.presentation.guide.GuideViewModel
import com.pertamina.digitalaudit.presentation.home.HomeViewModel
import com.pertamina.digitalaudit.presentation.inspection.InspectionViewModel
import com.pertamina.digitalaudit.presentation.inspectionfilter.InspectionFilterViewModel
import com.pertamina.digitalaudit.presentation.issuedetails.IssueDetailViewModel
import com.pertamina.digitalaudit.presentation.issues.IssuesViewModel
import com.pertamina.digitalaudit.presentation.login.LoginViewModel
import com.pertamina.digitalaudit.presentation.main.MainViewModel
import com.pertamina.digitalaudit.presentation.map.MapViewModel
import com.pertamina.digitalaudit.presentation.notification.NotificationViewModel
import com.pertamina.digitalaudit.presentation.reportinspection.ReportInspectionViewModel
import com.pertamina.digitalaudit.presentation.scheduledetail.ScheduleDetailViewModel
import com.pertamina.digitalaudit.presentation.search.SearchViewModel
import com.pertamina.digitalaudit.presentation.sortandfilter.SortAndFilterViewModel
import com.pertamina.digitalaudit.presentation.splashscreen.SplashScreenViewModel
import com.pertamina.digitalaudit.presentation.startinspection.StartInspectionViewModel
import com.pertamina.digitalaudit.presentation.startinspection.actionpage.ActionsViewModel
import com.pertamina.digitalaudit.presentation.startinspection.additionalinfo.AdditionalInfoViewModel
import com.pertamina.digitalaudit.presentation.startinspection.startpage.StartPageViewModel
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module

val viewModelModule = module {
    viewModel { MainViewModel(get()) }
    viewModel { HomeViewModel(get(), get()) }
    viewModel { InspectionViewModel(get(), get()) }
    viewModel { IssuesViewModel(get(), get()) }
    viewModel { ActionViewModel(get(), get()) }
    viewModel { AccountViewModel(get()) }
    viewModel { CreateScheduleViewModel(get(), get()) }
    viewModel { MapViewModel(get(), get()) }
    viewModel { SortAndFilterViewModel(get(), get(), get(), get(), get()) }
    viewModel { CreateIssueViewModel(get(), get(), get()) }
    viewModel { IssueDetailViewModel(get(), get()) }
    viewModel { NotificationViewModel() }
    viewModel { ScheduleDetailViewModel(get(), get()) }
    viewModel { ChatViewModel(get(), get(), get()) }
    viewModel { LoginViewModel(get(), get()) }
    viewModel { SplashScreenViewModel(get()) }
    viewModel { CreateActionViewModel(get(), get(), get()) }
    viewModel { SearchViewModel(get(), get(), get(), get()) }
    viewModel { ActionDetailViewModel(get(), get()) }
    viewModel { ActionRepairViewModel(get(), get(), get()) }
    viewModel { GuideViewModel() }
    viewModel { CreateInspectionViewModel(get(), get()) }
    viewModel { ReportInspectionViewModel(get()) }
    viewModel { StartInspectionViewModel(get(), get()) }
    viewModel { ActionsViewModel(get()) }
    viewModel { InspectionFilterViewModel(get()) }
    viewModel { StartPageViewModel(get(), get()) }
    viewModel { AdditionalInfoViewModel(get(), get()) }
    viewModel { ActionOfIssueViewModel(get()) }
}
