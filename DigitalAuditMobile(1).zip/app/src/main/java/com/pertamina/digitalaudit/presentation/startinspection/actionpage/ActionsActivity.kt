package com.pertamina.digitalaudit.presentation.startinspection.actionpage

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.recyclerview.widget.LinearLayoutManager
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.databinding.ActivityActionPageBinding
import com.pertamina.digitalaudit.presentation.createaction.CreateActionActivity
import com.pertamina.digitalaudit.presentation.startinspection.actionpage.adapter.InspectionActionAdapter
import com.pertamina.digitalaudit.util.SnackBar
import com.pertamina.framework.NetworkState
import com.pertamina.framework.ViewDataBindingOwner
import com.pertamina.framework.base.BaseActivity
import kotlinx.android.synthetic.main.activity_action_page.*
import kotlinx.android.synthetic.main.layout_empty_state.*
import kotlinx.android.synthetic.main.toolbar_layout.*
import org.koin.androidx.viewmodel.ext.android.viewModel

class ActionsActivity : BaseActivity<ActionsViewModel>(), ActionsView,
    ViewDataBindingOwner<ActivityActionPageBinding> {

    override val layoutResourceId: Int = R.layout.activity_action_page
    override val viewModel: ActionsViewModel by viewModel()
    override var binding: ActivityActionPageBinding? = null

    private var actionAdapter: InspectionActionAdapter? = null

    private var newActionInspectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                viewModel.getActionsList()
            }
        }

    companion object {
        private const val EXTRA_INSPECTION_ID = "EXTRA_INSPECTION_ID"
        private const val EXTRA_QUESTION_ID = "EXTRA_QUESTION_ID"
        private const val EXTRA_FROM_REPORT = "EXTRA_FROM_REPORT"

        fun startThisActivity(
            context: Context,
            inspectionId: String,
            questionId: String,
            isFromReport: Boolean = false
        ) {
            val intent = Intent(context, ActionsActivity::class.java)
            intent.putExtra(EXTRA_INSPECTION_ID, inspectionId)
            intent.putExtra(EXTRA_QUESTION_ID, questionId)
            intent.putExtra(EXTRA_FROM_REPORT, isFromReport)
            context.startActivity(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        getExtraData()
        setupToolbar()
        setupRv()
        observeActionList()
        observeDeletedAction()
    }

    private fun getExtraData() {
        viewModel.inspectionId = intent?.getStringExtra(EXTRA_INSPECTION_ID)
        viewModel.questionId = intent?.getStringExtra(EXTRA_QUESTION_ID)
        viewModel.isFromReport.value = intent?.getBooleanExtra(EXTRA_FROM_REPORT, false) ?: false
        viewModel.getActionsList()
    }

    private fun setupToolbar() {
        tvTitleToolbar.text = getString(R.string.inspection_actions)
        btnBackToolbar.apply {
            visibility = View.VISIBLE
            setImageResource(R.drawable.ic_close)
            setOnClickListener {
                onBackPressed()
            }
        }
    }

    private fun setupRv() {
        actionAdapter = InspectionActionAdapter()
        actionAdapter?.setIsFromReport(viewModel.isFromReport.value ?: false)
        actionAdapter?.setDeleteActionClickListener(object :
            InspectionActionAdapter.DeleteActionClickListener {
            override fun onClickDeleteAction(actionsId: String) {
                viewModel.deleteSelectedAction(actionsId)
            }
        })
        val manager = LinearLayoutManager(this)
        rvActions.apply {
            layoutManager = manager
            setHasFixedSize(true)
            adapter = actionAdapter
        }
    }

    private fun observeActionList() {
        observeData(viewModel.actionsResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { data ->
                            if (data.isNotEmpty()) {
                                viewModel.showEmptyState.value = false
                                actionAdapter?.setData(data)
                            } else {
                                viewModel.showEmptyState.value = true
                                tvEmptyMessage.text = getString(R.string.actions_empty)
                            }
                        }
                    }
                    NetworkState.ERROR -> {
                        when (it.code) {
                            404 -> {
                                viewModel.showEmptyState.value = true
                                actionAdapter?.removeAllData()
                            }
                            else -> {
                                SnackBar.snackBarShowError(
                                    this,
                                    parentLayout,
                                    it.message
                                        ?: getString(R.string.general_server_error_message)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    private fun observeDeletedAction() {
        observeData(viewModel.deletedActionResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        SnackBar.snackBarShowSuccess(
                            this,
                            parentLayout,
                            it.message ?: getString(R.string.deleted_data_message)
                        )
                        viewModel.deletedActionResponse.value = null
                        viewModel.getActionsList()
                    }
                    NetworkState.ERROR -> {
                        SnackBar.snackBarShowError(
                            this,
                            parentLayout,
                            it.message ?: getString(R.string.general_server_error_message)
                        )
                    }
                }
            }
        }
    }

    override fun onClickAdd(view: View) {
        val intent = Intent(this, CreateActionActivity::class.java)
        intent.putExtra(CreateActionActivity.EXTRA_INSPECTION_ID, viewModel.inspectionId)
        intent.putExtra(CreateActionActivity.EXTRA_QUESTION_ID, viewModel.questionId)
        newActionInspectionLauncher.launch(intent)
    }
}
