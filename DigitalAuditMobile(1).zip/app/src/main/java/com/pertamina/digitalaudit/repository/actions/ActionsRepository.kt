package com.pertamina.digitalaudit.repository.actions

import com.pertamina.digitalaudit.model.*
import com.pertamina.digitalaudit.model.body.*
import com.pertamina.digitalaudit.model.query.GetActionQuery
import com.pertamina.framework.base.BaseResponse
import com.pertamina.framework.base.Resource
import okhttp3.ResponseBody
import java.io.File

interface ActionsRepository {

    @Throws(Exception::class)
    suspend fun getActionList(actionQuery: GetActionQuery?): Resource<List<ActionModel.Action>>

    @Throws(Exception::class)
    suspend fun deleteAction(actionId: String): Resource<ActionModel>

    @Throws(Exception::class)
    suspend fun createNewAction(reqBody: CreateActionReqBody): Resource<ActionModel>

    @Throws(Exception::class)
    suspend fun getActionDetail(actionId: String): Resource<ActionDetailModel>

    @Throws(Exception::class)
    suspend fun updateAction(reqBody: UpdateActionReqBody): Resource<ActionModel>

    @Throws(Exception::class)
    suspend fun getActionLog(actionId: String): Resource<List<LogModel.Log>>

    @Throws(Exception::class)
    suspend fun sendLogChat(logReqBody: ActionLogReqBody): Resource<BaseResponse>

    @Throws(Exception::class)
    suspend fun getAssigneeByName(name: String?, pageSize: Int?, pageNumber: Int?): Resource<List<UserAssignModel.UserAssign>>

    @Throws(Exception::class)
    suspend fun getIssueStatus(): Resource<List<IssueStatusModel.IssueStatus>>

    @Throws(Exception::class)
    suspend fun updateActionStatus(reqBody: UpdateActionStatusReqBody): Resource<ActionModel>

    @Throws(Exception::class)
    suspend fun saveActionRepair(
        reqBody: ActionRepairReqBody,
        file: File
    ): Resource<ActionRepairModel>

    @Throws(Exception::class)
    suspend fun sendLogChatFile(
        actionId: String,
        userCreated: String,
        file: File
    ): Resource<BaseResponse>

    @Throws(Exception::class)
    suspend fun downloadFile(fileUrl: String): Resource<ResponseBody>
}
