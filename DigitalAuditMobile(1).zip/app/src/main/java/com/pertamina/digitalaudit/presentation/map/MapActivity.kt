package com.pertamina.digitalaudit.presentation.map

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.widget.RelativeLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.databinding.ActivityMapBinding
import com.pertamina.digitalaudit.model.AuditLocationModel
import com.pertamina.digitalaudit.model.InspectionModel
import com.pertamina.digitalaudit.model.IssueModel
import com.pertamina.digitalaudit.model.Reschedule
import com.pertamina.digitalaudit.model.ScheduleModel
import com.pertamina.digitalaudit.presentation.home.adapter.InspectionAdapter
import com.pertamina.digitalaudit.presentation.home.adapter.IssuesAdapter
import com.pertamina.digitalaudit.presentation.home.adapter.RescheduleAdapter
import com.pertamina.digitalaudit.presentation.home.adapter.ScheduleAdapter
import com.pertamina.digitalaudit.presentation.issues.IssuesViewModel
import com.pertamina.digitalaudit.presentation.login.LoginActivity
import com.pertamina.digitalaudit.presentation.map.adapter.ToolbarMenuAdapter
import com.pertamina.digitalaudit.presentation.scheduledetail.ScheduleDetailActivity
import com.pertamina.digitalaudit.util.SnackBar
import com.pertamina.digitalaudit.util.ViewUtils
import com.pertamina.framework.NetworkState
import com.pertamina.framework.ViewDataBindingOwner
import com.pertamina.framework.base.BaseActivity
import com.pertamina.framework.util.toPx
import kotlinx.android.synthetic.main.activity_map.*
import kotlinx.android.synthetic.main.layout_empty_state.*
import kotlinx.android.synthetic.main.toolbar_map_layout.*
import org.koin.androidx.viewmodel.ext.android.viewModel
import java.util.*


/**
 * Created by M Hafidh Abdul Aziz on 11/03/21.
 */

class MapActivity : BaseActivity<MapViewModel>(), MapView,
    ViewDataBindingOwner<ActivityMapBinding>, OnMapReadyCallback {

    override val layoutResourceId: Int = R.layout.activity_map
    override val viewModel: MapViewModel by viewModel()
    override var binding: ActivityMapBinding? = null

    private lateinit var toolbarMenuAdapter: ToolbarMenuAdapter
    private var issuesAdapter: IssuesAdapter? = null
    private var scheduleAdapter: ScheduleAdapter? = null
    private var rescheduleAdapter: RescheduleAdapter? = null
    private var inspectionAdapter: InspectionAdapter? = null

    private lateinit var map: GoogleMap
    private var markers: ArrayList<Marker> = ArrayList()
    private lateinit var sheetBehavior: BottomSheetBehavior<RelativeLayout>

    private var selectedMarkerLatitude = 0.0
    private var selectedMarkerLongitude = 0.0
    private var selectedMarkerAddress: String? = null
    private var selectedMenuPosition = 0
    private var isFromIssue = false
    private var isFromSchedule = false
    private var isFromInspection = false

    companion object {
        private const val MAPS_ZOOM_LEVEL = 13f
        private const val EXTRA_SELECTED_MENU_POSITION = "EXTRA_SELECTED_MENU_POSITION"
        private const val EXTRA_FROM_ISSUE = "EXTRA_FROM_ISSUE"
        private const val EXTRA_FROM_SCHEDULE = "EXTRA_FROM_SCHEDULE"
        private const val EXTRA_FROM_INSPECTION = "EXTRA_FROM_INSPECTION"

        fun startThisActivity(
            context: Context,
            selectedMenuPosition: Int = 0,
            isFromSchedule: Boolean = false,
            isFromIssue: Boolean = false,
            isFromInspection: Boolean = false
        ) {
            val intent = Intent(context, MapActivity::class.java)
            intent.putExtra(EXTRA_SELECTED_MENU_POSITION, selectedMenuPosition)
            intent.putExtra(EXTRA_FROM_ISSUE, isFromIssue)
            intent.putExtra(EXTRA_FROM_SCHEDULE, isFromSchedule)
            intent.putExtra(EXTRA_FROM_INSPECTION, isFromInspection)
            context.startActivity(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        getExtras()
        setupToolbar()
        setupBottomSheet()
        setupMap()
        setupRv()
        observeIssueList()
        observeScheduleList()
        observeRescheduleList()
        observeInspectionList()
    }

    private fun getExtras() {
        selectedMenuPosition = intent?.getIntExtra(EXTRA_SELECTED_MENU_POSITION, 0) ?: 0
        isFromIssue = intent?.getBooleanExtra(EXTRA_FROM_ISSUE, false) ?: false
        isFromSchedule = intent?.getBooleanExtra(EXTRA_FROM_SCHEDULE, false) ?: false
        isFromInspection = intent?.getBooleanExtra(EXTRA_FROM_INSPECTION, false) ?: false
        viewModel.getUserData()
        onClickMenu()
    }

    private fun setupToolbar() {
        val toolbarMenu =
            when {
                isFromIssue -> {
                    ArrayList(listOf(*resources.getStringArray(R.array.toolbar_menu_issue)))
                }
                isFromSchedule -> {
                    ArrayList(listOf(*resources.getStringArray(R.array.toolbar_menu_schedule)))
                }
                else -> {
                    ArrayList(listOf(*resources.getStringArray(R.array.toolbar_menu_inspection)))
                }
            }

        toolbarMenuAdapter = ToolbarMenuAdapter(arrayListOf())
        rvToolbarMenu.run {
            layoutManager = LinearLayoutManager(context, RecyclerView.HORIZONTAL, false)
            adapter = toolbarMenuAdapter
        }
        toolbarMenuAdapter.setSelectedMenuPosition(selectedMenuPosition)
        toolbarMenuAdapter.addData(toolbarMenu)

        toolbarMenuAdapter.setListener(object :
            ToolbarMenuAdapter.OnToolbarMenuInteractionListener {
            override fun onMenuItemClicked(menuPosition: Int) {
                toolbarMenuAdapter.setSelectedMenuPosition(menuPosition)
                selectedMenuPosition = menuPosition
                onClickMenu()
            }
        })

        btnBackToolbarMap.apply {
            visibility = View.VISIBLE
            setOnClickListener {
                onBackPressed()
            }
        }
    }

    private fun onClickMenu() {
        when {
            isFromIssue -> {
                when (selectedMenuPosition) {
                    IssuesViewModel.REPORTED_BY_ME -> {
                        removeExistingMarkers()
                        viewModel.setState(isIssueReportByMe = true)
                        viewModel.getIssue(null)
                    }
                    IssuesViewModel.ASSIGN_TO_ME -> {
                        removeExistingMarkers()
                        viewModel.setState(isIssueAssignToMe = true)
                        viewModel.getIssue(null)
                    }
                }
            }
            isFromSchedule -> {
                when (selectedMenuPosition) {
                    MapViewModel.SCHEDULE -> {
                        removeExistingMarkers()
                        viewModel.setState(isSchedule = true)
                        viewModel.getSchedule(null)
                    }
                    MapViewModel.RESCHEDULE -> {
                        removeExistingMarkers()
                        viewModel.setState(isReschedule = true)
                        viewModel.getReschedule(null)
                    }
                }
            }
            else -> {
                removeExistingMarkers()
                viewModel.setState(isInspection = true)
                viewModel.getInspection(null)
            }
        }
    }

    private fun setupMap() {
        val mapFragment =
            supportFragmentManager.findFragmentById(R.id.mapFragment) as? SupportMapFragment
        mapFragment?.getMapAsync(this)
    }

    private fun setupBottomSheet() {
        sheetBehavior =
            BottomSheetBehavior.from(bottomLayout)
        sheetBehavior.state = BottomSheetBehavior.STATE_COLLAPSED
        etBottomSheetSearch.setOnKeyListener { _, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_UP) {
                val search = etBottomSheetSearch.text.toString()
                when {
                    isFromIssue -> {
                        when (selectedMenuPosition) {
                            IssuesViewModel.REPORTED_BY_ME -> {
                                removeExistingMarkers()
                                viewModel.setState(isIssueReportByMe = true)
                                viewModel.getIssue(if (search.isNotEmpty()) search else null)
                            }
                            IssuesViewModel.ASSIGN_TO_ME -> {
                                removeExistingMarkers()
                                viewModel.setState(isIssueAssignToMe = true)
                                viewModel.getIssue(if (search.isNotEmpty()) search else null)
                            }
                        }
                    }
                    isFromSchedule -> {
                        when (selectedMenuPosition) {
                            MapViewModel.SCHEDULE -> {
                                removeExistingMarkers()
                                viewModel.setState(isSchedule = true)
                                viewModel.getSchedule(if (search.isNotEmpty()) search else null)
                            }
                            MapViewModel.RESCHEDULE -> {
                                removeExistingMarkers()
                                viewModel.setState(isReschedule = true)
                                viewModel.getReschedule(if (search.isNotEmpty()) search else null)
                            }
                        }
                    }
                    else -> {
                        if (search.isNotEmpty()) {
                            removeExistingMarkers()
                            viewModel.setState(isInspection = true)
                            viewModel.getInspection(search)
                        } else {
                            removeExistingMarkers()
                            viewModel.setState(isInspection = true)
                            viewModel.getInspection(null)
                        }
                    }
                }
                ViewUtils.hideKeyboard(this, etBottomSheetSearch)
            }
            false
        }
    }

    private fun setupRv() {
        issuesAdapter = IssuesAdapter()
        issuesAdapter?.setIssueClickListener(object : IssuesAdapter.IssueClickListener {
            override fun onClickIssue(issueId: String, issueTitle: String, latLng: String?) {
                val splitLatLng = latLng?.split(",")?.toTypedArray()
                val latitude = splitLatLng?.get(0)?.toDouble() ?: 0.0
                val longitude = splitLatLng?.get(1)?.toDouble() ?: 0.0
                setMapCameraMove(latitude, longitude)
            }
        })

        scheduleAdapter = ScheduleAdapter()
        scheduleAdapter?.setScheduleClickListener(object : ScheduleAdapter.ScheduleClickListener {
            override fun onClickSchedule(
                scheduleId: String,
                scheduleStatus: String
            ) {
                ScheduleDetailActivity.startThisActivity(
                    this@MapActivity,
                    scheduleId,
                    null,
                    scheduleStatus,
                    null,
                    null
                )
            }
        })

        rescheduleAdapter = RescheduleAdapter()
        rescheduleAdapter?.setRescheduleClickListener(object :
            RescheduleAdapter.RescheduleClickListener {
            override fun onClickReschedule(
                rescheduleId: String,
                scheduleId: String,
                scheduleStatus: String,
                userIdRequester: String,
                userIdApprover: String
            ) {
                ScheduleDetailActivity.startThisActivity(
                    this@MapActivity,
                    scheduleId,
                    rescheduleId,
                    scheduleStatus,
                    userIdRequester,
                    userIdApprover
                )
            }
        })

        inspectionAdapter = InspectionAdapter()
        inspectionAdapter?.setInspectionClickListener(object :
            InspectionAdapter.InspectionClickListener {
            override fun onClickInspection(
                inspectionId: String,
                location: AuditLocationModel.AuditLocation?,
                startDate: String,
                statusId: Int
            ) {
                val splitLatLng = location?.latLong?.split(",")?.toTypedArray()
                val latitude = splitLatLng?.get(0)?.toDouble() ?: 0.0
                val longitude = splitLatLng?.get(1)?.toDouble() ?: 0.0
                setMapCameraMove(latitude, longitude)
            }
        })
        val linearLayoutManager = LinearLayoutManager(this)
        val linearLayoutManagerReschedule = LinearLayoutManager(this)
        rvData.apply {
            layoutManager = linearLayoutManager
            setHasFixedSize(true)
            adapter =
                if (viewModel.isIssueAssignToMeState.value == true || viewModel.isIssueReportByMeState.value == true) {
                    issuesAdapter
                } else if (viewModel.isScheduleState.value == true) {
                    scheduleAdapter
                } else {
                    inspectionAdapter
                }
        }
        rvDataReschedule.apply {
            layoutManager = linearLayoutManagerReschedule
            setHasFixedSize(true)
            adapter = rescheduleAdapter
        }
    }

    private fun observeIssueList() {
        observeData(viewModel.issueListResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { data ->
                            if (data.isNotEmpty()) {
                                viewModel.showEmptyState.value = false
                                issuesAdapter?.setData(data)
                                addMarkers(issues = data)
                            } else {
                                viewModel.showEmptyState.value = true
                                tvEmptyMessage.text = getString(R.string.issues_empty)
                            }
                        }
                    }
                    NetworkState.ERROR -> {
                        when (it.code) {
                            404 -> {
                                tvEmptyMessage.text = it.message
                                viewModel.showEmptyState.value = true
                                issuesAdapter?.removeAllData()
                            }
                            else -> {
                                SnackBar.snackBarShowError(
                                    this,
                                    parentLayout,
                                    it.message
                                        ?: getString(R.string.general_server_error_message)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    private fun observeScheduleList() {
        observeData(viewModel.scheduleListResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { data ->
                            if (data.isNotEmpty()) {
                                viewModel.showEmptyState.value = false
                                scheduleAdapter?.setData(data)
                                addMarkers(schedules = data)
                            } else {
                                viewModel.showEmptyState.value = true
                            }
                        }
                    }
                    NetworkState.ERROR -> {
                        when (it.code) {
                            404 -> {
                                viewModel.showEmptyState.value = true
                                scheduleAdapter?.removeAllData()
                            }
                            else -> {
                                SnackBar.snackBarShowError(
                                    this,
                                    parentLayout,
                                    it.message
                                        ?: getString(R.string.general_server_error_message)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    private fun observeRescheduleList() {
        observeData(viewModel.rescheduleListResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { data ->
                            if (data.isNotEmpty()) {
                                viewModel.showEmptyState.value = false
                                rescheduleAdapter?.setData(data)
                                addMarkers(reschedules = data)
                            } else {
                                viewModel.showEmptyState.value = true
                            }
                        }
                    }
                    NetworkState.ERROR -> {
                        when (it.code) {
                            404 -> {
                                viewModel.showEmptyState.value = true
                                rescheduleAdapter?.removeAllData()
                            }
                            else -> {
                                SnackBar.snackBarShowError(
                                    this,
                                    parentLayout,
                                    it.message
                                        ?: getString(R.string.general_server_error_message)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    private fun observeInspectionList() {
        observeData(viewModel.inspectionListResponse) { result ->
            result?.let {
                when (it.networkState) {
                    NetworkState.SUCCESS -> {
                        it.data?.let { data ->
                            if (data.isNotEmpty()) {
                                viewModel.showEmptyState.value = false
                                inspectionAdapter?.setData(data)
                                addMarkers(inspections = data)
                            } else {
                                viewModel.showEmptyState.value = true
                            }
                        }
                    }
                    NetworkState.ERROR -> {
                        when (it.code) {
                            401 -> {
                                SnackBar.snackBarShowError(
                                    this,
                                    parentLayout,
                                    it.message
                                        ?: getString(R.string.general_server_error_message)
                                )
                                viewModel.preference.clearPreferences()
                                logout(Intent(this, LoginActivity::class.java))
                            }
                            404 -> {
                                viewModel.showEmptyState.value = true
                                inspectionAdapter?.removeAllData()
                            }
                            else -> {
                                //do nothing just to avoid error warning
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap
        map.setPadding(0, 0, 0, 15.toPx())
        val uiSettings = map.uiSettings
        uiSettings?.isZoomGesturesEnabled = true
    }

    private fun addMarkers(
        issues: List<IssueModel.Issue>? = null,
        schedules: List<ScheduleModel.Schedule>? = null,
        reschedules: List<Reschedule>? = null,
        inspections: List<InspectionModel.Inspection>? = null
    ) {
        issues?.let {
            for (i in it.indices) {
                val latLng = it[i].auditLocation?.latLong?.split(",")?.toTypedArray()
                val latitude = latLng?.get(0)?.toDouble() ?: 0.0
                val longitude = latLng?.get(1)?.toDouble() ?: 0.0
                val locationLatLng = LatLng(latitude, longitude)

                if (latitude != 0.0 && longitude != 0.0) {
                    //marker
                    val icon = BitmapDescriptorFactory.fromResource(R.drawable.ic_map_pin_red)
                    val marker = map.addMarker(
                        MarkerOptions().position(locationLatLng)
                            .title(it[i].auditLocation?.name)
                            .icon(icon)
                    )
                    markers.add(marker)
                }
            }
        }
        schedules?.let {
            for (i in it.indices) {
                val latLng = it[i].auditLocation?.latLong?.split(",")?.toTypedArray()
                val latitude = latLng?.get(0)?.toDouble() ?: 0.0
                val longitude = latLng?.get(1)?.toDouble() ?: 0.0
                val locationLatLng = LatLng(latitude, longitude)

                if (latitude != 0.0 && longitude != 0.0) {
                    //marker
                    val icon = BitmapDescriptorFactory.fromResource(R.drawable.ic_map_pin_red)
                    val marker = map.addMarker(
                        MarkerOptions().position(locationLatLng)
                            .title(it[i].auditLocation?.name)
                            .icon(icon)
                    )
                    markers.add(marker)
                }
            }
        }
        reschedules?.let {
            for (i in it.indices) {
                val latLng = it[i].latLong?.split(",")?.toTypedArray()
                val latitude = latLng?.get(0)?.toDouble() ?: 0.0
                val longitude = latLng?.get(1)?.toDouble() ?: 0.0
                val locationLatLng = LatLng(latitude, longitude)

                if (latitude != 0.0 && longitude != 0.0) {
                    //marker
                    val icon = BitmapDescriptorFactory.fromResource(R.drawable.ic_map_pin_red)
                    val marker = map.addMarker(
                        MarkerOptions().position(locationLatLng)
                            .title(it[i].locationName)
                            .icon(icon)
                    )
                    markers.add(marker)
                }
            }
        }
        inspections?.let {
            for (i in it.indices) {
                val latLng = it[i].auditLocation?.latLong?.split(",")?.toTypedArray()
                val latitude = latLng?.get(0)?.toDouble() ?: 0.0
                val longitude = latLng?.get(1)?.toDouble() ?: 0.0
                val locationLatLng = LatLng(latitude, longitude)

                if (latitude != 0.0 && longitude != 0.0) {
                    //marker
                    val icon = BitmapDescriptorFactory.fromResource(R.drawable.ic_map_pin_red)
                    val marker = map.addMarker(
                        MarkerOptions().position(locationLatLng)
                            .title(it[i].auditLocation?.name)
                            .icon(icon)
                    )
                    markers.add(marker)
                }
            }
        }
        setMapCameraBounds()
        map.setOnMarkerClickListener { marker ->
            setMapCameraMove(marker.position.latitude, marker.position.longitude)
            marker.showInfoWindow()
            selectedMarkerLatitude = marker.position.latitude
            selectedMarkerLongitude = marker.position.longitude
            selectedMarkerAddress = marker.title
            true
        }
    }

    private fun setMapCameraBounds() {
        val builder = LatLngBounds.Builder()
        for (marker in markers) {
            builder.include(marker.position)
        }
        val bounds = builder.build()
        val padding = 60 // offset from edges of the map in pixels
        val cameraUpdateFactory = CameraUpdateFactory.newLatLngBounds(bounds, padding)

        map.animateCamera(cameraUpdateFactory)
    }

    private fun setMapCameraMove(latitude: Double, longitude: Double) {
        map.animateCamera(
            CameraUpdateFactory.newLatLngZoom(
                LatLng(latitude, longitude),
                MAPS_ZOOM_LEVEL
            )
        )
    }

    private fun removeExistingMarkers() {
        for (pm in markers.indices) {
            markers[pm].remove()
        }
    }

    override fun onClickClearSearch(view: View) {
        viewModel.bTextSearch.value = ""
        when {
            isFromIssue -> {
                when (selectedMenuPosition) {
                    IssuesViewModel.REPORTED_BY_ME -> {
                        removeExistingMarkers()
                        viewModel.setState(isIssueReportByMe = true)
                        viewModel.getIssue(null)
                    }
                    IssuesViewModel.ASSIGN_TO_ME -> {
                        removeExistingMarkers()
                        viewModel.setState(isIssueAssignToMe = true)
                        viewModel.getIssue(null)
                    }
                }
            }
            isFromSchedule -> {
                when (selectedMenuPosition) {
                    MapViewModel.SCHEDULE -> {
                        removeExistingMarkers()
                        viewModel.setState(isSchedule = true)
                        viewModel.getSchedule(null)
                    }
                    MapViewModel.RESCHEDULE -> {
                        removeExistingMarkers()
                        viewModel.setState(isReschedule = true)
                        viewModel.getReschedule(null)
                    }
                }
            }
            else -> {
                removeExistingMarkers()
                viewModel.setState(isInspection = true)
                viewModel.getInspection(null)
            }
        }
    }
}
