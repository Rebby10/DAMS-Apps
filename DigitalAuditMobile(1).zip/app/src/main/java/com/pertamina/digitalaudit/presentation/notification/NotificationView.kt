package com.pertamina.digitalaudit.presentation.notification

import com.pertamina.framework.base.BaseView

/**
 * Created by M Hafidh Abdul Aziz on 20/03/21.
 */

interface NotificationView : BaseView {
    fun setupToolbar()
}