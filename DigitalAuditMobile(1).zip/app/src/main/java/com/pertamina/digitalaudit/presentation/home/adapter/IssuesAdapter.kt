package com.pertamina.digitalaudit.presentation.home.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.model.IssueModel
import com.pertamina.digitalaudit.presentation.issues.helper.IssuesStatusViewHelper.getPriorityTextColor
import com.pertamina.digitalaudit.presentation.issues.helper.IssuesStatusViewHelper.getStatusBackgroundColor
import com.pertamina.digitalaudit.presentation.issues.helper.IssuesStatusViewHelper.getStatusTextColor
import com.pertamina.framework.base.BaseRecyclerViewAdapter
import com.pertamina.framework.base.BaseViewHolder
import com.pertamina.framework.util.DateHelper
import kotlinx.android.synthetic.main.item_home_issues.view.*

/**
 * Created by M Hafidh Abdul Aziz on 08/03/21.
 */

class IssuesAdapter : BaseRecyclerViewAdapter<IssueModel.Issue>() {

    private var listener: IssueClickListener? = null

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BaseViewHolder<IssueModel.Issue> {
        val view = LayoutInflater.from(parent.context).inflate(viewType, parent, false)
        return ListViewHolder(parent.context, view, listener)
    }

    override fun onBindViewHolder(holder: BaseViewHolder<IssueModel.Issue>, position: Int) {
        holder.bindData(getItem(position))
    }

    override fun getItemViewType(position: Int): Int {
        return R.layout.item_home_issues
    }

    class ListViewHolder(context: Context, val view: View, listener: IssueClickListener?) :
        BaseViewHolder<IssueModel.Issue>(context, view) {

        private lateinit var data: IssueModel.Issue
        private var holderListener: IssueClickListener? = listener

        private var tvTitleIssues = view.tvTitleIssues
        private var tvReportedBy = view.tvReportedBy
        private var tvIssuesPriorityType = view.tvIssuesPriorityType
        private var tvLastUpdatedIssues = view.tvIssuesLastUpdated
        private var tvStatusIssues = view.tvIssuesStatus
        private var tvLocation = view.tvIssuesLocation

        @SuppressLint("SetTextI18n")
        override fun bindData(data: IssueModel.Issue) {
            this.data = data
            tvTitleIssues.text = data.title
            tvReportedBy.text = "Reported by ${data.creator?.displayName}"
            tvLocation.text = data.auditLocation?.name
            data.targetClosing?.let {
                tvLastUpdatedIssues.text = DateHelper.changeFormat(
                    it,
                    DateHelper.yyyy_MM_dd_T_HHmmss,
                    DateHelper.dd_MMM_yyyy
                )
            }
            tvIssuesPriorityType.apply {
                data.priority?.name?.let { priority ->
                    text = priority
                    setTextColor(ContextCompat.getColor(context, getPriorityTextColor(priority)))
                }
            }
            tvStatusIssues.apply {
                data.status?.let { status ->
                    text = status.name
                    setBackgroundResource(getStatusBackgroundColor(status.name.orEmpty()))
                    setTextColor(
                        ContextCompat.getColor(
                            context,
                            getStatusTextColor(status.name.orEmpty())
                        )
                    )
                }
            }
            itemView.setOnClickListener {
                holderListener?.onClickIssue(
                    data.issueId.orEmpty(),
                    data.title.orEmpty(),
                    data.auditLocation?.latLong
                )
            }
        }
    }

    fun setIssueClickListener(listener: IssueClickListener) {
        this.listener = listener
    }

    interface IssueClickListener {
        fun onClickIssue(issueId: String, issueTitle: String, latLng: String?)
    }
}
