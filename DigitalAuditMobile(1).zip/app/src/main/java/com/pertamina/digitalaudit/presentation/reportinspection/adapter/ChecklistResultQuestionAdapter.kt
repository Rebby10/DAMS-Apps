package com.pertamina.digitalaudit.presentation.reportinspection.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.model.reportinspection.QuestionItem
import com.pertamina.framework.base.BaseRecyclerViewAdapter
import com.pertamina.framework.base.BaseViewHolder
import kotlinx.android.synthetic.main.item_report_check_list_result_section_child.view.*

class ChecklistResultQuestionAdapter : BaseRecyclerViewAdapter<QuestionItem>() {

    private var listener: ItemClickListener? = null

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BaseViewHolder<QuestionItem> {
        val view = LayoutInflater.from(parent.context).inflate(viewType, parent, false)
        return ListViewHolder(parent.context, view, listener)
    }

    override fun onBindViewHolder(
        holder: BaseViewHolder<QuestionItem>,
        position: Int
    ) {
        holder.bindData(getItem(position))
    }

    override fun getItemViewType(position: Int): Int {
        return R.layout.item_report_check_list_result_section_child
    }

    class ListViewHolder(context: Context, val view: View, listener: ItemClickListener?) :
        BaseViewHolder<QuestionItem>(context, view) {

        private var holderListener: ItemClickListener? = listener
        private var tvCode = view.tvCode
        private var tvQuestion = view.tvQuestion
        private var tvAnswer = view.tvAnswer
        private var tvDescription = view.tvDescription
        private var rlImage = view.rlImage
        private var rlVoiceNote = view.rlVoiceNote
        private var rlActions = view.rlActions

        override fun bindData(data: QuestionItem) {
            tvCode.text = data.code
            tvQuestion.text = data.question

            if (data.answer?.answerId != null && data.answer.answerText.isNullOrEmpty()) {
                tvAnswer.text = when (data.answer.answerId) {
                    1 -> "Yes"
                    2 -> "No"
                    3 -> "Na"
                    4 -> "Nw"
                    else -> data.answer.answerText
                }
            } else {
                tvAnswer.text = data.answer?.answerText
            }
            tvDescription.text = data.answer?.notes ?: "-"
            rlImage.setOnClickListener {
                holderListener?.onClickAttachment(data.questionId.toString())
            }
            rlVoiceNote.apply {
                setOnClickListener {
                    holderListener?.onClickVoiceNote(data.questionId.toString())
                }
            }
            rlActions.apply {
                setOnClickListener {
                    holderListener?.onClickActions(data.questionId.toString())
                }
            }
        }
    }

    fun setItemClickListener(listener: ItemClickListener) {
        this.listener = listener
    }

    interface ItemClickListener {
        fun onClickAttachment(questionId: String)
        fun onClickVoiceNote(questionId: String)
        fun onClickActions(questionId: String)
    }
}