package com.pertamina.digitalaudit.model.reportinspection

import com.google.gson.annotations.SerializedName

data class ReportSummaryResponse(

    @field:SerializedName("TotalResult")
    val totalResult: Int? = null,

    @field:SerializedName("TotalData")
    val totalData: Int? = null,

    @field:SerializedName("Result")
    val data: ReportSummary? = null
)

data class ReportSummary(

    @field:SerializedName("Score")
    val score: Double? = null,

    @field:SerializedName("CurrentRecomendation")
    val currentRecomendation: CurrentRecomendation? = null,

    @field:SerializedName("InspectionId")
    val inspectionId: String? = null,

    @field:SerializedName("Images")
    val images: List<ImageLink>? = null,

    @field:SerializedName("PreviousRecomendation")
    val previousRecomendation: PreviousRecomendation? = null
)

data class PreviousRecomendation(

    @field:SerializedName("Action")
    val action: List<ActionItem>? = null,

    @field:SerializedName("Issue")
    val issue: List<IssueItem>? = null
)

data class CurrentRecomendation(

    @field:SerializedName("Action")
    val action: List<ActionItem>? = null,

    @field:SerializedName("Issue")
    val issue: List<IssueItem>? = null
)

data class IssueItem(

    @field:SerializedName("Status")
    val status: String? = null,

    @field:SerializedName("Total")
    val total: Int? = null
)

data class ActionItem(

    @field:SerializedName("Status")
    val status: String? = null,

    @field:SerializedName("Total")
    val total: Int? = null
)

class ImageLink(

    @field:SerializedName("link")
    val link: String? = null
)
