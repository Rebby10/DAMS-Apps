package com.pertamina.digitalaudit.model

import com.google.gson.annotations.SerializedName

class MasterModel {

    @SerializedName("Result")
    var data: Master? = null

    class Master {
        @SerializedName("RootCauseCategory")
        var rootCauseCategory: List<ActionRepairCategory>? = null

        @SerializedName("ActionRepairCategory")
        var actionRepairCategory: List<ActionRepairCategory>? = null

        @SerializedName("InspectionStatus")
        var inspectionStatus: List<InspectionStatus>? = null

        @SerializedName("IssueStatus")
        var issueStatus: List<IssueStatusModel.IssueStatus>? = null

        @SerializedName("IssueCategory")
        var issueCategory: List<IssueCategoryModel.IssueCategory>? = null

        @SerializedName("Priority")
        var priority: List<PriorityModel.Priority>? = null

        class ActionRepairCategory {
            @SerializedName("Id")
            var id: String? = null

            @SerializedName("Name")
            var name: String? = null

            /**
             * Pay attention here, you have to override the toString method as the
             * ArrayAdapter will reads the toString of the given object for the name
             *
             * @return name
             */
            override fun toString(): String {
                return name.orEmpty()
            }
        }

        class InspectionStatus {
            @SerializedName("StatusId")
            var statusId: String? = null

            @SerializedName("Name")
            var name: String? = null

            /**
             * Pay attention here, you have to override the toString method as the
             * ArrayAdapter will reads the toString of the given object for the name
             *
             * @return name
             */
            override fun toString(): String {
                return name.orEmpty()
            }
        }
    }
}