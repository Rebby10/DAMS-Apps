package com.pertamina.digitalaudit.presentation.issuedetails

import android.view.View
import com.pertamina.framework.base.BaseView

/**
 * Created by M Hafidh Abdul Aziz on 16/03/21.
 */

interface IssueDetailView : BaseView {
    fun onClickEditIssue(view: View)
    fun onClickChangeIssueStatus(view: View)
    fun onClickCreateActions(view: View)
    fun onClickSaveIssue(view: View)
    fun onClickViewActions(view: View)
}