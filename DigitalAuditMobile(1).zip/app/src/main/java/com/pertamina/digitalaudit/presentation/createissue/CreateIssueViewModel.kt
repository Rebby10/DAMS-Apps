package com.pertamina.digitalaudit.presentation.createissue

import androidx.lifecycle.MutableLiveData
import com.pertamina.digitalaudit.model.*
import com.pertamina.digitalaudit.model.body.CreateIssueReqBody
import com.pertamina.digitalaudit.model.body.UpdateIssueReqBody
import com.pertamina.digitalaudit.preference.PreferenceProvider
import com.pertamina.digitalaudit.repository.common.CommonRepository
import com.pertamina.digitalaudit.repository.issues.IssuesRepository
import com.pertamina.framework.NonNullMutableLiveData
import com.pertamina.framework.base.BaseViewModel
import com.pertamina.framework.base.Resource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Created by M Hafidh Abdul Aziz on 15/03/21.
 */

class CreateIssueViewModel(
    private val issuesRepository: IssuesRepository,
    private val commonRepository: CommonRepository,
    val preference: PreferenceProvider
) : BaseViewModel() {

    val showProgressBar = MutableLiveData(false)

    var bTextCreateIssueTitle = MutableLiveData("")
    var bTextCreateIssueDescription = MutableLiveData("")
    var bTextCreateIssueAssignAuditeeName = MutableLiveData("")
    var bTextCreateIssueTargetClosing = MutableLiveData("")
    var bTextCreateIssueLocation = MutableLiveData("")

    var createIssueLocationId = NonNullMutableLiveData("")
    var createIssueAssignAuditeeUserId = MutableLiveData<String>(null)
    var createIssueAssignAuditeeGroupId = MutableLiveData<String>(null)
    var createIssuePriorityId = NonNullMutableLiveData(0)
    var createIssueStatusId = NonNullMutableLiveData(1)
    var createIssueCategoryId = NonNullMutableLiveData(0)

    val createIssueResponse = MutableLiveData<Resource<IssueModel>>()
    val priorityListResponse = MutableLiveData<Resource<List<PriorityModel.Priority>>>()
    val issueCategoryListResponse =
        MutableLiveData<Resource<List<IssueCategoryModel.IssueCategory>>>()
    val updateIssueResponse = MutableLiveData<Resource<IssueModel>>()
    val issueDetailResponse = MutableLiveData<Resource<IssueDetailModel>>()

    var user = UserModel.User()
    var issueId: String = ""

    init {
        getUserData()
    }

    private fun getUserData() {
        launch {
            withContext(Dispatchers.IO) {
                user = preference.getAuthPreferences()
            }
        }
    }

    fun createNewIssue() {
        showProgressBar.value = true
        launch {
            val request = issuesRepository.createNewIssue(
                CreateIssueReqBody(
                    title = bTextCreateIssueTitle.value.orEmpty(),
                    descriptions = bTextCreateIssueDescription.value.orEmpty(),
                    auditLocationId = createIssueLocationId.value,
                    assignedGroup = createIssueAssignAuditeeGroupId.value,
                    assignedUser = createIssueAssignAuditeeUserId.value,
                    creator = user.userId.orEmpty(),
                    priorityId = createIssuePriorityId.value,
                    targetClosing = bTextCreateIssueTargetClosing.value.orEmpty(),
                    issueCategoryId = createIssueCategoryId.value,
                    statusId = createIssueStatusId.value,
                    userCreated = user.userId.orEmpty()
                )
            )
            createIssueResponse.value = request
            showProgressBar.value = false
        }
    }

    fun getPriorityList() {
        showProgressBar.value = true
        launch {
            val request = commonRepository.getPriority()
            priorityListResponse.value = request
            showProgressBar.value = false
        }
    }

    fun getIssueCategoryList() {
        showProgressBar.value = true
        launch {
            val request = issuesRepository.getIssueCategory()
            issueCategoryListResponse.value = request
            showProgressBar.value = false
        }
    }

    fun updateIssue() {
        showProgressBar.value = true
        launch {
            val request = issuesRepository.updateIssue(
                UpdateIssueReqBody(
                    issueId = issueId,
                    title = bTextCreateIssueTitle.value.orEmpty(),
                    descriptions = bTextCreateIssueDescription.value.orEmpty(),
                    auditLocationId = createIssueLocationId.value,
                    assignedGroup = createIssueAssignAuditeeGroupId.value,
                    assignedUser = createIssueAssignAuditeeUserId.value,
                    creator = user.userId.orEmpty(),
                    priorityId = createIssuePriorityId.value,
                    targetClosing = bTextCreateIssueTargetClosing.value,
                    issueCategoryId = createIssueCategoryId.value,
                    statusId = createIssueStatusId.value,
                    userCreated = user.userId.orEmpty()
                )
            )
            updateIssueResponse.value = request
            showProgressBar.value = false
        }
    }

    fun getIssueDetail() {
        showProgressBar.value = true
        launch {
            val request = issuesRepository.getIssueDetail(issueId)
            issueDetailResponse.value = request
            showProgressBar.value = false
        }
    }

    fun getSelectedPrioritySpinnerItemPosition(): Int {
        val prevSelectedPriority = createIssuePriorityId.value
        prevSelectedPriority.let {
            priorityListResponse.value?.data?.let { list ->
                val data = list.toMutableList()
                return list.indexOf(data.find { it.priorityId == prevSelectedPriority })
            }
        }
        return 0
    }

    fun getSelectedIssueCategorySpinnerItemPosition(): Int {
        val prevSelectedPriority = createIssueCategoryId.value
        prevSelectedPriority.let {
            issueCategoryListResponse.value?.data?.let { list ->
                val data = list.toMutableList()
                return list.indexOf(data.find { it.issueCategoryId == prevSelectedPriority })
            }
        }
        return 0
    }
}
