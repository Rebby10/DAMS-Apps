package com.pertamina.digitalaudit.model.body

import com.google.gson.annotations.SerializedName

class UpdateActionReqBody(
    @SerializedName("ActionId")
    var actionId: String,
    @SerializedName("Title")
    var title: String?,
    @SerializedName("Descriptions")
    var descriptions: String?,
    @SerializedName("AuditLocationId")
    var auditLocationId: String?,
    @SerializedName("AssignGroup")
    var assignedGroup: String?,
    @SerializedName("AssignUser")
    var assignedUser: String?,
    @SerializedName("IssueId")
    var issueId: String?,
    @SerializedName("Creator")
    var creator: String?,
    @SerializedName("PriorityId")
    var priorityId: Int?,
    @SerializedName("TargetClosing")
    var targetClosing: String?,
    @SerializedName("StatusId")
    var statusId: Int?
)
