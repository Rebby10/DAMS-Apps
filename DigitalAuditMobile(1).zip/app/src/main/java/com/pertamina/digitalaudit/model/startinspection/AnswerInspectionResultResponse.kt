package com.pertamina.digitalaudit.model.startinspection

import com.google.gson.annotations.SerializedName

data class AnswerInspectionResultResponse(

    @field:SerializedName("Result")
    val data: AnswerInspectionResult? = null
)

data class AnswerInspectionResult(

    @field:SerializedName("UserModified")
    val userModified: Any? = null,

    @field:SerializedName("IsDeleted")
    val isDeleted: Boolean? = null,

    @field:SerializedName("QuestionId")
    val questionId: Int? = null,

    @field:SerializedName("InspectionId")
    val inspectionId: String? = null,

    @field:SerializedName("LinkFile")
    val linkFile: Any? = null,

    @field:SerializedName("UserCreated")
    val userCreated: String? = null,

    @field:SerializedName("DateCreated")
    val dateCreated: String? = null,

    @field:SerializedName("AnswerId")
    val answerId: Int? = null,

    @field:SerializedName("AnswerText")
    val answerText: String? = null,

    @field:SerializedName("ResultId")
    val resultId: String? = null,

    @field:SerializedName("Notes")
    val notes: String? = null,

    @field:SerializedName("DateModified")
    val dateModified: Any? = null
)
