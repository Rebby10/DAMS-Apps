package com.pertamina.digitalaudit.model.body

import com.google.gson.annotations.SerializedName

/**
 * Created by M Hafidh Abdul Aziz on 28/03/21.
 */

data class IssueLogReqBody(
    @SerializedName("IssueId")
    var issueId: String,
    @SerializedName("text")
    var text: String?,
    @SerializedName("UserCreated")
    var userCreated: String
)