package com.pertamina.digitalaudit.presentation.inspection

import android.view.View
import com.pertamina.framework.base.BaseView

interface InspectionView : BaseView {
    fun onClickFilterMenuItem(menuPosition: Int)
    fun onClickFilterInspection(view: View)
}