package com.pertamina.digitalaudit.util

/**
 * Created by M Hafidh Abdul Aziz on 13/03/21.
 */

object CommonConstant {

    const val MENU_ISSUES = 0
    const val MENU_SCHEDULE = 1
    const val MENU_INSPECTION = 2

    const val USER_TYPE_AUDITOR_ID = 1
    const val USER_TYPE_AUDITEE_ID = 2

    const val LOG_TYPE_TEXT_ID = 1
    const val LOG_TYPE_UPDATE_ID = 2
    const val LOG_TYPE_FILE_ID = 3
    const val LOG_TYPE_TEXT_RECIPIENT_ID = 4
    const val LOG_TYPE_RECIPIENT_FILE_ID = 5


    const val IMAGE_FILE_TYPE = 1
    const val AUDIO_FILE_TYPE = 2

    const val RESPONSE_TYPE_MULTIPLE_CHOICE_ID = 1
    const val RESPONSE_TYPE_FREE_TEXT_ID = 2
    const val RESPONSE_TYPE_NUMBER_ID = 3
    const val RESPONSE_TYPE_DATE_ID = 4
    const val RESPONSE_TYPE_LOCATION_ID = 5
    const val RESPONSE_TYPE_SIGNATURE_ID = 6

    const val DEFAULT_PAGE_SIZE = 10

    const val RC_WRITE_EXTERNAL_STORAGE_PERM = 515
    const val RC_RECORD_AUDIO_PERM = 516

    const val ORDER_BY_DESC = "desc"
    const val SORT_BY_DATE_CREATED = "datecreated"
    const val MULTIPART_FORM_DATE = "multipart/form-data"

    const val INSPECTION_REPORT_PDF_URL = "Report/Inspection/Download/pdf/"
    const val INSPECTION_REPORT_WORD_URL = "Report/Inspection/Download/word/"

}
