package com.pertamina.digitalaudit.model.body

import com.google.gson.annotations.SerializedName
import com.pertamina.digitalaudit.model.AssignGroupModel

class CreateInspectionReqBody(
    @SerializedName("AuditLocationId")
    var auditLocationId: String?,
    @SerializedName("TemplateId")
    var templateId: String?,
    @SerializedName("UserCreated")
    var userCreated: String?,
    @SerializedName("Auditor")
    var auditor: AssignGroupModel.AssignGroup,
    @SerializedName("Auditee")
    var auditee: AssignGroupModel.AssignGroup
)
