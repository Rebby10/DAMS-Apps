package com.pertamina.digitalaudit.presentation.inspectionfilter

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.activity.result.contract.ActivityResultContracts
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.databinding.ActivityInspectionFilterBinding
import com.pertamina.digitalaudit.presentation.search.SearchActivity
import com.pertamina.framework.ViewDataBindingOwner
import com.pertamina.framework.base.BaseActivity
import kotlinx.android.synthetic.main.activity_inspection_filter.*
import kotlinx.android.synthetic.main.toolbar_layout.*
import org.koin.androidx.viewmodel.ext.android.viewModel

class InspectionFilterActivity : BaseActivity<InspectionFilterViewModel>(), InspectionFilterView,
    AdapterView.OnItemSelectedListener,
    ViewDataBindingOwner<ActivityInspectionFilterBinding> {

    override val layoutResourceId: Int = R.layout.activity_inspection_filter
    override val viewModel: InspectionFilterViewModel by viewModel()
    override var binding: ActivityInspectionFilterBinding? = null

    private var chooseLocationLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val locationId = result.data?.getStringExtra(SearchActivity.EXTRA_LOCATION_ID)
                val locationName = result.data?.getStringExtra(SearchActivity.EXTRA_LOCATION_NAME)
                viewModel.filterLocationId.value = locationId
                viewModel.bTextFilterLocation.value = locationName
            }
        }

    private var chooseRegionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val regionId = result.data?.getStringExtra(SearchActivity.EXTRA_REGION_ID)
                val regionName = result.data?.getStringExtra(SearchActivity.EXTRA_REGION_NAME)
                viewModel.filterRegionId.value = regionId
                viewModel.bTextFilterRegion.value = regionName
            }
        }

    private val userTypeFilter: Array<String> by lazy {
        resources.getStringArray(R.array.user_type_menu)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupToolbar()
        initUserTypeSpinner()
    }

    private fun setupToolbar() {
        tvTitleToolbar.text = getString(R.string.inspection_filter)
        btnBackToolbar.apply {
            visibility = View.VISIBLE
            setImageResource(R.drawable.ic_close)
            setOnClickListener {
                onBackPressed()
            }
        }
    }

    private fun initUserTypeSpinner() {
        val adapter =
            ArrayAdapter(this, android.R.layout.simple_spinner_item, userTypeFilter)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spInspectionFilterRole.adapter = adapter
        spInspectionFilterRole.onItemSelectedListener = this
    }

    override fun onClickApplyFilter(view: View) {
        viewModel.applyInspectionFilter()
        setResult(Activity.RESULT_OK)
        finish()
    }

    override fun onClickChooseLocation(view: View) {
        val intent = Intent(this, SearchActivity::class.java)
        intent.putExtra(SearchActivity.EXTRA_TITLE, getString(R.string.choose_location))
        intent.putExtra(SearchActivity.EXTRA_IS_SEARCH_LOCATION, true)
        chooseLocationLauncher.launch(intent)
    }

    override fun onClickChooseRegion(view: View) {
        val intent = Intent(this, SearchActivity::class.java)
        intent.putExtra(SearchActivity.EXTRA_TITLE, getString(R.string.choose_region))
        intent.putExtra(SearchActivity.EXTRA_IS_SEARCH_REGION, true)
        chooseRegionLauncher.launch(intent)
    }

    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
        when (parent?.id) {
            R.id.spInspectionFilterRole -> {
                viewModel.filterUserTypeId.value = position + 1
            }
        }
    }

    override fun onNothingSelected(p0: AdapterView<*>?) {
        //do nothing
    }
}
