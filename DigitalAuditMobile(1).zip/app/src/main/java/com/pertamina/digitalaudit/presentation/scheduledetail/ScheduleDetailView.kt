package com.pertamina.digitalaudit.presentation.scheduledetail

import android.text.TextWatcher
import android.view.View
import com.pertamina.framework.base.BaseView

/**
 * Created by M Hafidh Abdul Aziz on 20/03/21.
 */

interface ScheduleDetailView : BaseView {
    fun onClickReschedule(view: View)
    fun onClickConfirm(view: View)
    fun onClickReject(view: View)

    var bTextWatcherRescheduleReasonDescription: TextWatcher
}
