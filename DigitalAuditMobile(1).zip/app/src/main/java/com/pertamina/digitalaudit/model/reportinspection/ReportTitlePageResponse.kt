package com.pertamina.digitalaudit.model.reportinspection

import com.google.gson.annotations.SerializedName

data class ReportTitlePageResponse(

	@field:SerializedName("TotalResult")
	val totalResult: Int? = null,

	@field:SerializedName("TotalData")
	val totalData: Int? = null,

	@field:SerializedName("Result")
	val data: ReportTitlePage? = null
)

data class ResponseListItem(

	@field:SerializedName("SeqNo")
	val seqNo: Int? = null,

	@field:SerializedName("Score")
	val score: Int? = null,

	@field:SerializedName("ListId")
	val listId: Int? = null,

	@field:SerializedName("ResponseId")
	val responseId: Int? = null,

	@field:SerializedName("IsFailedResponse")
	val isFailedResponse: Boolean? = null,

	@field:SerializedName("Name")
	val name: String? = null
)

data class Response(

	@field:SerializedName("ResponseId")
	val responseId: Int? = null,

	@field:SerializedName("Name")
	val name: String? = null,

	@field:SerializedName("ResponseType")
	val responseType: ResponseType? = null,

	@field:SerializedName("ResponseList")
	val responseList: List<ResponseListItem?>? = null
)

data class Answer(

	@field:SerializedName("LinkFile")
	val linkFile: String? = null,

	@field:SerializedName("AnswerId")
	val answerId: Int? = null,

	@field:SerializedName("AnswerText")
	val answerText: String? = null,

	@field:SerializedName("ResultId")
	val resultId: String? = null,

	@field:SerializedName("Notes")
	val notes: String? = null
)

data class TemplatePageItem(

	@field:SerializedName("PageId")
	val pageId: String? = null,

	@field:SerializedName("Descriptions")
	val descriptions: String? = null,

	@field:SerializedName("SeqNo")
	val seqNo: Int? = null,

	@field:SerializedName("Title")
	val title: String? = null,

	@field:SerializedName("Question")
	val question: List<QuestionItem?>? = null,

	@field:SerializedName("Section")
	val section: List<SectionItem?>? = null,

	@field:SerializedName("TemplateId")
	val templateId: String? = null
)

data class TemplatePermissionType(

	@field:SerializedName("TemplatePermissionTypeId")
	val templatePermissionTypeId: Int? = null,

	@field:SerializedName("Name")
	val name: String? = null
)

data class QuestionItem(

	@field:SerializedName("PageId")
	val pageId: String? = null,

	@field:SerializedName("Response")
	val response: Response? = null,

	@field:SerializedName("SeqNo")
	val seqNo: Int? = null,

	@field:SerializedName("Answer")
	val answer: Answer? = null,

	@field:SerializedName("IsMandatory")
	val isMandatory: Boolean? = null,

	@field:SerializedName("QuestionId")
	val questionId: Int? = null,

	@field:SerializedName("Question")
	val question: String? = null,

	@field:SerializedName("Code")
	val code: String? = null,

	@field:SerializedName("SectionId")
	val sectionId: String? = null
)

data class ReportTitlePage(

	@field:SerializedName("Descriptions")
	val descriptions: String? = null,

	@field:SerializedName("TemplatePage")
	val templatePage: List<TemplatePageItem>? = null,

	@field:SerializedName("TemplateCategory")
	val templateCategory: TemplateCategory? = null,

	@field:SerializedName("Title")
	val title: String? = null,

	@field:SerializedName("Code")
	val code: String? = null,

	@field:SerializedName("TemplatePermissionType")
	val templatePermissionType: TemplatePermissionType? = null,

	@field:SerializedName("TemplatePermission")
	val templatePermission: List<TemplatePermissionItem?>? = null,

	@field:SerializedName("TemplateId")
	val templateId: String? = null
)

data class SectionItem(

	@field:SerializedName("PageId")
	val pageId: String? = null,

	@field:SerializedName("SeqNo")
	val seqNo: Int? = null,

	@field:SerializedName("Question")
	val question: List<QuestionItem>? = null,

	@field:SerializedName("SectionId")
	val sectionId: String? = null,

	@field:SerializedName("Name")
	val name: String? = null
)

data class TemplateCategory(

	@field:SerializedName("CategoryId")
	val categoryId: Int? = null,

	@field:SerializedName("Name")
	val name: String? = null
)

data class ResponseType(

	@field:SerializedName("TypeId")
	val typeId: Int? = null,

	@field:SerializedName("Name")
	val name: String? = null
)

data class TemplatePermissionItem(

	@field:SerializedName("OfficialName")
	val officialName: String? = null,

	@field:SerializedName("Username")
	val username: String? = null,

	@field:SerializedName("UserId")
	val userId: String? = null
)
