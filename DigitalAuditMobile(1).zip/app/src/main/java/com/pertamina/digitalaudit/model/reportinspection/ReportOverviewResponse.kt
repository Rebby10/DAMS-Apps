package com.pertamina.digitalaudit.model.reportinspection

import com.google.gson.annotations.SerializedName

data class ReportOverviewResponse(

	@field:SerializedName("TotalResult")
	val totalResult: Int? = null,

	@field:SerializedName("TotalData")
	val totalData: Int? = null,

	@field:SerializedName("Result")
	val data: ReportOverview? = null
)

data class ReportOverview(

	@field:SerializedName("Descriptions")
	val descriptions: String? = null,

	@field:SerializedName("Score")
	val score: Double? = null,

	@field:SerializedName("Address")
	val address: String? = null,

	@field:SerializedName("ApprovedDate")
	val approvedDate: String? = null,

	@field:SerializedName("InspectionId")
	val inspectionId: String? = null,

	@field:SerializedName("Title")
	val title: String? = null,

	@field:SerializedName("PreparedBy")
	val preparedBy: String? = null,

	@field:SerializedName("ConductedOn")
	val conductedOn: String? = null,

	@field:SerializedName("LatLong")
	val latLong: String? = null,

	@field:SerializedName("CompletedDate")
	val completedDate: String? = null,

	@field:SerializedName("LocationName")
	val locationName: String? = null,

	@field:SerializedName("StatusInspection")
	val statusInspection: String? = null
)
