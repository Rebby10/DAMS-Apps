package com.pertamina.digitalaudit.model

import com.pertamina.audiorecorder.Player

/**
 * @author Asadurrahman Al Qayyim
 * @date 10/1/2021
 */
data class VoiceNoteModel(val audioUri: String, var isPlaying : Boolean = false)