package com.pertamina.digitalaudit.model.body

import com.google.gson.annotations.SerializedName

data class UpdateScheduleReqBody(
    @SerializedName("Id")
    var id: String,
    @SerializedName("AuditLocationId")
    var auditLocationId: String,
    @SerializedName("StartDate")
    var startDate: String,
    @SerializedName("EndDate")
    var endDate: String,
    @SerializedName("TemplateId")
    var templateId: String?,
    @SerializedName("Auditor")
    var auditor: Auditor?,
    @SerializedName("Auditee")
    var auditee: Auditee
)

