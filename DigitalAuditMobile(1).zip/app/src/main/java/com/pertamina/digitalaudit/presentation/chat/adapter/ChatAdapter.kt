package com.pertamina.digitalaudit.presentation.chat.adapter

import android.content.Context
import android.os.Build
import android.text.Html
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.bumptech.glide.Glide
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.model.LogModel
import com.pertamina.digitalaudit.util.CommonConstant
import com.pertamina.framework.base.BaseRecyclerViewAdapter
import com.pertamina.framework.base.BaseViewHolder
import com.pertamina.framework.util.DateHelper
import kotlinx.android.synthetic.main.item_chat_bubble.view.*
import kotlinx.android.synthetic.main.item_chat_center.view.*
import kotlinx.android.synthetic.main.item_chat_file_bubble.view.*
import kotlinx.android.synthetic.main.item_chat_file_recipient_bubble.view.*
import kotlinx.android.synthetic.main.item_chat_recipient_bubble.view.*

/**
 * Created by M Hafidh Abdul Aziz on 24/03/21.
 */

class ChatAdapter : BaseRecyclerViewAdapter<LogModel.Log>() {

    companion object {
        const val ITEM_VIEW_TYPE_TEXT_SENDER = 101
        const val ITEM_VIEW_TYPE_UPDATE = 102
        const val ITEM_VIEW_TYPE_FILE_SENDER = 103
        const val ITEM_VIEW_TYPE_TEXT_RECIPIENT = 104
        const val ITEM_VIEW_TYPE_FILE_RECIPIENT = 105
    }

    private var listener: DownloadListener? = null

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BaseViewHolder<LogModel.Log> {
        val inflater = LayoutInflater.from(parent.context)
        when (viewType) {
            ITEM_VIEW_TYPE_TEXT_SENDER -> {
                val view = inflater?.inflate(R.layout.item_chat_bubble, parent, false)
                return TextViewHolder(parent.context, view!!)
            }
            ITEM_VIEW_TYPE_UPDATE -> {
                val view = inflater?.inflate(R.layout.item_chat_center, parent, false)
                return UpdateViewHolder(parent.context, view!!)
            }
            ITEM_VIEW_TYPE_FILE_SENDER -> {
                val view = inflater?.inflate(R.layout.item_chat_file_bubble, parent, false)
                return FileViewHolder(parent.context, view!!, listener)
            }
            ITEM_VIEW_TYPE_TEXT_RECIPIENT -> {
                val view = inflater?.inflate(R.layout.item_chat_recipient_bubble, parent, false)
                return TextRecipientViewHolder(parent.context, view!!)
            }
            ITEM_VIEW_TYPE_FILE_RECIPIENT -> {
                val view =
                    inflater?.inflate(R.layout.item_chat_file_recipient_bubble, parent, false)
                return FileRecipientViewHolder(parent.context, view!!, listener)
            }
        }
        val view = inflater?.inflate(R.layout.item_chat_bubble, parent, false)
        return TextViewHolder(parent.context, view!!)
    }

    override fun onBindViewHolder(holder: BaseViewHolder<LogModel.Log>, position: Int) {
        when (holder.itemViewType) {
            ITEM_VIEW_TYPE_TEXT_SENDER -> {
                val textViewHolder: TextViewHolder = holder as TextViewHolder
                textViewHolder.bindData(getItem(position))
            }
            ITEM_VIEW_TYPE_UPDATE -> {
                val updateViewHolder: UpdateViewHolder = holder as UpdateViewHolder
                updateViewHolder.bindData(getItem(position))
            }
            ITEM_VIEW_TYPE_FILE_SENDER -> {
                val fileViewHolder: FileViewHolder = holder as FileViewHolder
                fileViewHolder.bindData(getItem(position))
            }
            ITEM_VIEW_TYPE_TEXT_RECIPIENT -> {
                val textRecipientViewHolder: TextRecipientViewHolder =
                    holder as TextRecipientViewHolder
                textRecipientViewHolder.bindData(getItem(position))
            }
            ITEM_VIEW_TYPE_FILE_RECIPIENT -> {
                val fileRecipientViewHolder: FileRecipientViewHolder =
                    holder as FileRecipientViewHolder
                fileRecipientViewHolder.bindData(getItem(position))
            }
        }
    }

    override fun getItemViewType(position: Int): Int {
        return when (getItem(position).type?.logTypeId) {
            CommonConstant.LOG_TYPE_TEXT_ID -> {
                ITEM_VIEW_TYPE_TEXT_SENDER
            }
            CommonConstant.LOG_TYPE_UPDATE_ID -> {
                ITEM_VIEW_TYPE_UPDATE
            }
            CommonConstant.LOG_TYPE_FILE_ID -> {
                ITEM_VIEW_TYPE_FILE_SENDER
            }
            CommonConstant.LOG_TYPE_TEXT_RECIPIENT_ID -> {
                ITEM_VIEW_TYPE_TEXT_RECIPIENT
            }
            CommonConstant.LOG_TYPE_RECIPIENT_FILE_ID -> {
                ITEM_VIEW_TYPE_FILE_RECIPIENT
            }
            else -> {
                ITEM_VIEW_TYPE_TEXT_SENDER
            }
        }
    }

    class TextViewHolder(context: Context, val view: View) :
        BaseViewHolder<LogModel.Log>(context, view) {

        private lateinit var data: LogModel.Log

        private var tvChatContent = view.tvChatContent
        private var tvChatTime = view.tvChatTime

        override fun bindData(data: LogModel.Log) {
            this.data = data
            tvChatContent.text = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                Html.fromHtml(data.text, Html.FROM_HTML_MODE_COMPACT)
            } else {
                Html.fromHtml(data.text)
            }
            tvChatTime.text = DateHelper.changeFormat(
                data.datetime.orEmpty(),
                DateHelper.yyyy_MM_dd_T_HHmmss,
                DateHelper.hh_mm_a
            )
        }
    }

    class UpdateViewHolder(context: Context, val view: View) :
        BaseViewHolder<LogModel.Log>(context, view) {

        private lateinit var data: LogModel.Log

        private var tvChatCenter = view.tvChatCenter

        override fun bindData(data: LogModel.Log) {
            this.data = data
            tvChatCenter.text = data.text
        }
    }

    class FileViewHolder(context: Context, val view: View, listener: DownloadListener?) :
        BaseViewHolder<LogModel.Log>(context, view) {

        private lateinit var data: LogModel.Log
        private var holderListener: DownloadListener? = listener

        private var tvChatFileContent = view.tvChatFileContent
        private var tvChatFileTime = view.tvChatFileTime
        private var ivImagePreview = view.ivImagePreview
        private var tvChatImageTime = view.tvChatImageTime
        private var clDefaultChat = view.clDefaultChat
        private var clImageChat = view.clImageChat

        override fun bindData(data: LogModel.Log) {
            this.data = data
            tvChatFileContent.text = data.filename
            tvChatFileTime.text = DateHelper.changeFormat(
                data.datetime.orEmpty(),
                DateHelper.yyyy_MM_dd_T_HHmmss,
                DateHelper.hh_mm_a
            )
            tvChatImageTime.text = DateHelper.changeFormat(
                data.datetime.orEmpty(),
                DateHelper.yyyy_MM_dd_T_HHmmss,
                DateHelper.hh_mm_a
            )
            if (data.filename?.contains("jpg") == true ||
                data.filename?.contains("jpeg") == true ||
                data.filename?.contains("png") == true
            ) {
                clDefaultChat.visibility = View.GONE
                clImageChat.visibility = View.VISIBLE
                Glide.with(context).load(data.link)
                    .into(ivImagePreview)
            } else {
                clDefaultChat.visibility = View.VISIBLE
                clImageChat.visibility = View.GONE
            }
            itemView.setOnClickListener {
                holderListener?.onClickDownloadFile(data.filename, data.link)
            }
        }
    }

    class TextRecipientViewHolder(context: Context, val view: View) :
        BaseViewHolder<LogModel.Log>(context, view) {

        private lateinit var data: LogModel.Log

        private var tvChatContent = view.tvChatRecipientContent
        private var tvChatTime = view.tvChatRecipientTime

        override fun bindData(data: LogModel.Log) {
            this.data = data
            tvChatContent.text = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                Html.fromHtml(data.text, Html.FROM_HTML_MODE_COMPACT)
            } else {
                Html.fromHtml(data.text)
            }
            tvChatTime.text = DateHelper.changeFormat(
                data.datetime.orEmpty(),
                DateHelper.yyyy_MM_dd_T_HHmmss,
                DateHelper.hh_mm_a
            )
        }
    }

    class FileRecipientViewHolder(context: Context, val view: View, listener: DownloadListener?) :
        BaseViewHolder<LogModel.Log>(context, view) {

        private lateinit var data: LogModel.Log
        private var holderListener: DownloadListener? = listener

        private var tvChatFileContent = view.tvChatFileRecipientContent
        private var tvChatFileTime = view.tvChatFileRecipientTime
        private var ivImagePreview = view.ivImageRecipientPreview
        private var tvChatImageTime = view.tvChatImageRecipientTime
        private var clDefaultChat = view.clDefaultRecipientChat
        private var clImageChat = view.clImageRecipientChat

        override fun bindData(data: LogModel.Log) {
            this.data = data
            tvChatFileContent.text = data.filename
            tvChatFileTime.text = DateHelper.changeFormat(
                data.datetime.orEmpty(),
                DateHelper.yyyy_MM_dd_T_HHmmss,
                DateHelper.hh_mm_a
            )
            tvChatImageTime.text = DateHelper.changeFormat(
                data.datetime.orEmpty(),
                DateHelper.yyyy_MM_dd_T_HHmmss,
                DateHelper.hh_mm_a
            )
            if (data.filename?.contains("jpg") == true ||
                data.filename?.contains("jpeg") == true ||
                data.filename?.contains("png") == true
            ) {
                clDefaultChat.visibility = View.GONE
                clImageChat.visibility = View.VISIBLE
                Glide.with(context).load(data.link)
                    .into(ivImagePreview)
            } else {
                clDefaultChat.visibility = View.VISIBLE
                clImageChat.visibility = View.GONE
            }
            itemView.setOnClickListener {
                holderListener?.onClickDownloadFile(data.filename, data.link)
            }
        }
    }

    fun setDownloadListener(listener: DownloadListener) {
        this.listener = listener
    }

    interface DownloadListener {
        fun onClickDownloadFile(fileName: String?, fileUrl: String?)
    }
}