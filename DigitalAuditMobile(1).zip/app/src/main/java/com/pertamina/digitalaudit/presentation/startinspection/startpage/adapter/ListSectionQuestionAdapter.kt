package com.pertamina.digitalaudit.presentation.startinspection.startpage.adapter

import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import com.bumptech.glide.Glide
import com.pertamina.digitalaudit.R
import com.pertamina.digitalaudit.model.startinspection.QuestionItem
import com.pertamina.digitalaudit.model.startinspection.ResponseListItem
import com.pertamina.digitalaudit.presentation.issues.helper.IssuesStatusViewHelper
import com.pertamina.digitalaudit.util.CommonConstant
import com.pertamina.digitalaudit.util.GridSpacingItemDecoration
import com.pertamina.framework.base.BaseRecyclerViewAdapter
import com.pertamina.framework.base.BaseViewHolder
import com.pertamina.framework.customview.DateTimePicker
import kotlinx.android.synthetic.main.item_inspection_question_date.view.*
import kotlinx.android.synthetic.main.item_inspection_question_location.view.*
import kotlinx.android.synthetic.main.item_inspection_question_multiple_choice.view.*
import kotlinx.android.synthetic.main.item_inspection_question_number.view.*
import kotlinx.android.synthetic.main.item_inspection_question_signature.view.*
import kotlinx.android.synthetic.main.item_inspection_question_text.view.*

class ListSectionQuestionAdapter : BaseRecyclerViewAdapter<QuestionItem>() {

    companion object {
        const val MULTIPLE_CHOICE_TYPE = 101
        const val FREE_TEXT_TYPE = 102
        const val NUMBER_TYPE = 103
        const val DATE_TYPE = 104
        const val LOCATION_TYPE = 105
        const val SIGNATURE_TYPE = 106
    }

    private var listener: ItemClickListener? = null

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BaseViewHolder<QuestionItem> {
        val inflater = LayoutInflater.from(parent.context)
        when (viewType) {
            MULTIPLE_CHOICE_TYPE -> {
                val view = inflater?.inflate(
                    R.layout.item_inspection_question_multiple_choice,
                    parent,
                    false
                )
                return MultipleChoiceViewHolder(parent.context, view!!, listener)
            }
            FREE_TEXT_TYPE -> {
                val view = inflater?.inflate(
                    R.layout.item_inspection_question_text,
                    parent,
                    false
                )
                return FreeTextViewHolder(parent.context, view!!, listener)
            }
            NUMBER_TYPE -> {
                val view = inflater?.inflate(
                    R.layout.item_inspection_question_number,
                    parent,
                    false
                )
                return NumberViewHolder(parent.context, view!!, listener)
            }
            DATE_TYPE -> {
                val view = inflater?.inflate(
                    R.layout.item_inspection_question_date,
                    parent,
                    false
                )
                return DateViewHolder(parent.context, view!!, listener)
            }
            LOCATION_TYPE -> {
                val view = inflater?.inflate(
                    R.layout.item_inspection_question_location,
                    parent,
                    false
                )
                return LocationViewHolder(parent.context, view!!, listener)
            }
            SIGNATURE_TYPE -> {
                val view = inflater?.inflate(
                    R.layout.item_inspection_question_signature,
                    parent,
                    false
                )
                return SignatureViewHolder(parent.context, view!!, listener)
            }
        }
        val view =
            inflater?.inflate(R.layout.item_inspection_question_text, parent, false)
        return FreeTextViewHolder(parent.context, view!!, listener)
    }

    override fun onBindViewHolder(
        holder: BaseViewHolder<QuestionItem>,
        position: Int
    ) {
        when (holder.itemViewType) {
            MULTIPLE_CHOICE_TYPE -> {
                val multipleChoiceViewHolder: MultipleChoiceViewHolder =
                    holder as MultipleChoiceViewHolder
                multipleChoiceViewHolder.bindData(getItem(position))
            }
            FREE_TEXT_TYPE -> {
                val freeTextViewHolder: FreeTextViewHolder =
                    holder as FreeTextViewHolder
                freeTextViewHolder.bindData(getItem(position))
            }
            NUMBER_TYPE -> {
                val numberViewHolder: NumberViewHolder =
                    holder as NumberViewHolder
                numberViewHolder.bindData(getItem(position))
            }
            DATE_TYPE -> {
                val dateViewHolder: DateViewHolder =
                    holder as DateViewHolder
                dateViewHolder.bindData(getItem(position))
            }
            LOCATION_TYPE -> {
                val locationViewHolder: LocationViewHolder =
                    holder as LocationViewHolder
                locationViewHolder.bindData(getItem(position))
            }
            SIGNATURE_TYPE -> {
                val signatureViewHolder: SignatureViewHolder =
                    holder as SignatureViewHolder
                signatureViewHolder.bindData(getItem(position))
            }
        }
    }


    override fun getItemViewType(position: Int): Int {
        return when (getItem(position).response?.responseId) {
            CommonConstant.RESPONSE_TYPE_MULTIPLE_CHOICE_ID -> {
                MULTIPLE_CHOICE_TYPE
            }
            CommonConstant.RESPONSE_TYPE_FREE_TEXT_ID -> {
                FREE_TEXT_TYPE
            }
            CommonConstant.RESPONSE_TYPE_NUMBER_ID -> {
                NUMBER_TYPE
            }
            CommonConstant.RESPONSE_TYPE_DATE_ID -> {
                DATE_TYPE
            }
            CommonConstant.RESPONSE_TYPE_LOCATION_ID -> {
                LOCATION_TYPE
            }
            CommonConstant.RESPONSE_TYPE_SIGNATURE_ID -> {
                SIGNATURE_TYPE
            }
            else -> {
                FREE_TEXT_TYPE
            }
        }
    }

    class MultipleChoiceViewHolder(
        context: Context,
        val view: View,
        listener: ItemClickListener?
    ) : BaseViewHolder<QuestionItem>(context, view) {

        private var holderListener: ItemClickListener? = listener
        private var tvCode = view.tvMcCode
        private var tvQuestion = view.tvMcQuestion
        private var rvMultipleChoices = view.rvMultipleChoices
        private var tvAddNote = view.tvMcAddNote
        private var tvAddAction = view.tvMcAddAction
        private var tvAddVoiceNote = view.tvMcAddVoiceNote
        private var tvAddVoiceNoteSelected = view.tvMcAddVoiceNoteSelected
        private var tvAddPicture = view.tvMcAddPicture
        private var tvAddPictureSelected = view.tvMcAddPictureSelected

        override fun bindData(data: QuestionItem) {
            val questionItem = data
            tvCode.text = data.code
            tvQuestion.text = data.question
            if (data.answer?.notes.isNullOrEmpty()){
                tvAddNote.text = "Add Note.."
                tvAddNote.setTextColor(ContextCompat.getColor(context, R.color.black))
            } else {
                tvAddNote.text = data.answer?.notes
                tvAddNote.setTextColor(ContextCompat.getColor(context, R.color.royal_blue))
            }

            if (data.isVoiceAttached) {
                tvAddVoiceNoteSelected.visibility = View.VISIBLE
                tvAddVoiceNote.visibility = View.INVISIBLE
            } else {
                tvAddVoiceNoteSelected.visibility = View.INVISIBLE
                tvAddVoiceNote.visibility = View.VISIBLE
            }

            if (data.isImageAttached) {
                tvAddPictureSelected.visibility = View.VISIBLE
                tvAddPicture.visibility = View.INVISIBLE
            } else {
                tvAddPictureSelected.visibility = View.INVISIBLE
                tvAddPicture.visibility = View.VISIBLE
            }
            val gridManager = GridLayoutManager(context, 2)
            val multipleChoiceAdapter = MultipleChoiceAdapter()
            multipleChoiceAdapter.setItemClickListener(object :
                MultipleChoiceAdapter.ItemClickListener {
                override fun onClickChoice(data: ResponseListItem, position: Int) {
                    val choice = multipleChoiceAdapter.getData()
                    choice.forEach {
                        it.isSelected = data.listId == it.listId
                    }
                    multipleChoiceAdapter.notifyItemChanged(position)
                    holderListener?.onClickChoice(questionItem.questionId ?: 0, data, adapterPosition)
                }
            })
            rvMultipleChoices.apply {
                layoutManager = gridManager
                setHasFixedSize(true)
                adapter = multipleChoiceAdapter
            }
            multipleChoiceAdapter.setData(data.response?.responseList ?: mutableListOf())

            tvAddNote.setOnClickListener {
                holderListener?.onAddNote(data)
            }
            tvAddAction.setOnClickListener {
                holderListener?.onAddAction(data)
            }
            tvAddVoiceNote.setOnClickListener {
                holderListener?.onAddVoiceNote(data)
            }
            tvAddVoiceNoteSelected.setOnClickListener {
                holderListener?.onAddVoiceNote(data)
            }
            tvAddPicture.setOnClickListener {
                holderListener?.onAddPicture(data)
            }
            tvAddPictureSelected.setOnClickListener {
                holderListener?.onAddPicture(data)
            }
        }
    }

    class FreeTextViewHolder(
        context: Context,
        val view: View,
        listener: ItemClickListener?
    ) : BaseViewHolder<QuestionItem>(context, view) {

        private var holderListener: ItemClickListener? = listener
        private var tvCode = view.tvTextCode
        private var tvQuestion = view.tvTextQuestion
        private var etFreeText = view.etFreeText
        private var tvAddNote = view.tvTextAddNote
        private var tvAddAction = view.tvTextAddAction
        private var tvAddVoiceNoteSelected = view.tvTextAddVoiceNoteSelected
        private var tvAddVoiceNote = view.tvTextAddVoiceNote
        private var tvAddPictureSelected = view.tvTextAddPictureSelected
        private var tvAddPicture = view.tvTextAddPicture

        override fun bindData(data: QuestionItem) {
            tvCode.text = data.code
            tvQuestion.text = data.question
            if (data.answer?.notes.isNullOrEmpty()){
                tvAddNote.text = "Add Note.."
                tvAddNote.setTextColor(ContextCompat.getColor(context, R.color.black))
            } else {
                tvAddNote.text = data.answer?.notes
                tvAddNote.setTextColor(ContextCompat.getColor(context, R.color.royal_blue))
            }
            if (data.isVoiceAttached) {
                tvAddVoiceNoteSelected.visibility = View.VISIBLE
                tvAddVoiceNote.visibility = View.INVISIBLE
            } else {
                tvAddVoiceNoteSelected.visibility = View.INVISIBLE
                tvAddVoiceNote.visibility = View.VISIBLE
            }
            if (data.isImageAttached) {
                tvAddPictureSelected.visibility = View.VISIBLE
                tvAddPicture.visibility = View.INVISIBLE
            } else {
                tvAddPictureSelected.visibility = View.INVISIBLE
                tvAddPicture.visibility = View.VISIBLE
            }
            data.answer?.let {
                etFreeText.setText(it.answerText.orEmpty())
            }
            etFreeText.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    holderListener?.onFreeTextChange(
                        s.toString(),
                        adapterPosition,
                        data.questionId ?: 0
                    )
                }

                override fun beforeTextChanged(
                    s: CharSequence?,
                    start: Int,
                    count: Int,
                    after: Int
                ) {
                }

                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                }
            })
            tvAddNote.setOnClickListener {
                holderListener?.onAddNote(data)
            }
            tvAddAction.setOnClickListener {
                holderListener?.onAddAction(data)
            }
            tvAddVoiceNoteSelected.setOnClickListener {
                holderListener?.onAddVoiceNote(data)
            }
            tvAddVoiceNote.setOnClickListener {
                holderListener?.onAddVoiceNote(data)
            }
            tvAddPictureSelected.setOnClickListener {
                holderListener?.onAddPicture(data)
            }
            tvAddPicture.setOnClickListener {
                holderListener?.onAddPicture(data)
            }
        }
    }

    class NumberViewHolder(
        context: Context,
        val view: View,
        listener: ItemClickListener?
    ) : BaseViewHolder<QuestionItem>(context, view) {

        private var holderListener: ItemClickListener? = listener
        private var tvCode = view.tvNumberCode
        private var tvQuestion = view.tvNumberQuestion
        private var etNumberText = view.etNumberText
        private var tvAddNote = view.tvNumberAddNote
        private var tvAddAction = view.tvNumberAddAction
        private var tvAddVoiceNoteSelected = view.tvNumberAddVoiceNoteSelected
        private var tvAddPictureSelected = view.tvNumberAddPictureSelected
        private var tvAddVoiceNote = view.tvNumberAddVoiceNote
        private var tvAddPicture = view.tvNumberAddPicture

        override fun bindData(data: QuestionItem) {
            tvCode.text = data.code
            tvQuestion.text = data.question
            if (data.answer?.notes.isNullOrEmpty()){
                tvAddNote.text = "Add Note.."
                tvAddNote.setTextColor(ContextCompat.getColor(context, R.color.black))
            } else {
                tvAddNote.text = data.answer?.notes
                tvAddNote.setTextColor(ContextCompat.getColor(context, R.color.royal_blue))
            }
            if (data.isVoiceAttached) {
                tvAddVoiceNoteSelected.visibility = View.VISIBLE
                tvAddVoiceNote.visibility = View.INVISIBLE
            } else {
                tvAddVoiceNoteSelected.visibility = View.INVISIBLE
                tvAddVoiceNote.visibility = View.VISIBLE
            }
            if (data.isImageAttached) {
                tvAddPictureSelected.visibility = View.VISIBLE
                tvAddPicture.visibility = View.INVISIBLE
            } else {
                tvAddPictureSelected.visibility = View.INVISIBLE
                tvAddPicture.visibility = View.VISIBLE
            }
            data.answer?.let {
                etNumberText.setText(it.answerText.orEmpty())
            }
            etNumberText.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    holderListener?.onNumberTextChange(
                        s.toString(),
                        adapterPosition,
                        data.questionId ?: 0
                    )
                }

                override fun beforeTextChanged(
                    s: CharSequence?,
                    start: Int,
                    count: Int,
                    after: Int
                ) {
                }

                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                }
            })
            tvAddNote.setOnClickListener {
                holderListener?.onAddNote(data)
            }
            tvAddAction.setOnClickListener {
                holderListener?.onAddAction(data)
            }
            tvAddVoiceNoteSelected.setOnClickListener {
                holderListener?.onAddVoiceNote(data)
            }
            tvAddVoiceNote.setOnClickListener {
                holderListener?.onAddVoiceNote(data)
            }
            tvAddPictureSelected.setOnClickListener {
                holderListener?.onAddPicture(data)
            }
            tvAddPicture.setOnClickListener {
                holderListener?.onAddPicture(data)
            }
        }
    }

    class DateViewHolder(
        context: Context,
        val view: View,
        listener: ItemClickListener?
    ) : BaseViewHolder<QuestionItem>(context, view) {

        private var holderListener: ItemClickListener? = listener
        private var tvCode = view.tvDateCode
        private var tvQuestion = view.tvDateQuestion
        private var etDateInput = view.etDateInput
        private var tvAddNote = view.tvDateAddNote
        private var tvAddAction = view.tvDateAddAction
        private var tvAddVoiceNote = view.tvDateAddVoiceNote
        private var tvAddPicture = view.tvDateAddPicture

        override fun bindData(data: QuestionItem) {
            tvCode.text = data.code
            tvQuestion.text = data.question
            data.answer?.let {
                etDateInput.setText(it.answerText.orEmpty())
            }
            etDateInput.setEventListener(object : DateTimePicker.OnGetDateListener {
                override fun onGetDate(date: String) {
                    holderListener?.onDateTextChange(date, adapterPosition, data.questionId ?: 0)
                }
            })
            tvAddNote.setOnClickListener {
                holderListener?.onAddNote(data)
            }
            tvAddAction.setOnClickListener {
                holderListener?.onAddAction(data)
            }
            tvAddVoiceNote.setOnClickListener {
                holderListener?.onAddVoiceNote(data)
            }
            tvAddPicture.setOnClickListener {
                holderListener?.onAddPicture(data)
            }
        }
    }

    class LocationViewHolder(
        context: Context,
        val view: View,
        listener: ItemClickListener?
    ) : BaseViewHolder<QuestionItem>(context, view) {

        private var holderListener: ItemClickListener? = listener
        private var tvCode = view.tvLocationCode
        private var tvQuestion = view.tvLocationQuestion
        private var etLocation = view.etLocation
        private var tvAddNote = view.tvLocationAddNote
        private var tvAddAction = view.tvLocationAddAction
        private var tvAddVoiceNote = view.tvLocationAddVoiceNote
        private var tvAddPicture = view.tvLocationAddPicture

        override fun bindData(data: QuestionItem) {
            tvCode.text = data.code
            tvQuestion.text = data.question
            data.answer?.let {
                etLocation.setText(it.answerText.orEmpty())
            }
            etLocation.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    holderListener?.onLocationTextChange(
                        s.toString(),
                        adapterPosition,
                        data.questionId ?: 0
                    )
                }

                override fun beforeTextChanged(
                    s: CharSequence?,
                    start: Int,
                    count: Int,
                    after: Int
                ) {
                }

                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                }
            })
            tvAddNote.setOnClickListener {
                holderListener?.onAddNote(data)
            }
            tvAddAction.setOnClickListener {
                holderListener?.onAddAction(data)
            }
            tvAddVoiceNote.setOnClickListener {
                holderListener?.onAddVoiceNote(data)
            }
            tvAddPicture.setOnClickListener {
                holderListener?.onAddPicture(data)
            }
        }
    }

    class SignatureViewHolder(
        context: Context,
        val view: View,
        listener: ItemClickListener?
    ) : BaseViewHolder<QuestionItem>(context, view) {

        private var holderListener: ItemClickListener? = listener
        private var tvCode = view.tvSignatureCode
        private var tvQuestion = view.tvSignatureQuestion
        private var etSignatureName = view.etSignatureName
        private var ivAddSignature = view.ivAddSignature
        private var ivSignature = view.ivSignature
        private var tvAddNote = view.tvSignatureAddNote
        private var tvAddAction = view.tvSignatureAddAction
        private var tvAddVoiceNote = view.tvSignatureAddVoiceNote
        private var tvAddPicture = view.tvSignatureAddPicture

        override fun bindData(data: QuestionItem) {
            tvCode.text = data.code
            tvQuestion.text = data.question
            data.answer?.let {
                etSignatureName.setText(it.answerText.orEmpty())
            }
            etSignatureName.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    holderListener?.onSignatureNameTextChange(
                        s.toString(),
                        adapterPosition,
                        data.questionId ?: 0
                    )
                }

                override fun beforeTextChanged(
                    s: CharSequence?,
                    start: Int,
                    count: Int,
                    after: Int
                ) {
                }

                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                }
            })
            ivAddSignature.setOnClickListener {
                //todo scratch signature
            }
            Glide.with(context).load("") //todo url signature
                .into(ivSignature)
            tvAddNote.setOnClickListener {
                holderListener?.onAddNote(data)
            }
            tvAddAction.setOnClickListener {
                holderListener?.onAddAction(data)
            }
            tvAddVoiceNote.setOnClickListener {
                holderListener?.onAddVoiceNote(data)
            }
            tvAddPicture.setOnClickListener {
                holderListener?.onAddPicture(data)
            }
        }
    }

    fun setItemClickListener(listener: ItemClickListener) {
        this.listener = listener
    }

    interface ItemClickListener {
        fun onAddNote(data: QuestionItem)
        fun onAddAction(data: QuestionItem)
        fun onAddVoiceNote(data: QuestionItem)
        fun onAddPicture(data: QuestionItem)
        fun onClickChoice(questionId: Int, data: ResponseListItem, position: Int)
        fun onFreeTextChange(answerText: String, position: Int, questionId: Int)
        fun onNumberTextChange(answerText: String, position: Int, questionId: Int)
        fun onDateTextChange(answerText: String, position: Int, questionId: Int)
        fun onLocationTextChange(answerText: String, position: Int, questionId: Int)
        fun onSignatureNameTextChange(answerText: String, position: Int, questionId: Int)
    }
}