package com.pertamina.digitalaudit.model.startinspection

import com.google.gson.annotations.SerializedName

data class InspectionAddInfoResponse(

    @field:SerializedName("Result")
    val data: InspectionInfo? = null
)