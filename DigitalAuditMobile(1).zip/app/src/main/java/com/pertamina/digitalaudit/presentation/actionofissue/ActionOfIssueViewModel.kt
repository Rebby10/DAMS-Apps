package com.pertamina.digitalaudit.presentation.actionofissue

import androidx.lifecycle.MutableLiveData
import com.pertamina.digitalaudit.model.ActionModel
import com.pertamina.digitalaudit.model.query.GetActionQuery
import com.pertamina.digitalaudit.repository.actions.ActionsRepository
import com.pertamina.framework.base.BaseViewModel
import com.pertamina.framework.base.Resource
import kotlinx.coroutines.launch

class ActionOfIssueViewModel(
    private val actionsRepository: ActionsRepository
) : BaseViewModel() {

    val showProgressBar = MutableLiveData(false)
    val isLoading = MutableLiveData(false)
    val showEmptyState = MutableLiveData(false)

    val actionOfIssueResponse = MutableLiveData<Resource<List<ActionModel.Action>>>()

    var issueId = ""

    fun getActionOfIssue() {
        val reqBody = GetActionQuery()
        reqBody.issueId = issueId
        isLoading.value = true
        launch {
            val request = actionsRepository.getActionList(reqBody)
            actionOfIssueResponse.value = request
            isLoading.value = false
        }
    }
}