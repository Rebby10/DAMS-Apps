package com.pertamina.audiorecorder

interface MediaPlayListener {
    fun onStartMedia()
    fun onMediaCompleted()
}