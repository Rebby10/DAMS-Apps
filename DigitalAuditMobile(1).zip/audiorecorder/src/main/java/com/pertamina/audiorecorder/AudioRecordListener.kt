package com.pertamina.audiorecorder

interface AudioRecordListener {
    fun onAudioReady(audioUri: String?)
    fun onRecordFailed(errorMessage: String?)
    fun onReadyForRecord()
}