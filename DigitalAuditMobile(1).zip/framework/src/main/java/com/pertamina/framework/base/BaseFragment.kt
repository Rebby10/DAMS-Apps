package com.pertamina.framework.base

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.fragment.app.Fragment
import com.google.android.material.snackbar.Snackbar
import com.pertamina.framework.R
import com.pertamina.framework.ViewDataBindingOwner
import com.pertamina.framework.BR

/**
 * @author asadurrahman.qayyim
 * @date 24-Feb-21
 */

abstract class BaseFragment<VM : BaseViewModel> : Fragment() {

    abstract val layoutResourceId: Int
    abstract val viewModel: VM

    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        return getLayoutIfDefined(inflater, container)
    }

    private fun getLayoutIfDefined(inflater: LayoutInflater, container: ViewGroup?): View? {
        if (this is ViewDataBindingOwner<*>) {
            val view = inflateContentViewBinding(inflater, container, layoutResourceId)
            binding?.setVariable(BR.vm, viewModel)
            binding?.lifecycleOwner = this
            if (this is BaseView) {
                binding?.setVariable(BR.view, this)
            }

            return view
        } else {
            return inflater.inflate(layoutResourceId, container, false)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        if (this is ViewDataBindingOwner<*>) {
            clearDataBinding()
        }
    }

    fun CoordinatorLayout?.showSnackBarDefault(message: String) {
        this ?: return
        val snackBar = Snackbar.make(this, message, Snackbar.LENGTH_SHORT)
        val textView = snackBar.view.findViewById<TextView>(R.id.snackbar_text)
        //textView.typeface = FontUtil.REGULAR()
        snackBar.show()
    }

    fun checkIfFragmentNotAttachToActivity(): Boolean {
        return !isAdded || isDetached || activity == null
    }

    fun logout(intent: Intent){
        startActivity(intent)
        activity?.finish()
    }
}