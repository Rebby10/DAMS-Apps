package com.pertamina.framework.base

import androidx.recyclerview.widget.RecyclerView

/**
 * @author asadurrahman.qayyim
 * @date 24-Feb-21
 */

abstract class BaseRecyclerViewAdapter<T>() : RecyclerView.Adapter<BaseViewHolder<T>>() {
    private var data: MutableList<T> = ArrayList()

    fun setData(data: List<T>) {
        this.data.clear()
        this.data.addAll(data as MutableList<T>)
        notifyDataSetChanged()
    }

    fun updateDataByPosition(data: T, position: Int) {
        this.data[position] = data
        notifyItemChanged(position)
    }

    fun removeAllData() {
        this.data.clear()
        notifyDataSetChanged()
    }

    fun removeData(index: Int) {
        this.data.removeAt(index)
        notifyDataSetChanged()
    }

    fun getData():MutableList<T>{
        return this.data
    }

    fun addData(data: List<T>){
        this.data.addAll(data)
        notifyDataSetChanged()
    }

    fun getItem(position: Int): T {
        return data[position]
    }

    override fun getItemCount(): Int = data.size

    override fun onBindViewHolder(holder: BaseViewHolder<T>, position: Int) {
        holder.bindData(getItem(position))
    }
}