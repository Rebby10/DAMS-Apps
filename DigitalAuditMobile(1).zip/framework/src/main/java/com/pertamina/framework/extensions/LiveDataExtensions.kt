package com.pertamina.framework.extensions

import androidx.lifecycle.MutableLiveData
import com.pertamina.framework.NetworkState
import com.pertamina.framework.base.Resource

/**
 * @author asadurrahman.qayyim
 * @date 24-Feb-21
 */

//fun <T> MutableLiveData<Resource<T>>.setData(data: Resource<T>) {
//    value = data
//}
//
//fun <T> MutableLiveData<Resource<T>>.setUpdate(data: T) {
//    value = Resource(NetworkState.UPDATED, -1, data, "")
//}
//
//fun <T> MutableLiveData<Resource<T>>.setLoading() {
//    value = Resource(NetworkState.LOADING, -1, null, "")
//}
//
//fun <T> MutableLiveData<Resource<T>>.setEmpty() {
//    value = Resource(NetworkState.LOADING, -1, null, "")
//}
//
//fun <T> MutableLiveData<Resource<T>>.setError(message: Exception? = null, data: T? = null) {
//    value = Resource(NetworkState.ERROR,-1,  data, "")
//}
//
//fun <T> MutableLiveData<T>.update(actions: (MutableLiveData<T>) -> Unit) {
//    actions(this)
//    this.value = this.value
//}
