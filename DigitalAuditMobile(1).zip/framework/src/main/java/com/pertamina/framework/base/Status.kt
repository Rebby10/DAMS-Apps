package com.pertamina.framework.base

enum class Status {
    SUCCESS,
    ERROR
}
