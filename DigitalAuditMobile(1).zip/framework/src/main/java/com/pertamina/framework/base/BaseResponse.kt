package com.pertamina.framework.base

import com.google.gson.annotations.SerializedName

/**
 * @author asadurrahman.qayyim
 * @date 24-Feb-21
 */

open class BaseResponse {
    @SerializedName("IsSuccess")
    var isSuccess: Boolean = false

    @SerializedName("Message")
    var message: String? = ""

}
