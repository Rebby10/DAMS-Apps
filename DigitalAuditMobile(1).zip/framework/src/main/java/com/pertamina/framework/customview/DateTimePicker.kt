package com.pertamina.framework.customview

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.EditText
import androidx.appcompat.widget.AppCompatEditText
import com.pertamina.framework.R
import com.pertamina.framework.util.DateHelper
import com.pertamina.framework.util.DateHelper.HH_mm
import com.pertamina.framework.util.DateHelper.HH_mm_ss
import com.pertamina.framework.util.DateHelper.d_M_yyyy
import com.pertamina.framework.util.DateHelper.d_M_yyyy_hh_mm_ss
import com.pertamina.framework.util.DateHelper.yyyy_MM_dd_T_HHmmss
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*

/**
 * @author Asadurrahman Al Qayyim
 * @date 3/30/2021
 */

class DateTimePicker : AppCompatEditText, View.OnClickListener {
    var viewType = 0
    var formatDate = "dd-MM-yyyy"
    var isMinimumCurrentDate = false
    var isMaximumCurrentDate = false
    var ctx: Context
    var locale = Locale("id", "ID")
    private lateinit var onGetDateLister: OnGetDateListener

    constructor(context: Context) : super(context) {
        this.ctx = context
        super.setOnClickListener(this)
        super.setFocusable(false)
    }

    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
        val a = context.obtainStyledAttributes(attrs, R.styleable.DateTimePicker)
        viewType = a.getInteger(R.styleable.DateTimePicker_viewtype, 0)
        isMinimumCurrentDate = a.getBoolean(R.styleable.DateTimePicker_isminimumcurrentdate, false)
        isMaximumCurrentDate = a.getBoolean(R.styleable.DateTimePicker_ismaximumcurrentdate, false)
        a.getString(R.styleable.DateTimePicker_formatdate)?.let {
            formatDate = it
        }
        a.recycle()
        this.ctx = context
        super.setOnClickListener(this)
        super.setFocusable(false)
    }

    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    ) {
        val a = context.obtainStyledAttributes(attrs, R.styleable.DateTimePicker)
        viewType = a.getInteger(R.styleable.DateTimePicker_viewtype, 0)
        a.recycle()
        this.ctx = context
        super.setOnClickListener(this)
        super.setFocusable(false)
    }

    override fun onClick(v: View) {
        val calendar = Calendar.getInstance()
        val mYear = calendar[Calendar.YEAR]
        val mMonth = calendar[Calendar.MONTH]
        val mDay = calendar[Calendar.DAY_OF_MONTH]
        val hour = calendar[Calendar.HOUR_OF_DAY]
        val minute = calendar[Calendar.MINUTE]
        when (viewType) {
            1 -> {
                val datePickerDialog = DatePickerDialog(context, { _, year, month1, day ->
                    var month = month1
                    month++
                    val finalMonth = month
                    val dateTime = StringBuilder().append(day).append("-")
                        .append(finalMonth).append("-").append(year).toString()
                    try {
                        val txtDate =
                            DateHelper.changeFormat(dateTime, d_M_yyyy, formatDate, locale)
                        val dateTest =
                            DateHelper.changeFormat(dateTime, d_M_yyyy, yyyy_MM_dd_T_HHmmss)
                        onGetDateLister.onGetDate(dateTest)
                        (v as EditText).setText(txtDate)
                    } catch (e: ParseException) {
                        e.printStackTrace()
                    }
                }, mYear, mMonth, mDay)
                if (isMinimumCurrentDate) {
                    datePickerDialog.datePicker.minDate = System.currentTimeMillis() - 1000
                }
                if (isMaximumCurrentDate) {
                    datePickerDialog.datePicker.maxDate = System.currentTimeMillis() - 1000
                }
                datePickerDialog.show()
            }
            2 -> {
                val timePickerDialog = TimePickerDialog(context, { view, hourOfDay, minute1 ->
                    val dateTime =
                        StringBuilder().append(hourOfDay).append(":").append(minute1).append(":00")
                            .toString()
                    try {
                        val txtDateTime = DateHelper.changeFormat(dateTime, HH_mm_ss, HH_mm, locale)
                        onGetDateLister.onGetDate(txtDateTime)
                        (v as EditText).setText(txtDateTime)
                    } catch (e: ParseException) {
                        e.printStackTrace()
                    }
                }, hour, minute, true)
                timePickerDialog.show()
            }
            else -> {
                val datePickerDialog = DatePickerDialog(context, { _, year, month1, day ->
                    var month = month1
                    month++
                    val finalMonth = month
                    val timePickerDialog = TimePickerDialog(context, { view, hourOfDay, minute1 ->
                        val dateTime = StringBuilder().append(day).append("-").append(finalMonth)
                            .append("-").append(year).append(" ").append(hourOfDay)
                            .append(":").append(minute1).append(":00").toString()
                        try {
                            val txtDateTime = DateHelper.changeFormat(
                                dateTime,
                                d_M_yyyy_hh_mm_ss,
                                "$formatDate, HH:mm",
                                locale
                            )
                            val dateTimeFormat = DateHelper.changeFormat(
                                dateTime,
                                d_M_yyyy_hh_mm_ss,
                                yyyy_MM_dd_T_HHmmss
                            )
                            onGetDateLister.onGetDate(dateTimeFormat)
                            (v as EditText).setText(txtDateTime)
                        } catch (e: ParseException) {
                            e.printStackTrace()
                        }
                    }, hour, minute, true)
                    timePickerDialog.show()
                }, mYear, mMonth, mDay)
                if (isMinimumCurrentDate) {
                    datePickerDialog.datePicker.minDate = System.currentTimeMillis() - 1000
                }
                if (isMaximumCurrentDate) {
                    datePickerDialog.datePicker.maxDate = System.currentTimeMillis() - 1000
                }
                datePickerDialog.show()
            }
        }
    }

    @Throws(ParseException::class)
    fun getDate(resultFormat: String?): String? {
        var existingFormat = "dd-MM-yyyy HH:mm:ss"
        if (viewType == 1) {
            existingFormat = "dd-MM-yyyy"
        } else if (viewType == 2) {
            existingFormat = "HH:mm:ss"
        }
        val date = SimpleDateFormat(existingFormat, locale).parse(this.text.toString())
        date?.let {
            return SimpleDateFormat(resultFormat, locale).format(it)
        } ?: return null
    }

    @Throws(ParseException::class)
    fun getDate(): Date? {
        var existingFormat = "dd-MM-yyyy HH:mm:ss"
        if (viewType == 1) {
            existingFormat = "dd-MM-yyyy"
        } else if (viewType == 2) {
            existingFormat = "HH:mm:ss"
        }
        return SimpleDateFormat(existingFormat, Locale.ENGLISH).parse(this.text.toString())
    }

    override fun setOnClickListener(l: OnClickListener?) {
        super.setOnClickListener(l)
    }

    fun setFormat(f: Int) {
        viewType = f
    }

    fun getFormat(): Int {
        return viewType
    }

    fun setEventListener(onGetDateListener: OnGetDateListener) {
        this.onGetDateLister = onGetDateListener
    }

    interface OnGetDateListener {
        fun onGetDate(date: String)
    }
}
