package com.pertamina.framework.base

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import androidx.annotation.DrawableRes
import androidx.appcompat.app.AppCompatActivity
import com.pertamina.framework.BR
import com.pertamina.framework.ViewDataBindingOwner
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/**
 * @author asadurrahman.qayyim
 * @date 24-Feb-21
 */
abstract class BaseActivity<VM : BaseViewModel> : AppCompatActivity() {

    abstract val layoutResourceId: Int
    abstract val viewModel: VM

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        setLayoutIfDefined()
    }

    private fun setLayoutIfDefined() {
        if (this is ViewDataBindingOwner<*>) {
            setContentViewBinding(this, layoutResourceId)
            binding?.setVariable(BR.vm, viewModel)
            binding?.lifecycleOwner = this
            if (this is BaseView) {
                binding?.setVariable(BR.view, this)
            }
        } else {
            setContentView(layoutResourceId)
        }
    }


    override fun onDestroy() {
        super.onDestroy()
        if (this is ViewDataBindingOwner<*>) {
            clearDataBinding()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        item.itemId.let {
            if (it == android.R.id.home)
                onToolBarBackButtonPressed()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    protected open fun onToolBarBackButtonPressed() {
        finish()
    }

    protected fun setHomeAsUpIndicator(@DrawableRes resId: Int) {
        supportActionBar?.setHomeAsUpIndicator(resId)
    }

    protected fun checkIfActivityFinished(): Boolean {
        return isFinishing ||
                isDestroyed
    }

    fun logout(intent: Intent) {
        startActivity(intent)
        finish()
    }

    fun copy(source: File, destination: File) {
        val fileIn = FileInputStream(source).channel
        val fileOut = FileOutputStream(destination).channel
        try {
            fileIn.transferTo(0, fileIn.size(), fileOut)
        } catch (exception: Exception) {
            Log.i("FileCopyException", exception.toString())
        } finally {
            fileIn?.close()
            fileOut?.close()
        }
    }
}