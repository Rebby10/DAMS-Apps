package com.pertamina.framework.customview

import android.content.Context
import android.os.Bundle
import android.view.View
import androidx.annotation.StyleRes
import com.google.android.material.bottomsheet.BottomSheetDialog

/**
 * Created by M Hafidh Abdul Aziz on 13/03/21.
 */

abstract class BaseBottomSheet : BottomSheetDialog {

    constructor(context: Context) : super(context)

    constructor(context: Context, @StyleRes styleId: Int) : super(context, styleId)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        customBottomSheetView()
    }

    protected fun createBottomSheetView(layout: Int) {
        val bottomSheetView = layoutInflater.inflate(layout, null)
        setContentView(bottomSheetView)
        bottomSheetView(bottomSheetView)
    }

    protected abstract fun customBottomSheetView()
    protected abstract fun bottomSheetView(view: View)

}