package com.pertamina.framework.base

import android.content.Context
import android.view.View
import androidx.recyclerview.widget.RecyclerView

/**
 * @author asadurrahman.qayyim
 * @date 24-Feb-21
 */

abstract class BaseViewHolder<T>(val context: Context, view: View) : RecyclerView.ViewHolder(view) {
    abstract fun bindData(data: T)
}