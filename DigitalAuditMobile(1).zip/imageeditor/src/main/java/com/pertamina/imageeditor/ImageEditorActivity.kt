package com.pertamina.imageeditor

import ja.burhanrashid52.photoeditor.PhotoEditor
import android.os.Bundle
import android.graphics.Bitmap
import android.annotation.SuppressLint
import android.content.Context
import ja.burhanrashid52.photoeditor.SaveSettings
import ja.burhanrashid52.photoeditor.PhotoEditor.OnSaveListener
import android.widget.Toast
import android.content.Intent
import android.net.Uri
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.pertamina.imageeditor.ImageCompressorAndRotator.Companion.handleSamplingAndRotationBitmap
import kotlinx.android.synthetic.main.activity_image_editor.*
import java.io.File
import java.io.IOException
import java.lang.Exception
import java.text.SimpleDateFormat
import java.util.*

class ImageEditorActivity : AppCompatActivity(), View.OnClickListener, StickerBSFragment.StickerListener {

    lateinit var colorPickerView: VerticalSlideColorPicker
    private var mPhotoEditor: PhotoEditor? = null
    private var mStickerBSFragment: StickerBSFragment? = null
    private var mSelectedColor = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_image_editor)
        mPhotoEditor = PhotoEditor.Builder(this, vPhotoEditorView)
            .setPinchTextScalable(true)
            .build()
        colorPickerView = findViewById(R.id.vColorPickerView)
        colorPickerView.setOnColorChangeListener(object: VerticalSlideColorPicker.OnColorChangeListener{
            override fun onColorChange(selectedColor: Int) {
                mSelectedColor = selectedColor
                if (colorPickerView.visibility == View.VISIBLE) {
                    ivPhotoEditPaint.setBackgroundColor(selectedColor)
                    mPhotoEditor?.brushColor = selectedColor
                }
            }
        })
        ivPhotoEditBack.setOnClickListener(this)
        ivPhotoEditUndo.setOnClickListener(this)
        ivPhotoEditRedo.setOnClickListener(this)
        ivPhotoEditCrop.setOnClickListener(this)
        ivPhotoEditStickers.setOnClickListener(this)
        ivPhotoEditText.setOnClickListener(this)
        ivPhotoEditPaint.setOnClickListener(this)
        fabPhotoDone.setOnClickListener(this)
        mStickerBSFragment = StickerBSFragment()
        mStickerBSFragment!!.setStickerListener(this)
        try {
            val intent = intent.getStringExtra("imageUri")
            if (intent != null){
                val imageUri = Uri.parse(intent)
                val compressedBitmap = handleSamplingAndRotationBitmap(this, imageUri)
                vPhotoEditorView.source.setImageBitmap(compressedBitmap)
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.ivPhotoEditBack -> finish()
            R.id.ivPhotoEditUndo -> mPhotoEditor!!.undo()
            R.id.ivPhotoEditRedo -> mPhotoEditor!!.redo()
            R.id.ivPhotoEditCrop -> {
            }
            R.id.ivPhotoEditStickers -> {
                ShowBrush(false)
                /**
                 * To Open Sticker Fragment
                 */
                mStickerBSFragment!!.show(supportFragmentManager, mStickerBSFragment!!.tag)
            }
            R.id.ivPhotoEditText -> {
                ShowBrush(false)
                /**
                 * To Open Edit Text Fragment
                 */
                val textEditorDialogFragment = TextEditorDialogFragment.show(this)
                textEditorDialogFragment.setOnTextEditorListener(object: TextEditorDialogFragment.TextEditor{
                    override fun onDone(inputText: String?, colorCode: Int) {
                        mPhotoEditor!!.addText(inputText, colorCode)
                    }
                })
            }
            R.id.ivPhotoEditPaint -> if (colorPickerView.visibility == View.VISIBLE) {
                ShowBrush(false)
            } else {
                ShowBrush(true)
            }
            R.id.fabPhotoDone -> saveImage()
        }
    }

    /**
     * method to add stickers
     *
     * @param bitmap-selected sticker image
     */
    override fun onStickerClick(bitmap: Bitmap?) {
        mPhotoEditor!!.addImage(bitmap)
    }

    /**
     * allow and not allow paint edit
     *
     * @param enableBrush -true ( show color picker and allowed to paint edit in image )
     * -false ( hide color picker and not allowed to paint edit in image
     */
    private fun ShowBrush(enableBrush: Boolean) {
        if (enableBrush) {
            mPhotoEditor!!.brushColor = mSelectedColor
            ivPhotoEditPaint.setBackgroundColor(mSelectedColor)
            mPhotoEditor!!.setBrushDrawingMode(true)
            colorPickerView.visibility = View.VISIBLE
        } else {
            ivPhotoEditPaint.setBackgroundColor(resources.getColor(android.R.color.transparent))
            mPhotoEditor!!.setBrushDrawingMode(false)
            colorPickerView.visibility = View.INVISIBLE
        }
    }

    /**
     * Method to save the edited image
     */
    @SuppressLint("MissingPermission")
    private fun saveImage() {
        /**
         * set the local path to store the edited image
         */
        val folder = getOutputDirectory()

        val file = File(
                folder,
                SimpleDateFormat(
                        FILENAME_FORMAT, Locale.US
                ).format(System.currentTimeMillis()) + ".jpg"
        )
        try {
            file.createNewFile()
            val saveSettings = SaveSettings.Builder()
                .setClearViewsEnabled(true)
                .setTransparencyEnabled(true)
                .build()
            mPhotoEditor!!.saveAsFile(file.absolutePath, saveSettings, object : OnSaveListener {
                override fun onSuccess(imagePath: String) {
                    Toast.makeText(this@ImageEditorActivity, "Image Saved Successfully", Toast.LENGTH_SHORT).show()
                    /**
                     * send result back to the ImagePickActivity
                     */
                    setResult(RESULT_OK, Intent().putExtra("imagePath", imagePath))
                    finish()
                }

                override fun onFailure(exception: Exception) {
                    Toast.makeText(this@ImageEditorActivity, "Failed to save Image", Toast.LENGTH_SHORT).show()
                }
            })
        } catch (e: IOException) {
            e.printStackTrace()
            Toast.makeText(this, e.message, Toast.LENGTH_SHORT).show()
        }
    }

    private fun getOutputDirectory(): File {
        val mediaDir = externalMediaDirs.firstOrNull()?.let {
            File(it, "Digital Audit").apply { mkdirs() }
        }
        return if (mediaDir != null && mediaDir.exists())
            mediaDir else filesDir
    }
    /*private fun getOutputDirectory(): File {
        val mediaDir = externalMediaDirs.firstOrNull()?.let {
            File(it, resources.getString(R.string.app_name)).apply { mkdirs() }
        }
        return if (mediaDir != null && mediaDir.exists())
            mediaDir else filesDir
    }*/

    companion object{
        const val FILENAME_FORMAT = "yyyy-MM-dd-HH-mm-ss-SSS"
    }
}